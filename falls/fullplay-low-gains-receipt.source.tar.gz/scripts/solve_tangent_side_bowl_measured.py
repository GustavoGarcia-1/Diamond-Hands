"""Offline physical cup IK fitted to finite ellipsoid tangent points, not infinite planes."""
import argparse,json
from pathlib import Path
import numpy as np,mujoco
from scipy.optimize import least_squares,brentq
from g1_receiver.aero import make_aero_scene
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
from g1_receiver.scrimmage_throw import ScrimmagePass

def main():
 p=argparse.ArgumentParser()
 for n in ['source','trial','profile','output','velocity-calibration']:p.add_argument('--'+n,type=Path,required=True)
 p.add_argument('--seeds',type=int,default=6);p.add_argument('--inward',type=float,default=.68);p.add_argument('--flight',type=float,default=.8);a=p.parse_args()
 m=mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT,a.source));d=mujoco.MjData(m);v=np.load(a.trial/'view.npz');q=v['qpos'][np.argmin(abs(v['timestamps_s']-5.2))];d.qpos[:]=m.qpos0;base=int(m.joint('floating_base_joint').qposadr[0]);d.qpos[:36]=q[:36];world_xy=q[:2].copy();d.qpos[:2]=0.;mujoco.mj_kinematics(m,d)
 donor=json.loads(a.profile.read_text());names=donor['static_lower_pose']['arm_order'];adr=np.array([m.joint(n).qposadr[0]for n in names]);mechanical=np.array([m.joint(n).range.copy()for n in names]);bounds=mechanical.copy();bounds[:,0]+=.03;bounds[:,1]-=.03
 for i,n in enumerate(names):
  if 'elbow'in n:bounds[i]=[.25,1.8]
 shoulder=np.mean([d.body(s+'_shoulder_pitch_link').xpos for s in ['left','right']],0);C0=np.array([.35,-.30,shoulder[2]+.02]);seedq=np.array(donor['static_lower_pose']['arm_targets_rad']);origin=np.array(donor['play']['quarterback_origin_m']);body_velocity=np.array(json.loads(a.velocity_calibration.read_text())['actual_per_hand_velocity_ols_mps']).mean(0);sides={s:[g for g in range(m.ngeom)if m.body(int(m.geom_bodyid[g])).name.startswith('aero_'+s+'_')and(m.geom_contype[g]or m.geom_conaffinity[g])]for s in ['left','right']};prox=[g for g in range(m.ngeom)if any(m.body(int(m.geom_bodyid[g])).name.startswith(s+'_'+part)for s in ['left','right']for part in ['shoulder_roll','shoulder_yaw','elbow','wrist'])and(m.geom_contype[g]or m.geom_conaffinity[g])];torso=[g for g in range(m.ngeom)if m.body(int(m.geom_bodyid[g])).name=='torso_link'and(m.geom_contype[g]or m.geom_conaffinity[g])];pairs=np.array([(i,j)for i in sides['left']for j in sides['right']]+[(i,j)for i in prox for j in torso],int);count_hand=len(sides['left'])*len(sides['right'])
 def desired(C):
  Cworld=C+np.r_[world_xy,0.];relative_xy=(Cworld[:2]-origin[:2])/a.flight-body_velocity[:2];e=np.r_[relative_xy/np.linalg.norm(relative_xy),0.];l=np.cross([0.,0.,1.],e);vz=(Cworld[2]-origin[2])/a.flight-4.905*a.flight-body_velocity[2];speed=np.linalg.norm(relative_xy);f=brentq(lambda f:f*speed+np.sqrt(1-a.inward*a.inward-f*f)*vz+.6,.01,np.sqrt(1-a.inward*a.inward-.60**2));nz=np.sqrt(1-a.inward*a.inward-f*f);N=np.array([f*e-a.inward*l+[0,0,nz],f*e+a.inward*l+[0,0,nz]]);F=(nz*e-[0,0,f])/np.sqrt(nz*nz+f*f);rot=[]
  for n,sign in zip(N,[1,-1]):Y=sign*n;rot.append(np.column_stack([np.cross(Y,F),Y,F]))
  plan=ScrimmagePass(tuple(origin),tuple(Cworld),a.flight,horizontal_distance_only=True).plan(5.2-a.flight);R=np.empty(9);mujoco.mju_quat2Mat(R,np.array(plan.release_quaternion_wxyz));R=R.reshape(3,3);A=R@np.diag(np.array([.142,.085,.085])**2)@R.T;vectors=(A@N.T).T;vectors/=np.sqrt(np.sum(vectors*N,1))[:,None];return C-vectors,N,F,rot,Cworld,f
 def geometry(q):
  d.qpos[adr]=q;mujoco.mj_kinematics(m,d);points=[];R=[]
  for side,sign in [('left',1),('right',-1)]:
   b=d.body('aero_'+side+'_palm');r=b.xmat.reshape(3,3).copy();points.append(b.xpos+r@np.array([-.0025,sign*.017,.07225]));R.append(r)
  lower=np.linalg.norm(d.geom_xpos[pairs[:,0]]-d.geom_xpos[pairs[:,1]],axis=1)-m.geom_rbound[pairs[:,0]]-m.geom_rbound[pairs[:,1]];distances=np.full(len(pairs),.05)
  for k in np.flatnonzero(lower<.006):i,j=pairs[k];distances[k]=mujoco.mj_geomDistance(m,d,int(i),int(j),.05,None)
  return np.array(points),R,distances
 def residual(x):
  target,N,F,R,Cworld,f=desired(x[14:]);points,actual,gaps=geometry(x[:14]);return np.r_[((points-target)/.006).ravel(),*((actual[i]-R[i]).ravel()/.12 for i in range(2)),np.maximum(0.,.006-gaps)/.0005,.04*(x[:14]-seedq),(x[14:]-C0)/.12]
 lo=np.r_[bounds[:,0]+1e-6,[.20,-.45,shoulder[2]-.04]];hi=np.r_[bounds[:,1]-1e-6,[.45,-.22,shoulder[2]+.12]];rng=np.random.default_rng(173);best=None
 for index in range(a.seeds):
  start=np.r_[seedq,C0]if index==0 else best.x+rng.normal(0,.12,17);start=np.clip(start,lo+1e-6,hi-1e-6);fit=least_squares(residual,start,bounds=(lo,hi),max_nfev=350)
  if best is None or np.linalg.norm(fit.fun)<np.linalg.norm(best.fun):best=fit
 points,R,gaps=geometry(best.x[:14]);target,N,F,_,Cworld,f=desired(best.x[14:]);actualN=np.array([R[0][:,1],-R[1][:,1]]);error=np.linalg.norm(points-target,axis=1);result=dict(static_only=True,physical_model_unchanged=True,actual_body_template=str(a.trial),body_template_time_s=5.2,measured_template_cup_velocity_mps=body_velocity.tolist(),flight_s=a.flight,predeclared=dict(position_error_max_m=.020,palm_up_min=.60,physical_joint_margin_min_rad=.03,proximal_and_interhand_clearance_min_m=.005,desired_per_hand_normal_velocity_mps=-.6),inward_normal_component=a.inward,forward_normal_component=f,arm_order=names,arm_targets_rad=best.x[:14].tolist(),ball_center_world_m=Cworld.tolist(),desired_face_relative_base_xy_m=target.tolist(),actual_face_relative_base_xy_m=points.tolist(),position_error_m=error.tolist(),desired_normals=N.tolist(),actual_normals=actualN.tolist(),finger_axis=F.tolist(),minimum_interhand_m=float(gaps[:count_hand].min()),minimum_proximal_torso_m=float(gaps[count_hand:].min()),feasible_static=bool(error.max()<=.02 and actualN[:,2].min()>=.6 and gaps.min()>=.005));a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
