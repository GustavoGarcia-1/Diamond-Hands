"""Offline two-palm ballistic calibration; never imported by a controller."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import mujoco
import numpy as np
from g1_receiver.hand_route_plant import HandRoutePlant
from g1_receiver.scrimmage_throw import ScrimmagePass


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('source', 'trials', 'profiles', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--cases', type=int, nargs='+', required=True)
    parser.add_argument('--arrival', type=float, default=4.72)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    plant = HandRoutePlant(args.source, hand_model='aero', survey_camera=False)
    candidates, cases = [], []
    try:
        for index in args.cases:
            directory = args.trials / f'case-{index:02d}'
            profile = json.loads((args.profiles / f'profile-{index:02d}.json').read_text())
            form = json.loads((directory / 'anatomical-form.json').read_text())
            motion = np.load(directory / 'trace.npz')['motion']
            selected = min(form, key=lambda row: abs(row['time_s'] - args.arrival))
            stamp = selected['time_s']
            normals = np.array(selected['metrics']['palm_normals_world'])
            def world_faces(row):
                pelvis = np.array([np.interp(row['time_s'], motion[:, 0], motion[:, i]) for i in (1, 2, 3)])
                return np.array(row['metrics']['palm_face_centers_relative_pelvis_m']) + pelvis
            faces = world_faces(selected)
            window = [row for row in form if stamp - .060001 <= row['time_s'] <= stamp + 1e-8]
            times = np.array([row['time_s'] for row in window])
            design = np.c_[np.ones(len(times)), times - times[-1]]
            velocity = np.linalg.lstsq(design, np.array([world_faces(row) for row in window]).reshape(len(window), 6), rcond=None)[0][1].reshape(2, 3)
            view = np.load(directory / 'view.npz')
            k = int(np.argmin(abs(view['timestamps_s'] - stamp)))
            plant.data.qpos[:] = view['qpos'][k]
            mujoco.mj_kinematics(plant.model, plant.data)
            rotations = [plant.data.body('aero_' + side + '_palm').xmat.reshape(3, 3).copy() for side in ('left', 'right')]
            origin = np.array(profile['play']['quarterback_origin_m'])
            donor_candidates = []
            for flight in np.arange(.80, 1.201, .05):
                flight = round(float(flight), 3)
                point = faces.mean(0) + .11 * normals.mean(0)
                for _ in range(40):
                    plan = ScrimmagePass(tuple(origin), tuple(point), flight, horizontal_distance_only=True).plan(args.arrival - flight)
                    rotation = np.empty(9)
                    mujoco.mju_quat2Mat(rotation, np.array(plan.release_quaternion_wxyz))
                    rotation = rotation.reshape(3, 3)
                    Q = rotation @ np.diag(np.array([.142, .085, .085]) ** 2) @ rotation.T
                    radii = np.sqrt(np.einsum('ij,jk,ik->i', normals, Q, normals))
                    support = (Q @ normals.T).T / radii[:, None]
                    seed = np.mean(faces + support, axis=0)
                    planes = np.einsum('ij,ij->i', normals, faces) + radii
                    updated = seed + normals.T @ np.linalg.solve(normals @ normals.T, planes - normals @ seed)
                    if np.linalg.norm(updated - point) < 1e-9:
                        point = updated
                        break
                    point = updated
                terminal = np.array(plan.release_velocity_mps) + np.array([0., 0., -9.81 * flight])
                incidence = np.einsum('ij,ij->i', terminal - velocity, normals)
                feet = point - support - faces
                local = np.array([R.T @ delta for R, delta in zip(rotations, feet)])
                tangent = np.linalg.norm(local[:, [0, 2]], axis=1)
                eligible = bool(np.all((incidence >= -1.5) & (incidence <= -.05)) and tangent.max() <= .06)
                row = dict(donor=index, flight_s=flight, target_m=point.tolist(),
                           relative_normal_velocity_mps=incidence.tolist(),
                           finite_palm_tangent_offset_m=tangent.tolist(), contact_offset_palm_local_m=local.tolist(),
                           plane_gap_m=(normals @ point - planes).tolist(), eligible=eligible)
                candidates.append(row)
                if eligible:
                    donor_candidates.append(row)
            if not donor_candidates:
                continue
            chosen = min(donor_candidates, key=lambda row: max(abs(np.array(row['relative_normal_velocity_mps']) + .5)))
            normal = normals.mean(0); normal /= np.linalg.norm(normal)
            for depth in (-.005, 0., .005):
                result = deepcopy(profile)
                target = np.array(chosen['target_m']) + depth * normal
                result['play'].update(flight_s=chosen['flight_s'], release_s=args.arrival - chosen['flight_s'],
                                      quarterback_target_m=target.tolist(), field_catch_window_m=target.tolist(),
                                      field_approach_axis_xy=[1., 0.], quarterback_horizontal_distance_only=True)
                result['offline_two_palm_fixture'] = dict(**chosen, normal_offset_m=depth,
                    calibration_time_s=stamp, faces_m=faces.tolist(), normals=normals.tolist(),
                    cup_velocity_mps=velocity.tolist(), runtime_truth_input=False)
                name = f'profile-{len(cases):02d}.json'
                (args.output / name).write_text(json.dumps(result, indent=2) + '\n')
                cases.append(dict(profile=name, donor=index, flight_s=chosen['flight_s'], normal_offset_m=depth,
                                  initial_yaw=-.48, finish_camera_x=7., pose_use_pass_camera=True, stem_yaw_gain=.3))
        (args.output / 'calibration-candidates.json').write_text(json.dumps(candidates, indent=2) + '\n')
        (args.output / 'protocol.json').write_text(json.dumps(dict(cases=cases,
            calibration_gate='Each normal velocity -1.5..-.05m/s; finite-face tangent offsets<=60mm; closest to-.5m/s per donor. Offline predicted only.',
            physical_acceptance='Unchanged anatomical v1 and separate running checks; near10yd means9.144±.25m; fullstem<=.5m.'), indent=2) + '\n')
        print(json.dumps(dict(selected_cases=cases, candidate_count=len(candidates)), indent=2))
    finally:
        plant.close()


if __name__ == '__main__':
    main()
