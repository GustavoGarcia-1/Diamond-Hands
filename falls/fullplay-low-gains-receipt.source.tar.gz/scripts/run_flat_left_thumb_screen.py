"""Narrow thumb roof/give screen; frozen finger success and throw unchanged."""
from pathlib import Path
from copy import deepcopy
from concurrent.futures import ProcessPoolExecutor,as_completed
import argparse,json,multiprocessing as mp,traceback
import probe_lower_cup_native_witness as runner
REFERENCE='173bf57168f5f97d0471d7bfa0a05e067a00f1e27a385994f57f21998a30af15'

def run(job):
 root,donor,source,amp,index,opposition,flex,delay=job;p=deepcopy(donor);cfg=p['native_grip'];cfg['preload']=cfg['preload']*2;cfg['capture']=cfg['capture']*2;cfg['digit_delay_s']=cfg['digit_delay_s']*2;cfg['preload'][4]=opposition/1.7453;cfg['preload'][5]=flex*.522105091;cfg['preload'][6]=flex*.658750409;cfg['digit_delay_s'][:7]=[.08]*4+[delay,.08,.08]
 path=root/f'profile-{index:02d}.json';path.write_text(json.dumps(p,indent=2)+'\n');trial=root/f'case-{index:02d}'
 try:
  args=runner.build_parser().parse_args(['--source',str(source),'--amp-source',str(amp),'--profile',str(path),'--output',str(trial),'--walk-speed','1','--handoff-depth','1.3','--initial-yaw','-.7','--duration','8','--record-anatomical','--reference-physics-sha256',REFERENCE]);r=runner.run(args);result=dict(case=index,preload_opposition_rad=opposition,preload_flex_legacy=flex,opposition_delay_s=delay,anatomical=r['anatomical_score'],self_geometry=r['interhand_geometry_audit'],host_gains_sha256=r['host_gains_sha256'])
 except BaseException as e:result=dict(case=index,error=repr(e),traceback=traceback.format_exc())
 (root/f'score-{index:02d}.json').write_text(json.dumps(result,indent=2)+'\n');return result

def main():
 p=argparse.ArgumentParser()
 for n in ['source','amp-source','profile','output']:p.add_argument('--'+n,type=Path,required=True)
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);donor=json.loads(a.profile.read_text());jobs=[]
 for opposition in (.7,.9,1.1):
  for flex in (0.,):
   for delay in (.16,.24):jobs.append((a.output,donor,a.source,a.amp_source,len(jobs),opposition,flex,delay))
 rows=[]
 with ProcessPoolExecutor(max_workers=2,mp_context=mp.get_context('spawn'))as pool:
  for future in as_completed([pool.submit(run,j)for j in jobs]):rows.append(future.result());(a.output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
if __name__=='__main__':main()
