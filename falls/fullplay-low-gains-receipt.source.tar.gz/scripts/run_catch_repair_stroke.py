"""Matched anchor then sensor-triggered vertical absorption; unchanged physics."""
import argparse
import json
from dataclasses import replace
from pathlib import Path
import numpy as np
from stable_baselines3 import PPO
import probe_catch_repair_stroke as runner
from g1_receiver.native_cup_residual_rl import NativeCupAudit, compare_reference, OBS_SCHEMA
from g1_receiver.repair_cup_absorption import VerticalCupStroke

REFERENCE = '173bf57168f5f97d0471d7bfa0a05e067a00f1e27a385994f57f21998a30af15'

class Combined:
    def __init__(self, profile, model, gain, travel, lead, latency=0., feedforward_fraction=0.):
        self.audit = NativeCupAudit(profile, policy=lambda x: model.predict(x, deterministic=True)[0]*np.float32(.5))
        self.stroke = VerticalCupStroke(profile, gain=gain, max_give_m=travel, lead_s=lead, deceleration_s=.12, recovery_s=.5, actuator_latency_s=latency)
        self.rows = []
        self.previous_total = np.zeros(14)
        self.last_now = None
        self.feedforward_fraction = feedforward_fraction
        self.previous_stroke = np.zeros(14)
        self.stroke_velocity = np.zeros(14)
        self.torque_rows = []

    def bind(self, model, names):
        self.audit.bind(model, names)
        self.stroke.bind(model, names)
        ids = [next(i for i in range(model.nu) if model.actuator_trnid[i, 0] == model.joint(names[j]).id)
               for j in self.audit.arms]
        self.effort_cap = np.min(abs(model.actuator_ctrlrange[ids]), axis=1)*self.feedforward_fraction

    def __call__(self, obs, pose, frame, survey, target, native, encoders, enabled):
        learned, changed = self.audit(obs, pose, frame, survey, target, native, encoders, enabled)
        moved, _ = self.stroke(obs, pose, frame, survey, learned, np.zeros(2), enabled)
        arms = self.audit.arms
        residual = np.clip(moved[arms]-target[arms], -.6, .6)
        now = float(obs.timestamp)
        dt = .02 if self.last_now is None else now-self.last_now
        if not 0. < dt <= .041:
            raise ValueError('combined residual requires a causal control clock')
        delta = residual-self.previous_total
        delta *= min(1., 4.2*dt/max(1e-12, float(abs(delta).max())))
        residual = self.previous_total+delta
        moved[arms] = np.clip(target[arms]+residual, *self.audit.ranges.T)
        residual = moved[arms]-target[arms]
        self.previous_total, self.last_now = residual.copy(), now
        applied_stroke = moved[arms]-learned[arms]
        self.stroke_velocity = (applied_stroke-self.previous_stroke)/dt
        self.previous_stroke = applied_stroke.copy()
        self.rows.append(dict(time_s=float(obs.timestamp), total_residual_rad=residual.tolist()))
        return moved, changed

    def command(self, command, now):
        if not self.feedforward_fraction:
            return command
        requested = command.kd[self.audit.arms]*self.stroke_velocity
        added = np.clip(requested, -self.effort_cap, self.effort_cap)
        self.torque_rows.append(dict(time_s=float(now), stroke_velocity_rad_s=self.stroke_velocity.tolist(),
                                    requested_feedforward_nm=requested.tolist(), added_feedforward_nm=added.tolist(),
                                    effort_cap_nm=self.effort_cap.tolist()))
        if not np.any(added):
            return command
        torque = command.feedforward_torque.copy()
        torque[self.audit.arms] += added
        return replace(command, feedforward_torque=torque)

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('source', 'amp-source', 'profile', 'model', 'output', 'reference'):
        p.add_argument('--'+name, type=Path, required=True)
    p.add_argument('--latency', type=float, default=0.)
    p.add_argument('--feedforward-screen', action='store_true')
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    model = PPO.load(a.model, device='cuda')
    assert model.receiver_sensor_schema == OBS_SCHEMA
    profile = json.loads(a.profile.read_text())
    configurations = [('anchor', 0., .12, .08), ('stroke25-04', .25, .12, .04),
                      ('stroke25-08', .25, .12, .08), ('stroke25-12', .25, .12, .12),
                      ('stroke50-04', .5, .18, .04), ('stroke50-08', .5, .18, .08),
                      ('stroke50-12', .5, .18, .12)]
    if a.latency:
        configurations = [('anchor', 0., .12, .12), ('latency10', .1, .12, .12),
                          ('latency25', .25, .12, .12), ('latency50', .5, .18, .12)]
    configurations = [(*row, 0.) for row in configurations]
    if a.feedforward_screen:
        configurations = [('anchor', 0., .12, .12, .5),
                          ('give25-cap25', .25, .12, .12, .25), ('give25-cap50', .25, .12, .12, .5),
                          ('give50-cap25', .5, .18, .12, .25), ('give50-cap50', .5, .18, .12, .5)]
    results = []
    for label, gain, travel, lead, feedforward_fraction in configurations:
        callback = Combined(profile, model, gain, travel, lead, a.latency, feedforward_fraction)
        out = a.output/label
        args = runner.build_parser().parse_args([
            '--source', str(a.source), '--amp-source', str(a.amp_source),
            '--profile', str(a.profile), '--output', str(out/'trial'),
            '--walk-speed', '1', '--handoff-depth', '1.3', '--initial-yaw', '-.7',
            '--duration', '9', '--record-anatomical', '--evaluation-record-robot-qpos',
            '--reference-physics-sha256', REFERENCE])
        args.sensor_retention_camera_position = (6., -2.5, 2.4)
        args.sensor_retention_camera_target = (7., 0., 1.)
        args.sensor_retention_pose_camera_position = (3.5, 0., 1.4)
        args.sensor_retention_pose_camera_target = (6.5, 0., .9)
        report = runner.run(args, native_residual_callback=callback)
        callback.audit.save(out, callback.audit.finish())
        (out/'stroke.json').write_text(json.dumps(callback.stroke.rows, indent=2)+'\n')
        (out/'combined-actions.json').write_text(json.dumps(callback.rows, indent=2)+'\n')
        (out/'feedforward.json').write_text(json.dumps(callback.torque_rows, indent=2)+'\n')
        if label == 'anchor':
            comparisons = {name: compare_reference(out/'trial'/name, a.reference/name)
                           for name in ('trace.npz', 'view.npz')}
            (out/'exact.json').write_text(json.dumps(comparisons, indent=2)+'\n')
            assert all(x['protected_reference_arrays_exact'] for x in comparisons.values()), 'anchor differs; abort candidates'
        row = dict(label=label, gain=gain, max_travel_m=travel, lead_s=lead, actuator_latency_s=a.latency,
                   feedforward_effort_fraction=feedforward_fraction,
                   anatomical=report['anatomical_score'], geometry=report['interhand_geometry_audit'],
                   host_gains_sha256=report['host_gains_sha256'])
        results.append(row)
        (a.output/'summary.json').write_text(json.dumps(results, indent=2)+'\n')
        print(json.dumps(row), flush=True)

if __name__ == '__main__':
    main()
