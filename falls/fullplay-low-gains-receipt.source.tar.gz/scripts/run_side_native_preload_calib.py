"""Genuine-miss native-ready calibration before changing any pass grip."""
from pathlib import Path
from copy import deepcopy
from concurrent.futures import ProcessPoolExecutor,as_completed
import argparse,json,multiprocessing as mp
import probe_lower_cup_side_clear as runner
REFERENCE='173bf57168f5f97d0471d7bfa0a05e067a00f1e27a385994f57f21998a30af15'
def run(job):
 root,donor,source,amp,index,preload=job;p=deepcopy(donor);p['native_grip']['preload'][:4]=[preload]*4;p['play']['quarterback_target_m'][1]+=5.;p['offline_evaluation_robot_qpos']=True;p['offline_dry_grasp_command_s']=5.02;profile=root/f'profile-{index:02d}.json';profile.write_text(json.dumps(p,indent=2)+'\n');out=root/f'case-{index:02d}';args=runner.build_parser().parse_args(['--source',str(source),'--amp-source',str(amp),'--profile',str(profile),'--output',str(out),'--walk-speed','1','--handoff-depth','1.3','--initial-yaw','-.7','--duration','7','--record-anatomical','--reference-physics-sha256',REFERENCE]);r=runner.run(args);return dict(case=index,normalized_native_finger_preload=preload,minimum_upright_cosine=r['minimum_upright_cosine'],self_geometry=r['interhand_geometry_audit'],host_gains_sha256=r['host_gains_sha256'],not_catch_evidence=True)
def main():
 p=argparse.ArgumentParser()
 for n in ['source','amp-source','profile','output']:p.add_argument('--'+n,type=Path,required=True)
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);donor=json.loads(a.profile.read_text());rows=[]
 with ProcessPoolExecutor(max_workers=2,mp_context=mp.get_context('spawn'))as pool:
  for f in as_completed([pool.submit(run,(a.output,donor,a.source,a.amp_source,i,c))for i,c in enumerate([0.,.3,.5,.7])]):rows.append(f.result());(a.output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
if __name__=='__main__':main()
