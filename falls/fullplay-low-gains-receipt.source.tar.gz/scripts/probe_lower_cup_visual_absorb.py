"""Protected native runner with an archived sensor-only aperture feedback trace."""
import json
import probe_lower_cup_native_confirm as runner
from probe_aero_amp_slant import OpticalPass
from evaluate_dextra_in_stride import RearMarkerLocalizer

class RecordedOpticalPass(OpticalPass):
 instances=[]
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs);self.instances.append(self)
  self.aperture_localizer=RearMarkerLocalizer(allow_synthetic_fixture=True,max_range_m=8.)
  self.aperture_receiver_history=[];self.aperture_pose_trace=[]
 def _update_aperture(self,plant,now,pose,poses,capture):
  if 'aperture_pose'in plant.cameras:
   measured=self.aperture_localizer.estimate(*plant.capture('aperture_pose'))
   self.aperture_pose_trace.append(dict(time_s=now,detected=measured is not None))
   if measured is None:return
   self.aperture_receiver_history=[*self.aperture_receiver_history[-6:],(measured.timestamp_s,*measured.xy_m)]
   pose,poses=measured,self.aperture_receiver_history
  super()._update_aperture(plant,now,pose,poses,capture)

def main():
 args=runner.build_parser().parse_args();runner.OpticalPass=RecordedOpticalPass
 profile=json.loads(args.profile.read_text())
 if 'aperture_pose_camera'in profile:
  original_make=runner.make_plant
  def make_plant(*positional,**keyword):
   keyword['extra_cameras']={'aperture_pose':profile['aperture_pose_camera']}
   return original_make(*positional,**keyword)
  runner.make_plant=make_plant
 runner.run(args)
 if len(RecordedOpticalPass.instances)!=1:raise RuntimeError('expected one optical pass')
 delivery=RecordedOpticalPass.instances[0]
 (args.output/'visual-aperture-trace.json').write_text(json.dumps(delivery.aperture_trace,indent=2,allow_nan=False)+'\n')
 (args.output/'aperture-pose-trace.json').write_text(json.dumps(delivery.aperture_pose_trace,indent=2)+'\n')
if __name__=='__main__':main()
