"""Read-only checkpoint quality watcher, separate from the running learner.

Every new checkpoint gets one CPU deterministic nominal trial. No result is fed
back to the learner, used for curriculum, or promoted automatically.
"""
import argparse,json,subprocess,sys,time,zipfile
from pathlib import Path

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for name in ('profile','source','amp-source','models-root','output'):p.add_argument('--'+name,type=Path,required=True)
 p.add_argument('--wall-seconds',type=float,default=3600);p.add_argument('--skip',nargs='*',default=[]);a=p.parse_args()
 if not 0<a.wall_seconds<=4200:p.error('wall seconds must be bounded <=4200')
 a.output.mkdir(parents=True,exist_ok=False);done=set(a.skip);started=time.monotonic();rows=[]
 while time.monotonic()-started<a.wall_seconds:
  paths=sorted(a.models_root.glob('checkpoint-*.zip'))
  if (a.models_root/'final.zip').exists():paths.append(a.models_root/'final.zip')
  for model in paths:
   if model.name in done:continue
   try:
    with zipfile.ZipFile(model)as archive:
     if archive.testzip()is not None:continue
   except (zipfile.BadZipFile,OSError):continue
   out=a.output/model.stem;command=[sys.executable,'scripts/evaluate_native_cup_checkpoints.py','--profile',str(a.profile),'--source',str(a.source),'--amp-source',str(a.amp_source),'--output',str(out),'--models',str(model),'--device','cpu']
   with(a.output/(model.stem+'.log')).open('w')as stream:
    result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
   row={'model':str(model),'inference_device':'cpu','exit_code':result.returncode,'elapsed_s':time.monotonic()-started}
   if result.returncode==0:
    full=json.loads((out/'summary.json').read_text())[0];score=full['anatomical'];row.update(model_sha256=full['model_sha256'],longest_bilateral_s=score['longest_clean_bilateral_s'],first_excluded_support_s=score['first_excluded_support_s'],maximum_ball_penetration_m=-score['minimum_ball_contact_distance_m'],quality=score['quality_checks'],realistic_lower_catch=score['realistic_lower_catch'])
   rows.append(row);done.add(model.name);(a.output/'watcher-summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
  if 'final.zip'in done:break
  time.sleep(20.)
if __name__=='__main__':main()
