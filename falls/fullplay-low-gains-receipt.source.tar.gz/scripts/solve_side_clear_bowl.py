"""Static independent-hand flat cup IK. No live controller or physics edits."""
from pathlib import Path
import argparse,json
import numpy as np,mujoco
from scipy.optimize import least_squares
from g1_receiver.aero import make_aero_scene
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
from g1_receiver._vendor.g1_runtime.pool.wbc import BODY_NAMES

def main():
 p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--forward',type=float,default=.3);p.add_argument('--torso-yaw',type=float,default=-.65);p.add_argument('--lateral',type=float,default=-.3);p.add_argument('--seeds',type=int,default=8);a=p.parse_args();assert 1<=a.seeds<=16
 m=mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT,a.source));d=mujoco.MjData(m);names=[f'{s}_{n}_joint'for s in ('left','right')for n in ('shoulder_roll','shoulder_yaw','shoulder_pitch','elbow','wrist_roll','wrist_pitch','wrist_yaw')];ids=np.array([m.joint(n).id for n in names]);adr=m.jnt_qposadr[ids];mechanical=m.jnt_range[ids].copy();bounds=mechanical.copy();bounds[:,0]+=.03;bounds[:,1]-=.03
 for i,n in enumerate(names):
  if 'elbow'in n:bounds[i]=[.25,1.8]
 base=int(m.joint('floating_base_joint').qposadr[0]);d.qpos[:]=m.qpos0;d.qpos[base:base+7]=[0,0,0,1,0,0,0];d.qpos[int(m.joint('waist_yaw_joint').qposadr[0])]=a.torso_yaw;mujoco.mj_kinematics(m,d);shoulder=np.mean([d.body(s+'_shoulder_pitch_link').xpos for s in ('left','right')],axis=0);faces=[np.array([-.0025,y,.07225])for y in [.017,-.017]]
 torso_geoms=[g for g in range(m.ngeom) if m.body(int(m.geom_bodyid[g])).name=='torso_link' and (m.geom_contype[g]or m.geom_conaffinity[g])]
 arm_geoms=[g for g in range(m.ngeom) if any(m.body(int(m.geom_bodyid[g])).name.startswith(side+'_'+part) for side in ('left','right') for part in ('shoulder_roll','shoulder_yaw','elbow','wrist')) and (m.geom_contype[g]or m.geom_conaffinity[g])]
 def arm_body_distances():return np.array([mujoco.mj_geomDistance(m,d,int(i),int(j),.05,None) for i in arm_geoms for j in torso_geoms])
 oldopen=json.loads(Path('reports/catch-form-20261114/lower-palms-up/static-ik-bent.json').read_text())['rows'][-1];oldclosed=json.loads(Path('reports/catch-form-20261114/lower-palms-up/static-wrap-30.json').read_text())['rows'][-1];rng=np.random.default_rng(173);rows=[]
 for nx in (0.,.1):
  nz=np.sqrt(1-nx*nx);F=np.array([nz,0.,-nx]);previous=None
  for mode,halfgap,inward in [('open',.075,np.pi/12),('closed',.07,np.pi/6)]:
   N=np.array([nx,0,nz]);normals=[np.cos(inward)*N+np.array([0,-np.sin(inward),0]),np.cos(inward)*N+np.array([0,np.sin(inward),0])];desired=[]
   for j,sign in enumerate([1,-1]):
    Y=sign*normals[j];desired.append(np.column_stack((np.cross(Y,F),Y,F)))
   target=np.array([[a.forward,a.lateral+halfgap,shoulder[2]-.08],[a.forward,a.lateral-halfgap,shoulder[2]-.08]])
   def geometry(q):
    d.qpos[adr]=q;mujoco.mj_kinematics(m,d);pos=[];rot=[]
    for s,off in zip(('left','right'),faces):
     b=d.body('aero_'+s+'_palm');R=b.xmat.reshape(3,3).copy();pos.append(b.xpos+R@off);rot.append(R)
    return np.array(pos),rot
   seedq=np.array(oldopen['arm_targets_rad']) if previous is None else previous.copy()
   def residual(q):
    c,R=geometry(q);return np.r_[((c-target)/.012).ravel(),*((R[j]-desired[j]).ravel()/.12 for j in range(2)),.005*(q-seedq),np.maximum(0.,.005-arm_body_distances())/.0002]
   best=None
   for seed in range(a.seeds):
    qstart=(seedq if seed==0 else previous if seed==1 and previous is not None else rng.uniform(bounds[:,0],bounds[:,1]));qstart=np.clip(qstart,bounds[:,0]+1e-6,bounds[:,1]-1e-6);fit=least_squares(residual,qstart,bounds=(bounds[:,0]+1e-6,bounds[:,1]-1e-6),max_nfev=350)
    if best is None or np.linalg.norm(fit.fun)<np.linalg.norm(best.fun):best=fit
   c,R=geometry(best.x);actualn=np.array([R[0][:,1],-R[1][:,1]]);actualf=np.array([r[:,2]for r in R]);errors=np.linalg.norm(c-target,axis=1);previous=best.x.copy();row=dict(torso_yaw_rad=a.torso_yaw,normal_forward_target=nx,mode=mode,forward_m=a.forward,target_faces_relative_pelvis_m=target.tolist(),actual_faces_relative_pelvis_m=c.tolist(),position_error_m=errors.tolist(),palm_up_cos=actualn[:,2].tolist(),normals=actualn.tolist(),finger_axes=actualf.tolist(),arm_order=names,arm_targets_rad=best.x.tolist(),minimum_proximal_arm_torso_m=float(arm_body_distances().min()),mechanical_joint_min_margin_rad=float(np.minimum(best.x-mechanical[:,0],mechanical[:,1]-best.x).min()),feasible_static=bool(arm_body_distances().min()>=.0049 and errors.max()<=.02 and actualn[:,2].min()>=.6 and np.abs(actualn[:,0]).max()<=.4 and actualf[:,0].min()>=.70 and actualf[:,2].max()<=.30 and actualf[:,2].min()>=-.45));rows.append(row);a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(dict(static_only=True,physical_model_unchanged=True,predeclared=dict(position_error_max_m=.02,palm_up_min=.6,normal_forward_abs_max=.4,finger_forward_min=.70,finger_up_max=.30,finger_up_min=-.45,mechanical_margin_min_rad=.03,elbow_range_rad=[.25,1.8],lateral_center_m=a.lateral,torso_yaw_rad=a.torso_yaw,outward_shoulder_constraint=False,minimum_proximal_arm_torso_m=.005,open_face_gap_m=.15,closed_face_gap_m=.14),rows=rows),indent=2)+'\n');print(json.dumps(row),flush=True)
if __name__=='__main__':main()
