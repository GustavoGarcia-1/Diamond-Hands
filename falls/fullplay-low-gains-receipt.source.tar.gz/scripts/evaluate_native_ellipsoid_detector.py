"""Isolated image-detector ablation with unchanged physics and frozen policies."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import numpy as np
from stable_baselines3 import PPO
from g1_receiver.native_cup_training import NativeCatchEnv
from g1_receiver.native_cup_continuation import CAMERAS, mutate_throw_only
from g1_receiver.perception import ColorBallDetector
from g1_receiver.ellipsoid_perception import EllipsoidBallDetector, ORIGINAL_COLOR_CANDIDATE


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('source','amp-source','profile','model','output'):
        p.add_argument('--'+name,type=Path,required=True)
    a = p.parse_args()
    a.output.mkdir(parents=True,exist_ok=False)
    model = PPO.load(a.model,device='cuda')
    assert sha256(a.model.read_bytes()).hexdigest() == 'fcd915e0578115ba300ca697744699a534d2d6896209f03b06474097cc91acc5'
    donor = json.loads(a.profile.read_text())
    fixtures = [('nominal',(0.,0.)),('y-minus',(-.02,0.)),('y-plus',(.02,0.)),('z-minus',(0.,-.02)),('z-plus',(0.,.02))]
    policies = [('zero',None,np.zeros(20,np.float32)),('learned-half',model,np.full(20,.5,np.float32)),
                ('learned-split',model,np.r_[np.full(14,.5),np.full(6,.1)].astype(np.float32))]
    protocol = dict(scope='Inference-only sensor ablation. Original nominal anchors then five fixed-plane fixtures for zero, learned-half and learned-split. No weights, contact material, actuator gains, quality thresholds or fixture inputs in control change.',
        detector='Image-only known-axisymmetric-shape center correction, with original fallback and positive-semidefinite uncertainty inflation. Applies to every ColorBallDetector consumer, including visual grip, selection and sensor audit.',
        inference_device='cuda',seed=173,training=False,
        limits='Offline fit latency measured separately; synchronous simulator calls do not establish ARM64 real-time readiness. Sensor reward values across detector definitions are not comparable evidence of learning.',
        quality='No promotion unless all unchanged physical criteria pass and independent reproduction supports it.')
    (a.output/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
    rows = []
    try:
        for mode in ('original','ellipsoid'):
            ColorBallDetector._candidate = ORIGINAL_COLOR_CANDIDATE if mode == 'original' else EllipsoidBallDetector._candidate
            for label,policy,gain in policies[:2] if mode == 'original' else policies:
                for fixture,delta in fixtures[:1] if mode == 'original' else fixtures:
                    out = a.output/mode/label/fixture
                    out.mkdir(parents=True)
                    profile = out/'profile.json'
                    profile.write_text(json.dumps(mutate_throw_only(donor,delta),indent=2)+'\n')
                    env = NativeCatchEnv(profile,a.source,a.amp_source,duration=9.,evaluation_dir=out/'rollout',**CAMERAS)
                    try:
                        obs,_ = env.reset(seed=173)
                        total = 0.
                        while True:
                            action = np.zeros(20,np.float32) if policy is None else policy.predict(obs,deterministic=True)[0]*gain
                            obs,reward,done,_,info = env.step(action)
                            total += reward
                            if done:
                                break
                        assert np.isclose(total,info['sensor_return'],atol=1e-9)
                        report = json.loads((out/'rollout/episode-0001/trial/report.json').read_text())
                        rows.append(dict(detector=mode,controller=label,fixture=fixture,delta_yz_m=delta,
                            action_gain=gain.tolist(),anatomical=report['anatomical_score'],sensor=info))
                        (a.output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
                        print(json.dumps(dict(detector=mode,controller=label,fixture=fixture,completed=len(rows))),flush=True)
                    finally:
                        env.close()
    finally:
        ColorBallDetector._candidate = ORIGINAL_COLOR_CANDIDATE


if __name__ == '__main__':
    main()
