"""Asymmetric right-arm wrap delay; native digit controls unchanged."""
from pathlib import Path
from copy import deepcopy
from concurrent.futures import ProcessPoolExecutor,as_completed
import argparse,json,multiprocessing as mp
import probe_lower_cup_native_witness as runner
REFERENCE='173bf57168f5f97d0471d7bfa0a05e067a00f1e27a385994f57f21998a30af15'

def run(job):
 root,source,amp,profile,index,delay=job;p=deepcopy(json.loads(profile.read_text()));original=p['play']['grasp_offsets_rad'];p['play']['grasp_offsets_rad']=original[:7]+[0.]*7;p['play']['hold_offsets_rad']=[0.]*7+original[7:];p['play']['hold_delay_s']=delay;p['play']['hold_ramp_s']=.12;path=root/f'profile-{index:02d}.json';path.write_text(json.dumps(p,indent=2)+'\n');args=runner.build_parser().parse_args(['--source',str(source),'--amp-source',str(amp),'--profile',str(path),'--output',str(root/f'case-{index:02d}'),'--walk-speed','1','--handoff-depth','1.3','--initial-yaw','-.7','--duration','9','--record-anatomical','--reference-physics-sha256',REFERENCE]);r=runner.run(args);return dict(case=index,flight_s=p['play']['flight_s'],right_arm_delay_s=delay,anatomical=r['anatomical_score'],geometry=r['interhand_geometry_audit'],host_gains_sha256=r['host_gains_sha256'])
def main():
 p=argparse.ArgumentParser()
 for n in ['source','amp-source','profiles','output']:p.add_argument('--'+n,type=Path,required=True)
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);jobs=[]
 for case in [2,4]:
  for delay in [.20,.26]:jobs.append((a.output,a.source,a.amp_source,a.profiles/f'profile-{case:02d}.json',len(jobs),delay))
 rows=[]
 with ProcessPoolExecutor(max_workers=2,mp_context=mp.get_context('spawn'))as pool:
  for f in as_completed([pool.submit(run,j)for j in jobs]):rows.append(f.result());(a.output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
if __name__=='__main__':main()
