import argparse,concurrent.futures,json,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();
for k in['root','profile','source','amp-source','output']:p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);base=json.loads(a.profile.read_text());jobs=[]
for label,opp in [('original-opposition',base['native_grip']['preload'][4]),('opposition-0.5',.5)]:
 profile=json.loads(json.dumps(base));profile['native_grip']['preload'][4]=opp;profile['native_grip']['preload'][5:7]=profile['native_grip']['capture'][5:7];path=a.output/(label+'-profile.json');path.write_text(json.dumps(profile,indent=2)+'\n');jobs.append((label,path))
def run(job):
 label,profile=job;cmd=[sys.executable,str(a.root/'scripts/probe_go_thumb_precurl_dry.py'),'--frozen-root',str(a.root),'--profile',str(profile),'--source',str(a.source),'--amp-source',str(a.amp_source),'--output',str(a.output/label)]
 with(a.output/(label+'.log')).open('w')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 return dict(label=label,profile=str(profile),command=cmd,exit_code=r.returncode)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:rows=list(pool.map(run,jobs))
(a.output/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
if any(r['exit_code']for r in rows):raise RuntimeError('failedcalibrationpreserved')
