"""No-pass actual-actuator calibration; fixed route command clock, no runtime pose injection."""
import argparse,sys,json,hashlib
from pathlib import Path
from types import SimpleNamespace
import numpy as np
p=argparse.ArgumentParser();
for k in ['frozen-root','profile','source','amp-source','output']:p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();sys.path[:0]=[str(a.frozen_root/'src'),str(a.frozen_root/'scripts')]
from g1_receiver.lower_cup_grip import NativeCupGrip
from g1_receiver.anatomical_catch_eval import AnatomicalContactAudit
from g1_receiver.hand_route_plant import HandRoutePlant
import probe_native_cup_residual as runner
orig=NativeCupGrip.targets;record=AnatomicalContactAudit.record;init=HandRoutePlant.__init__;poses=[];controls=[];ball_robot_contacts=[]
def targets(self,now,closure,release_at,gate,encoders):return orig(self,now,closure,3.6,None,encoders)
def plant_init(self,*args,**kwargs):
 init(self,*args,**kwargs);a.output.mkdir(parents=True,exist_ok=False);(a.output/'scene.xml').write_text(self.scene_xml)
def audit(self,data):
 record(self,data)
 if 4.9<=data.time<=5.5:poses.append(np.r_[data.time,data.qpos.copy()]);controls.append(np.r_[data.time,data.ctrl.copy()])
 for c in data.contact:
  g1,g2=map(int,c.geom)
  if self.ball not in(g1,g2):continue
  other=g2 if g1==self.ball else g1
  if self.model.geom_bodyid[other]>0:ball_robot_contacts.append(dict(time_s=float(data.time),geom=self.model.geom(other).name,distance_m=float(c.dist)))
NativeCupGrip.targets=targets;AnatomicalContactAudit.record=audit;HandRoutePlant.__init__=plant_init
args=SimpleNamespace(source=a.source,amp_source=a.amp_source,profile=a.profile,output=a.output/'trial',no_pass=True,walk_speed=1.,handoff_depth=1.3,initial_yaw=-.7,duration=5.5,record_anatomical=True,reference_physics_sha256='173bf57168f5f97d0471d7bfa0a05e067a00f1e27a385994f57f21998a30af15',sensor_retention_camera_position=None,sensor_retention_camera_target=None,sensor_retention_pose_camera_position=None,sensor_retention_pose_camera_target=None)
try:runner.run(args,native_residual_callback=None)
finally:NativeCupGrip.targets=orig;AnatomicalContactAudit.record=record;HandRoutePlant.__init__=init
np.savez_compressed(a.output/'offline-robot-qpos.npz',timestamps_s=np.asarray(poses)[:,0],qpos=np.asarray(poses)[:,1:]);np.savez_compressed(a.output/'actual-control.npz',time_control=np.asarray(controls));(a.output/'dry-calibration.json').write_text(json.dumps(dict(no_pass=True,catch_claim=False,native_only_command='preloadfromfixedroutecommand3.6s, no visualcapture',no_runtime_qpos_injection=True,zero_residual=True,physics_unchanged=True,ball_robot_contacts=ball_robot_contacts,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),profile_sha256=hashlib.sha256(a.profile.read_bytes()).hexdigest()),indent=2)+'\n')
