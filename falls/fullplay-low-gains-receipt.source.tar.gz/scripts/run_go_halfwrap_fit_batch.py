"""Two geometry-selected actual half-wrap trials, original model/frozen policy."""
import argparse,concurrent.futures,json,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();
for k in ['root','profile','model','source','amp-source','fit','output']:p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);base=json.loads(a.profile.read_text());fits=json.loads(a.fit.read_text())['results'];jobs=[]
for T,mode in [(1.6,'launch'),(.8,'level')]:
 fit=next(r for r in fits if r['scale']==.5 and r['flight_s']==T and r['mode']==mode);assert fit['success'];label=f'halfwrap-T{T}-{mode}';profile=json.loads(json.dumps(base));g=profile['native_grip'];g['preload'][4]=.5;g['preload'][5:7]=[1.,1.];g['capture'][5:7]=[1.,1.];profile['play']['grasp_offsets_rad']=[.5*x for x in profile['play']['grasp_offsets_rad']];profile['play'].update(flight_s=T,release_s=5.2-T,quarterback_target_m=fit['aim_m'],quarterback_level_ball=mode=='level');path=a.output/(label+'-profile.json');path.write_text(json.dumps(profile,indent=2)+'\n');jobs.append((label,path))
def run(job):
 label,profile=job;cmd=[sys.executable,str(a.root/'scripts/probe_ball_hand_contact_model.py'),'--frozen-root',str(a.root),'--profile',str(profile),'--model',str(a.model),'--source',str(a.source),'--amp-source',str(a.amp_source),'--output',str(a.output/label),'--timeconstant','.02','--unmodified','--gain','.5','--device','cuda']
 with(a.output/(label+'.log')).open('w')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 return dict(label=label,gain=.5,profile=str(profile),command=cmd,exit_code=r.returncode)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:rows=list(pool.map(run,jobs))
(a.output/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
if any(r['exit_code']for r in rows):raise RuntimeError('failedtrialspreserved')
