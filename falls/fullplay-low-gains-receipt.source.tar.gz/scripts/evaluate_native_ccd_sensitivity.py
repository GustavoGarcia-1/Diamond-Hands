"""Isolated whole-episode collision-algorithm sensitivity, never a controller patch."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import numpy as np
import mujoco
from stable_baselines3 import PPO
import probe_native_cup_residual as runner
import g1_receiver.anatomical_catch_eval as scoring
from g1_receiver.native_cup_training import NativeCatchEnv
from g1_receiver.native_cup_continuation import CAMERAS


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('source', 'amp-source', 'profile', 'model', 'output'):
        p.add_argument('--'+name, type=Path, required=True)
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    model = PPO.load(a.model, device='cuda')
    assert sha256(a.model.read_bytes()).hexdigest() == 'fcd915e0578115ba300ca697744699a534d2d6896209f03b06474097cc91acc5'
    original_fingerprint = scoring.physics_fingerprint
    original_run, original_factory = runner.run, runner.make_plant
    context = {}
    def extended_fingerprint(physical_model):
        result = original_fingerprint(physical_model)
        parameters = result['parameters']
        parameters['schema'] = 'anatomical-physics-model-v1-plus-ccd-v1'
        parameters['ccd_options'] = {name:float(getattr(physical_model.opt, name)) if name == 'ccd_tolerance'
            else int(getattr(physical_model.opt, name)) for name in ('disableflags', 'enableflags', 'ccd_iterations', 'ccd_tolerance')}
        result['sha256'] = sha256(json.dumps(parameters, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        return result
    def run(args, native_residual_callback=None):
        def factory(*positional, **keyword):
            plant = original_factory(*positional, **keyword)
            native_reference = extended_fingerprint(plant.model)
            legacy_before = original_fingerprint(plant.model)['sha256']
            args.reference_physics_sha256 = native_reference['sha256']
            if context['mode'] == 'legacy_mpr':
                plant.model.opt.disableflags |= int(mujoco.mjtDisableBit.mjDSBL_NATIVECCD)
            current = extended_fingerprint(plant.model)
            context['configuration'] = dict(mode=context['mode'], native_reference_sha256=native_reference['sha256'],
                actual_extended_sha256=current['sha256'], actual_ccd_options=current['parameters']['ccd_options'],
                legacy_v1_sha256=original_fingerprint(plant.model)['sha256'], legacy_v1_before=legacy_before,
                legacy_v1_omits_ccd=True, changed_before_any_physics_steps=True,
                native_reference_match=current['sha256'] == native_reference['sha256'])
            mujoco.mj_forward(plant.model, plant.data)
            return plant
        runner.make_plant = factory
        try:
            return original_run(args, native_residual_callback)
        finally:
            runner.make_plant = original_factory
    scoring.physics_fingerprint = extended_fingerprint
    runner.run = run
    protocol = dict(scope='Numerical collision-algorithm sensitivity only. Whole episode uses one fixed option set; no midplay changes. Geometry, masses, contact material, host gains and controller weights unchanged.',
        reference='Extended default-nativeCCD fingerprint is the reference for every trial. LegacyMPR must fail reference_physics_verified; no realistic-quality promotion.',
        observation_boundary='Options and contacts are not policy/reward inputs. Private sensor FK does not step physics.',
        model_sha256=sha256(a.model.read_bytes()).hexdigest(), seed=173, inference_device='cuda', action_gain=.5)
    (a.output/'protocol.json').write_text(json.dumps(protocol, indent=2)+'\n')
    rows = []
    try:
        for mode in ('native_ccd', 'legacy_mpr'):
            for label, policy in (('zero', None), ('learned', model)):
                context['mode'] = mode
                out = a.output/mode/label
                env = NativeCatchEnv(a.profile, a.source, a.amp_source, duration=9., evaluation_dir=out/'rollout', **CAMERAS)
                try:
                    obs, _ = env.reset(seed=173)
                    total = 0.
                    while True:
                        action = np.zeros(20, np.float32) if policy is None else policy.predict(obs, deterministic=True)[0]*np.float32(.5)
                        obs, reward, done, _, info = env.step(action)
                        total += reward
                        if done:
                            break
                    assert np.isclose(total, info['sensor_return'], atol=1e-9)
                    report = json.loads((out/'rollout/episode-0001/trial/report.json').read_text())
                    assert report['anatomical_score']['physics_reference_match'] == (mode == 'native_ccd')
                    rows.append(dict(mode=mode, controller=label, configuration=context['configuration'],
                        anatomical=report['anatomical_score'], sensor=info, returned_reward=total))
                    (a.output/'summary.json').write_text(json.dumps(rows, indent=2)+'\n')
                    print(json.dumps(dict(mode=mode, controller=label, completed=len(rows))), flush=True)
                finally:
                    env.close()
    finally:
        scoring.physics_fingerprint = original_fingerprint
        runner.run, runner.make_plant = original_run, original_factory


if __name__ == '__main__':
    main()
