"""Offline finite-pad proposal from actual precontact encoder pose; not an online input."""
import json,re
from pathlib import Path
import mujoco,numpy as np
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
P=Path('reports/catch-repair-20261114/go-side-cup');r=P/'open-inlet-linux/artifacts/study/experimental2p5-preload00';xml=re.sub(r'/workspace/g1-receiver-runs/[^" ]+/source/src/g1_receiver/_vendor/g1_runtime',str(DEFAULT_RUNTIME_ROOT),(r/'scene.xml').read_text()).replace('/workspace/g1-receiver-runs/out-scrimmage-20261113/source/aero-source','/tmp/g1-aero-source');m=mujoco.MjModel.from_xml_string(xml);d=mujoco.MjData(m);q=np.load(r/'actual-state.npz')['time_qpos'];k=np.argmin(abs(q[:,0]-5.209));d.qpos[:]=q[k,1:];mujoco.mj_kinematics(m,d);faces=[];norms=[];longs=[];widths=[]
for side in ['left','right']:
 g=m.geom('aero_'+side+'_palm_collision_7').id;F=d.geom_xmat[g].reshape(3,3);faces.append(d.geom_xpos[g]+m.geom_size[g,0]*F[:,0]);norms.append(F[:,0]);longs.append(F[:,2]);widths.append(F[:,1])
norms=np.array(norms);profile=json.load(open(P/'confirmed-thumb30-profile.json'));old=np.array(profile['play']['field_catch_window_m']);yaw=np.deg2rad(100);R=np.array([[np.cos(yaw),-np.sin(yaw),0],[np.sin(yaw),np.cos(yaw),0],[0,0,1.]]);shape=R@np.diag(np.array([.142,.085,.085])**2)@R.T;supports=[shape@n/np.sqrt(n@shape@n)for n in norms];rhs=np.array([n@(f+s)for n,f,s in zip(norms,faces,supports)]);center=old+norms.T@np.linalg.solve(norms@norms.T,rhs-norms@old);null=np.cross(*norms);null/=np.linalg.norm(null);coeff=[];low=-.05;high=.05
for f,s,w,l in zip(faces,supports,widths,longs):
 for axis,lim in[(w,.032),(l,.008)]:
  a=float(axis@null);b=float(axis@(center-s-f));coeff.append((a,b,lim))
  if abs(a)>1e-9:
   bounds=sorted([(-lim-b)/a,(lim-b)/a]);low=max(low,bounds[0]);high=min(high,bounds[1])
  elif abs(b)>lim:low=1;high=0
if low<=high:
 lam=float(np.clip(-sum(a*b/l**2 for a,b,l in coeff)/sum(a*a/l**2 for a,b,l in coeff),low,high));center+=lam*null
result=dict(offline_only=True,source=str(r),precontact_sample_s=float(q[k,0]),first_contact_s=5.210,actual_quantized_release_s=4.36,actual_arrival_s=5.21,old_dry_facet_reference_s=5.2,criteria='width>=.010m,longitudinal>=.005m; zero normal support gap',feasible=low<=high,old_center_m=old.tolist(),proposed_center_m=center.tolist(),shift_m=(center-old).tolist(),margins=[])
for f,s,w,l,n in zip(faces,supports,widths,longs,norms):
 v=center-s-f;result['margins'].append(dict(width_m=float(.042-abs(w@v)),longitudinal_m=float(.013-abs(l@v)),normal_gap_m=float(n@v)))
(P/'causal-actual-facet-proposal.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
