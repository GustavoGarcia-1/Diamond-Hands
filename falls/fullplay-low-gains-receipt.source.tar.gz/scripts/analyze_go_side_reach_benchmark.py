"""Offline actual angular motion, settling and capture-frame FK from physical dry runs."""
from pathlib import Path
import json,re,argparse
import numpy as np,mujoco
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
parser=argparse.ArgumentParser();parser.add_argument('--prefix',default='reach-benchmark');args=parser.parse_args();P=Path('reports/catch-repair-20261114');O=P/'go-side-cup';root=O/(args.prefix+'-linux')/'artifacts/study';cup=json.load(open(O/'refined-balanced-candidate.json'));rows=[]
for duration in[.45,.65]:
 r=root/f'reach-{duration}';
 if not r.exists():continue
 meta=json.load(open(r/'benchmark.json'));xml=(r/'scene.xml').read_text();xml=re.sub(r'/workspace/g1-receiver-runs/[^" ]+/source/src/g1_receiver/_vendor/g1_runtime',str(DEFAULT_RUNTIME_ROOT),xml).replace('/workspace/g1-receiver-runs/out-scrimmage-20261113/source/aero-source','/tmp/g1-aero-source');m=mujoco.MjModel.from_xml_string(xml);d=mujoco.MjData(m);states=np.load(r/'actual-state.npz');cup['arm_targets_rad']=states['time_arm_target_phase'][-1,1:15].tolist();timeq=states['time_qpos'];v=states['time_qvel'];ids=np.array([m.joint(n).id for n in cup['arm_order']]);qa=m.jnt_qposadr[ids];va=m.jnt_dofadr[ids];cue=meta['command_cue_s'];stats={}
 for label,start,end in[('quiet_before_reach',4.1,cue),('during_reach',cue,5.),('last200ms',5.,5.2),('late_settled',5.2,5.5)]:
  a=v[(v[:,0]>=start)&(v[:,0]<=end)][:,1:][:,va];stats[label]=dict(peak_joint_velocity_rad_s=float(abs(a).max())if len(a)else None,rms_joint_velocity_rad_s=float(np.sqrt(np.mean(a*a)))if len(a)else None)
 snapshots=[]
 for t in[5.,5.1,5.2,5.4]:
  if timeq[-1,0]<t-.01:snapshots.append(dict(requested_time_s=t,available=False,last_recorded_s=float(timeq[-1,0])));continue
  k=np.argmin(abs(timeq[:,0]-t));d.qpos[:]=timeq[k,1:];mujoco.mj_kinematics(m,d);shoulder=np.mean([d.xpos[m.body(s+'_shoulder_pitch_link').id]for s in['left','right']],axis=0);faces=[]
  for side,sign in [('left',1),('right',-1)]:
   g=m.geom('aero_'+side+'_palm_collision_7').id;F=d.geom_xmat[g].reshape(3,3);center=d.geom_xpos[g]+m.geom_size[g,0]*F[:,0];b=m.body('aero_'+side+'_palm').id;N=d.xmat[b].reshape(3,3)@np.array([0,sign,0]);faces.append(dict(side=side,center_m=center.tolist(),normal=F[:,0].tolist(),long_axis=F[:,2].tolist(),width_axis=F[:,1].tolist(),body_palm_up_cos=float(N[2]),height_above_shoulders_m=float(center[2]-shoulder[2])))
  snapshots.append(dict(time_s=float(timeq[k,0]),actual_waist_yaw=float(d.qpos[int(m.joint('waist_yaw_joint').qposadr[0])]),max_arm_joint_target_error_rad=float(np.max(abs(timeq[k,1:][qa]-np.array(cup['arm_targets_rad'])))),faces=faces))
 rows.append(dict(duration_s=duration,benchmark=meta,actual_angular_velocity=stats,snapshots=snapshots))
(O/(args.prefix+'-analysis.json')).write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps([dict(T=r['duration_s'],up=r['benchmark']['minimum_upright'],drift=r['benchmark']['max_stem_error_m'],interhand=r['benchmark']['interhand'],vel=r['actual_angular_velocity'],capture=r['snapshots'][2])for r in rows],indent=2))
