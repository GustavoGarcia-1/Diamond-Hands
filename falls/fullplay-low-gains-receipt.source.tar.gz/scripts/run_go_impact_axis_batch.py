"""One analytically chosen orientation fixture, paired zero/half; two cases only."""
import argparse,concurrent.futures,json,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--profile',type=Path,required=True);p.add_argument('--model',type=Path,required=True);p.add_argument('--source',type=Path,required=True);p.add_argument('--amp-source',type=Path,required=True);p.add_argument('--fit',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);base=json.loads(a.profile.read_text());fit=next(r for r in json.loads(a.fit.read_text())['results']if r['flight_s']==1.6 and r['initial_axis_mode']=='impact');assert fit['fit_success'];base['play']['quarterback_target_m']=fit['aim_m'];profile=a.output/'profile.json';profile.write_text(json.dumps(base,indent=2)+'\n')
def run(gain):
 label=f'impact-axis-T16-gain{gain}';command=[sys.executable,str(a.root/'scripts/probe_go_impact_axis.py'),'--ball-axis','impact','--frozen-root',str(a.root),'--profile',str(profile),'--model',str(a.model),'--source',str(a.source),'--amp-source',str(a.amp_source),'--output',str(a.output/label),'--timeconstant','.02','--unmodified','--gain',str(gain),'--device','cuda']
 with (a.output/(label+'.log')).open('w')as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 return dict(label=label,gain=gain,command=command,exit_code=r.returncode)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:rows=list(pool.map(run,[0.,.5]))
(a.output/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
if any(r['exit_code']for r in rows):raise RuntimeError('failedtrialspreserved')
