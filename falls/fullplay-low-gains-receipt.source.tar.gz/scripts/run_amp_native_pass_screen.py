"""Bounded frozen-AMP receive sweep from precomputed fixture profiles."""
import argparse,json,subprocess,sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for name in ('source','amp-source'):p.add_argument('--'+name,required=True)
 p.add_argument('--profiles',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
 p.add_argument('--dry-grip-time',type=float)
 p.add_argument('--no-pass',action='store_true')
 p.add_argument('--record-full-interhand',action='store_true')
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
 protocol=json.loads((a.profiles/'protocol.json').read_text());(a.output/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
 def run(item):
  i,row=item;d=a.output/f'case-{i:02d}'
  cmd=[sys.executable,'scripts/probe_amp_native_catch.py','--source',a.source,'--amp-source',a.amp_source,'--profile',str(a.profiles/row['profile']),'--output',str(d),'--duration','7','--native-enable','route_stage']
  if a.dry_grip_time is not None:cmd+=['--no-pass','--dry-grip-time',str(a.dry_grip_time)]
  elif a.no_pass:cmd+=['--no-pass']
  if a.record_full_interhand:cmd+=['--record-full-interhand']
  if row.get('pose_use_pass_camera'):cmd+=['--pose-use-pass-camera']
  for key in ('speed','initial_yaw','stage_at','stage_duration','stem_yaw_gain','stem_lateral_gain','finish_camera_x'):
   if key in row:cmd+=['--'+key.replace('_','-'),str(row[key])]
  with (a.output/f'case-{i:02d}.log').open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  return dict(**row,command=cmd,exit_code=r.returncode,report=json.loads((d/'report.json').read_text())if(d/'report.json').exists()else None)
 with ThreadPoolExecutor(max_workers=2)as pool:rows=list(pool.map(run,enumerate(protocol['cases'])))
 (a.output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
 if any(r['exit_code']for r in rows):raise SystemExit(1)
if __name__=='__main__':main()
