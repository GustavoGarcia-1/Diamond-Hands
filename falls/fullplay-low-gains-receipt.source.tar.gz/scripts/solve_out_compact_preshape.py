"""Offline compact lower-arm waypoint, with receiving wrists already oriented."""
import argparse,json
from pathlib import Path
import numpy as np,mujoco
from scipy.optimize import least_squares
from g1_receiver.aero import make_aero_scene
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT

def main():
 p=argparse.ArgumentParser()
 for n in ['source','trial','profile','nominal','output']:p.add_argument('--'+n,type=Path,required=True)
 p.add_argument('--max-delta',type=float,default=.7);p.add_argument('--duration',type=float,default=.45);a=p.parse_args();pr=json.loads(a.profile.read_text());nom=json.loads(a.nominal.read_text());names=nom['arm_order'];final=np.array(nom['ready_targets_rad'])+pr['out_staged_arm_offsets_rad'];m=mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT,a.source));d=mujoco.MjData(m);v=np.load(a.trial/'view.npz');d.qpos[:]=v['qpos'][0];adr=np.array([int(m.joint(n).qposadr[0])for n in names]);proxidx=np.arange(14);limits=np.array([m.joint(n).range for n in names]);lo=np.maximum(final[proxidx]-a.max_delta,limits[proxidx,0]+.05);hi=np.minimum(final[proxidx]+a.max_delta,limits[proxidx,1]-.05)
 for i,k in enumerate(proxidx):
  if 'elbow'in names[k]:lo[i]=max(lo[i],.8)
  if k in [4,5,6,11,12,13]:lo[i]=max(lo[i],final[k]-.30);hi[i]=min(hi[i],final[k]+.30)
 pelvis=d.body('pelvis');mujoco.mj_kinematics(m,d);R=pelvis.xmat.reshape(3,3).copy();base=pelvis.xpos.copy();wanted=np.array([base+R@np.array([.23,+.17,.06]),base+R@np.array([.23,-.17,.06])]);hand={s:[g for g in range(m.ngeom)if m.body(int(m.geom_bodyid[g])).name.startswith('aero_'+s+'_')and(m.geom_contype[g]or m.geom_conaffinity[g])]for s in ['left','right']};cross=[(i,j)for i in hand['left']for j in hand['right']];obstacles=[g for g in range(m.ngeom)if any(part in m.body(int(m.geom_bodyid[g])).name for part in ['torso_link','waist_','hip_','knee_','elbow_link'])and(m.geom_contype[g]or m.geom_conaffinity[g])];pairs=cross+[(i,j)for s in ['left','right']for i in hand[s]for j in obstacles];npairs=len(cross);pprox=[g for g in range(m.ngeom)if any(m.body(int(m.geom_bodyid[g])).name.startswith(s+'_'+part)for s in ['left','right']for part in ['shoulder_roll','shoulder_yaw','elbow','wrist'])and(m.geom_contype[g]or m.geom_conaffinity[g])];torso=[g for g in obstacles if m.body(int(m.geom_bodyid[g])).name=='torso_link'];pairs+= [(i,j)for i in pprox for j in torso]
 def calc(x):
  q=final.copy();q[proxidx]=x;d.qpos[adr]=q;mujoco.mj_kinematics(m,d);points=[]
  for s in ['left','right']:
   g=int(m.geom('aero_'+s+'_palm_collision_7').id);r=d.geom_xmat[g].reshape(3,3);points.append(d.geom_xpos[g]+m.geom_size[g,0]*r[:,0])
  gaps=[]
  for i,j in pairs:gaps.append(mujoco.mj_geomDistance(m,d,i,j,.03,None)if np.linalg.norm(d.geom_xpos[i]-d.geom_xpos[j])-m.geom_rbound[i]-m.geom_rbound[j]<.03 else .03)
  return q,np.array(points),np.array(gaps)
 def residual(x):
  q,P,G=calc(x);local=(P-base)@R;return np.r_[((P-wanted)/.035).ravel(),np.maximum(0.,.006-G)/.001,np.maximum(0.,local[:,0]-.31)/.01,np.maximum(0.,local[:,2]-.15)/.01,.05*(q[proxidx]-final[proxidx])]
 best=None;rng=np.random.default_rng(19)
 for seed in range(3):
  start=np.clip(final[proxidx]+(rng.normal(0,.2,14)if seed else np.array([.1,.4,.4,.5,0,0,0,-.1,0,.4,.5,0,0,0])),lo+1e-6,hi-1e-6);fit=least_squares(residual,start,bounds=(lo,hi),max_nfev=200)
  if best is None or np.linalg.norm(fit.fun)<np.linalg.norm(best.fun):best=fit
 q,P,G=calc(best.x);local=(P-base)@R;delta=float(abs(q-final).max());out={'static_only':True,'arm_order':names,'compact_arm_targets_rad':q.tolist(),'receive_arm_targets_rad':final.tolist(),'max_arm_delta_rad':delta,'wrist_delta_max_rad':float(abs(q[[4,5,6,11,12,13]]-final[[4,5,6,11,12,13]]).max()),'compact_facet_centers_pelvis_frame_m':local.tolist(),'min_geometry_gap_m':float(G.min()),'min_interhand_gap_m':float(G[:npairs].min()),'quintic_duration_s':a.duration,'quintic_peak_command_velocity_rad_s':1.875*delta/a.duration,'quintic_peak_command_acceleration_rad_s2':5.773503*delta/a.duration**2,'predeclared':{'max_delta_rad':a.max_delta,'max_wrist_delta_rad':.30,'min_compact_elbow_rad':.8,'max_forward_extension_m':.31,'max_face_height_above_pelvis_m':.15,'min_gap_m':.005,'max_command_velocity_rad_s':3.,'max_command_acceleration_rad_s2':21.},'eligible_static':bool(delta<=a.max_delta+1e-6 and G.min()>=.005 and local[:,0].max()<=.31 and local[:,2].max()<=.15)};a.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
