"""Compare physical/control prefixes; distinguish native phase bookkeeping."""
import argparse,json
from pathlib import Path
import numpy as np

def eq(a,b):return a.shape==b.shape and np.array_equal(a,b,equal_nan=True)if a.dtype.kind in 'fc'else a.shape==b.shape and np.array_equal(a,b)
def main():
 p=argparse.ArgumentParser();p.add_argument('--baseline',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();old=np.load(a.baseline/'native-applied-control.npz')['native_applied_control'];new=np.load(a.candidate/'native-applied-control.npz')['native_applied_control'];assert np.array_equal(old[:,0],new[:,0]);changes=np.flatnonzero(np.any(old[:,1:]!=new[:,1:],axis=1));cut=float(old[changes[0],0])if len(changes)else float('inf');checks={}
 for fn in ['view.npz','offline-robot-qpos.npz']:
  x=np.load(a.baseline/fn);y=np.load(a.candidate/fn);mask=x['timestamps_s']<cut-1e-9;checks[fn]=bool(eq(x['timestamps_s'][mask],y['timestamps_s'][mask])and eq(x['qpos'][mask],y['qpos'][mask]))
 for fn,key in [('anatomical-contact.npz','anatomical_contact'),('interhand-geometry.npz','interhand_geometry'),('ball-contact-witness.npz','ball_contact_witness'),('native-applied-control.npz','native_applied_control')]:
  x=np.load(a.baseline/fn)[key];y=np.load(a.candidate/fn)[key];checks[fn]=bool(eq(x[x[:,0]<cut-1e-9],y[y[:,0]<cut-1e-9]))
 x=np.load(a.baseline/'trace.npz');y=np.load(a.candidate/'trace.npz')
 for k in ['motion','contact']:
  u=x[k];v=y[k];checks['trace/'+k]=bool(eq(u[u[:,0]<cut-1e-9],v[v[:,0]<cut-1e-9]))
 mask=x['foot_time_s']<cut-1e-9
 for k in ['foot_time_s','foot_floor_contact','robot_floor_contact','sole_clearance_m']:checks['trace/'+k]=bool(eq(x[k][mask],y[k][mask]))
 u=x['native_hand'];v=y['native_hand'];mask=u[:,0]<cut-1e-9;checks['trace/native_sensor_prefix']=bool(eq(u[mask,:15],v[mask,:15]));requested_changes=np.flatnonzero(np.any(u[:,15:29]!=v[:,15:29],axis=1));requested_cut=float(u[requested_changes[0],0])if len(requested_changes)else float('inf');requested_mask=u[:,0]<requested_cut-1e-9;checks['trace/native_requested_prefix']=bool(eq(u[requested_mask,:29],v[requested_mask,:29]));phase=np.flatnonzero(u[:,29]!=v[:,29]);result={'first_modified_requested_command_s':requested_cut,'first_modified_post_slew_control_s':cut,'all_physics_and_command_prefixes_exact':all(checks.values()),'checks':checks,'native_phase_bookkeeping_first_difference_s':float(u[phase[0],0])if len(phase)else None,'phase_interpretation':'Requested targets are logged at the 50Hz command time; post-slew controls are recorded after the next 1ms physics step. Each prefix stops at its own first changed timestamp. Logging-only stage indicator intentionally changes when configured delay/ramp changes; never used by controller. All requested targets, encoders and physical/control arrays checked separately.'};a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));assert all(checks.values())
if __name__=='__main__':main()
