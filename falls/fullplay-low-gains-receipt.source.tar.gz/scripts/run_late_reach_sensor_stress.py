"""Matched nominal/held-out sensor tests; physical metrics never select actions."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config', type=Path, required=True)
    p.add_argument('--protocol', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--model', type=Path)
    p.add_argument('--model-only', action='store_true')
    a = p.parse_args()
    if a.model_only and a.model is None:
        p.error('--model-only requires a checkpoint')
    a.output.mkdir(parents=True, exist_ok=False)
    config = json.loads(a.config.read_text())
    config.pop('sensor_domains', None)
    protocol = json.loads(a.protocol.read_text())
    root = Path(__file__).resolve().parents[1]
    runtime = a.output/'runtime'
    for folder in ('src', 'scripts'):
        shutil.copytree(Path(config['frozen_root'])/folder, runtime/folder,
                        ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    for name in ('src/g1_receiver/late_reach_rl.py', 'src/g1_receiver/rgbd_impairments.py',
                 'scripts/train_out_late_reach.py', 'scripts/run_out_late_cup_episode.py'):
        shutil.copy2(root/name, runtime/name)
    shutil.copy2(config['profile'], runtime/'profile.json')
    shutil.copy2(a.protocol, a.output/'protocol.json')
    if a.model:
        shutil.copy2(a.model, a.output/'evaluated-model.zip')
    config.update(frozen_root=str(runtime), profile=str(runtime/'profile.json'))
    hashes = {str(f.relative_to(runtime)): hashlib.sha256(f.read_bytes()).hexdigest()
              for f in sorted(runtime.rglob('*')) if f.is_file()}
    (a.output/'runtime-hashes.json').write_text(json.dumps(hashes, indent=2)+'\n')
    with tarfile.open(a.output/'runtime-source.tar.gz', 'x:gz') as archive:
        for name in hashes:
            archive.add(runtime/name, arcname=name)
    env = {**os.environ, 'PYTHONPATH': str(runtime/'src')+os.pathsep+str(runtime/'scripts')}
    results = []
    for case in protocol['cases']:
        for policy in (('model',) if a.model_only else (('zero', 'model') if a.model else ('zero',))):
            name = case['name']+'-'+policy
            output = a.output/name
            test_config = dict(config, sensor_impairments=case['impairments'])
            path = a.output/(name+'-config.json')
            path.write_text(json.dumps(test_config, indent=2)+'\n')
            command = [sys.executable, str(runtime/'scripts/train_out_late_reach.py'),
                       '--config', str(path), '--driver', 'run_out_late_cup_episode',
                       '--output', str(output)]
            command += ['--zero'] if policy == 'zero' else ['--evaluate', str(a.output/'evaluated-model.zip')]
            subprocess.run(command, cwd=runtime, env=env, check=True, timeout=240)
            evaluation = json.loads((output/'evaluation.json').read_text())
            report = json.loads((output/'evaluation/episode-0001/trial/report.json').read_text())
            results.append(dict(case=case['name'], policy=policy, sensor_evaluation=evaluation,
                                physical_evaluation_only=dict(
                                    duration_s=report['duration_s'],
                                    anatomical_score=report.get('anatomical_score'),
                                    quarterback_pass_score=report.get('quarterback_pass_score'),
                                    minimum_upright_cosine=report['minimum_upright_cosine'])))
            (a.output/'summary.json').write_text(json.dumps(results, indent=2)+'\n')


if __name__ == '__main__':
    main()
