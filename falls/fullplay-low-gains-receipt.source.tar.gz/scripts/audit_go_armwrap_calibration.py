"""Read-only actual dynamic capture-phase placement and incoming whole-hand geometry."""
from pathlib import Path
import json
import mujoco,numpy as np
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
from g1_receiver.scrimmage_throw import ScrimmagePass
P=Path('reports/catch-repair-20261114/contact-model');out=P/'go-inlet';base=out/'armwrap-calibration-linux/artifacts/study';originalxml=(P/'study-linux/artifacts/study/original20-gain0.5/scene.xml').read_text().replace('/workspace/g1-receiver-runs/catch-repair-contact-model-20261114-r1/source/src/g1_receiver/_vendor/g1_runtime',str(DEFAULT_RUNTIME_ROOT)).replace('/workspace/g1-receiver-runs/out-scrimmage-20261113/source/aero-source','/tmp/g1-aero-source');m=mujoco.MjModel.from_xml_string(originalxml);d=mujoco.MjData(m);ball=m.geom('football_surface').id;ba=int(m.joint('football_free').qposadr[0]);pads=[m.geom('aero_'+s+'_palm_collision_7').id for s in ['left','right']];geoms=np.array([g for g in range(m.ngeom)if g!=ball and m.geom_bodyid[g]>0 and(m.geom_contype[g]or m.geom_conaffinity[g])]);profile=json.load(open('reports/catch-form-20261114/overnight-grip/screen-r1/artifacts/screen/give4-thumb-ready-profile.json'))['play'];plan=ScrimmagePass(tuple(profile['quarterback_origin_m']),tuple(profile['quarterback_target_m']),1.6,horizontal_distance_only=True).plan(3.6);R=np.empty(9);mujoco.mju_quat2Mat(R,np.array(plan.release_quaternion_wxyz));R=R.reshape(3,3);shape=R@np.diag(m.geom_size[ball]**2)@R.T;rows=[]
for scale in [0.,.5]:
 root=base/f'grasp-scale-{scale}';p=np.load(root/'offline-robot-qpos.npz');first={};minimum={};poses=[]
 for t in [5.02,5.12,5.18,5.2]:
  k=np.argmin(abs(p['timestamps_s']-t));d.qpos[:]=p['qpos'][k];mujoco.mj_kinematics(m,d);dt=t-3.6;center=np.array(plan.release_xyz_m)+dt*np.array(plan.release_velocity_mps);center[2]-=4.905*(dt*dt+.001*dt);faces=[]
  for g in pads:
   F=d.geom_xmat[g].reshape(3,3);n=F[:,0];face=d.geom_xpos[g]+m.geom_size[g,0]*n;support=center-shape@n/np.sqrt(n@shape@n);delta=support-face;offset=F[:,1:].T@delta;faces.append(dict(geom=m.geom(g).name,face_center_m=face.tolist(),normal_world=n.tolist(),positive_face_support_normal_gap_m=float(delta@n),support_inplane_offset_m=offset.tolist(),support_finite_edge_excess_m=np.maximum(abs(offset)-m.geom_size[g,1:],0).tolist()))
  poses.append(dict(time_s=t,face_center_gap_m=float(np.linalg.norm(np.array(faces[0]['face_center_m'])-np.array(faces[1]['face_center_m']))),faces=faces))
 for stamp,qpos in zip(p['timestamps_s'],p['qpos']):
  if not 4.95<=stamp<=5.2001:continue
  d.qpos[:]=qpos;dt=stamp-3.6;center=np.array(plan.release_xyz_m)+dt*np.array(plan.release_velocity_mps);center[2]-=4.905*(dt*dt+.001*dt);d.qpos[ba:ba+7]=np.r_[center,plan.release_quaternion_wxyz];mujoco.mj_kinematics(m,d);lower=np.linalg.norm(d.geom_xpos[geoms]-center,axis=1)-m.geom_rbound[geoms]-m.geom_rbound[ball]
  for g in geoms[lower<.02]:
   gap=float(mujoco.mj_geomDistance(m,d,ball,int(g),.02,None));r=dict(geom=m.geom(int(g)).name or f'geom-{g}',body=m.body(int(m.geom_bodyid[g])).name,time_s=float(stamp),gap_m=gap)
   if g not in minimum or gap<minimum[g]['gap_m']:minimum[int(g)]=r
   if gap<=0 and g not in first:first[int(g)]=r
 rows.append(dict(scale=scale,calibration=json.load(open(root/'calibration.json')),poses=poses,first_intersections=sorted(first.values(),key=lambda x:x['time_s']),minimum_gaps=sorted(minimum.values(),key=lambda x:x['gap_m'])))
(out/'armwrap-calibration-audit.json').write_text(json.dumps(dict(offline_only=True,not_catch_evidence=True,actual_no_throw_dynamic_calibration=True,original_fixture_target=True,scale_offsets_only=True,records=rows),indent=2)+'\n');print(json.dumps([dict(scale=r['scale'],calibration=r['calibration'],poses=r['poses'][-2:],first=r['first_intersections'][:3],minimum=r['minimum_gaps'][:2])for r in rows],indent=2))
