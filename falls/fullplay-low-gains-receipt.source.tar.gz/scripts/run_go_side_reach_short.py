import argparse,concurrent.futures,json,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();
for k in['root','profile','compact','cup','source','amp-source','output']:p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
def run(duration):
 label=f'reach-{duration}';cmd=[sys.executable,str(a.root/'scripts/probe_go_side_late_reach_benchmark.py'),'--frozen-root',str(a.root),'--profile',str(a.profile),'--compact',str(a.compact),'--cup',str(a.cup),'--source',str(a.source),'--amp-source',str(a.amp_source),'--output',str(a.output/label),'--reach-duration',str(duration)]
 with(a.output/(label+'.log')).open('w')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 return dict(label=label,command=cmd,exit_code=r.returncode)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:rows=list(pool.map(run,[.45]))
(a.output/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
if any(r['exit_code']for r in rows):raise RuntimeError('failedbenchpreserved')
