"""Read-only no-ball gait audit of archived AMP-native trials."""
import argparse
import json
from pathlib import Path
import numpy as np
from g1_receiver.running_catch_eval import _flight_phases, RunningCatchCriteria


def summarize(directory):
    report = json.loads((directory / 'report.json').read_text())
    with np.load(directory / 'trace.npz', allow_pickle=False) as trace:
        motion = trace['motion']
        crossings = np.flatnonzero((motion[:-1, 1] < 9.144) & (motion[1:, 1] >= 9.144))
        crossing = None
        phases = []
        if len(crossings):
            i = int(crossings[0])
            crossing = float(np.interp(9.144, motion[i:i + 2, 1], motion[i:i + 2, 0]))
            phases = _flight_phases(trace['foot_time_s'], trace['foot_floor_contact'],
                                    trace['robot_floor_contact'], trace['sole_clearance_m'],
                                    motion[:, :5], np.array([1., 0.]), crossing, .4,
                                    RunningCatchCriteria())
        spans = any(left['start_s'] <= crossing <= right['land_s'] and
                    0 < right['start_s'] - left['start_s'] <= .72
                    for left, right in zip(phases[:-1], phases[1:]))
        geometry = report.get('interhand_geometry_audit', {})
        geometry_ok = bool(geometry) and not geometry['exceeds_predeclared_5mm_penetration']
        result = dict(case=directory.name, duration_s=report['duration_s'],
                      minimum_upright_cosine=report['minimum_upright_cosine'],
                      max_stem_error_m=report['max_stem_error_m'],
                      first_ten_yard_crossing_s=crossing, qualified_flights=phases,
                      recurrent_flights_span_crossing=spans,
                      interhand_geometry_pass=geometry_ok)
        result['passes_no_ball_gait_check'] = bool(
            report['duration_s'] >= 7. - 1e-8 and report['minimum_upright_cosine'] >= .9
            and report['max_stem_error_m'] <= .5 and spans and geometry_ok)
        result['catch_established'] = False
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    rows = [summarize(path) for path in sorted(args.input.glob('case-*')) if path.is_dir()]
    args.output.write_text(json.dumps(rows, indent=2) + '\n')
    for row in rows:
        print(row['case'], round(row['max_stem_error_m'], 3),
              len(row['qualified_flights']), row['passes_no_ball_gait_check'])


if __name__ == '__main__':
    main()
