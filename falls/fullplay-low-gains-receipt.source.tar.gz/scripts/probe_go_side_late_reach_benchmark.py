"""No-throw physical compact→cup reach benchmark. Timed cue is calibration only, never a catch controller."""
import argparse,sys,json,hashlib
from pathlib import Path
from types import SimpleNamespace
from dataclasses import replace
import numpy as np,mujoco
p=argparse.ArgumentParser();
for k in['frozen-root','profile','compact','cup','source','amp-source','output']:p.add_argument('--'+k,type=Path,required=True)
p.add_argument('--reach-duration',type=float,choices=[.45,.65],required=True);a=p.parse_args();sys.path[:0]=[str(a.frozen_root/'src'),str(a.frozen_root/'scripts')]
from g1_receiver.hand_route_plant import HandRoutePlant
from g1_receiver.lower_cup_grip import NativeCupGrip
from g1_receiver.native_hand_eval import NativeInterhandGeometryAudit
from g1_receiver.anatomical_catch_eval import physics_fingerprint
from g1_receiver._vendor.g1_runtime.pool.wbc import WholeBodyController
import probe_native_cup_residual as runner
compact=json.load(open(a.compact));cup=json.load(open(a.cup));q0=np.array(compact['arm_targets_rad']);q1=np.array(cup['arm_targets_rad']);cue=5.-a.reach_duration;commands=[];poses=[];velocities=[];controls=[];ball_robot=[];self_contacts=[];holder={}
original_ready=runner.aero_ready_joint_targets;original_delivery=runner.OpticalPass;original_native=NativeCupGrip.targets;original_init=HandRoutePlant.__init__;original_step=HandRoutePlant.step;original_wbc=WholeBodyController.act

def ready(nominal,names):
 target=original_ready(nominal,names);target[[names.index(n)for n in cup['arm_order']]]=q0;return target
class BenchmarkNoThrow:
 def __init__(self,plant,profile,shift):self.release=None;self.handoff_at=None;self.initial=None;self.hands=SimpleNamespace(closed_at=5.02,ready_at=5.02);self.indices=[plant.joint_names.index(n)for n in cup['arm_order']]
 def ready(self):pass
 def observe(self,plant,now,pose,history):
  if self.handoff_at is None and pose is not None and pose.fresh(now,.14) and pose.xy_m[0]>=1.3:self.handoff_at=now
 def targets(self,now,upper):
  if self.initial is None:self.initial=upper[self.indices].copy()
  target=upper.copy();u=float(np.clip((now-cue)/a.reach_duration,0,1));phase=u*u*u*(10-15*u+6*u*u)
  if self.handoff_at is None:target[self.indices]=self.initial
  else:
   prep=float(np.clip((now-self.handoff_at-.7)/1.,0,1));prep=prep**3*(10-15*prep+6*prep*prep);prepared=self.initial+prep*(q0-self.initial);target[self.indices]=prepared+phase*(q1-q0)
  commands.append(np.r_[now,target[self.indices],phase]);return target,0.

 def close(self):pass

def native(self,now,closure,release_at,gate,encoders):return original_native(self,now,closure,3.6,5.02,encoders)
def init(self,*args,**kwargs):
 original_init(self,*args,**kwargs);a.output.mkdir(parents=True,exist_ok=False);(a.output/'scene.xml').write_text(self.scene_xml);holder.update(model=self.model,ball=self.model.geom('football_surface').id,interhand=NativeInterhandGeometryAudit(self.model),physics=physics_fingerprint(self.model)['sha256'],joint_addresses=self.joint_qpos.copy())
def step(self,command,*,closure=0.,hand_target_rad=None,post_step=None):
 def observe(data):
  if post_step:post_step(data)
  holder['interhand'].record(data);poses.append(np.r_[data.time,data.qpos.copy()]);velocities.append(np.r_[data.time,data.qvel.copy()]);controls.append(np.r_[data.time,data.ctrl.copy()])
  for ci,c in enumerate(data.contact):
   x,y=map(int,c.geom)
   if self.model.geom_bodyid[x]>0 and self.model.geom_bodyid[y]>0 and holder['ball']not in(x,y):
    force=np.zeros(6);mujoco.mj_contactForce(self.model,data,ci,force);self_contacts.append(np.r_[data.time,x,y,c.dist,force[0]])
   if holder['ball']not in(x,y):continue
   other=y if x==holder['ball']else x
   if self.model.geom_bodyid[other]>0:ball_robot.append(dict(t=float(data.time),geom=self.model.geom(other).name,dist_m=float(c.dist)))
 return original_step(self,command,closure=closure,hand_target_rad=hand_target_rad,post_step=observe)
def wbc(self,obs,goal,upper_target=None):
 u=float(np.clip((obs.timestamp-3.)/1.,0,1));phase=u*u*u*(10-15*u+6*u*u);goal=replace(goal,torso_rpy=np.array([0.,0.,-.65*phase]));return original_wbc(self,obs,goal,upper_target)
runner.OpticalPass=BenchmarkNoThrow;NativeCupGrip.targets=native;HandRoutePlant.__init__=init;HandRoutePlant.step=step;WholeBodyController.act=wbc
args=SimpleNamespace(source=a.source,amp_source=a.amp_source,profile=a.profile,output=a.output/'trial',no_pass=False,walk_speed=1.,handoff_depth=1.3,initial_yaw=-.7,duration=5.8,record_anatomical=False,reference_physics_sha256='173bf57168f5f97d0471d7bfa0a05e067a00f1e27a385994f57f21998a30af15',sensor_retention_camera_position=None,sensor_retention_camera_target=None,sensor_retention_pose_camera_position=None,sensor_retention_pose_camera_target=None)
try:r=runner.run(args,native_residual_callback=None)
finally:runner.aero_ready_joint_targets=original_ready;runner.OpticalPass=original_delivery;NativeCupGrip.targets=original_native;HandRoutePlant.__init__=original_init;HandRoutePlant.step=original_step;WholeBodyController.act=original_wbc
np.savez_compressed(a.output/'self-contact-witness.npz',contacts=np.asarray(self_contacts),geom_names=np.array([holder['model'].geom(i).name or f'geom-{i}'for i in range(holder['model'].ngeom)]),body_names=np.array([holder['model'].body(i).name for i in range(holder['model'].nbody)]),geom_bodyid=holder['model'].geom_bodyid);np.savez_compressed(a.output/'actual-state.npz',time_qpos=np.asarray(poses),time_qvel=np.asarray(velocities),time_control=np.asarray(controls),time_arm_target_phase=np.asarray(commands));np.savez_compressed(a.output/'interhand-geometry.npz',**holder['interhand'].arrays());(a.output/'benchmark.json').write_text(json.dumps(dict(calibration_only=True,no_throw=True,no_causal_visual_arm_cue_claim=True,not_catch_evidence=True,command_cue_s=cue,reach_duration_s=a.reach_duration,quintic_target_peak_joint_velocity_rad_s=float(1.875*np.max(abs(q1-q0))/a.reach_duration),quiet_compact_until_cue=True,initial_upper_posture="protectedAeroReadyunchanged",compact_preparation="existingRGBDhandoff+.7s,1sramp;bodyhandoffparametersunchanged",body_route_handoff_parameters_unchanged=True,torso_goal_ramp_s=[3.,4.],torso_goal_yaw_rad=-.65,ball_robot_contacts=ball_robot,minimum_upright=r['minimum_upright_cosine'],max_stem_error_m=r['max_stem_error_m'],physics_sha256=holder['physics'],interhand=holder['interhand'].summary(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),profile_sha256=hashlib.sha256(a.profile.read_bytes()).hexdigest()),indent=2)+'\n')
