"""Two explicitly combined fixture/grip hypotheses; no training or physics changes."""
import argparse,concurrent.futures,json,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();
for k in ['root','profile','model','source','amp-source','flat-fit','impact-fit','output']:p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);base=json.loads(a.profile.read_text());flat=next(r for r in json.loads(a.flat_fit.read_text())['results']if r['flight_s']==.8 and r['world_level_x']is True);impact=next(r for r in json.loads(a.impact_fit.read_text())['results']if r['flight_s']==1.6 and r['initial_axis_mode']=='impact');jobs=[]
for label,fit,axis in [('T08-level-fullprecurl',flat,None),('T16-impact-fullprecurl',impact,'impact')]:
 profile=json.loads(json.dumps(base));g=profile['native_grip'];g['preload'][4]=.5;g['preload'][5:7]=[1.,1.];g['capture'][5:7]=[1.,1.];profile['play'].update(flight_s=fit['flight_s'],release_s=5.2-fit['flight_s'],quarterback_target_m=fit['aim_m'],quarterback_level_ball=True);path=a.output/(label+'-profile.json');path.write_text(json.dumps(profile,indent=2)+'\n');jobs.append((label,path,axis))
def run(job):
 label,profile,axis=job;runner='probe_go_impact_axis.py'if axis else'probe_ball_hand_contact_model.py';cmd=[sys.executable,str(a.root/'scripts'/runner)]
 if axis:cmd+=['--ball-axis',axis]
 cmd+=['--frozen-root',str(a.root),'--profile',str(profile),'--model',str(a.model),'--source',str(a.source),'--amp-source',str(a.amp_source),'--output',str(a.output/label),'--timeconstant','.02','--unmodified','--gain','.5','--device','cuda']
 with(a.output/(label+'.log')).open('w')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 return dict(label=label,gain=.5,profile=str(profile),command=cmd,exit_code=r.returncode)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:rows=list(pool.map(run,jobs))
(a.output/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
if any(r['exit_code']for r in rows):raise RuntimeError('failedtrialspreserved')
