"""Longer frontside flight and zero-arm-wrap matched controls; native grip fixed."""
from pathlib import Path
from copy import deepcopy
from concurrent.futures import ProcessPoolExecutor,as_completed
import argparse,json,multiprocessing as mp,traceback
import numpy as np
import probe_lower_cup_native_witness as runner
from probe_overnight_forward_grid import seed
REFERENCE='173bf57168f5f97d0471d7bfa0a05e067a00f1e27a385994f57f21998a30af15'

def run(job):
 root,donor,source,amp,cal,index,flight,wrap=job;p=deepcopy(donor);target,n,description=seed(p,flight,cal);target+=.01*n;p['play'].update(flight_s=flight,release_s=5.2-flight,quarterback_target_m=target.tolist(),field_catch_window_m=target.tolist());axis=target[:2]-p['play']['quarterback_origin_m'][:2];p['play']['field_approach_axis_xy']=(axis/np.linalg.norm(axis)).tolist()
 if not wrap:p['play']['grasp_offsets_rad']=[0.]*14;p['play']['hold_offsets_rad']=[0.]*14
 p['frontside_control']=dict(flight_s=flight,arm_wrap_enabled=wrap,normal_depth_m=.01,offline_seed=description);path=root/f'profile-{index:02d}.json';path.write_text(json.dumps(p,indent=2)+'\n')
 try:
  args=runner.build_parser().parse_args(['--source',str(source),'--amp-source',str(amp),'--profile',str(path),'--output',str(root/f'case-{index:02d}'),'--walk-speed','1','--handoff-depth','1.3','--initial-yaw','-.7','--duration','9','--record-anatomical','--reference-physics-sha256',REFERENCE]);r=runner.run(args);row=dict(case=index,flight_s=flight,arm_wrap_enabled=wrap,anatomical=r['anatomical_score'],geometry=r['interhand_geometry_audit'],host_gains_sha256=r['host_gains_sha256'])
 except BaseException as e:row=dict(case=index,error=repr(e),traceback=traceback.format_exc())
 (root/f'score-{index:02d}.json').write_text(json.dumps(row,indent=2)+'\n');return row

def main():
 p=argparse.ArgumentParser()
 for n in ['source','amp-source','profile','calibration','output']:p.add_argument('--'+n,type=Path,required=True)
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);donor=json.loads(a.profile.read_text());cal=json.loads(a.calibration.read_text());parameters=[(t,w)for t in [1.1,1.2,1.3,1.4]for w in [True,False]]+[(.9,False),(1.,False)];rows=[]
 with ProcessPoolExecutor(max_workers=2,mp_context=mp.get_context('spawn'))as pool:
  for f in as_completed([pool.submit(run,(a.output,donor,a.source,a.amp_source,cal,i,t,w))for i,(t,w)in enumerate(parameters)]):rows.append(f.result());(a.output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
if __name__=='__main__':main()
