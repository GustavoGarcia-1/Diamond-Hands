"""Exact physical baseline replay for the new isolated Out native/evaluation runner."""
import argparse,json
from pathlib import Path
import numpy as np
import probe_out_native_lower as runner

def main():
 p=argparse.ArgumentParser()
 for n in ['source','amp-source','profile','reference','output']:p.add_argument('--'+n,type=Path,required=True)
 a=p.parse_args();runner.main(['--source',str(a.source),'--amp-source',str(a.amp_source),'--output',str(a.output),'--duration','8','--approach-handoff-depth-m','2.1','--cut-speed','1.4','--blend-s','.5','--turn-s','.4','--hold-straight-s','0','--depth-feedback-gain','4','--camera-start-s','.8','--stopping-lookahead-s','.55','--reverse-speed','0','--approach-speed','.48','--horizontal-pass-distance','--pass-profile',str(a.profile),'--record-poses','--record-anatomical','--reference-physics-sha256','173bf57168f5f97d0471d7bfa0a05e067a00f1e27a385994f57f21998a30af15']);matched={}
 for file in ['trace.npz','view.npz']:
  with np.load(a.reference/file)as x,np.load(a.output/file)as y:matched[file]={k:bool(k in y.files and np.array_equal(x[k],y[k],equal_nan=True))if x[k].dtype.kind in 'fc'else bool(k in y.files and np.array_equal(x[k],y[k]))for k in x.files}
 assert all(all(v.values())for v in matched.values()),matched
 (a.output/'zero-exact.json').write_text(json.dumps(matched,indent=2)+'\n');print('ALL original Out physics arrays exact')
if __name__=='__main__':main()
