"""Lower palms-up running receiver with native Aero digit control.

Frozen AMP uses measured legs/IMU and arm encoders centered on the commanded
upper-body offset. RGB-D gates the grip; the native preload starts at the
commanded route stage by default. Physics state is confined to recorded audits.
"""
import argparse
from dataclasses import asdict, replace
import json
from pathlib import Path
from types import SimpleNamespace
import mujoco
import numpy as np
from evaluate_aero_receiver import make_plant
from evaluate_dextra_in_stride import RearMarkerLocalizer
from probe_aero_amp_slant import OpticalPass
from g1_receiver.aero import aero_ready_joint_targets, PALM_BODIES
from g1_receiver.anatomical_catch_eval import AnatomicalContactAudit, score_anatomical_catch
from g1_receiver.catch_form import CatchFormEvaluator, CatchFormContext
from g1_receiver.football_routes import imu_yaw, heading_error
from g1_receiver.in_stride_eval import score_in_stride_catch
from g1_receiver.locomotion import CONTROL_DT
from g1_receiver.lower_cup_grip import NativeHandCalibration, NativeCupGrip
from g1_receiver.running_catch_eval import FootContactRecorder, score_running_long_pass
from g1_receiver.running_policy import AmpRunningPolicy
from g1_receiver.routes import Route
from g1_receiver.runtime import RobotObservation, SkillGoal
from g1_receiver.throw_eval import score_throw_receive

def build_parser():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('source','amp-source','profile','output'):p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--no-pass',action='store_true')
    p.add_argument('--initial-yaw',type=float,default=-.5)
    p.add_argument('--duration',type=float,default=7.)
    p.add_argument('--stage-at',type=float,default=1.6)
    p.add_argument('--stage-duration',type=float,default=1.)
    p.add_argument('--speed',type=float,default=2.)
    p.add_argument('--centering',type=float,default=1.)
    p.add_argument('--native-enable',choices=('route_stage','commanded_release'),default='route_stage')
    p.add_argument('--initial-hand-closure',type=float,default=.2)
    p.add_argument('--dry-grip-time',type=float,help='No-ball command-only diagnostic; never a catch result')
    p.add_argument('--leg-checkpoint',type=Path)
    p.add_argument('--leg-device',default='cuda')
    p.add_argument('--record-full-interhand',action='store_true')
    p.add_argument('--stem-yaw-gain',type=float,default=0.)
    p.add_argument('--stem-lateral-gain',type=float,default=0.)
    p.add_argument('--finish-camera-x',type=float,default=5.)
    p.add_argument('--pose-use-pass-camera',action='store_true')
    p.add_argument('--reference-physics-sha256',default='173bf57168f5f97d0471d7bfa0a05e067a00f1e27a385994f57f21998a30af15')
    return p

def run(a):
    if a.output.exists():raise FileExistsError(a.output)
    if not -.8<=a.initial_yaw<=.8 or not 3<=a.duration<=14 or not .5<=a.speed<=3 or not 0<=a.centering<=1 or not .3<=a.stage_duration<=2:
        raise ValueError('bounded stance, speed, duration and centering required')
    if not 0. <= a.initial_hand_closure <= 1.:raise ValueError('initial hand closure must be in [0,1]')
    if not 0.<=a.stem_yaw_gain<=1. or not 0.<=a.stem_lateral_gain<=1.:raise ValueError('bounded surveyed-stem feedback gains required')
    if not 5.<=a.finish_camera_x<=9.:raise ValueError('finish camera survey must remain in declared field interval')
    if a.dry_grip_time is not None and (not a.no_pass or not a.stage_at<a.dry_grip_time<a.duration):
        raise ValueError('dry grip requires no-pass and a time after staging and before finish')
    profile=json.loads(a.profile.read_text())
    if not np.allclose(profile['play']['quarterback_origin_m'],(0.,-1.8288,1.4),atol=1e-10,rtol=0.):
        raise ValueError('fixed two-yard inside machine formation required')
    route=Route('go',((0.,0.),(9.144,0.),(16.,0.)),2.)
    plant=make_plant(a.source,route,tracking_camera=((-1.,0.,1.5),(3.,0.,.9)),
                     finish_camera=((a.finish_camera_x,0.,1.5),(a.finish_camera_x+5.,0.,.9)),
                     pass_camera=profile.get('pass_camera',((6.,-4.,3.8),(9.,0.,1.5))))
    try:
        policy=AmpRunningPolicy(plant.joint_names,plant.joint_ranges,a.amp_source)
        ready=aero_ready_joint_targets(policy.nominal,plant.joint_names)
        arms=[plant.joint_names.index(f'{side}_{axis}_joint') for side in ('left','right')
              for axis in ('shoulder_roll','shoulder_yaw','shoulder_pitch','elbow','wrist_roll','wrist_pitch','wrist_yaw')]
        offsets=np.asarray(profile['out_staged_arm_offsets_rad'])
        if offsets.shape!=(14,) or not np.isfinite(offsets).all():raise ValueError('finite fourteen arm offsets required')
        calibration=NativeHandCalibration.from_model(plant.model)
        grip=NativeCupGrip(calibration,profile['native_grip']) if 'native_grip' in profile else None
        leg_residual=None
        if a.leg_checkpoint is not None:
            if a.centering!=1. or a.speed!=2. or a.stage_at!=1.6 or a.stage_duration!=1. or a.native_enable!='route_stage':
                raise ValueError('learned leg residual requires its declared centering, speed and stage schedule')
            from g1_receiver.amp_native_leg_residual import NativeCupLegResidual
            leg_residual=NativeCupLegResidual(a.leg_checkpoint,profile,plant.joint_names,plant.joint_ranges,a.leg_device)
        delivery=None if a.no_pass else OpticalPass(plant,profile['play'],(0.,0.,0.))
        # Reuse the exact arm-target interpolation in a visibly declared no-ball
        # diagnostic. This command schedule is never used to claim a visual catch.
        dry_target=SimpleNamespace(profile=profile['play'],hands=SimpleNamespace(closed_at=a.dry_grip_time),
                                   arm_indices=arms,aperture_correction=np.zeros(14))
        plant.reset(joint_positions=ready,release_position_m=(-10.,-10.,.085) if a.no_pass else (0.,-1.8288,1.4))
        plant.data.qpos[plant.base+3:plant.base+7]=(np.cos(a.initial_yaw/2),0.,0.,np.sin(a.initial_yaw/2))
        mujoco.mj_forward(plant.model,plant.data)
        if delivery is not None:delivery.ready()
        policy.reset();feet=FootContactRecorder(plant.model)
        anatomy=AnatomicalContactAudit(plant.model,reference_physics_sha256=a.reference_physics_sha256)
        from g1_receiver.native_hand_eval import NativeBallContactWitness
        contact_witness=NativeBallContactWitness(plant.model)
        interhand=None
        if a.record_full_interhand:
            from g1_receiver.native_hand_eval import NativeInterhandGeometryAudit
            interhand=NativeInterhandGeometryAudit(plant.model)
        form=CatchFormEvaluator(mujoco.MjModel.from_xml_string(plant.scene_xml),tuple(plant.joint_names))
        localizer=RearMarkerLocalizer(allow_synthetic_fixture=True,max_range_m=8.)
        pose=None;history=[];motion=[];views=[];palms=[];commands=[];form_rows=[];stem_observations=[];last_shift=np.zeros(14)
        def record(data):
            feet.record(data)
            if delivery is not None and delivery.release is not None:
                delivery.audit.record(data);anatomy.record(data);contact_witness.record(data)
            elif a.no_pass:anatomy.record(data);contact_witness.record(data)
            if interhand is not None:interhand.record(data)
        count=round(a.duration/CONTROL_DT)
        for tick in range(count+1):
            now=plant.timestamp_s;obs=RobotObservation(now,*plant.observe(),np.zeros(29),None)
            yaw=imu_yaw(obs.imu_quat_wxyz)
            leg_pose_measurement=None
            if tick%2==0 and now>=.8:
                for name in (('finish','track','pass') if a.pose_use_pass_camera else ('finish','track')):
                    measured=localizer.estimate(*plant.capture(name))
                    if measured is not None:
                        leg_pose_measurement=measured
                        pose=measured;history=[*history[-6:],(now,*pose.xy_m)];break
            if delivery is not None:delivery.observe(plant,now,pose,history)
            u=float(np.clip((now-a.stage_at)/a.stage_duration,0.,1.));stage=u*u*(3.-2.*u)
            target=ready.copy();target[arms]+=stage*offsets
            target,closure=(target,.2)if delivery is None else delivery.targets(now,target)
            dry_gate=a.dry_grip_time if a.dry_grip_time is not None and now>=a.dry_grip_time else None
            if dry_gate is not None:target,closure=OpticalPass.targets(dry_target,now,target)
            shift=target[arms]-ready[arms]
            q=obs.joint_position.copy();dq=obs.joint_velocity.copy()
            q[arms]-=a.centering*shift;dq[arms]-=a.centering*(shift-last_shift)/CONTROL_DT
            centered=replace(obs,joint_position=q,joint_velocity=dq);last_shift=shift.copy()
            stem_y=0. if pose is None or not pose.fresh(now,.14) else float(pose.xy_m[1])
            desired_heading=float(np.clip(-a.stem_yaw_gain*stem_y,-.2,.2))
            lateral_drive=float(np.clip(-a.stem_lateral_gain*stem_y,-.2,.2))
            stem_observations.append((now,pose is not None and pose.fresh(now,.14),stem_y,desired_heading,lateral_drive))
            drive=np.array([min(a.speed,1.8*max(0.,now-.4)),lateral_drive,np.clip(1.8*heading_error(desired_heading,yaw),-.75,.75)])
            # The following exact-state samples are evaluation/rendering only.
            pelvis=plant.data.body('pelvis');motion.append((now,*pelvis.xpos,float(pelvis.xmat[8]),yaw))
            commands.append((now,*drive,stage,*target))
            form_rows.append(dict(time_s=now,**form.evaluate(obs,CatchFormContext(over_shoulder=True,phase='receive'))))
            if tick%2==0:
                views.append((now,plant.data.qpos.copy()));palms.append((now,*np.mean([plant.data.body(n).xpos for n in PALM_BODIES],axis=0)))
            _,x,y,_=obs.imu_quat_wxyz
            if tick==count or 1.-2.*(x*x+y*y)<.54:break
            command=policy.act(centered,SkillGoal(base_velocity=drive),upper_target=target)
            if leg_residual is not None:
                command=leg_residual.apply(command,obs,leg_pose_measurement,drive,stage)
            if grip is None:plant.step(command,closure=closure,post_step=record)
            else:
                enabled_at=(a.stage_at if a.native_enable=='route_stage' else
                            None if delivery is None or delivery.release is None else delivery.release.release_time_s)
                # Match the no-ball and delivery startup posture explicitly.
                # The initial encoder-driven hand command must not depend on
                # whether a parked ball or a fixed passing fixture was selected.
                startup_closure=a.initial_hand_closure if enabled_at is None or now<enabled_at else closure
                native=grip.targets(now,startup_closure,enabled_at,dry_gate if delivery is None else delivery.hands.closed_at,
                                    plant.data.sensordata[calibration.sensor_addresses].copy())
                plant.step(command,hand_target_rad=native,post_step=record)
        m=np.asarray(motion);arrays=feet.arrays();metadata=anatomy.metadata();anatomical=anatomy.arrays()
        report=dict(evidence_class='experimental_lower_amp_native_receive',duration_s=float(m[-1,0]),
                    minimum_upright_cosine=float(m[:,4].min()),max_stem_error_m=float(abs(m[:,2]).max()),
                    final_xyz_m=m[-1,1:4].tolist(),initial_yaw_rad=a.initial_yaw,
                    command_offset_centering=a.centering,native_enable=a.native_enable,
                    initial_hand_closure=a.initial_hand_closure,
                    dry_grip_command_s=a.dry_grip_time,
                    surveyed_stem_feedback=dict(yaw_gain=a.stem_yaw_gain,lateral_gain=a.stem_lateral_gain,pose_max_age_s=.14,heading_limit_rad=.2,lateral_limit_mps=.2,pose_use_pass_camera=a.pose_use_pass_camera),
                    route_stage_at_s=a.stage_at,route_stage_duration_s=a.stage_duration,
                    warning_count=sum(int(w.number)for w in plant.data.warning),physics_step_s=float(plant.model.opt.timestep),
                    controller_inputs=['surveyed RGB-D','IMU','29 body encoders','14 native actuator encoders','commanded route stage'],
                    camera_surveys={n:dict(rotation=r.tolist(),position_m=p.tolist())for n,(r,p)in plant.cameras.items()})
        if delivery is not None and delivery.release is not None:
            contact=delivery.audit.trace();release=asdict(delivery.release)
            strict=score_in_stride_catch(contact,m[:,:5],route,release_time_s=release['release_time_s'],
                      finish_time_s=float(m[-1,0]),ball_weight_n=delivery.audit.ball_weight_n,
                      verified_free_ball=True,simulator_warning_count=report['warning_count'])
            report.update(play=profile['play'],release=release,strict_score=strict,
                          visual_closure_s=delivery.hands.closed_at,observed_ball=delivery.hands.trace,
                          quarterback_pass_score=score_throw_receive(contact,m[:,:5],release,strict['first_tip_contact_s'],physics_step_s=plant.model.opt.timestep),
                          anatomical_score=score_anatomical_catch(anatomical,release_time_s=release['release_time_s'],
                           finish_time_s=float(m[-1,0]),ball_weight_n=anatomy.ball_weight_n,form_rows=form_rows,motion=m,
                           physics_reference_match=metadata['physics_reference_match'],verified_free_ball=metadata['free_ball_joint_and_no_attachment_verified']))
            report['running_score']=score_running_long_pass(contact,m[:,:5],**arrays,strict_catch_score=strict,
                                    release_time_s=release['release_time_s'],gait_start_s=.4,pass_toward_receiver_xy=(-1.,0.))
            arrays['contact']=contact
        if grip is not None:arrays['native_hand']=np.asarray(grip.rows)
        if leg_residual is not None:
            arrays['leg_residual']=np.asarray(leg_residual.rows)
            arrays['leg_observation']=np.asarray(leg_residual.observations)
            report['learned_leg_residual']=dict(checkpoint_sha256=leg_residual.digest,device=leg_residual.device,
                                               learned_component='15 leg/waist position residuals; no catch training')
        a.output.mkdir(parents=True)
        np.savez_compressed(a.output/'trace.npz',motion=m,commands=commands,palms=palms,stem_observations=stem_observations,**arrays)
        stamps,qpos=zip(*views);np.savez_compressed(a.output/'view.npz',timestamps_s=stamps,qpos=qpos)
        np.savez_compressed(a.output/'anatomical-contact.npz',**anatomical)
        np.savez_compressed(a.output/'ball-contact-witness.npz',**contact_witness.arrays())
        if interhand is not None:
            np.savez_compressed(a.output/'interhand-geometry.npz',**interhand.arrays())
            report['interhand_geometry_audit']=interhand.summary()
        for name,value in [('report',report),('anatomical-metadata',metadata),('anatomical-form',form_rows)]:
            (a.output/(name+'.json')).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
        print(json.dumps({k:report[k]for k in ('duration_s','minimum_upright_cosine','max_stem_error_m')}))
        return report
    finally:plant.close()

if __name__=='__main__':run(build_parser().parse_args())
