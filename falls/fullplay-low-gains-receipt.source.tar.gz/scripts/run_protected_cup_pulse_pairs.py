"""Zero-exact preflight then bounded sensor-only anticipatory cup give."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import argparse,json,multiprocessing as mp,numpy as np
import probe_lower_cup_native_witness as runner
from g1_receiver.lower_cup_absorption import AnticipatoryCupGive
from run_native_cup_grip_screen import exact
REFERENCE='173bf57168f5f97d0471d7bfa0a05e067a00f1e27a385994f57f21998a30af15'

def run(job):
 root,profile,source,amp,label,gain,travel,lead=job;plan=json.loads(profile.read_text());callback=AnticipatoryCupGive(plan,gain=gain,max_give_m=travel,lead_s=lead,pulse_lead_s=.025);out=root/label;args=runner.build_parser().parse_args(['--source',str(source),'--amp-source',str(amp),'--profile',str(profile),'--output',str(out),'--walk-speed','1','--handoff-depth','1.3','--initial-yaw','-.7','--duration','9','--record-anatomical','--reference-physics-sha256',REFERENCE]);args.sensor_retention_pose_camera_position=(3.5,0.,1.4);args.sensor_retention_pose_camera_target=(6.5,0.,.9);r=runner.run(args,residual_callback=callback);(out/'give-trace.json').write_text(json.dumps(callback.rows,indent=2)+'\n');valid=[x['time_s']for x in callback.rows if x['fresh_rgbd_pose_and_velocity']];active=[x['time_s']for x in callback.rows if np.linalg.norm(x['actual_joint_residual_rad'])>1e-10];return dict(label=label,gain=gain,max_give_m=travel,lead_s=lead,first_valid_sensor_s=min(valid)if valid else None,first_nonzero_action_s=min(active)if active else None,max_joint_residual_rad=max(float(np.max(np.abs(x['actual_joint_residual_rad'])))for x in callback.rows),anatomical=r['anatomical_score'],self_geometry=r['interhand_geometry_audit'],host_gains_sha256=r['host_gains_sha256'])
def main():
 p=argparse.ArgumentParser()
 for n in ['source','amp-source','profile','output','reference']:p.add_argument('--'+n,type=Path,required=True)
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);donor=json.loads(a.profile.read_text());jobs=[]
 for dz in [0.,-.02,.02]:
  modified=json.loads(json.dumps(donor));modified['play']['quarterback_target_m'][2]+=dz
  modified['fixture_perturbation_eval_only']={'target_height_delta_m':dz,'policy_catch_plane_unchanged':True}
  profile=a.output/f'profile-{dz:+.2f}.json';profile.write_text(json.dumps(modified,indent=2)+'\n')
  for gain in [0.,.02]:jobs.append((a.output,profile,a.source,a.amp_source,f"dz{dz:+.2f}-gain{gain:.2f}",gain,.05,.15))
 rows=[]
 with ProcessPoolExecutor(max_workers=2,mp_context=mp.get_context('spawn'))as pool:
  for f in as_completed([pool.submit(run,j)for j in jobs]):rows.append(f.result());(a.output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
 matched=exact(a.reference,a.output/'dz+0.00-gain0.00')
 pulse_reference=a.reference.parent/'pulse02'
 (a.output/'zero-exact.json').write_text(json.dumps(dict(all_original_arrays=matched),indent=2)+'\n')
if __name__=='__main__':main()
