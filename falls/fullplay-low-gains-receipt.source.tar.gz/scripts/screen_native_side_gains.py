"""Serial zero-reference gate followed by three bounded learned-gain trials."""
import argparse,json,subprocess,sys
from pathlib import Path

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for n in ['source','amp-source','profile','model','output','reference-trace','reference-view']:p.add_argument('--'+n,type=Path,required=True)
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);rows=[]
 for gain in [0.,.25,.5,1.]:
  out=a.output/('gain-'+str(gain));cmd=[sys.executable,'scripts/probe_native_side_gain.py','--source',str(a.source),'--amp-source',str(a.amp_source),'--profile',str(a.profile),'--output',str(out),'--walk-speed','1','--handoff-depth','1.3','--initial-yaw','-.7','--duration','9','--record-anatomical','--reference-physics-sha256','173bf57168f5f97d0471d7bfa0a05e067a00f1e27a385994f57f21998a30af15','--gain',str(gain),'--sensor-retention-camera-position','6','-2.5','2.4','--sensor-retention-camera-target','7','0','1','--sensor-retention-pose-camera-position','3.5','0','1.4','--sensor-retention-pose-camera-target','6.5','0','.9']
  if gain:cmd+=['--model',str(a.model),'--device','cpu']
  else:cmd+=['--reference-trace',str(a.reference_trace),'--reference-view',str(a.reference_view)]
  subprocess.run(cmd,check=True);report=json.loads((out/'trial/report.json').read_text());sensor=json.loads((out/'sensor-summary.json').read_text());rows.append(dict(gain=gain,anatomical=report['anatomical_score'],legacy=report['quarterback_pass_score'],sensor=sensor,host_gains_sha256=report['host_gains_sha256']));(a.output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
if __name__=='__main__':main()
