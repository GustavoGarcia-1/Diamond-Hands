"""Predeclared model-assumption study; no training or adaptive parameter selection."""
import argparse,concurrent.futures,json,subprocess,sys
from pathlib import Path
import numpy as np
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--profile',type=Path,required=True);p.add_argument('--model',type=Path,required=True);p.add_argument('--source',type=Path,required=True);p.add_argument('--amp-source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
def case(label,tau,gain,unmodified=False):
 command=[sys.executable,str(a.root/'scripts/probe_ball_hand_contact_model.py'),'--frozen-root',str(a.root),'--profile',str(a.profile),'--model',str(a.model),'--source',str(a.source),'--amp-source',str(a.amp_source),'--output',str(a.output/label),'--timeconstant',str(tau),'--gain',str(gain),'--device','cuda']
 if unmodified:command+=['--unmodified']
 with (a.output/(label+'.log')).open('w')as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 return dict(label=label,timeconstant_s=tau,gain=gain,unmodified=unmodified,command=command,exit_code=r.returncode)
def run(jobs):
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
  result=list(pool.map(lambda j:case(*j),jobs))
 if any(r['exit_code']for r in result):(a.output/'failed-results.json').write_text(json.dumps(result,indent=2));raise RuntimeError('preserved failed cases')
 return result
def equal_arrays(first,second):
 result={}
 for name in ['trace.npz','view.npz','anatomical-contact.npz']:
  x=np.load(first/name);y=np.load(second/name);result[name]=dict(keys_equal=set(x.files)==set(y.files),arrays={k:bool(np.array_equal(x[k],y[k],equal_nan=True)if x[k].dtype.kind not in 'SU'else np.array_equal(x[k],y[k]))for k in x.files if k in y.files})
 return result
results=run([(f'original20-gain{g}',.02,g,True)for g in [0.,.5]])
results+=run([(f'pair20-gain{g}',.02,g,False)for g in [0.,.5]])
proof={str(g):equal_arrays(a.output/f'original20-gain{g}'/'rollout/episode-0001/trial',a.output/f'pair20-gain{g}'/'rollout/episode-0001/trial')for g in [0.,.5]}
exact=all(v['keys_equal']and all(v['arrays'].values())for p in proof.values()for v in p.values());(a.output/'pair20-exact-proof.json').write_text(json.dumps(dict(exact=exact,comparisons=proof),indent=2))
if not exact:(a.output/'results.json').write_text(json.dumps(results,indent=2));raise RuntimeError('pair20 structure does not exactly reproduce original; candidate study stopped')
results+=run([(f'pair{ms}-gain{g}',ms/1000,g,False)for ms in [10,5,2.5]for g in [0.,.5]])
(a.output/'results.json').write_text(json.dumps(results,indent=2)+'\n')
