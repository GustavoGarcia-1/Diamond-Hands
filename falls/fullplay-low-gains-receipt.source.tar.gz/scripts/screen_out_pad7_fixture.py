"""Offline finite-patch fixture search against exact recorded robot poses."""
import argparse,json
from pathlib import Path
import numpy as np,mujoco
from g1_receiver.aero import make_aero_scene
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
from g1_receiver.offline_cup_fixture import one_palm_seed
from g1_receiver.scrimmage_throw import ScrimmagePass
from g1_receiver.anatomical_catch_eval import AnatomicalContactAudit

def main():
 p=argparse.ArgumentParser()
 for n in ['source','trial','profile','calibration','velocity','output']:p.add_argument('--'+n,type=Path,required=True)
 a=p.parse_args();profile=json.loads(a.profile.read_text());cal=json.loads(a.calibration.read_text());vel=np.array(json.loads(a.velocity.read_text())['actual_per_hand_velocity_ols_mps']);arrival=profile['offline_fixture_arrival_s'];v=np.load(a.trial/'offline-robot-qpos.npz');m=mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT,a.source));d=mujoco.MjData(m);audit=AnatomicalContactAudit(m);ball=int(m.geom('football_surface').id);ba=int(m.joint('football_free').qposadr[0]);excluded=np.array([g for g in range(m.ngeom)if m.geom_bodyid[g]>0 and g!=ball and(m.geom_contype[g]or m.geom_conaffinity[g])and audit.kind[g]not in ['finger','thumb','palmar_candidate']],int);row=min(cal['poses'],key=lambda r:abs(r['time_s']-arrival));N=np.array([h['normal_world']for h in row['hands']]);rows=[]
 for T in [1.15,1.2,1.25]:
  for w in [-.035,-.0175,0.,.0175,.035]:
   for f in [-.01,0.,.01]:
    C,normal,description=one_palm_seed(profile,T,cal,'left',w,f);plan=ScrimmagePass(tuple(profile['play']['quarterback_origin_m']),tuple(C),T,horizontal_distance_only=True).plan(arrival-T);vn=np.sum((np.array(plan.intercept_velocity_mps)-vel)*N,axis=1);best=(.05,None,None)
    for now,q in zip(v['timestamps_s'],v['qpos']):
     if now<arrival-.25 or now>arrival+1e-8:continue
     elapsed=now-plan.release_time_s;center=np.array(plan.release_xyz_m)+elapsed*np.array(plan.release_velocity_mps)+[0,0,-4.905*elapsed*elapsed];d.qpos[:]=q;d.qpos[ba:ba+7]=np.r_[center,plan.release_quaternion_wxyz];mujoco.mj_kinematics(m,d);lower=np.linalg.norm(d.geom_xpos[excluded]-center,axis=1)-m.geom_rbound[excluded]-m.geom_rbound[ball]
     for g in excluded[lower<best[0]]:
      gap=float(mujoco.mj_geomDistance(m,d,ball,int(g),.05,None))
      if gap<best[0]:best=(gap,float(now),int(g))
    gap,time,g=best;rows.append(dict(flight_s=T,width_offset_m=w,finger_offset_m=f,target_m=C.tolist(),per_hand_normal_velocity_mps=vn.tolist(),minimum_excluded_gap_m=gap,minimum_time_s=time,minimum_body=None if g is None else m.body(int(m.geom_bodyid[g])).name,offline_eligible=bool(gap>=.01 and vn.max()<-.1 and vn[0]>=-1.5),fixture=description))
 result=dict(offline_only=True,not_a_catch_score=True,predeclared=dict(finite_patch_width_abs_max_m=.035,finger_axis_offsets_m=[-.01,.01],excluded_body_gap_min_m=.01,primary_normal_range_mps=[-1.5,-.1],other_palm_frontside=True),rows=rows);a.output.write_text(json.dumps(result,indent=2)+'\n');eligible=[r for r in rows if r['offline_eligible']];print(json.dumps(sorted(eligible,key=lambda r:(abs(r['per_hand_normal_velocity_mps'][0]+.6),-r['minimum_excluded_gap_m']))[:8],indent=2))
if __name__=='__main__':main()
