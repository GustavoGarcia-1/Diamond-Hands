"""Full closed-loop timestep sensitivity, fixed throw/controller/contact timeconstant."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import numpy as np


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('frozen-root', 'profile', 'source', 'amp-source', 'output', 'reference'):
        p.add_argument('--'+name, type=Path, required=True)
    p.add_argument('--fixed-servo', action='store_true')
    p.add_argument('--break-release-delay', type=float)
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    results = []
    for timestep in (.001, .0005, .00025):
        output = a.output/str(timestep)
        command = [sys.executable, 'scripts/run_out_contact_repair.py', '--case', 'pair25',
                   '--duration', '10', '--timestep', str(timestep), '--output', str(output)]
        if a.fixed_servo:
            command.append('--fixed-servo')
        if a.break_release_delay is not None:
            command += ['--break-release-delay', str(a.break_release_delay)]
        for name in ('frozen_root', 'profile', 'source', 'amp_source', 'reference'):
            command += ['--'+name.replace('_', '-'), str(getattr(a, name))]
        subprocess.run(command, check=True)
        if timestep == .001:
            checks = {}
            for filename in ('trace.npz', 'view.npz', 'anatomical-contact.npz', 'interhand-geometry.npz'):
                with np.load(output/'trial'/filename) as current, np.load(a.reference/filename) as reference:
                    row = {}
                    for key in reference.files:
                        old, new = reference[key], current[key]
                        if old.ndim and new.ndim == old.ndim and new.shape[0] >= old.shape[0]:
                            new = new[:old.shape[0]]
                        row[key] = bool(np.array_equal(old, new, equal_nan=True)) if old.dtype.kind not in 'US' else bool(np.array_equal(old, new))
                    checks[filename] = row
            (a.output/'extended-prefix-exact.json').write_text(json.dumps(checks, indent=2)+'\n')
            if not all(all(v.values()) for v in checks.values()):
                raise RuntimeError('1ms extension prefix differs; stop sensitivity tests')
        report = json.loads((output/'trial/report.json').read_text())
        results.append(dict(timestep_s=timestep, contact_timeconstant_s=.0025,
                            body_servo_hz=1000. if a.fixed_servo else 1./timestep,
                            break_release_delay_s=a.break_release_delay,
                            same_profile_controller_initial_conditions=True,
                            ball_flight_recalibrated=False, duration_s=10.,
                            anatomical=report['anatomical_score']))
        (a.output/'summary.json').write_text(json.dumps(results, indent=2)+'\n')


if __name__ == '__main__':
    main()
