"""Compare image-only football center estimates on archived camera replays."""
import argparse
import json
from pathlib import Path
import time
import numpy as np
import mujoco
from evaluate_aero_receiver import make_plant
from g1_receiver.routes import Route
from g1_receiver.perception import ColorBallDetector
from g1_receiver.ellipsoid_perception import EllipsoidBallDetector


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('source', 'trial', 'profile', 'output'):
        p.add_argument('--'+name, type=Path, required=True)
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    profile = json.loads(a.profile.read_text())
    plant = make_plant(a.source, Route('go', ((0.,0.),(9.144,0.),(12.,0.)), 2.),
        tracking_camera=((-1.,0.,1.5),(3.,0.,.9)), finish_camera=((5.,0.,1.5),(10.,0.,.9)),
        pass_camera=profile.get('pass_camera', ((6.,-4.,3.8),(9.,0.,1.5))),
        retention_camera=((6.,-2.5,2.4),(7.,0.,1.)), retention_pose_camera=((3.5,0.,1.4),(6.5,0.,.9)))
    baseline = ColorBallDetector(max_depth_m=20., ball_center_offset_m=.075)
    fitted = EllipsoidBallDetector(max_depth_m=20., ball_center_offset_m=.075)
    view = np.load(a.trial/'view.npz')
    rows = []
    try:
        for k in range(0,len(view['timestamps_s']),2):
            stamp = float(view['timestamps_s'][k])
            if not 4.3999 <= stamp <= 6.4001:
                continue
            plant.data.qpos[:] = view['qpos'][k]
            plant.data.time = stamp
            mujoco.mj_forward(plant.model, plant.data)
            # Truth is used only AFTER each estimator returns, for offline error.
            truth = plant.data.qpos[plant.ball_qpos:plant.ball_qpos+3].copy()
            for camera in ('pass','finish','retention'):
                frame, survey = plant.capture(camera)
                started = time.perf_counter()
                old = baseline.detect(frame, survey)
                old_ms = (time.perf_counter()-started)*1000
                started = time.perf_counter()
                new = fitted.detect(frame, survey)
                new_ms = (time.perf_counter()-started)*1000
                row = dict(time_s=stamp, camera=camera, baseline_detected=old is not None,
                    fitted_detected=new is not None, baseline_ms=old_ms, fitted_ms=new_ms)
                if old is not None and new is not None:
                    row.update(baseline_error_m=float(np.linalg.norm(old.position_m-truth)),
                        fitted_error_m=float(np.linalg.norm(new.position_m-truth)),
                        center_correction_m=(new.position_m-old.position_m).tolist(),
                        fit_applied=bool(np.linalg.norm(new.position_m-old.position_m)>1e-9),
                        uncertainty_not_reduced=bool(np.linalg.eigvalsh(new.covariance_m2-old.covariance_m2).min()>=-1e-12),
                        baseline_position_m=old.position_m.tolist(), fitted_position_m=new.position_m.tolist(),
                        offline_truth_m=truth.tolist())
                rows.append(row)
        result = dict(scope='Offline image-only perception diagnostic. Pose replay generates RGB-D; exact ball center is evaluation-only and never passed to either detector. No controller/training changes.',
            trial=str(a.trial), profile=str(a.profile), frames=rows)
        (a.output/'report.json').write_text(json.dumps(result, indent=2)+'\n')
        pairs = [r for r in rows if 'baseline_error_m' in r]
        summary = dict(total_views=len(rows), valid_pairs=len(pairs), applied=sum(r['fit_applied'] for r in pairs),
            median_baseline_error_mm=1000*float(np.median([r['baseline_error_m'] for r in pairs])) if pairs else None,
            median_fitted_error_mm=1000*float(np.median([r['fitted_error_m'] for r in pairs])) if pairs else None,
            maximum_fitted_error_mm=1000*max((r['fitted_error_m'] for r in pairs),default=0),
            median_fit_latency_ms=float(np.median([r['fitted_ms'] for r in rows])),
            p95_fit_latency_ms=float(np.quantile([r['fitted_ms'] for r in rows],.95)),
            sensor_uncertainty_not_reduced=all(r['uncertainty_not_reduced'] for r in pairs))
        (a.output/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
        print(json.dumps(summary, indent=2))
    finally:
        plant.close()


if __name__ == '__main__':
    main()
