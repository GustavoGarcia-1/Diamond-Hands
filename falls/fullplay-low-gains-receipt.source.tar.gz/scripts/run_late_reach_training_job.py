"""Freeze the isolated late-reach runtime, preflight its queues, then train."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--wall-seconds', type=int, default=2700)
    p.add_argument('--workers', type=int, default=2)
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    config = json.loads(a.config.read_text())
    original_root = Path(config['frozen_root'])
    profile = json.loads(Path(config['profile']).read_text())
    if profile.get('late_cup', {}).get('enabled') is not True:
        raise ValueError('Training requires an enabled late-reach actuator, not observer-only mode')
    overlay = Path(__file__).resolve().parents[1]
    runtime = a.output/'runtime'
    for folder in ('src', 'scripts'):
        shutil.copytree(original_root/folder, runtime/folder,
                        ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    for name in ('src/g1_receiver/late_reach_rl.py', 'src/g1_receiver/rgbd_impairments.py', 'scripts/train_out_late_reach.py',
                 'scripts/run_out_late_cup_episode.py'):
        shutil.copy2(overlay/name, runtime/name)
    shutil.copy2(config['profile'], runtime/'profile.json')
    config.update(frozen_root=str(runtime), profile=str(runtime/'profile.json'))
    config_path = a.output/'runtime-config.json'
    config_path.write_text(json.dumps(config, indent=2)+'\n')
    hashes = {str(f.relative_to(runtime)): hashlib.sha256(f.read_bytes()).hexdigest()
              for f in sorted(runtime.rglob('*')) if f.is_file()}
    (a.output/'runtime-hashes.json').write_text(json.dumps(hashes, indent=2)+'\n')
    with tarfile.open(a.output/'runtime-source.tar.gz', 'x:gz') as archive:
        for name in hashes:
            archive.add(runtime/name, arcname=name)
    env = {**os.environ, 'PYTHONPATH': str(runtime/'src')+os.pathsep+str(runtime/'scripts')}
    command = [sys.executable, str(runtime/'scripts/train_out_late_reach.py'),
               '--config', str(config_path), '--driver', 'run_out_late_cup_episode']
    subprocess.run(command+['--zero', '--output', str(a.output/'zero-preflight')],
                   cwd=runtime, env=env, check=True, timeout=240)
    zero = json.loads((a.output/'zero-preflight/evaluation.json').read_text())
    if zero['sensor_coverage']['forecast_over_half_second'] == 0:
        raise RuntimeError('No early visual forecast; refusing to train a blind late reach')
    if zero['sensor_coverage']['visible'] == 0:
        raise RuntimeError('No reward-qualified visual captures; repair confidence before training')
    subprocess.run(command+['--output', str(a.output/'ppo'), '--workers', str(a.workers),
                            '--wall-seconds', str(a.wall_seconds)],
                   cwd=runtime, env=env, check=True, timeout=a.wall_seconds+300)
    subprocess.run(command+['--evaluate', str(a.output/'ppo/final.zip'),
                            '--output', str(a.output/'final-evaluation')],
                   cwd=runtime, env=env, check=True, timeout=240)


if __name__ == '__main__':
    main()
