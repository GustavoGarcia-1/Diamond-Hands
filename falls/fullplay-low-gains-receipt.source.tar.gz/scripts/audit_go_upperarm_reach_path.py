"""Static collision screen of compact→cup joint interpolation; no dynamics."""
from pathlib import Path
import json
import numpy as np,mujoco
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
P=Path('reports/catch-repair-20261114');O=P/'go-side-cup';cup=json.load(open(O/'upperarm-x35-y20.json'));ready=json.load(open(O/'compact-upperarm.json'));x=(P/'contact-model/study-linux/artifacts/study/original20-gain0.5/scene.xml').read_text().replace('/workspace/g1-receiver-runs/catch-repair-contact-model-20261114-r1/source/src/g1_receiver/_vendor/g1_runtime',str(DEFAULT_RUNTIME_ROOT)).replace('/workspace/g1-receiver-runs/out-scrimmage-20261113/source/aero-source','/tmp/g1-aero-source');m=mujoco.MjModel.from_xml_string(x);d=mujoco.MjData(m);a=np.load(P/'validation/protected-witness-linux/witness/offline-robot-qpos.npz');base=a['qpos'][np.argmin(abs(a['timestamps_s']-5.18))].copy();q=np.load(P/'out-cup/right-up-margin-dry-r1/artifacts/trial/offline-robot-qpos.npz');native=q['qpos'][np.argmin(abs(q['timestamps_s']-6.2))]
for j in range(m.njnt):
 n=m.joint(j).name
 if n.startswith('aero_'):
  other=n.replace('left','TEMP').replace('right','left').replace('TEMP','right');base[int(m.jnt_qposadr[j])]=native[int(m.jnt_qposadr[m.joint(other).id])]
base[int(m.joint('waist_yaw_joint').qposadr[0])]=cup['waist_yaw_rad'];ad=np.array([m.joint(n).qposadr[0]for n in cup['arm_order']],dtype=int);active=[g for g in range(m.ngeom)if m.geom_contype[g]or m.geom_conaffinity[g]];body=lambda g:m.body(int(m.geom_bodyid[g])).name;L=[g for g in active if body(g).startswith(('aero_left_','left_'))and not any(s in body(g)for s in['hip','knee','ankle'])];R=[g for g in active if body(g).startswith(('aero_right_','right_'))and not any(s in body(g)for s in['hip','knee','ankle'])];torso=[g for g in active if body(g)in['pelvis','torso_link','waist_yaw_link','waist_roll_link','waist_pitch_link','head_link']];pairs=[(l,r)for l in L for r in R]+[(g,t)for g in L+R for t in torso ];
# Mirror engine body/weld/parent and explicit-exclusion filtering; include nonadjacent SHOULDER colliders.
excluded=set(map(int,m.exclude_signature));filtered=[]
for g,h in pairs:
 b1,b2=int(m.geom_bodyid[g]),int(m.geom_bodyid[h]);w1,w2=int(m.body_weldid[b1]),int(m.body_weldid[b2]);signature=(min(b1,b2)<<16)+max(b1,b2)
 if w1==w2 or signature in excluded:continue
 if int(m.body_weldid[int(m.body_parentid[w1])])==w2 or int(m.body_weldid[int(m.body_parentid[w2])])==w1:continue
 filtered.append((g,h))
pairs=filtered;minimum={};rows=[]
for phase in np.linspace(0,1,31):
 d.qpos[:]=base;d.qpos[ad]=(1-phase)*np.array(ready['arm_targets_rad'])+phase*np.array(cup['arm_targets_rad']);mujoco.mj_kinematics(m,d);best=dict(distance_m=.05)
 for g,h in pairs:
  if np.linalg.norm(d.geom_xpos[g]-d.geom_xpos[h])-m.geom_rbound[g]-m.geom_rbound[h]>.05:continue
  gap=float(mujoco.mj_geomDistance(m,d,g,h,.05,None))
  if gap<best['distance_m']:best=dict(distance_m=gap,g=g,h=h,body1=body(g),body2=body(h),geom1=m.geom(g).name or f'geom-{g}',geom2=m.geom(h).name or f'geom-{h}')
 rows.append(dict(phase=float(phase),**best))
report=dict(offline_only=True,no_dynamic_claim=True,minimum=min(rows,key=lambda x:x['distance_m']),phases=rows);(O/'upperarm-reach-path.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['minimum']))
