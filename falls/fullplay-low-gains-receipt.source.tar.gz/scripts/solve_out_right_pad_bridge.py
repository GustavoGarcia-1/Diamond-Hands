"""Offline right-arm finite-pad IK; left arm, base, torso and throw are fixed."""
import argparse
import json
from pathlib import Path

import mujoco
import numpy as np
from scipy.optimize import least_squares

from g1_receiver.aero import make_aero_scene
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
from g1_receiver.scrimmage_throw import ScrimmagePass


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ['source', 'trial', 'profile', 'output']:
        parser.add_argument('--'+name, type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    profile = json.loads(args.profile.read_text())
    model = mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT, args.source))
    data = mujoco.MjData(model)
    poses = np.load(args.trial/'offline-robot-qpos.npz')
    index = int(np.argmin(abs(poses['timestamps_s']-6.2)))
    data.qpos[:] = poses['qpos'][index]
    fixed_qpos = data.qpos.copy()
    names = profile['static_lower_pose']['arm_order'][7:]
    addresses = np.array([int(model.joint(n).qposadr[0]) for n in names])
    seed = data.qpos[addresses].copy()
    limits = np.array([model.joint(n).range.copy() for n in names])
    ball_center = np.array(profile['play']['quarterback_target_m'])
    plan = ScrimmagePass(tuple(profile['play']['quarterback_origin_m']), tuple(ball_center),
        profile['play']['flight_s'], align_ball_to_launch=not profile['play'].get('quarterback_level_ball', False),
        horizontal_distance_only=True).plan(profile['play']['release_s'])
    rotation = np.empty(9)
    mujoco.mju_quat2Mat(rotation, np.array(plan.release_quaternion_wxyz))
    rotation = rotation.reshape(3, 3)
    shape = rotation @ np.diag(np.array([.142, .085, .085])**2) @ rotation.T
    pad = model.geom('aero_right_palm_collision_7').id
    mujoco.mj_kinematics(model, data)
    initial_rotation = data.geom_xmat[pad].reshape(3, 3).copy()
    body_normal = -data.body('aero_right_palm').xmat.reshape(3, 3)[:, 1]
    axis = int(np.argmax(abs(initial_rotation.T@body_normal)))
    sign = float(np.sign((initial_rotation.T@body_normal)[axis]))
    collidable = [g for g in range(model.ngeom) if model.geom_contype[g] or model.geom_conaffinity[g]]
    sides = {s: [g for g in collidable if model.body(int(model.geom_bodyid[g])).name.startswith('aero_'+s+'_')] for s in ['left', 'right']}
    proximal = [g for g in collidable if any(model.body(int(model.geom_bodyid[g])).name.startswith('right_'+part) for part in ['shoulder_roll', 'shoulder_yaw', 'elbow', 'wrist'])]
    torso = [g for g in collidable if model.body(int(model.geom_bodyid[g])).name == 'torso_link']
    pairs = np.array([(i, j) for i in sides['left'] for j in sides['right']]+[(i, j) for i in proximal for j in torso], int)
    hand_count = len(sides['left'])*len(sides['right'])

    def geometry(q):
        data.qpos[:] = fixed_qpos
        data.qpos[addresses] = q
        mujoco.mj_kinematics(model, data)
        rot = data.geom_xmat[pad].reshape(3, 3).copy()
        normal = sign*rot[:, axis]
        face = data.geom_xpos[pad]+model.geom_size[pad, axis]*normal
        target = ball_center-shape@normal/np.sqrt(normal@shape@normal)
        lower = np.linalg.norm(data.geom_xpos[pairs[:, 0]]-data.geom_xpos[pairs[:, 1]], axis=1)-model.geom_rbound[pairs[:, 0]]-model.geom_rbound[pairs[:, 1]]
        gaps = np.full(len(pairs), .05)
        for k in np.flatnonzero(lower < .006):
            i, j = pairs[k]
            gaps[k] = mujoco.mj_geomDistance(model, data, int(i), int(j), .05, None)
        return face, target, normal, rot, gaps

    rows = []
    for bound in [.35, .6, .9]:
        low = np.maximum(limits[:, 0]+.03, seed-bound)
        high = np.minimum(limits[:, 1]-.03, seed+bound)

        def residual(q):
            face, target, normal, rot, gaps = geometry(q)
            return np.r_[(face-target)/.004, (rot-initial_rotation).ravel()/.3,
                np.maximum(0., .006-gaps)/.0005, max(0., .62-normal[2])/.01, .02*(q-seed)]

        fit = least_squares(residual, np.clip(seed, low+1e-7, high-1e-7), bounds=(low, high), max_nfev=300)
        face, target, normal, rot, gaps = geometry(fit.x)
        error = float(np.linalg.norm(face-target))
        row = dict(max_right_joint_change_rad=bound, success=bool(fit.success), right_arm_order=names,
            right_joint_delta_rad=(fit.x-seed).tolist(), right_joint_target_rad=fit.x.tolist(),
            finite_pad_center_error_m=error, actual_face_world_m=face.tolist(),
            desired_face_world_m=target.tolist(), actual_pad_normal=normal.tolist(),
            minimum_interhand_gap_m=float(gaps[:hand_count].min()),
            minimum_right_proximal_torso_gap_m=float(gaps[hand_count:].min()),
            eligible_for_dynamic_preflight=bool(error <= .005 and gaps.min() >= .005 and normal[2] >= .6),
            remaining_gates='Static only. Incoming ball/finger clearance, whole gesture sweep, dynamic balance, actuator readiness and physical catch must still be verified.')
        rows.append(row)
        print(json.dumps(row), flush=True)
    args.output.write_text(json.dumps(dict(scope=__doc__, offline_only=True,
        source_trial=str(args.trial), template_time_s=float(poses['timestamps_s'][index]),
        fixed_ball_center_m=ball_center.tolist(), criteria=dict(pad_error_max_m=.005,
        interhand_and_proximal_torso_gap_min_m=.005, pad_up_min=.6, mechanical_margin_rad=.03), rows=rows), indent=2)+'\n')


if __name__ == '__main__':
    main()
