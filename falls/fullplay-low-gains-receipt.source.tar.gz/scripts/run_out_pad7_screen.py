"""Bounded first physical-pad Out screen; unchanged route, model and rates."""
from pathlib import Path
from copy import deepcopy
import argparse,json
import numpy as np
import probe_out_native_lower as runner
REF='173bf57168f5f97d0471d7bfa0a05e067a00f1e27a385994f57f21998a30af15'
def argv(a,profile,out):
 return ['--source',str(a.source),'--amp-source',str(a.amp_source),'--output',str(out),'--duration','8','--approach-handoff-depth-m','2.1','--cut-speed','1.4','--blend-s','.5','--turn-s','.4','--hold-straight-s','0','--depth-feedback-gain','4','--camera-start-s','.8','--stopping-lookahead-s','.55','--reverse-speed','0','--approach-speed','.48','--horizontal-pass-distance','--pass-profile',str(profile),'--record-poses','--record-anatomical','--reference-physics-sha256',REF]
def main():
 p=argparse.ArgumentParser()
 for n in ['source','amp-source','profile','output']:p.add_argument('--'+n,type=Path,required=True)
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);donor=json.loads(a.profile.read_text());rows=[]
 for index,(preload,open_thumb)in enumerate((c,o)for c in [.3,.5,.7]for o in [False,True]):
  profile=deepcopy(donor);cfg=profile['native_grip'];cfg['preload'][:4]=[preload]*4
  if open_thumb:cfg['preload'][4]=0.;cfg['digit_delay_s'][4]=.20
  path=a.output/f'profile-{index:02d}.json';path.write_text(json.dumps(profile,indent=2)+'\n');out=a.output/f'case-{index:02d}';runner.main(argv(a,path,out));r=json.loads((out/'report.json').read_text());score=r['anatomical_score'];meta=json.loads((out/'anatomical-metadata.json').read_text());valid={int(x['geom_id'])for x in meta['geometry_classification']if x['category']in ['finger','thumb','palmar_candidate']};z=np.load(out/'ball-contact-witness.npz');w=z['ball_contact_witness'];cutoff=score['first_excluded_support_s'];end=float('inf')if cutoff is None else cutoff;native=w[(w[:,0]<end)&np.isin(w[:,1].astype(int),list(valid))];first=score['first_anatomical_contact_s'];entry=native if first is None else native[native[:,0]<=first+.2];peak=None if not len(entry)else entry[np.argmin(entry[:,3])];motion=np.load(out/'trace.npz')['motion'];v=np.diff(motion[:,1:3],axis=0)/np.diff(motion[:,0])[:,None];f=np.sum(v*np.stack([np.cos(motion[:-1,5]),np.sin(motion[:-1,5])],1),1);post=motion[:-1,0]>=r['break_at_s'];result=dict(case=index,normalized_native_finger_preload=preload,thumb_entry_open=open_thumb,visual_closure_s=r['visual_closure_s'],anatomical=score,entry_hand_overlap_m=None if peak is None else float(-peak[3]),entry_peak_geom=None if peak is None else str(z['geom_names'][int(peak[1])]),body_forward_min_after_break_mps=float(f[post].min()),negative_body_forward_duration_s=float(np.sum(f[post]<0)*.02),minimum_upright_cosine=r['minimum_upright_cosine'],maximum_downfield_overshoot_m=r['maximum_downfield_overshoot_m'],host_gains_sha256=r['host_gains_sha256']);rows.append(result);(a.output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
