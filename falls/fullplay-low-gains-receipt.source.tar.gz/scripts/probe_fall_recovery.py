"""Predeclared matched SIM-only stumble/full-fall supervision experiment."""
import argparse,json,hashlib
from dataclasses import asdict
from pathlib import Path
import numpy as np,mujoco
from g1_receiver.hand_route_plant import HandRoutePlant
from g1_receiver.aero import aero_ready_joint_targets
from g1_receiver.runtime import RobotObservation,SkillGoal
from g1_receiver.fall_supervisor import FallSupervisor,FallConfig

FIXTURES=[('mild-forward',.12,.3),('mild-backward',-.12,-.3),('moderate-forward',.25,.8),('moderate-backward',-.25,-.8),('full-forward',.65,2.),('full-backward',-.65,-2.)]

def trial(source,output,pitch,angular_velocity,mode,duration):
 output.mkdir(parents=True,exist_ok=False);plant=HandRoutePlant(source,hand_model='aero',survey_camera=False)
 try:
  upper=aero_ready_joint_targets(plant.nominal,plant.joint_names);plant.reset(joint_positions=upper,release_position_m=(8.,4.,.085),closure=.2);model=plant.model;floor=model.geom('floor').id;ball=model.geom('football_surface').id
  # Offline prescribed initial condition only. Put the lowest actual collision surface3mm above floor.
  plant.data.qpos[plant.base+3:plant.base+7]=(np.cos(pitch/2),0.,np.sin(pitch/2),0.);plant.data.qvel[plant.base+3:plant.base+6]=(0.,angular_velocity,0.);mujoco.mj_forward(model,plant.data)
  robot=[i for i in range(model.ngeom)if i!=ball and model.geom_bodyid[i]>0 and(model.geom_contype[i]or model.geom_conaffinity[i])]
  gap=min(mujoco.mj_geomDistance(model,plant.data,floor,i,2.,None)for i in robot);plant.data.qpos[plant.base+2]+=.003-gap;mujoco.mj_forward(model,plant.data);initial_gap=min(mujoco.mj_geomDistance(model,plant.data,floor,i,2.,None)for i in robot);assert initial_gap>=.00299
  initial=plant.data.qpos.copy();initialv=plant.data.qvel.copy();cfg=FallConfig()if mode!='crouch_tuck'else FallConfig(mode='crouch_tuck',severe_upright_cos=.84,warning_upright_cos=.96,warning_gyro_rad_s=1.8);supervisor=FallSupervisor(plant.joint_names,plant.joint_ranges,upper,cfg);poses=[];stamps=[];forces=[];motion=[];actual=[];work=np.zeros(6);group={};foot={}
  for i in robot:
   body=model.body(int(model.geom_bodyid[i])).name;mesh=model.mesh(int(model.geom_dataid[i])).name if model.geom_type[i]==mujoco.mjtGeom.mjGEOM_MESH else'';group[i]='head'if'head'in mesh else'hand'if body.startswith('aero_')else'torso'if body=='torso_link'else'other';foot[i]=body.endswith('ankle_roll_link')
  def audit(data):
   normal=np.zeros(4);nonfoot=0.
   for j,c in enumerate(data.contact):
    a,b=map(int,c.geom)
    if a==floor:g=b
    elif b==floor:g=a
    else:continue
    if g not in group:continue
    mujoco.mj_contactForce(model,data,j,work);normal[['head','hand','torso','other'].index(group[g])]+=max(0.,work[0]);nonfoot+=0. if foot[g]else max(0.,work[0])
   forces.append(np.r_[data.time,normal,nonfoot]);base=data.qpos[plant.base:plant.base+7];motion.append(np.r_[data.time,base[:3],1.-2.*(base[4]**2+base[5]**2),data.qvel[plant.base:plant.base+6]]);actual.append(np.r_[data.time,data.ctrl[plant.body_actuators]])
  for tick in range(round(duration/.02)+1):
   now=plant.timestamp_s;obs=RobotObservation(now,*plant.observe(),np.zeros(29),None)
   if tick%2==0 or tick==round(duration/.02):stamps.append(now);poses.append(plant.data.qpos.copy())
   if tick==round(duration/.02):break
   aborted=supervisor.observe(obs)if mode!='baseline'else False
   speed=.4 if now<duration-3. else 0.
   if mode=='balance_abort'and aborted:speed=0.
   command=plant.wbc.act(obs,SkillGoal(base_velocity=np.array([speed,0.,0.]),base_height=.74),upper)
   if mode!='baseline':command=supervisor.apply(obs,command)
   plant.step(command,closure=.2,post_step=audit)
  f=np.asarray(forces);m=np.asarray(motion);u=np.asarray(actual);metrics={}
  for k,name in enumerate(['head','hand','torso','other']):
   active=np.flatnonzero(f[:,k+1]>.1);start=None if len(active)==0 else float(f[active[0],0]);window=np.zeros(len(f),bool)if start is None else(f[:,0]>=start)&(f[:,0]<=start+.15);metrics[name]=dict(first_floor_force_s=start,peak_sum_normal_n=float(f[:,k+1].max()),first150ms_normal_impulse_ns=float(f[window,k+1].sum()*model.opt.timestep))
  last=m[m[:,0]>=duration-2];stable=(last[:,3]>.65)&(last[:,4]>.9)&(np.linalg.norm(last[:,5:7],axis=1)<.15)&(np.linalg.norm(last[:,8:11],axis=1)<.35);standing=bool(len(last)>1000 and stable.all());nf=np.flatnonzero(f[:,5]>.1);fell=bool(len(nf));label='fallen_then_stable_standing'if fell and standing else'stumble_recovery'if standing else'not_recovered'
  report=dict(scope='SIMONLYsensor-supervisedabort. No trainedfallpolicy/getup orhardwareclaim.',mode=mode,initial_pitch_rad=pitch,initial_angular_velocity_rad_s=angular_velocity,duration_s=float(m[-1,0]),minimum_initial_floor_gap_m=float(initial_gap),initial_pelvis_height_m=float(initial[plant.base+2]),supervisor_trigger_s=supervisor.triggered_at,supervisor_config=asdict(cfg),impacts_evaluation_only=metrics,first_nonfoot_floor_force_s=None if not fell else float(f[nf[0],0]),stable_standing_final2s=standing,recovery_label=label,final_pelvis_height_m=float(m[-1,3]),final_upright_cos=float(m[-1,4]),minimum_pelvis_height_m=float(m[:,3].min()),joint_gain_and_effort_clamps_unchanged=True,actual_body_torque_within_original_limits=bool(np.all(u[:,1:]>=plant._effort_min-1e-9)and np.all(u[:,1:]<=plant._effort_max+1e-9)),no_midplay_state_overwrite=True,no_active_external_push=True,head_geometry='head_link collisionmesh weldedtorso_link',physics_timestep_s=float(model.opt.timestep),warning_count=sum(int(w.number)for w in plant.data.warning),scene_xml_sha256=hashlib.sha256(plant.scene_xml.encode()).hexdigest(),initial_state_sha256=hashlib.sha256(np.r_[initial,initialv].tobytes()).hexdigest(),source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
  np.savez_compressed(output/'view.npz',timestamps_s=stamps,qpos=poses);np.savez_compressed(output/'trace.npz',floor_forces=f,motion=m,body_actual_control=u);(output/'report.json').write_text(json.dumps(report,indent=2)+'\n');(output/'supervisor.json').write_text(json.dumps(supervisor.rows,indent=2)+'\n');return report
 finally:plant.close()

def main():
 p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--duration',type=float,default=12.);p.add_argument('--smoke',action='store_true');a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);rows=[];fixtures=FIXTURES[:1]if a.smoke else FIXTURES;duration=2. if a.smoke else a.duration
 (a.output/'protocol.json').write_text(json.dumps(dict(hypothesis='IMU-triggeredzero-velocitybalanceabort may improve moderate stumblerecovery; latecrouchtuck mayredistributecriticalimpacts. No successassumed.',fixtures=fixtures,modes=['baseline','balance_abort','crouch_tuck'],duration_s=duration,initial_placement='allcollidablerobotgeometryminfloorclearance3mm, offlineresetonly',recovery_definition='final2s pelvis>.65m/up>.9/planarspeed<.15mps/angularspeed<.35radps; no nonfootfloor=>stumbleonly, otherwisefallen-recovery ifactualachieved',selection='All18fixedcasesreported, no adaptiveparametersearch'),indent=2)+'\n')
 for label,pitch,velocity in fixtures:
  pair=[]
  for mode in ['baseline','balance_abort','crouch_tuck']:
   r=trial(a.source,a.output/(label+'-'+mode),pitch,velocity,mode,duration);rows.append(dict(case=label+'-'+mode,**r));pair.append(r);(a.output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
  assert len({r['initial_state_sha256']for r in pair})==1 and len({r['scene_xml_sha256']for r in pair})==1
if __name__=='__main__':main()
