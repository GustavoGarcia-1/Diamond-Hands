"""Independent offline checks of the frozen sensor-relative Out servo screen."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import mujoco
import numpy as np
from g1_receiver.anatomical_catch_eval import score_anatomical_catch
from g1_receiver.running_catch_eval import score_running_long_pass

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT/'reports/catch-repair-20261114/out-cup'


def main():
    rows = []
    identities = []
    for name in ('000', '025', '050'):
        base = BASE/f'relative-servo-{name}-r1/artifacts/rollout'
        trial = base/'trial'
        report = json.loads((trial/'report.json').read_text())
        meta = json.loads((trial/'anatomical-metadata.json').read_text())
        form = json.loads((trial/'anatomical-form.json').read_text())
        trace = dict(np.load(trial/'trace.npz'))
        contacts = dict(np.load(trial/'anatomical-contact.npz'))
        score = score_anatomical_catch(contacts, release_time_s=report['release']['release_time_s'],
            finish_time_s=report['duration_s'], ball_weight_n=meta['ball_weight_n'], form_rows=form,
            motion=trace['motion'], physics_reference_match=meta['physics_reference_match'],
            verified_free_ball=meta['free_ball_joint_and_no_attachment_verified'])
        assert score == report['anatomical_score'], name
        scene = ET.fromstring((base/'scene.xml').read_text())
        assert scene.find('.//body[@name="football"]/freejoint') is not None
        assert not any('football' in str(e.attrib) for e in scene.findall('./equality/*'))
        scene.find('compiler').set('meshdir', str(ROOT/'src/g1_receiver/_vendor/g1_runtime/assets/robot/meshes'))
        for element in scene.iter():
            f = element.get('file')
            if f and '/aero-source/' in f:
                element.set('file', '/tmp/g1-aero-source/'+f.split('/aero-source/', 1)[1])
        model = mujoco.MjModel.from_xml_string(ET.tostring(scene, encoding='unicode'))
        qadr = int(model.joint('football_free').qposadr[0])
        view = dict(np.load(trial/'view.npz'))
        before = view['timestamps_s'] < report['release']['release_time_s']-1e-8
        pre = view['qpos'][before, qadr:qadr+3]
        assert len(pre) and np.max(np.ptp(pre, axis=0)) == 0.
        assert np.max(np.abs(pre-np.asarray(report['release']['release_xyz_m']))) < 1e-10
        columns = {k:i for i,k in enumerate(contacts['anatomical_contact_columns'])}
        load = contacts['anatomical_contact'][:, columns['applied_ball_load']]
        assert not np.any(load)
        heading = report['field_heading_rad']
        outside = report['outside_sign']*np.array([-np.sin(heading), np.cos(heading)])
        running = score_running_long_pass(trace['contact'], trace['motion'][:, :5],
            trace['foot_time_s'], trace['foot_floor_contact'], trace['robot_floor_contact'],
            trace['sole_clearance_m'], strict_catch_score=report['catch_score'],
            release_time_s=report['release']['release_time_s'], forward_xy=outside)
        identities.append(meta['physics_parameters'])
        rows.append(dict(case=name, score_exact=True, score=score, running=running,
            prerelease_stationary_frames=len(pre), football_free_joint=True,
            no_attachment=True, applied_load_samples=int(np.count_nonzero(load)),
            stable_acquisition_delay_s=(score['longest_clean_start_s']-score['first_anatomical_contact_s']
                                       if score['longest_clean_start_s'] is not None else None),
            source=str(base.relative_to(ROOT)),
            report_sha256=hashlib.sha256((trial/'report.json').read_bytes()).hexdigest()))
    assert all(identity == identities[0] for identity in identities)
    output = ROOT/'reports/catch-repair-20261114/validation/out-relative-servo-independent.json'
    output.write_text(json.dumps(dict(rows=rows, matched_physics_parameters=True,
        limitations=['Explicit 2.5 ms contact model is uncalibrated.',
                     'Sampled prerelease poses verify position, not unrecorded velocity.',
                     'Successful retention does not establish acquisition form, running, or hardware transfer.']), indent=2)+'\n')
    print(json.dumps([dict(case=r['case'], hold_s=r['score']['longest_clean_bilateral_s'],
        form=r['score']['form']['joint_form_fraction'], running=r['running']['running_at_catch'],
        forward_speed=r['running']['pre_tip_forward_speed_mps']) for r in rows]))


if __name__ == '__main__':
    main()
