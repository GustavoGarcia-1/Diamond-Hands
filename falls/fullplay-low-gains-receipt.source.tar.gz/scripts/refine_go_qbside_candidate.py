"""Bounded FK refinement of the balanced-approach cup with explicit wrist clearance."""
from pathlib import Path
import json,time,argparse
import mujoco,numpy as np
from scipy.optimize import least_squares
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
parser=argparse.ArgumentParser();parser.add_argument('--shift-x',type=float,default=0.);parser.add_argument('--shift-y',type=float,default=0.);parser.add_argument('--output-name',default='upperarm-clear-candidate.json');args=parser.parse_args();P=Path('reports/catch-repair-20261114');O=P/'go-side-cup';source=O/'static-up72-yaw-20.json';r=json.load(open(source))['results'][3];s=(P/'contact-model/study-linux/artifacts/study/original20-gain0.5/scene.xml').read_text().replace('/workspace/g1-receiver-runs/catch-repair-contact-model-20261114-r1/source/src/g1_receiver/_vendor/g1_runtime',str(DEFAULT_RUNTIME_ROOT)).replace('/workspace/g1-receiver-runs/out-scrimmage-20261113/source/aero-source','/tmp/g1-aero-source');m=mujoco.MjModel.from_xml_string(s);d=mujoco.MjData(m);a=np.load(P/'validation/protected-witness-linux/witness/offline-robot-qpos.npz');base=a['qpos'][np.argmin(abs(a['timestamps_s']-5.18))].copy();q=np.load(P/'out-cup/right-up-margin-dry-r1/artifacts/trial/offline-robot-qpos.npz');native=q['qpos'][np.argmin(abs(q['timestamps_s']-6.2))]
for j in range(m.njnt):
 n=m.joint(j).name
 if n.startswith('aero_'):
  other=n.replace('left','TEMP').replace('right','left').replace('TEMP','right');base[int(m.jnt_qposadr[j])]=native[int(m.jnt_qposadr[m.joint(other).id])]
base[int(m.joint('waist_yaw_joint').qposadr[0])]=r['waist_yaw_rad'];ids=np.array([m.joint(n).id for n in r['arm_order']]);ad=m.jnt_qposadr[ids];lo=m.jnt_range[ids,0]+.08;hi=m.jnt_range[ids,1]-.08;seed=np.clip(r['arm_targets_rad'],lo+1e-6,hi-1e-6);pads=[m.geom('aero_'+s+'_palm_collision_7').id for s in['left','right']];palms=[m.body('aero_'+s+'_palm').id for s in['left','right']];targets=[{k:np.array(v)for k,v in t.items()}for t in r['targets']];pairs=[(50,42),(52,42),(157,42),(159,42),(58,163),(58,165),(58,167),(56,163),(56,165),(60,163),(60,165),(54,42)];shift=np.array([args.shift_x,args.shift_y,0.]);r['cup_center_pelvis_yaw_frame_m']=(np.array(r['cup_center_pelvis_yaw_frame_m'])+shift).tolist();
for target in targets:target['pos']+=shift
start=time.monotonic()
def fk(q):
 d.qpos[:]=base;d.qpos[ad]=q;mujoco.mj_kinematics(m,d);rows=[]
 for g,b,sign in zip(pads,palms,[1,-1]):
  F=d.geom_xmat[g].reshape(3,3);rows.append(dict(pos=d.geom_xpos[g]+m.geom_size[g,0]*F[:,0],normal=F[:,0].copy(),long=F[:,2].copy(),body_normal=d.xmat[b].reshape(3,3)@np.array([0,sign,0])))
 return rows
def objective(q):
 if time.monotonic()-start>45:raise TimeoutError('45secondboundedrefinement')
 f=fk(q);v=[]
 for a,b in zip(f,targets):v.extend(200*(a['pos']-b['pos']));v.extend(3*(a['normal']-b['normal']));v.extend(2*(a['long']-b['long']));v.append(30*max(0,.72-a['body_normal'][2]))
 for g,h in pairs:
  dist=mujoco.mj_geomDistance(m,d,g,h,.03,None);v.append(500*max(0,.012-dist))
 v.extend(.04*(q-seed));return v
fit=least_squares(objective,seed,bounds=(lo,hi),max_nfev=160,ftol=1e-9,xtol=1e-9,gtol=1e-9);f=fk(fit.x);report={**r,'arm_targets_rad':fit.x.tolist(),'minimum_arm_joint_margin_rad':float(np.min(np.minimum(fit.x-m.jnt_range[ids,0],m.jnt_range[ids,1]-fit.x))),'body_palm_up_cos':[float(a['body_normal'][2])for a in f],'facet_up_cos':[float(a['normal'][2])for a in f],'position_error_m':[float(np.linalg.norm(a['pos']-b['pos']))for a,b in zip(f,targets)],'normal_error_deg':[float(np.rad2deg(np.arccos(np.clip(a['normal']@b['normal'],-1,1))))for a,b in zip(f,targets)],'actual_fk':[{k:v.tolist()for k,v in a.items()}for a in f],'clearance_pairs':[dict(g=g,h=h,distance_m=float(mujoco.mj_geomDistance(m,d,g,h,.05,None)))for g,h in pairs],'offline_only':True,'no_controller_transfer':True,'elapsed_s':time.monotonic()-start};(O/args.output_name).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k]for k in['position_error_m','normal_error_deg','body_palm_up_cos','minimum_arm_joint_margin_rad','clearance_pairs','elapsed_s']},indent=2))
