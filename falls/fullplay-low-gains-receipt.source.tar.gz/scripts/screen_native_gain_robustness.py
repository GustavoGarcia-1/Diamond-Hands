"""Fixed-checkpoint diagnostic gain screen; fixture values never enter policy."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import numpy as np
from stable_baselines3 import PPO
from g1_receiver.native_cup_training import NativeCatchEnv
from g1_receiver.native_cup_continuation import CAMERAS, mutate_throw_only
from g1_receiver.native_cup_residual_rl import OBS_SCHEMA


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('source', 'amp-source', 'profile', 'model', 'output'):
        p.add_argument('--'+name, type=Path, required=True)
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    model = PPO.load(a.model, device='cuda')
    assert model.observation_space.shape == (169,) and model.action_space.shape == (20,)
    assert model.receiver_sensor_schema == OBS_SCHEMA
    assert sha256(a.model.read_bytes()).hexdigest() == 'fcd915e0578115ba300ca697744699a534d2d6896209f03b06474097cc91acc5'
    donor = json.loads(a.profile.read_text())
    gains = [.5, .4, .45, .55, .6]
    fixtures = [('nominal', (0., 0.)), ('y-minus', (-.02, 0.)), ('y-plus', (.02, 0.)),
                ('z-minus', (0., -.02)), ('z-plus', (0., .02))]
    protocol = dict(model_sha256=sha256(a.model.read_bytes()).hexdigest(), gains=gains, fixtures=fixtures,
        seed=173, inference_device='cuda', duration_s=9., actual_training=False,
        scope='Post-hoc engineering gain calibration, independent physical evaluation. No policy or reward updates.',
        ranking='Report every case; any physical-quality failure prevents promotion as a realistic catch. Retention diagnostics ranked by minimum hold then endpoint count across all five fixtures.',
        fixed='catch plane, cameras, route, physics, fingers, model weights; only launch aim Y/Z and inference action gain vary')
    (a.output/'protocol.json').write_text(json.dumps(protocol, indent=2)+'\n')
    rows = []
    for gain in gains:
        for label, delta in fixtures:
            out = a.output / f'gain-{gain:g}' / label
            out.mkdir(parents=True)
            profile = out/'profile.json'
            profile.write_text(json.dumps(mutate_throw_only(donor, delta), indent=2)+'\n')
            env = NativeCatchEnv(profile, a.source, a.amp_source, duration=9., evaluation_dir=out/'rollout', **CAMERAS)
            try:
                obs, _ = env.reset(seed=173)
                total = 0.
                while True:
                    action = model.predict(obs, deterministic=True)[0] * np.float32(gain)
                    obs, reward, done, _, info = env.step(action)
                    total += reward
                    if done:
                        break
                assert np.isclose(total, info['sensor_return'], atol=1e-9)
                report = json.loads((out/'rollout/episode-0001/trial/report.json').read_text())
                rows.append(dict(gain=gain, fixture=label, delta_yz_m=delta,
                    anatomical=report['anatomical_score'], sensor=info, returned_reward=total))
                (a.output/'summary.json').write_text(json.dumps(rows, indent=2)+'\n')
                print(json.dumps(dict(gain=gain, fixture=label, completed=len(rows))), flush=True)
            finally:
                env.close()


if __name__ == '__main__':
    main()
