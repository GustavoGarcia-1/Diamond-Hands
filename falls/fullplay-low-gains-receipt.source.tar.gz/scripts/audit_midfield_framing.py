"""Conservative whole-play camera-frustum audit of recorded poses and scenery."""
import argparse
import json
from pathlib import Path
import numpy as np
import mujoco
from g1_receiver.hand_route_plant import HandRoutePlant
from g1_receiver.stadium import StadiumRenderer, FIELD_CENTER


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', type=Path, required=True)
    p.add_argument('--directory', type=Path, required=True)
    a = p.parse_args()
    rows = []
    for presentation in sorted(a.directory.glob('*/presentation.json')):
        item = json.loads(presentation.read_text())
        command = item['render_command']
        def option(name, count=1):
            i = command.index('--'+name)+1
            values = [float(x) for x in command[i:i+count]]
            return values[0] if count == 1 else values
        trial = Path(item['source'])
        report = json.loads((trial/'report.json').read_text())
        origin = report['release']['release_xyz_m']
        release = report['release']['release_time_s']
        velocity = report['release']['release_velocity_mps']
        heading = np.radians(option('heading-deg'))
        plant = HandRoutePlant(a.source, hand_model='aero', survey_camera=False)
        renderer = StadiumRenderer(plant, width=int(option('width')), height=int(option('height')),
            field_heading_rad=heading, quarterback_origin=origin, release_time=release,
            quarterback_heading_rad=float(np.arctan2(velocity[1], velocity[0])),
            studio=True, receiver_split_m=1.8288, midfield=True)
        try:
            camera = mujoco.MjvCamera()
            camera.lookat[:] = option('fixed-lookat', 3)
            camera.distance = option('distance-m')
            camera.azimuth = option('azimuth-deg')+option('heading-deg')
            camera.elevation = option('elevation-deg')
            renderer.update_scene(plant.data, camera=camera)
            left, right = renderer.renderer.scene.camera
            eye = (left.pos.astype(float)+right.pos.astype(float))/2
            forward = left.forward.astype(float)
            up = left.up.astype(float)
            side = np.cross(forward, up)
            aspect = option('width')/option('height')
            tan_y = left.frustum_top/left.frustum_near
            tan_x = tan_y*aspect
            model, data = renderer.model, renderer.data
            ids = np.array([g for g in range(model.ngeom) if model.geom_bodyid[g] != 0
                and model.body(int(model.geom_bodyid[g])).name != 'stadium' and model.geom_rgba[g, 3] > 0])
            radii = model.geom_rbound[ids]
            worst = dict(normalized_bound=0.)
            view = np.load(trial/'view.npz')
            for stamp, q in zip(view['timestamps_s'], view['qpos']):
                data.qpos[:] = q
                mujoco.mj_kinematics(model, data)
                delta = data.geom_xpos[ids]-eye
                depth = delta@forward
                bound_x = (abs(delta@side)+radii)/(depth-radii)/tan_x
                bound_y = (abs(delta@up)+radii)/(depth-radii)/tan_y
                bound = np.maximum(bound_x, bound_y)
                i = int(np.argmax(bound))
                if bound[i] > worst['normalized_bound']:
                    worst = dict(normalized_bound=float(bound[i]), time_s=float(stamp),
                        geom=model.geom(int(ids[i])).name, body=model.body(int(model.geom_bodyid[ids[i]])).name,
                        horizontal_bound=float(bound_x[i]), vertical_bound=float(bound_y[i]))
                assert np.all(depth-radii > left.frustum_near), 'actor bounding sphere crosses near plane'
            stadium = model.body('stadium').id
            center = data.xpos[stadium]+data.xmat[stadium].reshape(3, 3)@np.r_[FIELD_CENTER, 0.]
            center_error = float(np.linalg.norm(center[:2]-np.asarray(origin)[:2]))
            rows.append(dict(route=item['route'], recorded_frames=len(view['qpos']),
                method='Perspective bounding spheres of all visible actor/machine geometries; excludes field/world. Conservative frustum bound, not occlusion or pixel segmentation.',
                worst=worst, all_actor_bounds_in_frame=worst['normalized_bound'] <= 1.,
                field_center_error_m=center_error, field_center_at_passer=center_error < 1e-5))
        finally:
            renderer.close()
            plant.close()
    output = a.directory/'framing-audit.json'
    if output.exists():
        raise FileExistsError(output)
    output.write_text(json.dumps(rows, indent=2)+'\n')
    print(json.dumps(rows, indent=2))


if __name__ == '__main__':
    main()
