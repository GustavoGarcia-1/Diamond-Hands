"""Read-only exact-facet fixture, actual actuator-readiness and velocity audit."""
import argparse,json
from pathlib import Path
import mujoco,numpy as np
from g1_receiver.aero import make_aero_scene
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
from g1_receiver.offline_cup_fixture import projected_cup_seed
from g1_receiver.lower_cup_grip import NativeHandCalibration

def main():
 p=argparse.ArgumentParser()
 for n in ['source','trial','profile','output']:p.add_argument('--'+n,type=Path,required=True)
 p.add_argument('--arrival',type=float,default=6.2);a=p.parse_args();profile=json.loads(a.profile.read_text());m=mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT,a.source));d=mujoco.MjData(m);v=np.load(a.trial/'offline-robot-qpos.npz');times=v['timestamps_s'];q=v['qpos'];poses=[];fingers=[];widths=[];points=[]
 for t in times[(times>=a.arrival-.061)&(times<=a.arrival+.001)]:
  idx=np.argmin(abs(times-t));d.qpos[:]=q[idx];mujoco.mj_kinematics(m,d);hands=[];fs=[];ws=[];ps=[]
  for side in ['left','right']:
   g=int(m.geom('aero_'+side+'_palm_collision_7').id);R=d.geom_xmat[g].reshape(3,3);N=R[:,0];P=d.geom_xpos[g]+m.geom_size[g,0]*N;B=d.body('aero_'+side+'_palm').xmat.reshape(3,3);F=B[:,2];bodyN=(1 if side=='left'else-1)*B[:,1];hands.append(dict(side=side,face_world_m=P.tolist(),normal_world=N.tolist(),finger_axis_world=R[:,2].tolist(),body_finger_world=F.tolist(),body_palm_up_cos=float(bodyN[2]),face_height_above_shoulder_m=float(P[2]-d.body(side+'_shoulder_pitch_link').xpos[2])));fs.append(F);ws.append(R[:,1]);ps.append(P)
  poses.append(dict(time_s=float(t),hands=hands));points.append(ps);fingers.append(fs);widths.append(ws)
 cal={'poses':poses};C,N,meta=projected_cup_seed(profile,profile['play']['flight_s'],cal);row=min(poses,key=lambda x:abs(x['time_s']-a.arrival));k=poses.index(row);ts=np.array([x['time_s']for x in poses]);X=np.column_stack([ts-ts.mean(),np.ones(len(ts))]);velocity=np.array([np.linalg.lstsq(X,np.array(points)[:,i],rcond=None)[0][0]for i in range(2)]);ballv=(C-profile['play']['quarterback_origin_m'])/profile['play']['flight_s']+[0,0,-4.905*profile['play']['flight_s']];rel=ballv-velocity;normal=np.array([x['normal_world']for x in row['hands']]);long=np.array([x['finger_axis_world']for x in row['hands']]);width=np.array(widths)[k];trace=np.load(a.trial/'trace.npz');native=trace['native_hand'];natrow=native[np.argmin(abs(native[:,0]-a.arrival))];act=np.load(a.trial/'native-applied-control.npz')['native_applied_control'];actrow=act[np.argmin(abs(act[:,0]-a.arrival))];calibration=NativeHandCalibration.from_model(m)
 result={'evaluation_only':True,'actual_trial':str(a.trial),'actual_face':row,'fixture':meta,'actual_ball_center_m':C.tolist(),'flight_s':profile['play']['flight_s'],'per_hand_velocity_mps':velocity.tolist(),'declared_ball_arrival_velocity_mps':ballv.tolist(),'relative_velocity_mps':rel.tolist(),'relative_normal_mps':np.sum(rel*normal,1).tolist(),'relative_pad_long_mps':np.sum(rel*long,1).tolist(),'relative_pad_width_mps':np.sum(rel*width,1).tolist(),'finite_actual_pad7':bool(np.max(abs(np.array(meta['width_offset_m'])))<=.042 and np.max(abs(np.array(meta['finger_axis_offset_m'])))<=.013),'native_actual_encoder_fractions':calibration.fractions(natrow[1:15]).tolist(),'native_requested_fractions':calibration.fractions(natrow[15:29]).tolist(),'native_actual_post_slew_fractions':calibration.fractions(actrow[1:15]).tolist(),'sensor_limits_note':'Fractions normalize encoder readings to target calibration spans; measured underactuated encoders are not asserted to obey hard fraction bounds or determine individual joint posture.'};a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in ['actual_ball_center_m','finite_actual_pad7','relative_normal_mps','relative_pad_long_mps','relative_pad_width_mps','native_actual_encoder_fractions']}))
if __name__=='__main__':main()
