"""Bounded immutable-source manual Out experiment launcher; no actor source edits."""
from pathlib import Path
import argparse,json,hashlib,uuid
from antioch.client import Client,targeting
from antioch.client.service import copy_path
from antioch.transport import exit_code_of

def main():
 p=argparse.ArgumentParser();p.add_argument('--profile',type=Path,required=True);p.add_argument('--tag',required=True);p.add_argument('--duration',default='8');a=p.parse_args();root=Path.cwd();out=root/'reports/catch-repair-20261114/out-cup';session='ses-3A0R1JMJWD4E7ENS2SEQQZRYS0';base='/workspace/g1-receiver-runs/catch-repair-out-'+a.tag;parent='/workspace/g1-receiver-runs/overnight-out-level-open-inlet-20261114-r1';baseline=json.loads((root/'reports/catch-form-20261114/overnight-grip/out-level-open-inlet-receipt.json').read_text());client=Client();selected=targeting.resolve_session(client,session=session,any_project=True,fresh=True)
 with targeting.attach_agent(client,selected.session,'sim')as agent:
  def run(cmd,timeout=90):
   r=agent.run(cmd,cwd='/tmp',timeout=timeout);assert exit_code_of(r)==0,r.stderr.decode();return r.stdout.decode()
  run(['python3','-c','from pathlib import Path;import shutil,sys;b=Path(sys.argv[1]);b.mkdir();(b/"artifacts").mkdir();shutil.copytree(Path(sys.argv[2])/"source",b/"source")',base,parent]);data=a.profile.read_text();run(['python3','-c','from pathlib import Path;import sys;Path(sys.argv[1]).write_text(sys.argv[2])',base+'/profile.json',data]);cmd=[x.replace(parent,base)for x in baseline['launch']['command']];cmd[cmd.index('--output')+1]=base+'/artifacts/trial';cmd[cmd.index('--duration')+1]=a.duration;config={'wall_seconds':1200,'snapshot_sha256':hashlib.sha256(data.encode()).hexdigest(),'command':cmd};run(['python3','-c','from pathlib import Path;import sys;Path(sys.argv[1]).write_text(sys.argv[2])',base+'/launch.json',json.dumps(config)]);inputs={k:v for k,v in baseline['inputs'].items()if k!='profile.json'};inputs['profile.json']=hashlib.sha256(data.encode()).hexdigest();receipt={'session':session,'remote_root':base,'launch':config,'inputs':inputs,'immutable_controller_parent':parent}
  # Freeze before launching: original source tree, original profile and launch only.
  transfer='/workspace/project/.repair-source-'+uuid.uuid4().hex+'.tar.gz';run(['tar','--exclude=__pycache__','--exclude=*.pyc','-czf',transfer,'-C',base,'source/src','source/scripts','profile.json','launch.json'],120);target=out/(a.tag+'-receipt.source.tar.gz');copy_path(agent,root,local=target,remote=transfer,download=True,cwd='/tmp',warn=lambda _:None);run(['rm',transfer]);receipt['source_archive_sha256']=hashlib.sha256(target.read_bytes()).hexdigest();receipt['command_handle']=agent.exec(['python3',base+'/source/scripts/remote_worker.py',base],cwd='/tmp',timeout_s=30,drop_unread=True).handle;(out/(a.tag+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(base)
if __name__=='__main__':main()
