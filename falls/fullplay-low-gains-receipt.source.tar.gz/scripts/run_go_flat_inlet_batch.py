"""Analytically chosen fixture trials; fixed original physics and sensor catch plane."""
import argparse,concurrent.futures,json,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--profile',type=Path,required=True);p.add_argument('--model',type=Path,required=True);p.add_argument('--source',type=Path,required=True);p.add_argument('--amp-source',type=Path,required=True);p.add_argument('--fit',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);base=json.loads(a.profile.read_text());fits=json.loads(a.fit.read_text())['results'];choices=[dict(label='T08-aligned-original-target',flight=.8,level=False,aim=base['play']['quarterback_target_m'])]
for flight,level,label in [(.8,True,'T08-level-finite-fit'),(1.2,False,'T12-aligned-finite-fit')]:
 fit=next(r for r in fits if r['flight_s']==flight and r['world_level_x']==level);assert fit['fit_success'];choices.append(dict(label=label,flight=flight,level=level,aim=fit['aim_m']))
for c in choices:
 profile=json.loads(json.dumps(base));profile['play'].update(release_s=5.2-c['flight'],flight_s=c['flight'],quarterback_level_ball=c['level'],quarterback_target_m=c['aim']);path=a.output/(c['label']+'-profile.json');path.write_text(json.dumps(profile,indent=2)+'\n');c['profile']=str(path)
def run(job):
 c,gain=job;label=c['label']+f'-gain{gain}';command=[sys.executable,str(a.root/'scripts/probe_ball_hand_contact_model.py'),'--frozen-root',str(a.root),'--profile',c['profile'],'--model',str(a.model),'--source',str(a.source),'--amp-source',str(a.amp_source),'--output',str(a.output/label),'--timeconstant','.02','--unmodified','--gain',str(gain),'--device','cuda']
 with (a.output/(label+'.log')).open('w')as f:result=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 return dict(label=label,fixture=c,gain=gain,command=command,exit_code=result.returncode)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:results=list(pool.map(run,[(c,g)for c in choices for g in [0.,.5]]))
(a.output/'results.json').write_text(json.dumps(results,indent=2)+'\n')
if any(r['exit_code']for r in results):raise RuntimeError('failedtrialpreserved')
