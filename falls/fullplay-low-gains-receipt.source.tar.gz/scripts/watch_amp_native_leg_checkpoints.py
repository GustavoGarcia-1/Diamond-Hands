"""Bounded independent physical checkpoint checks while sensor-only PPO runs."""
import argparse,hashlib,json,shutil,subprocess,sys,time,zipfile
from pathlib import Path
import numpy as np
from g1_receiver.running_catch_eval import _flight_phases,RunningCatchCriteria

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for n in ('source','amp-source','profile','training','output'):p.add_argument('--'+n,type=Path,required=True)
 p.add_argument('--wall-seconds',type=float,default=3900.)
 a=p.parse_args()
 if not 1<=a.wall_seconds<=4200:p.error('bounded watch duration required')
 a.output.mkdir(parents=True,exist_ok=False);(a.output/'models').mkdir();start=time.monotonic();seen=set();summary=[]
 (a.output/'protocol.json').write_text(json.dumps(dict(initial_yaws_rad=[-.52,-.5,-.48],selection='Complete7s; upright>=.9; maxstem<=.5m; >=2 qualified recurrent flights spanning10yd. Preserveallnominal/perturbedresults; no ball/catch claim.',training_truth_boundary='Evaluator is a separate process and writes no observations/rewards/curriculum to PPO'),indent=2)+'\n')
 while time.monotonic()-start<a.wall_seconds:
  models=[a.training/'initial.zip',*sorted(a.training.glob('checkpoint-*.zip'))]
  if (a.training/'training-receipt.json').exists():models.append(a.training/'final.zip')
  for model in models:
   if model.name in seen or not model.exists()or time.time()-model.stat().st_mtime<3:continue
   try:
    with zipfile.ZipFile(model)as z:
     if z.testzip()is not None:continue
   except(zipfile.BadZipFile,OSError):continue
   copied=a.output/'models'/model.name;shutil.copy2(model,copied);digest=hashlib.sha256(copied.read_bytes()).hexdigest()
   if digest!=hashlib.sha256(model.read_bytes()).hexdigest():copied.unlink();continue
   rows=[]
   for j,yaw in enumerate((-.52,-.5,-.48)):
    out=a.output/model.stem/f'yaw-{j}';out.parent.mkdir(exist_ok=True)
    cmd=[sys.executable,'scripts/probe_amp_native_catch.py','--source',str(a.source),'--amp-source',str(a.amp_source),'--profile',str(a.profile),'--output',str(out),'--no-pass','--duration','7','--initial-yaw',str(yaw),'--leg-checkpoint',str(copied),'--leg-device','cuda']
    with(out.parent/f'yaw-{j}.log').open('w')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=150)
    row=dict(initial_yaw_rad=yaw,exit_code=r.returncode,command=cmd)
    if r.returncode==0:
     report=json.loads((out/'report.json').read_text());z=np.load(out/'trace.npz');m=z['motion'];tc=None if m[:,1].max()<9.144 else float(np.interp(9.144,m[:,1],m[:,0]));ph=[]if tc is None else _flight_phases(z['foot_time_s'],z['foot_floor_contact'],z['robot_floor_contact'],z['sole_clearance_m'],m[:,:5],np.array([1.,0.]),tc,.4,RunningCatchCriteria());spans=any(x['start_s']<=tc<=y['land_s'] and 0<y['start_s']-x['start_s']<=.72 for x,y in zip(ph[:-1],ph[1:]))if tc is not None else False
     row.update(duration_s=report['duration_s'],minimum_upright_cosine=report['minimum_upright_cosine'],max_stem_error_m=report['max_stem_error_m'],time_at_10yd_s=tc,qualified_flights=ph,recurrent_flights_span_10yd=spans)
     row['passes_no_ball_gait_check']=bool(report['duration_s']>=7.-1e-8 and report['minimum_upright_cosine']>=.9 and report['max_stem_error_m']<=.5 and spans)
    rows.append(row)
   summary.append(dict(checkpoint=model.name,sha256=digest,trials=rows));seen.add(model.name)
   (a.output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(dict(checkpoint=model.name,sha256=digest,passed=sum(r.get('passes_no_ball_gait_check',False)for r in rows))),flush=True)
  if (a.training/'training-receipt.json').exists()and'final.zip'in seen:break
  time.sleep(20)
 (a.output/'watch-completion.json').write_text(json.dumps(dict(elapsed_s=time.monotonic()-start,evaluated_models=len(seen),training_completed=(a.training/'training-receipt.json').exists()),indent=2)+'\n')
if __name__=='__main__':main()
