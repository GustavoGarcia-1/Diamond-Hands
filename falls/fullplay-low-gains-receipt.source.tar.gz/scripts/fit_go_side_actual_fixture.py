"""Analytic fixture fit to actual 0.45s reach facets, declared margins and no physical-score search."""
from pathlib import Path
import json
import numpy as np
P=Path('reports/catch-repair-20261114/go-side-cup');data=json.load(open(P/'reach-benchmark-r4-analysis.json'))[0]['snapshots'][2];faces=[np.array(f['center_m'])for f in data['faces']];norms=np.array([f['normal']for f in data['faces']]);longs=[np.array(f['long_axis'])for f in data['faces']];widths=[np.array(f['width_axis'])for f in data['faces']];seed=np.mean(faces,axis=0)+np.array([0,0,.09]);records=[]
for yawdeg in[70,80,90,100,110]:
 yaw=np.deg2rad(yawdeg);R=np.array([[np.cos(yaw),-np.sin(yaw),0],[np.sin(yaw),np.cos(yaw),0],[0,0,1.]]);shape=R@np.diag(np.array([.142,.085,.085])**2)@R.T;support=[shape@n/np.sqrt(n@shape@n)for n in norms];rhs=np.array([n@(f+s)for n,f,s in zip(norms,faces,support)]);center=seed+norms.T@np.linalg.solve(norms@norms.T,rhs-norms@seed);null=np.cross(*norms);null/=np.linalg.norm(null);low,high=-.06,.06;coeff=[]
 for f,s,w,l in zip(faces,support,widths,longs):
  for axis,limit in[(w,.032),(l,.008)]:
   a=float(axis@null);b=float(axis@(center-s-f));coeff.append((a,b,limit))
   if abs(a)>1e-9:bounds=sorted([(-limit-b)/a,(limit-b)/a]);low=max(low,bounds[0]);high=min(high,bounds[1])
   elif abs(b)>limit:low=1;high=0
 ok=low<=high
 if ok:lam=float(np.clip(-sum(a*b/l**2 for a,b,l in coeff)/sum(a*a/l**2 for a,b,l in coeff),low,high));center+=lam*null
 margins=[]
 for f,s,w,l,n in zip(faces,support,widths,longs,norms):
  delta=center-s-f;margins.append(dict(width_margin_m=float(.042-abs(w@delta)),finger_margin_m=float(.013-abs(l@delta)),normal_gap_m=float(n@delta)))
 records.append(dict(yaw_deg=yawdeg,feasible=ok,center_m=center.tolist(),margins=margins,quaternion_wxyz=[float(np.cos(yaw/2)),0.,0.,float(np.sin(yaw/2))]))
feasible=[r for r in records if r['feasible']];selected=max(feasible,key=lambda r:min(min(x['width_margin_m']/.010,x['finger_margin_m']/.005)for x in r['margins']))if feasible else None
(P/'actual-fixture-fit.json').write_text(json.dumps(dict(source='reach-benchmark-r4actual5.2FK',offline_only=True,criteria='width>=10mm andfinger>=5mm; fixedbeforetests; no physicalscoreselection',candidates=records,selected=selected),indent=2)+'\n');print(json.dumps(selected,indent=2))
if selected:
 profile=json.load(open(P/'benchmark-profile.json'));profile['play']['quarterback_target_m']=(np.array(selected['center_m'])+np.array([0,0,4.905*.001*.85])).tolist();profile['play']['field_catch_window_m']=selected['center_m'];profile['play']['flight_s']=.85;profile['play']['release_s']=4.35;profile['play']['grip']=json.load(open('reports/catch-repair-20261114/out-cup/right-up-margin-entry-profile.json'))['play']['grip'];axis=np.array(selected['center_m'])[:2]-np.array([0,-1.8288]);profile['play']['field_approach_axis_xy']=(axis/np.linalg.norm(axis)).tolist();profile['initial_ball_quaternion_wxyz']=selected['quaternion_wxyz'];profile['research_scope']='NewGoQBsideCshape; ORIGINALphysicsanchor/separated2.5mscomparison; latearmsfreshRGBDTTConly; nativepreloadstillmachineevent; nolearningclaim';(P/'causal-pass-profile.json').write_text(json.dumps(profile,indent=2)+'\n')
