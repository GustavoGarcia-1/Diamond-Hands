"""Inventory unique remote job receipts and their locally retrieved artifacts."""
import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import tarfile


def digest(path):
    result = sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            result.update(chunk)
    return result.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    jobs = {}
    for path in sorted(args.root.rglob('*receipt.json')):
        try:
            receipt = json.loads(path.read_text())
        except (ValueError, OSError):
            continue
        if not isinstance(receipt, dict) or not {'session', 'remote_root', 'command_handle'} <= receipt.keys():
            continue
        key = (receipt['session'], receipt['remote_root'], receipt['command_handle'])
        jobs.setdefault(key, []).append((path, receipt))
    rows = []
    for key, aliases in jobs.items():
        available = [pair for pair in aliases if pair[0].with_suffix('.artifacts.tar.gz').exists()]
        path, receipt = (available or aliases)[0]
        archive = path.with_suffix('.artifacts.tar.gz')
        row = dict(session=key[0], remote_root=key[1], command_handle=key[2],
            canonical_receipt=str(path), receipt_aliases=[str(p) for p, _ in aliases],
            locally_retrieved=archive.exists())
        if archive.exists():
            row.update(artifact_archive=str(archive), artifact_bytes=archive.stat().st_size,
                artifact_sha256=digest(archive))
            with tarfile.open(archive, mode='r|gz') as tar:
                for member in tar:
                    if member.name == 'artifacts/status.json':
                        row['status'] = json.load(tar.extractfile(member))
                        break
        source = path.with_suffix('.source.tar.gz')
        if source.exists():
            actual = digest(source)
            expected = receipt.get('source_archive_sha256')
            row.update(source_archive=str(source), source_sha256=actual,
                source_matches_receipt=actual == expected if expected is not None else None)
        rows.append(row)
    phases = {}
    for row in rows:
        phase = row.get('status', {}).get('phase', 'not_locally_recorded')
        phases[phase] = phases.get(phase, 0)+1
    result = dict(generated_utc=datetime.now(timezone.utc).isoformat(),
        scope='Local archive integrity/status inventory only, not a claim that failed experiments qualify or that every remote command is enumerated.',
        unique_receipted_jobs=len(rows), locally_retrieved=sum(r['locally_retrieved'] for r in rows),
        recorded_phases=phases, jobs=rows)
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'jobs'}))
    for row in rows:
        if not row['locally_retrieved'] or row.get('source_matches_receipt') is False:
            print(json.dumps(row))


if __name__ == '__main__':
    main()
