"""Explicit initial throw-axis fixture; no orientation control after free release."""
import argparse,sys,runpy,json,hashlib
from pathlib import Path
from dataclasses import replace
import numpy as np
p=argparse.ArgumentParser(add_help=False);p.add_argument('--ball-axis',choices=['impact','vertical'],required=True);a,rest=p.parse_known_args();frozen=Path(rest[rest.index('--frozen-root')+1]);sys.path[:0]=[str(frozen/'src'),str(frozen/'scripts')]
from g1_receiver.scrimmage_throw import ScrimmagePass
original=ScrimmagePass.plan;records=[]
def plan(self,*args,**kwargs):
 result=original(self,*args,**kwargs);axis=np.asarray(result.intercept_velocity_mps)if a.ball_axis=='impact'else np.array([0.,0.,1.]);yaw=.5*np.arctan2(axis[1],axis[0]);pitch=-.5*np.arctan2(axis[2],np.linalg.norm(axis[:2]));sy,cy,sp,cp=np.sin(yaw),np.cos(yaw),np.sin(pitch),np.cos(pitch);quaternion=(cy*cp,-sy*sp,cy*sp,sy*cp);records.append(dict(release_time_s=result.release_time_s,declared_expected_impact_velocity_mps=list(result.intercept_velocity_mps),initial_quaternion_wxyz=list(quaternion)));return replace(result,release_quaternion_wxyz=quaternion)
ScrimmagePass.plan=plan;sys.argv=[str(Path(__file__).with_name('probe_ball_hand_contact_model.py')),*rest]
try:runpy.run_path(sys.argv[0],run_name='__main__')
finally:ScrimmagePass.plan=original
out=Path(rest[rest.index('--output')+1]);(out/'initial-axis-fixture.json').write_text(json.dumps(dict(mode=a.ball_axis,plans=records,initial_only=True,free_ball_after_release=True,not_aerodynamic_alignment_claim=True,axis_depends_only_on_fixed_fixture=True,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),indent=2)+'\n')
