"""Read-only actual arm tracking/PD saturation proxy and full shoulder/torso geometry."""
import argparse,json
from pathlib import Path
import numpy as np,mujoco
from g1_receiver.hand_route_plant import HandRoutePlant

def main():
 p=argparse.ArgumentParser()
 for n in ['source','trial','output']:p.add_argument('--'+n,type=Path,required=True)
 a=p.parse_args();report=json.loads((a.trial/'report.json').read_text());packets=report['late_cup_trace'];host=json.loads((a.trial/'host-gains.json').read_text());names=report['native_hand_contract'].get('body_joint_names',host['body_joint_names']);arms=[f'{s}_{n}_joint'for s in ['left','right']for n in ['shoulder_roll','shoulder_yaw','shoulder_pitch','elbow','wrist_roll','wrist_pitch','wrist_yaw']];ids=[host['body_joint_names'].index(n)for n in arms];kp=np.array(host['wbc_kp'])[ids];kd=np.array(host['wbc_kd'])[ids];lo=np.array(host['body_effort_min'])[ids];hi=np.array(host['body_effort_max'])[ids];q=[];dq=[];target=[];times=[]
 for x in packets:
  times.append(x['time_s']);q.append(np.array(x['receive_arm_targets_rad'])-x['receive_error_rad']);dq.append(x['arm_velocity_rad_s']);target.append(x['actual_target_rad'])
 times=np.array(times);q=np.array(q);dq=np.array(dq);target=np.array(target);effort=kp*(target-q)-kd*dq;saturated=(effort<lo)|(effort>hi);mask=times>=report['break_at_s'];cue=next((x['triggered_at_s']for x in packets if x['triggered_at_s']is not None),None);pre=mask&(times<(cue if cue is not None else 6.2));receive=(times>=6.0)&(times<=6.4)
 tracking={'scope':'50Hz sensor+command PD-effort estimate at commandtime, NOT recorded1kHz appliedtorque; bodyWBCfullblend aftercamera cut.','arm_order':arms,'max_abs_target_error_rad':np.max(abs(target[mask]-q[mask]),0).tolist(),'max_abs_estimated_effort_nm':np.max(abs(effort[mask]),0).tolist(),'effort_min_nm':lo.tolist(),'effort_max_nm':hi.tolist(),'saturated_command_sample_count':saturated[mask].sum(0).tolist(),'pre_cue_arm_velocity_rms_rad_s':float(np.sqrt(np.mean(dq[pre]**2))),'pre_cue_arm_velocity_peak_rad_s':float(abs(dq[pre]).max()),'receive_window_max_tracking_error_rad':np.max(abs(target[receive]-q[receive]),0).tolist(),'triggered_at_s':cue}
 plant=HandRoutePlant(a.source,hand_model='aero',rear_markers=True);m=plant.model;d=mujoco.MjData(m);view=np.load(a.trial/'view.npz');upper=[g for g in range(m.ngeom)if any(m.body(int(m.geom_bodyid[g])).name.startswith(s+'_'+part)for s in ['left','right']for part in ['shoulder_pitch','shoulder_roll','shoulder_yaw','elbow','wrist'])and(m.geom_contype[g]or m.geom_conaffinity[g])];torso=[g for g in range(m.ngeom)if m.body(int(m.geom_bodyid[g])).name=='torso_link'and(m.geom_contype[g]or m.geom_conaffinity[g])];worst={};enabled=[]
 for stamp,state in zip(view['timestamps_s'],view['qpos']):
  d.qpos[:]=state;mujoco.mj_forward(m,d)
  for g in upper:
   for h in torso:
    distance=mujoco.mj_geomDistance(m,d,g,h,.03,None);key=(g,h)
    if key not in worst or distance<worst[key]['distance_m']:worst[key]={'geom_ids':[g,h],'body_names':[m.body(int(m.geom_bodyid[j])).name for j in key],'distance_m':float(distance),'time_s':float(stamp),'direct_parent_pair':bool(m.body_parentid[m.geom_bodyid[g]]==m.geom_bodyid[h])}
  for c in d.contact:
   if (int(c.geom[0])in upper and int(c.geom[1])in torso)or(int(c.geom[1])in upper and int(c.geom[0])in torso):enabled.append({'time_s':float(stamp),'distance_m':float(c.dist),'geom_ids':[int(g)for g in c.geom],'body_names':[m.body(int(m.geom_bodyid[g])).name for g in c.geom]})
 plant.close();out={'evaluation_only':True,'tracking':tracking,'geometry_scope':'Actual archived25Hzqpos, all ACTIVE shoulderpitch/roll/yaw/elbow/wrist vs torso INCLUDED. Direct-parent overlaps are reported separately, not silently removed. mj_forwardcontact identifies enabledpairs but reconstructedforcesareNOT used.','worst_per_pair':sorted(worst.values(),key=lambda x:x['distance_m']),'enabled_upper_torso_contacts':enabled};a.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'tracking':tracking,'worst_enabled_contact':min(enabled,key=lambda x:x['distance_m'])if enabled else None}))
if __name__=='__main__':main()
