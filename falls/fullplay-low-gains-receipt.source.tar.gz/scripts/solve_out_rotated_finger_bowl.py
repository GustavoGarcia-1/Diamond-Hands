"""Offline IK: rotate each actual pad frame about its receiving normal.
No runtime/controller/physics changes. Output is a static proposal only.
"""
import argparse,json
from pathlib import Path
import numpy as np,mujoco
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation
from g1_receiver.aero import make_aero_scene
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT

def main():
 p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--trial',type=Path,required=True);p.add_argument('--profile',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--time',type=float,default=6.2);a=p.parse_args()
 m=mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT,a.source));d=mujoco.MjData(m);v=np.load(a.trial/'view.npz');idx=np.argmin(abs(v['timestamps_s']-a.time));d.qpos[:]=v['qpos'][idx];template=d.qpos.copy();mujoco.mj_forward(m,d);profile=json.loads(a.profile.read_text());names=profile['mirrored_side_cup']['arm_order'];ad=np.array([m.joint(n).qposadr[0]for n in names]);seed=d.qpos[ad].copy();mechanical=np.array([m.joint(n).range for n in names]);bounds=mechanical.copy();bounds[:,0]+=.03;bounds[:,1]-=.03
 for i,n in enumerate(names):
  if 'elbow'in n:bounds[i,0]=max(bounds[i,0],.20)
 geoms={s:[g for g in range(m.ngeom)if m.body(int(m.geom_bodyid[g])).name.startswith('aero_'+s+'_')and(m.geom_contype[g]or m.geom_conaffinity[g])]for s in ['left','right']};pairs=[(g,h)for g in geoms['left']for h in geoms['right']];rows={}
 def facet(side):
  b=d.body('aero_'+side+'_palm');R=b.xmat.reshape(3,3);sgn=1 if side=='left'else -1;return b.xpos+R@np.array([.002,sgn*.0208568189,.0763422906]),R.copy(),R@np.array([0.,sgn*.965749,.259478])
 for si,side in enumerate(['left','right']):
  ids=ad[si*7:si*7+7];mujoco.mj_forward(m,d);point,R0,N=facet(side);N/=np.linalg.norm(N);candidates=[]
  for angle in [-180,-150,-120,-90,-60,0,60,90,120,150,180]:
   wanted=Rotation.from_rotvec(N*np.deg2rad(angle)).as_matrix()@R0
   def residual(q):
    d.qpos[ids]=q;mujoco.mj_kinematics(m,d);x,R,_=facet(side);return np.r_[(x-point)/.002,Rotation.from_matrix(wanted.T@R).as_rotvec()/.03,.012*(q-seed[si*7:si*7+7])]
   best=None
   for start in [seed[si*7:si*7+7],np.clip(seed[si*7:si*7+7]+np.array([0,0,0,0,0,.5,-.5]),bounds[si*7:si*7+7,0]+1e-6,bounds[si*7:si*7+7,1]-1e-6)]:
    fit=least_squares(residual,np.clip(start,bounds[si*7:si*7+7,0]+1e-6,bounds[si*7:si*7+7,1]-1e-6),bounds=(bounds[si*7:si*7+7,0],bounds[si*7:si*7+7,1]),max_nfev=200)
    if best is None or np.linalg.norm(fit.fun)<np.linalg.norm(best.fun):best=fit
   residual(best.x);x,R,n=facet(side);candidates.append(dict(angle_deg=angle,arm_targets_rad=best.x.tolist(),position_error_m=float(np.linalg.norm(x-point)),orientation_error_rad=float(np.linalg.norm(Rotation.from_matrix(wanted.T@R).as_rotvec())),finger_axis_world=R[:,2].tolist(),pad_normal_world=n.tolist(),physical_margin_rad=float(np.min(np.minimum(best.x-mechanical[si*7:si*7+7,0],mechanical[si*7:si*7+7,1]-best.x)))))
  rows[side]=candidates;d.qpos[:]=template
 results=[]
 for left in rows['left']:
  for right in rows['right']:
   if min(left['finger_axis_world'][2],right['finger_axis_world'][2])<0. or max(left['position_error_m'],right['position_error_m'])>.005 or max(left['orientation_error_rad'],right['orientation_error_rad'])>.10:continue
   d.qpos[:]=template;d.qpos[ad]=left['arm_targets_rad']+right['arm_targets_rad'];mujoco.mj_forward(m,d);gap=min(mujoco.mj_geomDistance(m,d,int(g),int(h),.1,None)for g,h in pairs)
   results.append(dict(left=left,right=right,minimum_interhand_distance_m=float(gap),static_eligible=bool(gap>=.005)))
 result=dict(static_only=True,template=str(a.trial),template_time_s=float(v['timestamps_s'][idx]),predeclared=dict(finger_up_min=0.,pad_target_error_max_m=.005,rotation_error_max_rad=.10,interhand_clearance_min_m=.005,physical_joint_margin_min_rad=.03),arm_order=names,template_arm_targets_rad=seed.tolist(),per_hand=rows,pairs=results);a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'pairs':len(results),'eligible':sum(x['static_eligible']for x in results),'output':str(a.output)}))
if __name__=='__main__':main()
