"""Read stage-specific progress from a late-reach training receipt."""
import argparse
import json
from pathlib import Path
from antioch.client import Client, targeting
from antioch.transport import exit_code_of


def main():
    p = argparse.ArgumentParser()
    p.add_argument('receipt', type=Path)
    p.add_argument('--full', action='store_true')
    a = p.parse_args()
    receipt = json.loads(a.receipt.read_text())
    client = Client()
    session = targeting.resolve_session(client, session=receipt['session'], any_project=True, fresh=True)
    code = '''import json,pathlib,sys
p=pathlib.Path(sys.argv[1])/'artifacts';s=p/'study';result={'status':json.loads((p/'status.json').read_text())}
for name in ('zero-preflight/evaluation.json','ppo/receipt.json','final-evaluation/evaluation.json'):
 f=s/name
 if f.exists():result[name]=json.loads(f.read_text())
f=s/'ppo/progress.jsonl'
if f.exists():result['progress']=[json.loads(x)for x in f.read_text().splitlines()[-2:]]
result['episodes']={}
for f in (s/'ppo').glob('worker-*-episodes.jsonl'):
 rows=f.read_text().splitlines();result['episodes'][f.name]={'count':len(rows),'latest':json.loads(rows[-1])if rows else None}
result['checkpoints']=[f.name for f in (s/'ppo').glob('*.zip')]
result['log_tail']=(p/'training.log').read_text()[-2500:]
print(json.dumps(result))
'''
    with targeting.attach_agent(client, session.session, 'sim') as agent:
        result = agent.run(['python3', '-c', code, receipt['remote_root']], cwd='/tmp', timeout=30)
        if exit_code_of(result) != 0:
            raise RuntimeError(result.stderr.decode())
        row = json.loads(result.stdout.decode())
        if not a.full:
            row['log_tail'] = row['log_tail'][-700:]
            row['checkpoint_count'] = len(row['checkpoints'])
            row['checkpoints'] = sorted(row['checkpoints'])[-2:]
            for value in row.values():
                if isinstance(value, dict) and 'sensor_impairments' in value:
                    value['sensor_impairments'] = value['sensor_impairments']['config']
            for value in row['episodes'].values():
                latest = value['latest']
                if latest and 'sensor_impairments' in latest:
                    latest['sensor_impairments'] = latest['sensor_impairments']['config']
        print(json.dumps(row, indent=2))


if __name__ == '__main__':
    main()
