"""Read concise status from immutable experiment receipts; never modify a job."""
import argparse,json
from pathlib import Path
from antioch.client import Client,targeting
from antioch.transport import exit_code_of

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('receipts',type=Path,nargs='+');a=p.parse_args()
 receipts=[json.loads(p.read_text())for p in a.receipts]
 if len({r['session']for r in receipts})!=1:raise ValueError('one session per read-only status call')
 c=Client();s=targeting.resolve_session(c,session=receipts[0]['session'],any_project=True,fresh=True)
 code='''import pathlib,json,sys
for name in json.loads(sys.argv[1]):
 p=pathlib.Path(name)/'artifacts';row={'run':pathlib.Path(name).name}
 f=p/'status.json'
 if f.exists():row['status']=json.loads(f.read_text())
 f=p/'training/progress.jsonl'
 if f.exists()and f.read_text().splitlines():row['progress']=json.loads(f.read_text().splitlines()[-1])
 f=p/'audit/summary.json'
 if f.exists():
  rows=json.loads(f.read_text());row['evaluated_models']=len(rows)
  if rows:row['latest']={'checkpoint':rows[-1]['checkpoint'],'trials':[{k:r.get(k)for k in('initial_yaw_rad','exit_code','duration_s','minimum_upright_cosine','max_stem_error_m','time_at_10yd_s','passes_no_ball_gait_check')}for r in rows[-1]['trials']]}
 print(json.dumps(row))
'''
 with targeting.attach_agent(c,s.session,'sim')as agent:
  result=agent.run(['python3','-c',code,json.dumps([r['remote_root']for r in receipts])],cwd='/tmp',timeout=30)
  if exit_code_of(result)!=0:raise RuntimeError(result.stderr.decode())
  print(result.stdout.decode(),end='')
if __name__=='__main__':main()
