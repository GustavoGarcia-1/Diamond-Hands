"""Finite post-hour half-gain screen; selection times fixed before inspecting scores."""
import argparse,json,subprocess,sys
from pathlib import Path

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for n in ['profile','source','amp-source','models-root','output']:p.add_argument('--'+n,type=Path,required=True)
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
 if not(a.models_root/'final.zip').exists():raise RuntimeError('screen only after final checkpoint exists')
 rows=[json.loads(x)for x in(a.models_root/'progress.jsonl').read_text().splitlines()];by_steps={r['timesteps']:r['elapsed_s']for r in rows};available=[]
 for model in sorted(a.models_root.glob('checkpoint-*.zip')):
  steps=int(model.stem.split('-')[-1])
  if steps in by_steps:available.append((by_steps[steps],steps,model))
 selected=[]
 for minutes in [25,30,40,50]:
  eligible=[x for x in available if x[0]>=minutes*60]
  if not eligible:raise RuntimeError('missing predeclared checkpoint after '+str(minutes)+'min')
  elapsed,steps,path=min(eligible);selected.append(dict(requested_minute=minutes,actual_elapsed_s=elapsed,timesteps=steps,model=str(path)))
 selected.append(dict(requested_minute=60,model=str(a.models_root/'final.zip')))
 if len(set(x['model']for x in selected))!=5:raise RuntimeError('time selection produced duplicates')
 (a.output/'predeclared-model-selection.json').write_text(json.dumps(dict(rule='first periodic checkpoint at/after25,30,40,50min plus final; all gain.5 CPU; no reward ranking',controller_selection_rule='max continuous bilateral among all gates except initial ball penetration passing; report penetration separately; tiebreak lower penetration then earlier model',models=selected),indent=2)+'\n')
 command=[sys.executable,'scripts/evaluate_native_cup_action_scale.py','--profile',str(a.profile),'--source',str(a.source),'--amp-source',str(a.amp_source),'--output',str(a.output/'trials'),'--models',*[x['model']for x in selected],'--scales','.5','--device','cpu']
 subprocess.run(command,check=True)
if __name__=='__main__':main()
