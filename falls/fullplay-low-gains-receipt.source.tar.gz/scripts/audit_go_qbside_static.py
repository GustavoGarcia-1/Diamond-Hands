"""Read-only full-body clearance audit for proposed Go side-cup joint vectors."""
from pathlib import Path
import json,time
import numpy as np,mujoco
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
P=Path('reports/catch-repair-20261114');O=P/'go-side-cup';s=(P/'contact-model/study-linux/artifacts/study/original20-gain0.5/scene.xml').read_text().replace('/workspace/g1-receiver-runs/catch-repair-contact-model-20261114-r1/source/src/g1_receiver/_vendor/g1_runtime',str(DEFAULT_RUNTIME_ROOT)).replace('/workspace/g1-receiver-runs/out-scrimmage-20261113/source/aero-source','/tmp/g1-aero-source');m=mujoco.MjModel.from_xml_string(s);d=mujoco.MjData(m);a=np.load(P/'validation/protected-witness-linux/witness/offline-robot-qpos.npz');base=a['qpos'][np.argmin(abs(a['timestamps_s']-5.18))].copy();q=np.load(P/'out-cup/right-up-margin-dry-r1/artifacts/trial/offline-robot-qpos.npz');native=q['qpos'][np.argmin(abs(q['timestamps_s']-6.2))]
for j in range(m.njnt):
 n=m.joint(j).name
 if n.startswith('aero_'):
  other=n.replace('left','TEMP').replace('right','left').replace('TEMP','right');base[int(m.jnt_qposadr[j])]=native[int(m.jnt_qposadr[m.joint(other).id])]
active=[g for g in range(m.ngeom)if m.geom_contype[g]or m.geom_conaffinity[g]];body=lambda g:m.body(int(m.geom_bodyid[g])).name
L=[g for g in active if body(g).startswith(('aero_left_','left_'))and not any(k in body(g)for k in ['hip','knee','ankle'])];R=[g for g in active if body(g).startswith(('aero_right_','right_'))and not any(k in body(g)for k in ['hip','knee','ankle'])];HL=[g for g in L if body(g).startswith('aero_')];HR=[g for g in R if body(g).startswith('aero_')];torso=[g for g in active if body(g)in['pelvis','torso_link','waist_yaw_link','waist_roll_link','waist_pitch_link','head_link']];distpairs=dict(interhand=[(l,r)for l in HL for r in HR],opposite_arm=[(l,r)for l in L for r in R],hand_torso=[(g,t)for g in HL+HR for t in torso],forearm_torso=[(g,t)for g in L+R for t in torso if not body(g).startswith('aero_')and'shoulder'not in body(g)])
results=[];started=time.monotonic()
for filename in sorted(O.glob('static-up72-yaw*.json')):
 report=json.load(open(filename))
 for index,r in enumerate(report['results']):
  if time.monotonic()-started>50:raise TimeoutError('staticclearancewall50s')
  d.qpos[:]=base;d.qpos[int(m.joint('waist_yaw_joint').qposadr[0])]=r['waist_yaw_rad']
  for n,value in zip(r['arm_order'],r['arm_targets_rad']):d.qpos[int(m.joint(n).qposadr[0])]=value
  mujoco.mj_kinematics(m,d);gaps={}
  for category,pairs in distpairs.items():
   best=dict(distance_m=.05,lower_bound_only=True)
   for g,h in pairs:
    if np.linalg.norm(d.geom_xpos[g]-d.geom_xpos[h])-m.geom_rbound[g]-m.geom_rbound[h]>.05:continue
    gap=float(mujoco.mj_geomDistance(m,d,g,h,.05,None))
    if gap<best['distance_m']:best=dict(distance_m=gap,geom1=m.geom(g).name or f'geom-{g}',body1=body(g),geom2=m.geom(h).name or f'geom-{h}',body2=body(h),lower_bound_only=False)
   gaps[category]=best
  results.append(dict(source=str(filename),index=index,center=r['cup_center_pelvis_yaw_frame_m'],up=r['body_palm_up_cos'],normal_error_deg=r['normal_error_deg'],position_error_m=r['position_error_m'],margin_rad=r['minimum_arm_joint_margin_rad'],gaps=gaps))
(O/'static-clearance.json').write_text(json.dumps(dict(offline_only=True,no_dynamics=True,results=results,elapsed_s=time.monotonic()-started),indent=2)+'\n');print(json.dumps(results,indent=2))
