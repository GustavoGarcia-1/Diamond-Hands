"""Preserve the verified three-route package and add a qualified learned study."""
from pathlib import Path
from zipfile import ZipFile
import argparse
import hashlib
import json
import shutil
from package_held_routes import zip_bytes, safe

ROOT = Path(__file__).resolve().parents[1]
NATIVE = ROOT / 'reports/catch-form-20261114/overnight-lower/native-rl'
BASE = ROOT / 'artifacts/him-open-build-three-held-20261113/project.zip'
BASE_SHA = '6910521493abbde55cbb7dda4279ad410c17cefa15f700df91a1af499164fa5a'
PREFIX = 'experiments/native-cup-19456'

README = '''# Lower, palms-up learned catch component

This is a separate 6.6535 m walking development throw, not a ten-yard route or
a replacement for the three primary videos. The learned component is a PPO
residual with 169 measured features and 20 actions: fourteen arm targets plus
six native hand groups. Locomotion and the nominal grasp remain pretrained or
scripted. Checkpoint 19,456 and action gain 0.5 were selected after screening.

The matched zero-action baseline holds for 1.457 s. The selected CPU policy
holds for 3.229 s, reproduces exactly, and holds through the 9 s finish. CUDA
holds for 3.178 s. Both retain palms-up form near shoulder height. With a fixed
catch plane, vertical throw offsets of −2/+2 cm give 2.645/2.607 s on CUDA,
versus baseline 0.459/0.246 s; lateral offsets give only 0.114/0.150 s and fail.
This is axis-specific retention evidence, not general robustness.

Initial ball overlap is 43.717 mm in the nominal learned trial, above the
unchanged 10 mm guard. It therefore fails the realistic-catch quality check.
The primary Go/Out/Slant videos also have unresolved impact and hand-form
limitations under the newer audit. No hardware or deployment pass is claimed.

## Reproduce this component

Use a new Linux x86_64 Python 3.12.3 environment. Install
`reproducibility/requirements-linux-compatible.txt`; it preserves Torch
2.11.0+cu130. A fresh isolated environment using these pins passed the normal
dependency resolver and dependency check, then reproduced every archived
baseline and learned array and report exactly. The original worker inventory
is also recorded; only its incompatible Setuptools 84.2.1 was changed to 81.0.0.
Do not substitute the parent project's Torch 2.15 lock for this experiment.

Extract `frozen-source.tar.gz` into a new `source` directory. The archive's
230 files are checked by `source-manifest.json`. Obtain the pinned external
AMP assets as described in `reproducibility/README.md`; use the parent
submission's `aero-source` or the frozen Aero fetch script. Keep asset notices.
Set absolute FROZEN (source extraction), FREEZE (this directory), AERO_SOURCE,
AMP_SOURCE, OUTPUT (new directory), and PYTHON (the new interpreter), then run:

    bash reproducibility/run-cpu-pair.sh

This evaluates gains 0 and 0.5 with the frozen controller, model, cameras and
seed. Compare outputs with `evidence/baseline` and `evidence/learned-cpu`.
CPU and CUDA results are separate evidence, not interchangeable trajectories.
The additional surveyed RGB-D cameras and commanded machine-release preload
event are explicit experimental inputs; physical integration is unverified.

`full-play.mp4` is the complete 9 s recorded trial in a continuous fixed view
(9.04 s encoded at 25 fps). Robot and ball poses are unchanged. Independent
score audits and clean-environment proof are included. The raw 33 MB RGB frame
archive is unnecessary for reproduction and is deliberately excluded.
'''

CAPTION = '''Simulated Unitree G1 with Aero hands receives three passes from a fixed midfield machine, starting two yards beside it. All primary receives use grounded walking. Original clean two-hand holds: Go 3.820 s, Out 2.926 s, Slant 2.795 s. Go receives at 9.146 m with 0.176 m maximum stem drift. Out turns left 81.53° and moves forward. Slant changes inward 42.49° early versus 14.65° zero steering, then curves about 59–61°. These primary plays use pretrained locomotion and scripted RGB-D grip. Newer audits find excessive impact overlap and high hands, so possession scores do not establish realistic catch quality.

A separate 6.65 m lower, palms-up study includes a learned arm/native-hand residual: a post-hoc selected checkpoint improves nominal CPU retention from 1.457 to 3.229 s and reproduces in a clean Linux environment. Vertical ±2 cm aim trials improve; lateral trials fail, and 43.717 mm initial overlap still fails the 10 mm guard. It is not used in the primary plays. Full plays are shown; cuts occur only between routes. No ordered stop, ARM64 image, current-controller HIM safety checks or hardware qualification is established.
'''


def sha(data):
    return hashlib.sha256(data).hexdigest()


def build(output):
    output.mkdir(parents=True, exist_ok=False)
    assert sha(BASE.read_bytes()) == BASE_SHA
    with ZipFile(BASE) as archive:
        original = json.loads(archive.read('MANIFEST.json'))
        assert archive.testzip() is None
        files = {safe(name): archive.read(name) for name in original}
    assert all(sha(files[name]) == digest for name, digest in original.items())
    def add(path, name):
        files[safe(name)] = path.read_bytes()
    freeze = NATIVE / 'selected-freeze/artifacts'
    for name in ('frozen-source.tar.gz', 'checkpoint-00019456.zip', 'profile.json'):
        add(freeze / name, f'{PREFIX}/{name}')
    add(freeze / 'manifest.json', f'{PREFIX}/source-manifest.json')
    for path in sorted((NATIVE / 'reproducibility').iterdir()):
        if path.is_file() and path.suffix in ('.md', '.txt', '.json', '.sh', '.in'):
            add(path, f'{PREFIX}/reproducibility/{path.name}')
    for name in ('clean-comparison.json', 'exact-environment-comparison.json'):
        add(NATIVE / 'reproducibility/clean-environment' / name,
            f'{PREFIX}/reproducibility/clean-environment/{name}')
    for label, relative in (
        ('baseline', 'gain-ablation/artifacts/evaluation/checkpoint-00019456-gain-0.0/episode-0001'),
        ('learned-cpu', 'gain-confirm/artifacts/evaluation/cpu/checkpoint-00019456-gain-0.5/episode-0001'),
    ):
        for path in sorted((NATIVE / relative).rglob('*')):
            if path.is_file() and path.suffix in ('.json', '.npz'):
                add(path, f'{PREFIX}/evidence/{label}/{path.relative_to(NATIVE / relative).as_posix()}')
    for name in ('native-component-independent.json', 'component-review.md'):
        add(ROOT / 'reports/catch-form-20261114/overnight-validation' / name,
            f'{PREFIX}/independent/{name}')
    for name in ('yz-candidates-summary.json', 'gain-half-held-form.json'):
        add(NATIVE / name, f'{PREFIX}/independent/{name}')
    for name in ('full-play.mp4', 'video-verification.json', 'qualification.json', 'contact-sheet.jpg'):
        add(NATIVE / 'review-half19456' / name, f'{PREFIX}/{name}')
    files[f'{PREFIX}/README.md'] = README.encode()
    previous_readme = files['README.md'].decode()
    previous_readme = previous_readme.replace(
        'New residual-policy training has\nnot demonstrated a catch improvement and is not used in these selected plays.',
        'No newly learned residual is used in these primary plays. A separate\nlearned retention study is included under experiments/native-cup-19456.')
    previous_readme = previous_readme.replace(
        'No environment, credentials,\nnew residual-training checkpoints, or Kimodo model is bundled.',
        'No environment, credentials or Kimodo model is bundled. The separate native\nexperiment includes its own learned checkpoint and frozen runtime source.')
    previous_readme = previous_readme.replace(
        'The public kit fetch\nreturned 403 and Docker was unavailable; reports/him-builder-20261113 records this.',
        'The cached official kit is intact, but container tooling and the 29-joint\nrunner versus 43-actuator Aero/RGB-D integration remain open. See the updated\ndeployment-gap report under reports/deployment-gap-20261114.')
    files['README.md'] = (previous_readme + '\n## November 14 qualification and learned component\n\n'
        'The original possession scores are preserved. Newer impact/form audits find\n'
        'excessive hand–ball overlap and high hands; the primary videos are not a\n'
        'realistic-catch quality pass. Read experiments/native-cup-19456/README.md for\n'
        'a separate lower, palms-up learned retention result, its failed impact and\n'
        'lateral-aim checks, and clean Linux reproduction. Original route controller\n'
        'sources and simulation evidence are byte-for-byte unchanged.\n').encode()
    files['caption.txt'] = CAPTION.encode()
    add(ROOT / 'SENSOR_CONTRACT.md', 'SENSOR_CONTRACT.md')
    for path in (ROOT / 'reports/deployment-gap-20261114').iterdir():
        if path.is_file() and path.suffix in ('.md', '.json', '.sh'):
            add(path, f'reports/deployment-gap-20261114/{path.name}')
    corrections = ROOT / 'reports/catch-form-20261114/overnight-validation/native-study-package-review/bundle-additions.json'
    for item in json.loads(corrections.read_text())['files']:
        source = ROOT / item['source']
        assert sha(source.read_bytes()) == item['sha256']
        add(source, item['archive_member'])
    repro_prefix = f'{PREFIX}/reproducibility/'
    repro_manifest = {name.removeprefix(repro_prefix): sha(data)
        for name, data in sorted(files.items()) if name.startswith(repro_prefix)
        and name != repro_prefix + 'MANIFEST.json'}
    files[repro_prefix + 'MANIFEST.json'] = (json.dumps(repro_manifest, indent=2, sort_keys=True) + '\n').encode()
    unchanged = [name for name in original if name not in ('README.md', 'caption.txt', 'SENSOR_CONTRACT.md')]
    assert all(sha(files[name]) == original[name] for name in unchanged)
    manifest = {name: sha(data) for name, data in sorted(files.items())}
    files['MANIFEST.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    target = output / 'project.zip'
    zip_bytes(target, files)
    with ZipFile(target) as archive:
        assert archive.testzip() is None
        assert all(sha(archive.read(name)) == digest for name, digest in manifest.items())
    shutil.copyfile(BASE.parent / 'full-play.mp4', output / 'full-play.mp4')
    (output / 'caption.txt').write_text(CAPTION)
    shutil.copyfile(NATIVE / 'review-half19456/full-play.mp4', output / 'native-lower-study.mp4')
    (output / 'native-lower-study-notes.txt').write_text(README)
    size = target.stat().st_size + (output / 'full-play.mp4').stat().st_size
    assert size < 100_000_000, size
    receipt = dict(base_project_sha256=BASE_SHA, project_sha256=sha(target.read_bytes()),
        project_bytes=target.stat().st_size, combined_bytes=size, limit_bytes=100_000_000,
        unchanged_original_members=len(unchanged), changed_original_members=['README.md', 'caption.txt', 'SENSOR_CONTRACT.md'],
        primary_video_sha256=sha((output / 'full-play.mp4').read_bytes()),
        all_member_hashes_and_crc_verified=True, original_route_sources_and_evidence_unchanged=True,
        learned_component='post-hoc selected native19456 gain0.5; impact/lateral robustness fail',
        clean_linux_x86_cpu_reproduction=True, hardware_qualified=False, arena_submitted=False)
    (output / 'package-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    build(parser.parse_args().output.resolve())
