"""Offline right-only cup rotation about its actual pad7 face center."""
import argparse,json
from pathlib import Path
import mujoco,numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation
from g1_receiver.aero import make_aero_scene
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT

def main():
 p=argparse.ArgumentParser()
 for n in ['source','trial','profile','output']:p.add_argument('--'+n,type=Path,required=True)
 p.add_argument('--tilt-rad',type=float,default=-.075);a=p.parse_args();pr=json.loads(a.profile.read_text());m=mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT,a.source));d=mujoco.MjData(m);v=np.load(a.trial/'view.npz');idx=np.argmin(abs(v['timestamps_s']-6.2));d.qpos[:]=v['qpos'][idx];mujoco.mj_forward(m,d);names=pr['mirrored_side_cup']['arm_order'];ids=np.array([m.joint(n).qposadr[0]for n in names]);right=ids[7:];q0=d.qpos[right].copy();limits=np.array([m.joint(n).range for n in names[7:]]);lo=np.maximum(q0-.25,limits[:,0]+.035);hi=np.minimum(q0+.25,limits[:,1]-.035);g=int(m.geom('aero_right_palm_collision_7').id)
 def geo():
  R=d.geom_xmat[g].reshape(3,3);point=d.geom_xpos[g]+m.geom_size[g,0]*R[:,0];return point,R.copy()
 P0,R0=geo();rotation=Rotation.from_rotvec(R0[:,1]*a.tilt_rad).as_matrix();wanted=rotation@R0;hands={s:[j for j in range(m.ngeom)if m.body(int(m.geom_bodyid[j])).name.startswith('aero_'+s+'_')and(m.geom_contype[j]or m.geom_conaffinity[j])]for s in ['left','right']};pairs=[(i,j)for i in hands['left']for j in hands['right']];prox=[j for j in range(m.ngeom)if any(m.body(int(m.geom_bodyid[j])).name.startswith('right_'+part)for part in ['shoulder_roll','shoulder_yaw','elbow','wrist'])and(m.geom_contype[j]or m.geom_conaffinity[j])];torso=[j for j in range(m.ngeom)if m.body(int(m.geom_bodyid[j])).name=='torso_link'and(m.geom_contype[j]or m.geom_conaffinity[j])];pp=[(i,j)for i in prox for j in torso]
 def gaps(pairs):
  return np.array([mujoco.mj_geomDistance(m,d,int(i),int(j),.02,None)if np.linalg.norm(d.geom_xpos[i]-d.geom_xpos[j])-m.geom_rbound[i]-m.geom_rbound[j]<.02 else .02 for i,j in pairs])
 def fun(q):
  d.qpos[right]=q;mujoco.mj_kinematics(m,d);P,R=geo();return np.r_[(P-P0)/.001,Rotation.from_matrix(wanted.T@R).as_rotvec()/.02,.01*(q-q0),np.maximum(0.,.005-gaps(pairs))/.001,np.maximum(0.,.005-gaps(pp))/.001]
 fit=least_squares(fun,np.clip(q0,lo+1e-7,hi-1e-7),bounds=(lo,hi),max_nfev=200);fun(fit.x);P,R=geo();body=d.body('aero_right_palm');bodyR=body.xmat.reshape(3,3);C=np.array(pr['play']['field_catch_window_m']);A=np.diag(np.array([.142,.085,.085])**2);N=R[:,0];support=C-A@N/np.sqrt(N@A@N);local=R.T@(support-P);result={'static_only':True,'baseline':str(a.trial),'tilt_about_actual_pad_width_rad':a.tilt_rad,'scope':'Right arm only; actual face center preserved; fixed throw unchanged; no model/controller gains changed.','predeclared':{'max_position_error_m':.001,'max_orientation_error_rad':.02,'min_joint_margin_rad':.035,'min_interhand_gap_m':.005,'min_right_proximal_torso_gap_m':.005},'arm_order':names,'measured_right_arm_q':q0.tolist(),'right_arm_targets_rad':fit.x.tolist(),'right_arm_delta_rad':(fit.x-q0).tolist(),'face_center_before_m':P0.tolist(),'face_center_after_m':P.tolist(),'face_error_m':float(np.linalg.norm(P-P0)),'orientation_error_rad':float(np.linalg.norm(Rotation.from_matrix(wanted.T@R).as_rotvec())),'actual_pad_normal_world':N.tolist(),'body_palm_up_cos':float(-bodyR[2,1]),'body_finger_up_cos':float(bodyR[2,2]),'actual_pad_long_up_cos':float(R[2,2]),'support_finite_offsets_m':[float(local[1]),float(local[2])],'support_plane_gap_m':float(local[0]),'minimum_interhand_gap_m':float(gaps(pairs).min()),'minimum_right_proximal_torso_gap_m':float(gaps(pp).min()),'eligible_static':bool(np.linalg.norm(P-P0)<=.001 and np.linalg.norm(Rotation.from_matrix(wanted.T@R).as_rotvec())<=.02 and gaps(pairs).min()>=.005 and gaps(pp).min()>=.005 and abs(local[1])<=.042 and abs(local[2])<=.013)};a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
