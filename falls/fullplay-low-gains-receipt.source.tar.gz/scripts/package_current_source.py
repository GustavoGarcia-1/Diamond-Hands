"""Create an allowlisted current source snapshot, separate from Arena evidence."""
import argparse
from datetime import datetime, timezone
from hashlib import sha256
import io
import json
from pathlib import Path
import tarfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    if args.output.exists():
        raise FileExistsError(args.output)
    files = []
    for directory in ['src', 'scripts', 'tests', 'docs']:
        for path in (root/directory).rglob('*'):
            if not path.is_file() or any(part == '__pycache__' or part.endswith('.egg-info') for part in path.parts):
                continue
            if path.name == '.DS_Store' or path.suffix == '.pyc':
                continue
            if path.is_symlink():
                raise ValueError(f'Source snapshot requires regular files: {path.relative_to(root)}')
            files.append(path)
    for name in ['.gitignore', 'README.md', 'SENSOR_CONTRACT.md', 'handoff.md', 'pyproject.toml', 'uv.lock']:
        files.append(root/name)
    manifest = dict(created_utc=datetime.now(timezone.utc).isoformat(),
        scope='Current source for resuming development. Not a replacement for frozen experiment sources or the reviewed Arena submission.',
        excluded='Git history, environments, caches, credentials, research downloads, website checkout, experiment reports, checkpoints and generated media.',
        reproduction='Use the reviewed r3 project ZIP for selected evidence. Native experiment pins and source freezes are documented in handoff.md; the development uv.lock is not that exact runtime.',
        files={str(p.relative_to(root)): sha256(p.read_bytes()).hexdigest() for p in sorted(files)})
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(args.output, 'x:gz') as tar:
        for name in manifest['files']:
            tar.add(root/name, arcname=name, recursive=False)
        payload = (json.dumps(manifest, indent=2)+'\n').encode()
        entry = tarfile.TarInfo('SOURCE-SNAPSHOT.json')
        entry.size = len(payload)
        entry.mode = 0o644
        tar.addfile(entry, io.BytesIO(payload))
    with tarfile.open(args.output) as tar:
        for name, expected in manifest['files'].items():
            if sha256(tar.extractfile(name).read()).hexdigest() != expected:
                raise RuntimeError(f'Archive member mismatch: {name}')
    manifest.update(archive=str(args.output), archive_bytes=args.output.stat().st_size,
        archive_sha256=sha256(args.output.read_bytes()).hexdigest(), all_member_hashes_verified=True)
    args.output.with_name(args.output.name+'.manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print(json.dumps({k: v for k, v in manifest.items() if k != 'files'}))


if __name__ == '__main__':
    main()
