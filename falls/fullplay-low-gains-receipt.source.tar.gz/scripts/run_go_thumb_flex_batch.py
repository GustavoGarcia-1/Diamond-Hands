"""Narrow thumb-flex inlet engineering; original throw/physics and frozen PPO."""
import argparse,concurrent.futures,json,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--profile',type=Path,required=True);p.add_argument('--model',type=Path,required=True);p.add_argument('--source',type=Path,required=True);p.add_argument('--amp-source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);base=json.loads(a.profile.read_text());configs=[]
for label,opposition in [('original-opposition',base['native_grip']['preload'][4]),('opposition-0.5',.5)]:
 profile=json.loads(json.dumps(base));grip=profile['native_grip'];grip['preload'][4]=opposition;grip['preload'][5:7]=[0.,0.];grip['digit_delay_s'][5:7]=[.08,.08];path=a.output/(label+'-profile.json');path.write_text(json.dumps(profile,indent=2)+'\n');configs.append((label,path))
def run(job):
 (label,profile),gain=job;label+=f'-gain{gain}';command=[sys.executable,str(a.root/'scripts/probe_ball_hand_contact_model.py'),'--frozen-root',str(a.root),'--profile',str(profile),'--model',str(a.model),'--source',str(a.source),'--amp-source',str(a.amp_source),'--output',str(a.output/label),'--timeconstant','.02','--unmodified','--gain',str(gain),'--device','cuda']
 with (a.output/(label+'.log')).open('w')as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 return dict(label=label,gain=gain,profile=str(profile),command=command,exit_code=r.returncode)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:rows=list(pool.map(run,[(c,g)for c in configs for g in[0.,.5]]))
(a.output/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
if any(r['exit_code']for r in rows):raise RuntimeError('failedtrialspreserved')
