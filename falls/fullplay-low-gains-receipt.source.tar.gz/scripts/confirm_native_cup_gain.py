"""Same checkpoint/gain matched CPU repeat and CUDA precision confirmation."""
import argparse,json,subprocess,sys
from pathlib import Path

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for n in ('profile','source','amp-source','model','output'):p.add_argument('--'+n,type=Path,required=True)
 p.add_argument('--gain',type=float,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
 results=[]
 for device in ['cpu','cuda']:
  out=a.output/device;command=[sys.executable,'scripts/evaluate_native_cup_action_scale.py','--profile',str(a.profile),'--source',str(a.source),'--amp-source',str(a.amp_source),'--output',str(out),'--models',str(a.model),'--scales',str(a.gain),'--device',device]
  result=subprocess.run(command,check=False);results.append(dict(device=device,exit_code=result.returncode,command=command));(a.output/'confirm-receipt.json').write_text(json.dumps(results,indent=2)+'\n')
  if result.returncode:raise RuntimeError('confirmation failed')
if __name__=='__main__':main()
