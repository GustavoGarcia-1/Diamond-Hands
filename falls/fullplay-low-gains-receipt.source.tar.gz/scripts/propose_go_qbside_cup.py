"""Bounded static FK/IK proposal from the measured mirrored Out cup; no dynamics or controller transfer."""
import json,time,hashlib,argparse
from pathlib import Path
import numpy as np,mujoco
from scipy.optimize import least_squares
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
parser=argparse.ArgumentParser();parser.add_argument('--cup-yaw-deg',type=float,default=-20.);parser.add_argument('--min-up',type=float,default=.65);parser.add_argument('--output-name',default='static-proposals.json');args=parser.parse_args();P=Path('reports/catch-repair-20261114');out=P/'go-side-cup';out.mkdir(exist_ok=True);source=P/'out-cup/right-up-margin-transfer-geometry.json';template=json.loads(source.read_text());scene=P/'contact-model/study-linux/artifacts/study/original20-gain0.5/scene.xml';xml=scene.read_text().replace('/workspace/g1-receiver-runs/catch-repair-contact-model-20261114-r1/source/src/g1_receiver/_vendor/g1_runtime',str(DEFAULT_RUNTIME_ROOT)).replace('/workspace/g1-receiver-runs/out-scrimmage-20261113/source/aero-source','/tmp/g1-aero-source');m=mujoco.MjModel.from_xml_string(xml);d=mujoco.MjData(m);original=np.load(P/'validation/protected-witness-linux/witness/offline-robot-qpos.npz');k=np.argmin(abs(original['timestamps_s']-5.18));base=original['qpos'][k].copy();names=template['arm_order'];ids=np.array([m.joint(n).id for n in names]);addresses=m.jnt_qposadr[ids];lo=m.jnt_range[ids,0]+.04;hi=m.jnt_range[ids,1]-.04;sign=np.array([-1,-1,1,1,-1,1,-1]);old=np.array(template['actual_measured_arm_q_rad']);seed=np.r_[old[7:]*sign,old[:7]*sign];seed=np.clip(seed,lo+1e-6,hi-1e-6);S=np.diag([1,-1,1]);phi=np.deg2rad(args.cup_yaw_deg);R=np.array([[np.cos(phi),-np.sin(phi),0],[np.sin(phi),np.cos(phi),0],[0,0,1.]])
# Native digit pose is physically measured in the Out dry run; mirror joint identities.
qsource=np.load(P/'out-cup/right-up-margin-dry-r1/artifacts/trial/offline-robot-qpos.npz');qi=np.argmin(abs(qsource['timestamps_s']-6.2));native_source=qsource['qpos'][qi]
for j in range(m.njnt):
 n=m.joint(j).name
 if not n.startswith('aero_'):continue
 opposite=n.replace('left','TEMP').replace('right','left').replace('TEMP','right');other=m.joint(opposite).id;base[int(m.jnt_qposadr[j])]=native_source[int(m.jnt_qposadr[other])]
waist=m.joint('waist_yaw_joint').qposadr[0];base[waist]=-template['actual_waist_yaw_rad'];d.qpos[:]=base;mujoco.mj_kinematics(m,d);pelvis=d.xpos[m.body('pelvis').id].copy();Fpel=d.xmat[m.body('pelvis').id].reshape(3,3);yaw=np.arctan2(Fpel[1,0],Fpel[0,0]);Y=np.array([[np.cos(yaw),-np.sin(yaw),0],[np.sin(yaw),np.cos(yaw),0],[0,0,1.]])
hands=template['hands'];mirrored=[]
for source_hand in [hands[1],hands[0]]:mirrored.append(dict(pos=S@np.array(source_hand['facet_center_pelvis_yaw_frame_m']),normal=R@S@np.array(source_hand['facet_normal_pelvis_yaw_frame']),long=R@S@np.array(source_hand['facet_long_axis_pelvis_yaw_frame'])))
mean=np.mean([h['pos']for h in mirrored],axis=0);pads=[m.geom('aero_'+s+'_palm_collision_7').id for s in ['left','right']];palms=[m.body('aero_'+s+'_palm').id for s in ['left','right']];start=time.monotonic();results=[]
def fk(q):
 d.qpos[:]=base;d.qpos[addresses]=q;mujoco.mj_kinematics(m,d);rows=[]
 for g,b,sgn in zip(pads,palms,[1,-1]):
  F=d.geom_xmat[g].reshape(3,3);center=d.geom_xpos[g]+m.geom_size[g,0]*F[:,0];bodyN=d.xmat[b].reshape(3,3)@np.array([0,sgn,0]);rows.append(dict(pos=center.copy(),normal=F[:,0].copy(),long=F[:,2].copy(),body_normal=bodyN.copy()))
 return rows
for x,y in[(.30,-.15),(.30,-.20),(.25,-.20),(.30,-.25)]:
 center=np.array([x,y,.40]);targets=[dict(pos=pelvis+Y@(center+R@(h['pos']-mean)),normal=Y@h['normal'],long=Y@h['long'])for h in mirrored]
 def objective(q):
  if time.monotonic()-start>55:raise TimeoutError('boundedIKwall55s')
  f=fk(q);res=[]
  for a,b in zip(f,targets):res.extend(150*(a['pos']-b['pos']));res.extend(3*(a['normal']-b['normal']));res.extend(2*(a['long']-b['long']));res.append(30*max(0,args.min_up-a['body_normal'][2]))
  res.extend(.07*(q-seed));return res
 try:fit=least_squares(objective,seed,bounds=(lo,hi),max_nfev=150,ftol=1e-9,xtol=1e-9,gtol=1e-9)
 except TimeoutError:break
 f=fk(fit.x);position=[float(np.linalg.norm(a['pos']-b['pos']))for a,b in zip(f,targets)];angles=[float(np.rad2deg(np.arccos(np.clip(a['normal']@b['normal'],-1,1))))for a,b in zip(f,targets)];rows=[]
 for a in f:rows.append({k:v.tolist()for k,v in a.items()})
 results.append(dict(cup_center_pelvis_yaw_frame_m=center.tolist(),waist_yaw_rad=float(base[waist]),torso_goal_yaw_rad=-.65,cup_common_yaw_rotation_rad=float(phi),arm_order=names,arm_targets_rad=fit.x.tolist(),arm_seed_rad=seed.tolist(),max_arm_change_from_seed_rad=float(np.max(abs(fit.x-seed))),position_error_m=position,normal_error_deg=angles,body_palm_up_cos=[float(a['body_normal'][2])for a in f],facet_up_cos=[float(a['normal'][2])for a in f],minimum_arm_joint_margin_rad=float(np.min(np.minimum(fit.x-m.jnt_range[ids,0],m.jnt_range[ids,1]-fit.x))),actual_fk=rows,targets=[{k:v.tolist()for k,v in t.items()}for t in targets],solver_success=bool(fit.success),cost=float(fit.cost),offline_only=True))
report=dict(offline_only=True,no_physics_steps=True,no_runtime_qpos_injection=True,no_catch_claim=True,source_template=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),geometry_from_measured_dry=True,body_snapshot_time_s=float(original['timestamps_s'][k]),arm_coordinate_mirror_signs=sign.tolist(),native_schedule='reuseOut .4fingers/thumb0; gate+.35 finger.65, gate+.5thumb(.5,.3,.4),ramp.25; no modeltransfer',results=results,elapsed_s=time.monotonic()-start);(out/args.output_name).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps([dict(center=r['cup_center_pelvis_yaw_frame_m'],error=r['position_error_m'],normal=r['normal_error_deg'],up=r['body_palm_up_cos'],margin=r['minimum_arm_joint_margin_rad'])for r in results],indent=2))
