"""Matched nominal-controller robustness: shift throw aim ONLY, catch plane fixed."""
import argparse,hashlib,json
from pathlib import Path
import numpy as np
from stable_baselines3 import PPO
from g1_receiver.native_cup_training import NativeCatchEnv

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for n in ('profile','source','amp-source','model','output'):p.add_argument('--'+n,type=Path,required=True)
 p.add_argument('--gain',type=float,default=.5);p.add_argument('--device',choices=['cpu','cuda'],default='cuda');a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
 if not 0<=a.gain<=1:p.error('gain must lie0..1')
 donor=json.loads(a.profile.read_text());model=PPO.load(a.model,device=a.device);results=[]
 for shift in [-.02,.02]:
  case=a.output/('minus2cm'if shift<0 else'plus2cm');case.mkdir();profile=json.loads(json.dumps(donor));profile['play']['quarterback_target_m'][1]+=shift;path=case/'profile.json';path.write_text(json.dumps(profile,indent=2)+'\n')
  for name,gain in [('half',a.gain)]:
   env=NativeCatchEnv(path,a.source,a.amp_source,evaluation_dir=case/name,duration=9.,sensor_retention_camera_position=(6,-2.5,2.4),sensor_retention_camera_target=(7,0,1),sensor_retention_pose_camera_position=(3.5,0,1.4),sensor_retention_pose_camera_target=(6.5,0,.9))
   try:
    obs,_=env.reset(seed=173);total=0.
    while True:
     action=np.zeros(20,dtype=np.float32)if name=='zero'else model.predict(obs,deterministic=True)[0]*gain
     obs,reward,done,_,info=env.step(action);total+=reward
     if done:break
    report=json.loads((case/name/'episode-0001/trial/report.json').read_text());row=dict(throw_target_lateral_shift_m=shift,catchplane_unchanged=profile['play']['field_catch_window_m']==donor['play']['field_catch_window_m'],controller=name,action_gain=gain,model_sha256=hashlib.sha256(a.model.read_bytes()).hexdigest(),inference_device=a.device,returned_sensor_reward=total,sensor=info,anatomical=report['anatomical_score'],legacy=report['quarterback_pass_score'])
    if not np.isclose(total,info['sensor_return'],atol=1e-9):raise RuntimeError('ledger mismatch')
    results.append(row);(a.output/'summary.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
   finally:env.close()
if __name__=='__main__':main()
