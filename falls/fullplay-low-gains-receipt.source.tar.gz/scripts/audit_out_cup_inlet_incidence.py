"""Offline dry-run initial contact incidence; post-contact free-path overlap is diagnostic only."""
import argparse,json
from pathlib import Path
import numpy as np,mujoco
from g1_receiver.aero import make_aero_scene
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT

def main():
 p=argparse.ArgumentParser()
 for n in ['source','trial','profile','output']:p.add_argument('--'+n,type=Path,required=True)
 a=p.parse_args();pr=json.loads(a.profile.read_text());m=mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT,a.source));d=mujoco.MjData(m);prev=mujoco.MjData(m);v=np.load(a.trial/'offline-robot-qpos.npz');t=v['timestamps_s'];q=v['qpos'];ba=int(m.joint('football_free').qposadr[0]);bg=int(m.geom('football_surface').id);T=pr['play']['flight_s'];arrival=pr['offline_fixture_arrival_s'];release=arrival-T;O=np.array(pr['play']['quarterback_origin_m']);C=np.array(pr['play']['field_catch_window_m']);V=(C-O)/T+[0,0,4.905*T];rows=[];prox=[g for g in range(m.ngeom)if any(m.body(int(m.geom_bodyid[g])).name.startswith(s+'_'+part)for s in ['left','right']for part in ['shoulder_roll','shoulder_yaw','elbow','wrist'])and(m.geom_contype[g]or m.geom_conaffinity[g])];torso=[g for g in range(m.ngeom)if m.body(int(m.geom_bodyid[g])).name=='torso_link'and(m.geom_contype[g]or m.geom_conaffinity[g])];min_gap=.1;witness=None
 for i in np.flatnonzero((t>=release)&(t<=arrival+.001)):
  d.qpos[:]=q[i];elapsed=t[i]-release;ball=O+V*elapsed+[0,0,-4.905*elapsed*elapsed];d.qpos[ba:ba+7]=np.r_[ball,[1,0,0,0]];mujoco.mj_forward(m,d)
  for g in prox:
   for h in torso:
    if np.linalg.norm(d.geom_xpos[g]-d.geom_xpos[h])-m.geom_rbound[g]-m.geom_rbound[h]>.02:continue
    gap=mujoco.mj_geomDistance(m,d,g,h,.02,None)
    if gap<min_gap:min_gap=float(gap);witness=dict(time_s=float(t[i]),geom1=g,geom2=h,body1=m.body(int(m.geom_bodyid[g])).name,body2=m.body(int(m.geom_bodyid[h])).name)
  if rows:continue
  contacts=[c for c in d.contact if bg in c.geom and c.dist<=0]
  if not contacts:continue
  prev.qpos[:]=q[max(0,i-1)];mujoco.mj_kinematics(m,prev)
  for c in contacts:
   other=int(c.geom[1]if c.geom[0]==bg else c.geom[0]);body=int(m.geom_bodyid[other]);n=c.frame[:3].copy()*(1 if c.geom[0]==bg else-1);point=c.pos.copy();local=d.xmat[body].reshape(3,3).T@(point-d.xpos[body]);old=prev.xpos[body]+prev.xmat[body].reshape(3,3)@local;pv=(point-old)/(t[i]-t[max(0,i-1)]);bv=V+[0,0,-9.81*elapsed];rows.append(dict(geometry_time_s=float(t[i]),force_recorder_expected_next_step_s=float(t[i]+.001),geom_id=other,geom=m.geom(other).name,body=m.body(body).name,initial_geometric_depth_m=float(-c.dist),normal_ball_toward_geom_world=n.tolist(),native_surface_point_velocity_mps=pv.tolist(),relative_velocity_mps=(bv-pv).tolist(),normal_closing_speed_mps=float((bv-pv)@n)))
 result=dict(evaluation_only=True,assumptions='Unimpeded declared fixture versus actual recorded dry robot; real contact may deflect and rotate ball. Full future free-path overlap is not an actual-penetration claim.',first_contacts=rows,minimum_proximal_torso_gap_m=min_gap,proximal_torso_witness=witness);a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
