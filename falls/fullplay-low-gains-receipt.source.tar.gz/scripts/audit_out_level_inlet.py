"""Offline unimpeded ball sweep against a recorded open-hand dry trajectory."""
import argparse
import json
from pathlib import Path

import mujoco
import numpy as np

from g1_receiver.aero import make_aero_scene
from g1_receiver.anatomical_catch_eval import AnatomicalContactAudit
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
from g1_receiver.scrimmage_throw import ScrimmagePass


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ['source', 'trial', 'profile', 'output']:
        parser.add_argument('--'+key, type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    profile = json.loads(args.profile.read_text())
    model = mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT, args.source))
    data = mujoco.MjData(model)
    audit = AnatomicalContactAudit(model)
    ball = model.geom('football_surface').id
    address = int(model.joint('football_free').qposadr[0])
    arrival = profile['offline_fixture_arrival_s']
    release = arrival-profile['play']['flight_s']
    recorded_release = json.loads((args.trial/'report.json').read_text())['release']['release_time_s']
    if not np.isclose(release, recorded_release, atol=1e-8, rtol=0.):
        raise ValueError('Offline arrival must use the actual quantized release from the calibration report')
    plan = ScrimmagePass(tuple(profile['play']['quarterback_origin_m']),
        tuple(profile['play']['quarterback_target_m']), profile['play']['flight_s'],
        align_ball_to_launch=not profile['play'].get('quarterback_level_ball', False),
        horizontal_distance_only=True).plan(release)
    geoms = np.array([g for g in range(model.ngeom) if g != ball and model.geom_bodyid[g] > 0 and (model.geom_contype[g] or model.geom_conaffinity[g])])
    poses = np.load(args.trial/'offline-robot-qpos.npz')
    minimum = {}
    first = {}
    for stamp, qpos in zip(poses['timestamps_s'], poses['qpos']):
        if not arrival-.25-1e-8 <= stamp <= arrival+1e-8:
            continue
        elapsed = stamp-release
        center = np.array(plan.release_xyz_m)+elapsed*np.array(plan.release_velocity_mps)
        center[2] -= 4.905*(elapsed**2+model.opt.timestep*elapsed)
        data.qpos[:] = qpos
        data.qpos[address:address+7] = np.r_[center, plan.release_quaternion_wxyz]
        mujoco.mj_kinematics(model, data)
        lower = np.linalg.norm(data.geom_xpos[geoms]-center, axis=1)-model.geom_rbound[geoms]-model.geom_rbound[ball]
        for geom in geoms[lower < .05]:
            gap = float(mujoco.mj_geomDistance(model, data, ball, int(geom), .05, None))
            if geom not in minimum or gap < minimum[geom]['gap_m']:
                minimum[geom] = dict(geom=model.geom(int(geom)).name, category=audit.kind[geom], gap_m=gap, time_s=float(stamp))
            if gap <= 0 and geom not in first:
                first[geom] = dict(geom=model.geom(int(geom)).name, category=audit.kind[geom], gap_m=gap, time_s=float(stamp))
    result = dict(scope=__doc__, offline_only=True, not_a_physical_rollout=True,
        physics_unchanged=True, release_s=release, arrival_s=arrival,
        recorded_calibration_release_s=recorded_release,
        timing='Measured 50 Hz release and 1 ms semi-implicit gravity extrapolation; fixed initial orientation.',
        minimum_gaps=sorted(minimum.values(), key=lambda x: x['gap_m']),
        first_intersections=sorted(first.values(), key=lambda x: x['time_s']))
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(dict(first_intersections=result['first_intersections'][:12], minimum_gaps=result['minimum_gaps'][:12]), indent=2))


if __name__ == '__main__':
    main()
