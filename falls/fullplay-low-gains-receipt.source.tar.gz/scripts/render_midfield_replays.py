"""Render immutable selected traces with the machine at the field's midpoint."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
from concurrent.futures import ThreadPoolExecutor
from package_held_routes import ROUTES


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    root = Path(__file__).resolve().parents[1]
    native = root/'reports/catch-form-20261114/overnight-lower/native-rl'
    entries = [(name, root/r['expected'], dict(go=0., out=23.777748497929165, slant=42.74267735623945)[name], False)
        for name, r in ROUTES.items()]
    entries += [('native-baseline', native/'gain-ablation/artifacts/evaluation/checkpoint-00019456-gain-0.0/episode-0001/trial', 0., True),
                ('native-learned', native/'gain-confirm/artifacts/evaluation/cpu/checkpoint-00019456-gain-0.5/episode-0001/trial', 0., True)]
    def render(entry):
        name, trial, heading, fixed = entry
        out = a.output/name
        out.mkdir()
        command = [str(root/'.venv/bin/mjpython'), 'scripts/render_aero_stadium.py', '--source', str(a.source),
            '--input', str(trial/'view.npz'), '--output', str(out/'full-play.npz'),
            '--report', str(trial/'report.json'), '--quarterback', '--studio', '--midfield',
            '--receiver-split-m', '1.8288', '--heading-deg', str(heading), '--width', '1280', '--height', '720']
        if fixed:
            command += ['--fixed-lookat', '4', '-.3', '.8', '--distance-m', '11', '--azimuth-deg', '105', '--elevation-deg', '-15']
        else:
            camera = dict(go=(6.6, -.7, 1.1, 13.), out=(2., 2.7, 1.1, 12.), slant=(6.4, -.4, 1.1, 13.))
            x, y, z, distance = camera[name]
            command += ['--fixed-lookat', str(x), str(y), str(z), '--distance-m', str(distance), '--azimuth-deg', '105', '--elevation-deg', '-15']
        subprocess.run(command, cwd=root, check=True)
        subprocess.run([str(root/'.venv/bin/python'), 'scripts/encode_receiver_replay.py', str(out/'full-play.npz'), str(out/'full-play.mp4')], cwd=root, check=True)
        subprocess.run([str(root/'.venv/bin/python'), 'scripts/verify_field_replay.py', '--directory', str(out), '--source', str(trial/'view.npz')], cwd=root, check=True)
        receipt = dict(route=name, source=str(trial), source_pose_sha256=sha256((trial/'view.npz').read_bytes()).hexdigest(),
            render_command=command, video_sha256=sha256((out/'full-play.mp4').read_bytes()).hexdigest(),
            field_50yard_center_at_actual_passer=True, physics_and_poses_unchanged=True,
            replay_verification=json.loads((out/'video-verification.json').read_text()))
        (out/'presentation.json').write_text(json.dumps(receipt, indent=2)+'\n')
        return receipt
    with ThreadPoolExecutor(max_workers=2) as pool:
        rows = list(pool.map(render, entries))
    result = dict(replays=rows, source_sha256={name:sha256((root/name).read_bytes()).hexdigest()
        for name in ('scripts/render_midfield_replays.py', 'scripts/render_aero_stadium.py', 'src/g1_receiver/stadium.py')})
    (a.output/'manifest.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(dict(completed=[r['route'] for r in rows])))


if __name__ == '__main__':
    main()
