"""Offline local flight-duration bound for the recorded downhill palm direction."""
import argparse
import json
from pathlib import Path
import numpy as np


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--profile', type=Path, required=True)
    parser.add_argument('--rollout-analysis', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    profile = json.loads(args.profile.read_text())
    measured = json.loads(args.rollout_analysis.read_text())
    axis = np.array(measured['left_pad_longitudinal_world'])
    normal = np.array(measured['left_pad_normal_world'])
    velocity = np.array(measured['pad_velocity_ols_mps'])
    origin = np.array(profile['play']['quarterback_origin_m'])
    center = np.array(profile['play']['field_catch_window_m'])
    delta = center-origin
    gravity, step = 9.81, .001
    A = float(delta@axis)
    B = float(-.5*gravity*axis[2])
    C = float(.5*gravity*step*axis[2]-velocity@axis)
    if A <= 0 or B <= 0:
        raise ValueError('Positive A/B required for this downhill analytic bound')
    optimum = float(np.clip(np.sqrt(A/B), .4, 1.6))

    def measure(duration):
        relative = delta/duration+np.array([0., 0., -.5*gravity*duration+.5*gravity*step])-velocity
        return dict(flight_s=duration, relative_longitudinal_mps=float(relative@axis),
            relative_normal_mps=float(relative@normal), relative_total_mps=float(np.linalg.norm(relative)))

    minimum = A/optimum+B*optimum+C
    grid = np.linspace(.4, 1.6, 10001)
    grid_minimum = float(np.min(A/grid+B*grid+C))
    assert abs(grid_minimum-minimum) < 1e-6
    report = dict(scope=__doc__, offline_only=True, formula='s(T)=A/T+B*T+C',
        coefficients=dict(A_m=A, B_mps2=B, C_mps=C),
        permitted_flight_interval_s=[.4, 1.6], minimizing_flight_s=optimum,
        minimum_longitudinal_speed_mps=minimum, sampled_grid_minimum_mps=grid_minimum,
        current_duration=measure(profile['play']['flight_s']), optimum=measure(optimum),
        samples=[measure(t) for t in [.4, .6, .8, 1., 1.25, 1.6]],
        assumptions=['Fixed measured pad axis and OLS velocity at the same receiving pose/time.',
            'Fixed surveyed release point and desired physical target; only flight duration varies.',
            'Constant gravity and 1 ms semi-implicit aim correction; no aerodynamic or spin model.',
            'Evaluated at intended arrival. A velocity estimated over an earlier precontact window need not equal this instantaneous value.'],
        conclusion='Changing flight duration alone cannot substantially reduce the longitudinal speed in this local frozen geometry. This does not constrain changed hand pose, body motion, target position, sustained contact or other trajectories. No runtime, reward, scoring or physics changes.')
    args.output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(dict(minimum=report['optimum'], current=report['current_duration'])))


if __name__ == '__main__':
    main()
