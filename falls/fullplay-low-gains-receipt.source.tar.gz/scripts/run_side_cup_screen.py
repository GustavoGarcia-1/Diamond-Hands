"""Actual-ready FK + declared ellipsoid geometry seeds; small fixedthrow grid."""
from pathlib import Path
from copy import deepcopy
from concurrent.futures import ProcessPoolExecutor,as_completed
import argparse,json,traceback
import numpy as np,mujoco
import probe_lower_cup_side_clear as runner
from g1_receiver.scrimmage_throw import ScrimmagePass

def seed(profile,flight,calibration):
 row=min(calibration['poses'],key=lambda x:abs(x['time_s']-5.2));faces=np.array([h['face_world_m']for h in row['hands']]);N=np.array([h['normal_world']for h in row['hands']]);mid=faces.mean(0);normal=N.mean(0);normal/=np.linalg.norm(normal);point=mid+.12*normal;origin=profile['play']['quarterback_origin_m'];radii=None
 for _ in range(30):
  plan=ScrimmagePass(tuple(origin),tuple(point),flight,horizontal_distance_only=True).plan(5.2-flight);R=np.empty(9);mujoco.mju_quat2Mat(R,np.array(plan.release_quaternion_wxyz));R=R.reshape(3,3);radii=np.sqrt(np.sum(((N@R)*np.array([.142,.085,.085]))**2,axis=1));A=R@np.diag(np.array([.142,.085,.085])**2)@R.T;support_vectors=(A@N.T).T/radii[:,None];new=np.mean(faces+support_vectors,axis=0)
  if np.linalg.norm(new-point)<1e-8:point=new;break
  point=new
 return point,normal,dict(face_world_m=faces.tolist(),normal_world=N.tolist(),support_radius_m=radii.tolist(),seed_m=point.tolist(),calibration_time_s=row['time_s'],method='declaredlaunchorientation/full ellipsoid support VECTOR at actual finite palm faces; offlineonly')

def execute(job):
 root,donor,source,amp,reference,index,flight,depth,calibration,phase=job;p=deepcopy(donor);target,normal,description=seed(p,flight,calibration);target+=depth*normal;p['play']['grasp_joint_lead_s']=-.18 if phase=='late'else-.04;p['play']['flight_s']=flight;p['play']['release_s']=5.2-flight;p['play']['quarterback_target_m']=target.tolist();p['play']['field_catch_window_m']=target.tolist();axis=target[:2]-np.array(p['play']['quarterback_origin_m'])[:2];p['play']['field_approach_axis_xy']=(axis/np.linalg.norm(axis)).tolist();p['offline_forward_calibration']=dict(**description,normal_delta_m=depth,target_m=target.tolist());path=root/f'profile-{index:02d}.json';path.write_text(json.dumps(p,indent=2)+'\n')
 try:
  args=runner.build_parser().parse_args(['--source',str(source),'--amp-source',str(amp),'--profile',str(path),'--output',str(root/f'case-{index:02d}'),'--walk-speed','1','--handoff-depth','1.3','--initial-yaw','-.7','--duration','9','--record-anatomical','--reference-physics-sha256',reference]);report=runner.run(args);r=dict(case=index,arm_phase=phase,flight_s=flight,normal_depth_m=depth,anatomical=report['anatomical_score'],legacy=report['quarterback_pass_score'],minimum_upright_cosine=report['minimum_upright_cosine'])
 except BaseException as e:r=dict(case=index,arm_phase=phase,flight_s=flight,normal_depth_m=depth,error=repr(e),traceback=traceback.format_exc())
 (root/f'score-{index:02d}.json').write_text(json.dumps(r,indent=2)+'\n');return r

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for n in ['source','amp-source','profile','output','calibration']:p.add_argument('--'+n,type=Path,required=True)
 p.add_argument('--reference',required=True);p.add_argument('--workers',type=int,default=2);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);profile=json.loads(a.profile.read_text());cal=json.loads(a.calibration.read_text());parameters=[(.8,0.,'late'),(.8,0.,'full'),(.85,0.,'late'),(.85,0.,'full'),(.8,.005,'late'),(.8,-.005,'late')];jobs=[(a.output,profile,a.source,a.amp_source,a.reference,i,t,d,cal,phase)for i,(t,d,phase)in enumerate(parameters)];rows=[]
 with ProcessPoolExecutor(max_workers=a.workers)as pool:
  for f in as_completed([pool.submit(execute,j)for j in jobs]):rows.append(f.result());(a.output/'summary.json').write_text(json.dumps(sorted(rows,key=lambda x:x['case']),indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
if __name__=='__main__':main()
