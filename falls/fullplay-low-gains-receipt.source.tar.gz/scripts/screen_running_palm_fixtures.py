"""Offline finite-palm fixture screen over recorded running poses; no control."""
from pathlib import Path
import argparse
import json
import mujoco
import numpy as np
from g1_receiver.hand_route_plant import HandRoutePlant
from g1_receiver.scrimmage_throw import ScrimmagePass


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', type=Path, required=True)
    p.add_argument('--trials', type=Path, required=True)
    p.add_argument('--cases', type=int, nargs='+', required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    if a.output.exists():
        p.error('use a fresh output')
    plant = HandRoutePlant(a.source, hand_model='aero', survey_camera=False)
    origin = np.array([0., -1.8288, 1.4])
    rows = []
    skipped_unsynchronized_poses = 0
    try:
        for case in a.cases:
            trial = a.trials / f'case-{case:02d}'
            form = json.loads((trial / 'anatomical-form.json').read_text())
            motion = np.load(trial / 'trace.npz')['motion']
            view = np.load(trial / 'view.npz')
            def faces(row):
                xyz = [np.interp(row['time_s'], motion[:, 0], motion[:, i]) for i in (1, 2, 3)]
                return np.array(row['metrics']['palm_face_centers_relative_pelvis_m']) + xyz
            selected = [r for r in form if 8.894 <= np.interp(r['time_s'], motion[:, 0], motion[:, 1]) <= 9.394]
            for row in selected:
                t = row['time_s']
                F = faces(row)
                N = np.array(row['metrics']['palm_normals_world'])
                if N[:, 2].min() < .60 or np.linalg.matrix_rank(N) < 2:
                    continue
                history = [r for r in form if t - .060001 <= r['time_s'] <= t + 1e-8]
                times = np.array([r['time_s'] for r in history])
                V = np.linalg.lstsq(np.c_[np.ones(len(times)), times - times[-1]],
                    np.array([faces(r) for r in history]).reshape(len(times), 6), rcond=None)[0][1].reshape(2, 3)
                k = int(np.argmin(abs(view['timestamps_s'] - t)))
                if abs(view['timestamps_s'][k] - t) > 1e-8:
                    skipped_unsynchronized_poses += 1
                    continue
                plant.data.qpos[:] = view['qpos'][k]
                mujoco.mj_kinematics(plant.model, plant.data)
                R = [plant.data.body(f'aero_{s}_palm').xmat.reshape(3, 3).copy() for s in ('left', 'right')]
                tangent_axis = np.cross(*N)
                tangent_axis /= np.linalg.norm(tangent_axis)
                for flight in np.arange(.7, 1.601, .05):
                    flight = round(float(flight), 3)
                    for slide in np.linspace(-.12, .12, 13):
                        point = F.mean(0) + .11 * N.mean(0)
                        converged = False
                        condition = float(np.linalg.cond(N @ N.T))
                        for iteration in range(20):
                            plan = ScrimmagePass(tuple(origin), tuple(point), flight, horizontal_distance_only=True).plan(t-flight)
                            rotation = np.empty(9)
                            mujoco.mju_quat2Mat(rotation, np.array(plan.release_quaternion_wxyz))
                            rotation = rotation.reshape(3, 3)
                            Q = rotation @ np.diag(np.array([.142, .085, .085])**2) @ rotation.T
                            radius = np.sqrt(np.einsum('ij,jk,ik->i', N, Q, N))
                            support = (Q @ N.T).T / radius[:, None]
                            seed = (F + support).mean(0) + slide * tangent_axis
                            plane = np.einsum('ij,ij->i', N, F) + radius
                            updated = seed + N.T @ np.linalg.solve(N @ N.T, plane - N @ seed)
                            if np.linalg.norm(updated-point) < 1e-9:
                                point = updated
                                converged = True
                                break
                            point = updated
                        local = np.array([r.T @ (point-s-f) for r, s, f in zip(R, support, F)])
                        terminal = np.array(plan.release_velocity_mps) - np.array([0., 0., 9.81*flight])
                        incidence = np.einsum('ij,ij->i', terminal - V, N)
                        patch_error = np.c_[np.maximum(abs(local[:, 0])-.025, 0),
                            abs(local[:, 1]), np.maximum(local[:, 2]-.020, 0)+np.maximum(-.035-local[:, 2], 0)]
                        front = bool(np.all((incidence >= -1.5) & (incidence <= -.05)))
                        eligible = converged and condition < 1e6 and front and float(patch_error.max()) <= .003
                        rows.append(dict(case=case, time_s=t, flight_s=flight, slide_m=float(slide),
                            target_m=point.tolist(), local_support_offsets_m=local.tolist(),
                            relative_normal_velocity_mps=incidence.tolist(), frontside=front,
                            view_timestamp_s=float(view['timestamps_s'][k]), converged=converged,
                            fixed_point_iterations=iteration+1, normal_gram_condition=condition,
                            maximum_finite_patch_error_m=float(patch_error.max()), eligible_geometry_only=eligible))
        a.output.parent.mkdir(parents=True, exist_ok=True)
        result = dict(scope='Offline recorded-pose geometry only. No runtime inputs, dynamics or catch claim.',
            criteria='Pelvis X9.144±.250m; up>=.60; both incidence[-1.5,-.05]m/s; finite palm X±25mm,Z[-35,+20]mm with3mm allowance. Actual collision validation still required.',
            count=len(rows), skipped_unsynchronized_poses=skipped_unsynchronized_poses,
            eligible=[r for r in rows if r['eligible_geometry_only']],
            closest_frontside=sorted([r for r in rows if r['frontside']], key=lambda r:r['maximum_finite_patch_error_m'])[:30],
            candidates=rows)
        a.output.write_text(json.dumps(result, indent=2)+'\n')
        print(json.dumps(dict(count=len(rows), eligible_count=len(result['eligible']),
            skipped_unsynchronized_poses=skipped_unsynchronized_poses,
            closest_frontside=result['closest_frontside'][:1]), indent=2))
    finally:
        plant.close()


if __name__ == '__main__':
    main()
