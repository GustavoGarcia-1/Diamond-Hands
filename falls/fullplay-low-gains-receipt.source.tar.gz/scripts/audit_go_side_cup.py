"""Independent trace-only rescore and release/actuation checks for Go side cup."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import numpy as np
import mujoco
from g1_receiver.anatomical_catch_eval import score_anatomical_catch

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT/'reports/catch-repair-20261114/go-side-cup'
OUTPUT = ROOT/'reports/catch-repair-20261114/validation/go-side-cup-independent.json'


def main():
    model = mujoco.MjModel.from_binary_path(str(ROOT/'reports/catch-form-20261114/overnight-validation/frozen-reference-linux/artifacts/reference/baseline.mjb'))
    ball_q = int(model.joint('football_free').qposadr[0])
    ball_v = int(model.joint('football_free').dofadr[0])
    cases = [BASE/'causal-pass-linux/artifacts/study'/x for x in ('original20', 'experimental2p5')]
    cases += [BASE/'thumb-timing-linux/artifacts/study'/x for x in ('original20-thumb30', 'original20-thumb40', 'experimental2p5-thumb30', 'experimental2p5-thumb40')]
    cases += [BASE/'causal-confirm-linux/artifacts/study'/x for x in ('confirm-9s', 'confirm-11s')]
    rows = []
    for path in cases:
        trial = path/'trial'
        report = json.loads((trial/'report.json').read_text())
        metadata = json.loads((trial/'anatomical-metadata.json').read_text())
        form = json.loads((trial/'anatomical-form.json').read_text())
        arrays = dict(np.load(trial/'anatomical-contact.npz'))
        trace = dict(np.load(trial/'trace.npz'))
        score = score_anatomical_catch(arrays, release_time_s=report['release']['release_time_s'],
                                      finish_time_s=report['duration_s'], ball_weight_n=metadata['ball_weight_n'],
                                      form_rows=form, motion=trace['motion'],
                                      physics_reference_match=metadata['physics_reference_match'],
                                      verified_free_ball=metadata['free_ball_joint_and_no_attachment_verified'])
        assert score == report['anatomical_score'], path
        state = np.load(path/'actual-state.npz')
        q, v, ctrl = (state[k] for k in ('time_qpos', 'time_qvel', 'time_control'))
        before = q[:, 0] <= report['release']['release_time_s']+1e-8
        columns = {k: i for i, k in enumerate(arrays['anatomical_contact_columns'])}
        contact = arrays['anatomical_contact']
        scene = ET.fromstring((path/'scene.xml').read_text())
        free = scene.find('.//body[@name="football"]/freejoint') is not None
        attached = any('football' in str(e.attrib) for e in scene.findall('./equality/*'))
        assert free and not attached
        displacement = np.ptp(q[before, 1+ball_q:1+ball_q+3], axis=0)
        pre_speed = np.max(np.abs(v[before, 1+ball_v:1+ball_v+6]))
        load_count = int(np.count_nonzero(contact[:, columns['applied_ball_load']]))
        assert np.max(displacement) == 0. and pre_speed == 0. and load_count == 0
        ranges = np.asarray(metadata['physics_parameters']['actuator_ctrlrange'])[:29]
        # First 29 channels are body torque motors; native position/tendon
        # channels have different units and are not interpreted as Nm.
        torque = ctrl[:, 1:30]
        assert np.all(torque >= ranges[:, 0]-1e-8) and np.all(torque <= ranges[:, 1]+1e-8)
        witness = np.load(path/'ball-contact-witness.npz')
        w = witness['ball_contact_witness']
        active = w[w[:, 4] > .1]
        def describe(row):
            return dict(time_s=float(row[0]), geom=str(witness['geom_names'][int(row[1])]),
                        body=str(witness['body_names'][int(row[2])]),
                        penetration_m=max(0., -float(row[3])), normal_n=float(row[4]))
        excluded = score['first_excluded_support_s']
        first_excluded = [] if excluded is None else [describe(r) for r in active[np.abs(active[:, 0]-excluded) < 1e-8]]
        rows.append(dict(case=path.name, source=str(path.relative_to(ROOT)), score_exact=True, score=score,
                         ball_free_joint_no_attachment=True, stationary_prerelease_frames=int(before.sum()),
                         max_prerelease_displacement_m=displacement.tolist(), max_prerelease_speed=pre_speed,
                         applied_load_samples_after_release=load_count, body_torque_caps_respected=True,
                         first_active_contacts=[describe(r) for r in active[np.abs(active[:, 0]-active[0, 0]) < 1e-8]],
                         peak_force=describe(active[np.argmax(active[:, 4])]),
                         first_excluded_contacts=first_excluded,
                         running=report['running_score'], short_receive=report['quarterback_pass_score'],
                         report_sha256=hashlib.sha256((trial/'report.json').read_bytes()).hexdigest()))
        print(json.dumps(dict(case=path.name, clean_hold_s=score['longest_clean_bilateral_s'],
                              finish_fraction=score['final_bilateral_fraction'], excluded=excluded,
                              overlap_mm=-1000*score['minimum_ball_contact_distance_m'],
                              first_excluded_contacts=first_excluded)))
    OUTPUT.write_text(json.dumps(dict(rows=rows, limitations=[
        'Explicit 2.5 ms contact model is uncalibrated and distinct from the original model.',
        'Long clean control starts after initial acquisition/bobbles; short-receive and running checks remain separate.',
        'Single deterministic cases and exact repeats do not establish statistical robustness or hardware validity.']), indent=2)+'\n')


if __name__ == '__main__':
    main()
