"""Actual timed no-throw capture-phase tracking, explicitly not sensor-triggered catch evidence."""
import argparse,sys,json,hashlib
from pathlib import Path
from types import SimpleNamespace
import numpy as np
p=argparse.ArgumentParser();
for k in ['frozen-root','profile','source','amp-source','output']:p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();sys.path[:0]=[str(a.frozen_root/'src'),str(a.frozen_root/'scripts')]
from g1_receiver.lower_cup_grip import NativeCupGrip
from g1_receiver.hand_route_plant import HandRoutePlant
from g1_receiver.native_hand_eval import NativeInterhandGeometryAudit
from g1_receiver.anatomical_catch_eval import physics_fingerprint
import probe_native_cup_residual as runner
original_delivery=runner.OpticalPass;original_targets=NativeCupGrip.targets;original_init=HandRoutePlant.__init__;original_step=HandRoutePlant.step;poses=[];controls=[];ball_robot=[];holder={}
class TimedNoThrow:
 def __init__(self,plant,profile,shift):
  self.profile=profile;self.release=None;self.hands=SimpleNamespace(closed_at=5.02,ready_at=5.02);self.aperture_correction=np.zeros(14);self.arm_indices=[plant.joint_names.index(f'{s}_{axis}_joint')for s in ['left','right']for axis in ['shoulder_roll','shoulder_yaw','shoulder_pitch','elbow','wrist_roll','wrist_pitch','wrist_yaw']]
 def ready(self):pass
 def observe(self,*args):pass
 targets=original_delivery.targets
 close=lambda self:None

def targets(self,now,closure,release_at,gate,encoders):return original_targets(self,now,closure,3.6,5.02,encoders)
def init(self,*args,**kwargs):
 original_init(self,*args,**kwargs);a.output.mkdir(parents=True,exist_ok=False);(a.output/'scene.xml').write_text(self.scene_xml);holder.update(model=self.model,ball=self.model.geom('football_surface').id,interhand=NativeInterhandGeometryAudit(self.model),physics=physics_fingerprint(self.model)['sha256'])
def step(self,command,*,closure=0.,hand_target_rad=None,post_step=None):
 def observe(data):
  if post_step:post_step(data)
  holder['interhand'].record(data)
  if 4.9<=data.time<=5.5:poses.append(np.r_[data.time,data.qpos.copy()]);controls.append(np.r_[data.time,data.ctrl.copy()])
  for c in data.contact:
   g1,g2=map(int,c.geom)
   if holder['ball']not in(g1,g2):continue
   other=g2 if g1==holder['ball']else g1
   if self.model.geom_bodyid[other]>0:ball_robot.append(dict(time_s=float(data.time),geom=self.model.geom(other).name,distance_m=float(c.dist)))
 return original_step(self,command,closure=closure,hand_target_rad=hand_target_rad,post_step=observe)
runner.OpticalPass=TimedNoThrow;NativeCupGrip.targets=targets;HandRoutePlant.__init__=init;HandRoutePlant.step=step
args=SimpleNamespace(source=a.source,amp_source=a.amp_source,profile=a.profile,output=a.output/'trial',no_pass=False,walk_speed=1.,handoff_depth=1.3,initial_yaw=-.7,duration=5.5,record_anatomical=False,reference_physics_sha256='173bf57168f5f97d0471d7bfa0a05e067a00f1e27a385994f57f21998a30af15',sensor_retention_camera_position=None,sensor_retention_camera_target=None,sensor_retention_pose_camera_position=None,sensor_retention_pose_camera_target=None)
try:report=runner.run(args,native_residual_callback=None)
finally:runner.OpticalPass=original_delivery;NativeCupGrip.targets=original_targets;HandRoutePlant.__init__=original_init;HandRoutePlant.step=original_step
np.savez_compressed(a.output/'offline-robot-qpos.npz',timestamps_s=np.asarray(poses)[:,0],qpos=np.asarray(poses)[:,1:]);np.savez_compressed(a.output/'actual-control.npz',time_control=np.asarray(controls));np.savez_compressed(a.output/'interhand-geometry.npz',**holder['interhand'].arrays());(a.output/'calibration.json').write_text(json.dumps(dict(no_throw=True,catch_claim=False,no_sensor_trigger_claim=True,command_clocks=dict(native_ready_s=3.6,arm_native_capture_gate_s=5.02),no_runtime_qpos_injection=True,zero_residual=True,physics_sha256=holder['physics'],original_physics_match=holder['physics']=='173bf57168f5f97d0471d7bfa0a05e067a00f1e27a385994f57f21998a30af15',interhand=holder['interhand'].summary(),ball_robot_contacts=ball_robot,minimum_upright=report['minimum_upright_cosine'],script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),profile_sha256=hashlib.sha256(a.profile.read_bytes()).hexdigest()),indent=2)+'\n')
