"""Predeclared15/30minute fixed-plane Y probes, four trials, no policy selection."""
import argparse,json,subprocess,sys,time,zipfile
from pathlib import Path

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for n in ['profile','source','amp-source','models-root','output']:p.add_argument('--'+n,type=Path,required=True)
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);started=time.monotonic();selected=[]
 (a.output/'predeclared.json').write_text(json.dumps(dict(minutes=[15,30],rule='first saved checkpoint at/after each elapsed trainingtime',perturbations='actualthrowY±.02m only; catchplane/axis/cameras fixed; gain.5CUDA; matchedzeros reused',policy_selector=False),indent=2))
 for minute in [15,30]:
  chosen=None
  while time.monotonic()-started<1800:
   progress=[json.loads(x)for x in(a.models_root/'progress.jsonl').read_text().splitlines()];times={x['timesteps']:x['elapsed_s']for x in progress};eligible=[]
   for path in a.models_root.glob('checkpoint-*.zip'):
    steps=int(path.stem.split('-')[-1]);elapsed=times.get(steps,-1)
    if elapsed<minute*60:continue
    try:
     with zipfile.ZipFile(path)as archive:
      if archive.testzip()is not None:continue
    except(zipfile.BadZipFile,OSError):continue
    eligible.append((elapsed,steps,path))
   if eligible:chosen=min(eligible);break
   time.sleep(20.)
  if chosen is None:raise RuntimeError('missing predeclared checkpoint')
  elapsed,steps,path=chosen;selected.append(dict(minute=minute,elapsed_s=elapsed,steps=steps,model=str(path)));(a.output/'selected.json').write_text(json.dumps(selected,indent=2))
  cmd=[sys.executable,'scripts/evaluate_native_checkpoint_y.py','--source',str(a.source),'--amp-source',str(a.amp_source),'--profile',str(a.profile),'--model',str(path),'--gain','.5','--device','cuda','--output',str(a.output/f'minute-{minute}')]
  with(a.output/f'minute-{minute}.log').open('w')as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=180)
if __name__=='__main__':main()
