"""Matched original20ms versus explicitly different2.5ms numerical contact assumption."""
import argparse,concurrent.futures,json,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();
for k in['root','profile','compact','cup','source','amp-source','output']:p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
def run(duration):
 tau=.0025
 label=f'confirm-{duration:g}s';cmd=[sys.executable,str(a.root/'scripts/probe_go_side_causal_confirm.py'),'--frozen-root',str(a.root),'--profile',str(a.profile),'--compact',str(a.compact),'--cup',str(a.cup),'--source',str(a.source),'--amp-source',str(a.amp_source),'--output',str(a.output/label),'--timeconstant',str(tau),'--cue-lead','.65','--reach-duration','.45','--duration',str(duration)]
 with(a.output/(label+'.log')).open('w')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 return dict(label=label,contact_timeconstant_s=tau,command=cmd,exit_code=r.returncode)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:rows=list(pool.map(run,[9.,11.]))
(a.output/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
if any(r['exit_code']for r in rows):raise RuntimeError('failedtrialspreserved')
