"""Matched physical readiness test; zero exact first, one simulation worker."""
import argparse,json
from pathlib import Path
from copy import deepcopy
import numpy as np
import probe_lower_cup_side_clear as runner
from run_native_cup_grip_screen import exact
REFERENCE='173bf57168f5f97d0471d7bfa0a05e067a00f1e27a385994f57f21998a30af15'
def main():
 p=argparse.ArgumentParser()
 for n in ['source','amp-source','profile','reference','output']:p.add_argument('--'+n,type=Path,required=True)
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);donor=json.loads(a.profile.read_text());rows=[]
 for i,preload in enumerate([0.,.3,.5,.7]):
  profile=deepcopy(donor);profile['native_grip']['preload'][:4]=[preload]*4;path=a.output/f'profile-{i:02d}.json';path.write_text(json.dumps(profile,indent=2)+'\n');out=a.output/f'case-{i:02d}';args=runner.build_parser().parse_args(['--source',str(a.source),'--amp-source',str(a.amp_source),'--profile',str(path),'--output',str(out),'--walk-speed','1','--handoff-depth','1.3','--initial-yaw','-.7','--duration','9','--record-anatomical','--reference-physics-sha256',REFERENCE]);r=runner.run(args)
  if i==0:
   matched=exact(a.reference,out)
   with np.load(a.reference/'trace.npz')as x,np.load(out/'trace.npz')as y:assert np.array_equal(x['native_hand'],y['native_hand'],equal_nan=True)
   (a.output/'zero-exact.json').write_text(json.dumps(matched,indent=2)+'\n')
  rows.append(dict(case=i,normalized_native_finger_preload=preload,anatomical=r['anatomical_score'],self_geometry=r['interhand_geometry_audit'],host_gains_sha256=r['host_gains_sha256']));(a.output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
if __name__=='__main__':main()
