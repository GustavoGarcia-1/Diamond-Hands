"""Final CUDA axis robustness with fixed catch plane and reused matched zeros."""
import argparse,hashlib,json
from pathlib import Path
import numpy as np
from stable_baselines3 import PPO
from g1_receiver.native_cup_training import NativeCatchEnv
CAMERAS=dict(sensor_retention_camera_position=(6,-2.5,2.4),sensor_retention_camera_target=(7,0,1),sensor_retention_pose_camera_position=(3.5,0,1.4),sensor_retention_pose_camera_target=(6.5,0,.9))

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for n in ['profile','source','amp-source','model','output','baseline-nominal','baseline-y-root','baseline-z-root']:p.add_argument('--'+n,type=Path,required=True)
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);donor=json.loads(a.profile.read_text());model=PPO.load(a.model,device='cuda')
 if model.observation_space.shape!=(169,)or model.action_space.shape!=(20,)or getattr(model,'receiver_action_gain',None)!=.5:raise RuntimeError('native169D/20D fixedgain.5 continuation required')
 rows=[]
 refs=[('nominal',a.baseline_nominal),('y-minus',a.baseline_y_root/'minus2cm/zero/episode-0001/trial/report.json'),('y-plus',a.baseline_y_root/'plus2cm/zero/episode-0001/trial/report.json'),('z-minus',a.baseline_z_root/'z-0.02-zero/rollout/episode-0001/trial/report.json'),('z-plus',a.baseline_z_root/'z+0.02-zero/rollout/episode-0001/trial/report.json')]
 for label,path in refs:
  report=json.loads(path.read_text());rows.append(dict(case=label,controller='zero',reused_from=str(path),anatomical=report['anatomical_score']))
 for label,delta in [('nominal',(0.,0.)),('y-minus',(-.02,0.)),('y-plus',(.02,0.)),('z-minus',(0.,-.02)),('z-plus',(0.,.02))]:
  out=a.output/label;out.mkdir();profile=json.loads(json.dumps(donor));profile['play']['quarterback_target_m'][1]+=delta[0];profile['play']['quarterback_target_m'][2]+=delta[1];before=json.loads(json.dumps(profile));before['play']['quarterback_target_m']=donor['play']['quarterback_target_m'];assert before==donor
  path=out/'profile.json';path.write_text(json.dumps(profile,indent=2)+'\n');env=NativeCatchEnv(path,a.source,a.amp_source,evaluation_dir=out/'rollout',duration=9.,**CAMERAS)
  try:
   obs,_=env.reset(seed=173);total=0.
   while True:
    obs,reward,done,_,info=env.step(model.predict(obs,deterministic=True)[0]*np.float32(.5));total+=reward
    if done:break
   if not np.isclose(total,info['sensor_return'],atol=1e-9):raise RuntimeError('ledger mismatch')
   report=json.loads((out/'rollout/episode-0001/trial/report.json').read_text());row=dict(case=label,controller='learned',model_sha256=hashlib.sha256(a.model.read_bytes()).hexdigest(),inference_device='cuda',action_gain=.5,delta_yz_m=delta,catchplane_axis_cameras_fixed=True,anatomical=report['anatomical_score'],legacy=report['quarterback_pass_score'],sensor=info,returned_reward=total);rows.append(row);(a.output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
  finally:env.close()
if __name__=='__main__':main()
