"""Bounded action-gain diagnostic, independently audited; no learner feedback."""
import argparse,json,hashlib
from pathlib import Path
import numpy as np
from stable_baselines3 import PPO
from g1_receiver.native_cup_training import NativeCatchEnv

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for n in ('profile','source','amp-source','output'):p.add_argument('--'+n,type=Path,required=True)
 p.add_argument('--models',type=Path,nargs='+',required=True);p.add_argument('--scales',type=float,nargs='+',default=[0.,.25,.5,1.]);p.add_argument('--device',choices=['cpu','cuda'],default='cpu');a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);results=[]
 if len(a.models)*len(a.scales)>12 or any(not 0<=x<=1 for x in a.scales):p.error('at most12 cases, scaleswithin0..1')
 for path,gain in [(m,g)for m in a.models for g in a.scales]:
  model=PPO.load(path,device=a.device);out=a.output/(path.stem+'-gain-'+str(gain))
  env=NativeCatchEnv(a.profile,a.source,a.amp_source,evaluation_dir=out,duration=9.,sensor_retention_camera_position=(6,-2.5,2.4),sensor_retention_camera_target=(7,0,1),sensor_retention_pose_camera_position=(3.5,0,1.4),sensor_retention_pose_camera_target=(6.5,0,.9))
  try:
   obs,_=env.reset(seed=173);total=0.
   while True:
    action=model.predict(obs,deterministic=True)[0]*gain;obs,reward,done,_,info=env.step(action);total+=reward
    if done:break
   report=json.loads((out/'episode-0001/trial/report.json').read_text())
   row=dict(model=str(path),model_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),inference_device=a.device,inference_policy_action_gain=gain,returned_sensor_reward=total,anatomical=report['anatomical_score'],legacy=report['quarterback_pass_score'],minimum_upright_cosine=report['minimum_upright_cosine'],sensor=info)
   if not np.isclose(total,info['sensor_return'],atol=1e-9):raise RuntimeError('ledger mismatch')
   results.append(row);(a.output/'summary.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
  finally:env.close()
if __name__=='__main__':main()
