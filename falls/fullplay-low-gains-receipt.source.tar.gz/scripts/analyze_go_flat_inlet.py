"""Offline original-physics whole-hand inlet screening; no dynamics/controller mutation."""
import json,hashlib
from pathlib import Path
import mujoco,numpy as np
from g1_receiver.scrimmage_throw import ScrimmagePass
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
P=Path('reports/catch-repair-20261114/contact-model');out=P/'go-inlet';scene=P/'study-linux/artifacts/study/original20-gain0.5/scene.xml';xml=scene.read_text().replace('/workspace/g1-receiver-runs/catch-repair-contact-model-20261114-r1/source/src/g1_receiver/_vendor/g1_runtime',str(DEFAULT_RUNTIME_ROOT)).replace('/workspace/g1-receiver-runs/out-scrimmage-20261113/source/aero-source','/tmp/g1-aero-source');model=mujoco.MjModel.from_xml_string(xml);data=mujoco.MjData(model)
profile_path=Path('reports/catch-form-20261114/overnight-grip/screen-r1/artifacts/screen/give4-thumb-ready-profile.json');profile=json.loads(profile_path.read_text())['play'];poses_path=Path('reports/catch-repair-20261114/validation/protected-witness-linux/witness/offline-robot-qpos.npz');poses=np.load(poses_path);times=poses['timestamps_s'];qposes=poses['qpos'];anchor=5.18;arrival=5.2;ki=np.argmin(abs(times-anchor));kp=np.argmin(abs(times-5.16));velocity=np.zeros(model.nv);mujoco.mj_differentiatePos(model,velocity,times[ki]-times[kp],qposes[kp],qposes[ki]);ball=model.geom('football_surface').id;addr=int(model.joint('football_free').qposadr[0]);pads=[model.geom('aero_'+side+'_palm_collision_7').id for side in ['left','right']];geoms=np.array([g for g in range(model.ngeom)if g!=ball and model.geom_bodyid[g]>0 and(model.geom_contype[g]or model.geom_conaffinity[g])]);radii=model.geom_size[ball].copy();results=[]
def setrobot(t):
 if t<=anchor+1e-8:data.qpos[:]=qposes[np.argmin(abs(times-t))]
 else:data.qpos[:]=qposes[ki];mujoco.mj_integratePos(model,data.qpos,velocity,t-times[ki])
for flight in [.7,.8,.9,1.,1.1,1.2,1.3,1.4,1.6]:
 for level in [False,True]:
  release=arrival-flight;plan=ScrimmagePass(tuple(profile['quarterback_origin_m']),tuple(profile['quarterback_target_m']),flight,align_ball_to_launch=not level,horizontal_distance_only=True).plan(release);quat=np.array(plan.release_quaternion_wxyz);rotation=np.empty(9);mujoco.mju_quat2Mat(rotation,quat);rotation=rotation.reshape(3,3);shape=rotation@np.diag(radii*radii)@rotation.T;first={};minima={}
  for t in np.arange(4.95,arrival+.0001,.001):
   setrobot(t);dt=t-release;center=np.array(plan.release_xyz_m)+dt*np.array(plan.release_velocity_mps);center[2]-=4.905*(dt*dt+model.opt.timestep*dt);data.qpos[addr:addr+7]=np.r_[center,quat];mujoco.mj_kinematics(model,data);lower=np.linalg.norm(data.geom_xpos[geoms]-center,axis=1)-model.geom_rbound[geoms]-model.geom_rbound[ball]
   for g in geoms[lower<.03]:
    gap=float(mujoco.mj_geomDistance(model,data,ball,int(g),.03,None));body=model.body(int(model.geom_bodyid[g])).name;name=model.geom(int(g)).name or f'geom-{g}';record=dict(geom=name,body=body,gap_m=gap,time_s=float(t))
    if gap<minima.get(int(g),dict(gap_m=1))['gap_m']:minima[int(g)]=record
    if gap<=0 and int(g)not in first:first[int(g)]=record
  setrobot(arrival);data.qpos[addr:addr+7]=np.r_[center,quat];mujoco.mj_kinematics(model,data);patch=[]
  for g in pads:
   F=data.geom_xmat[g].reshape(3,3);normal=F[:,0];face=data.geom_xpos[g]+model.geom_size[g,0]*normal;support=center-shape@normal/np.sqrt(normal@shape@normal);delta=support-face
   # Encoder-FK motion estimate from precontact pose20ms earlier.
   setrobot(arrival-.001);mujoco.mj_kinematics(model,data);F0=data.geom_xmat[g].reshape(3,3);face0=data.geom_xpos[g]+model.geom_size[g,0]*F0[:,0];palmvel=(face-face0)/.001;setrobot(arrival);mujoco.mj_kinematics(model,data)
   inplane=F[:,1:].T@delta;ext=model.geom_size[g,1:];ballvel=np.array(plan.intercept_velocity_mps)-np.array([0,0,.004905]);patch.append(dict(geom=model.geom(g).name,normal_world=normal.tolist(),face_center_m=face.tolist(),support_point_m=support.tolist(),signed_normal_gap_m=float(delta@normal),inplane_offset_m=inplane.tolist(),half_extents_m=ext.tolist(),inside_finite_patch=bool(np.all(abs(inplane)<=ext)),edge_excess_m=np.maximum(abs(inplane)-ext,0).tolist(),relative_normal_velocity_mps=float((ballvel-palmvel)@normal),palm_velocity_mps=palmvel.tolist()))
  results.append(dict(flight_s=flight,world_level_x=level,release_s=release,arrival_s=arrival,release_velocity_mps=list(plan.release_velocity_mps),arrival_velocity_mps=list(plan.intercept_velocity_mps),quaternion_wxyz=quat.tolist(),patches=patch,both_patch_support_inside=all(p['inside_finite_patch']for p in patch),first_intersections=sorted(first.values(),key=lambda r:r['time_s']),minimum_gaps=sorted(minima.values(),key=lambda r:r['gap_m'])))
report=dict(offline_only=True,no_physical_rollout=True,original_physics=True,actual_precontact_anchor_s=anchor,arm_motion_after_anchor='fullqposvelocityextrapolated5.16to5.18,20msmaximum; no claimnewfixturewristtrajectorymatches',semiimplicit_gravity=True,inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [scene,poses_path,profile_path]},results=results);(out/'offline-screen.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps([dict(T=r['flight_s'],level=r['world_level_x'],bothpatch=r['both_patch_support_inside'],normvel=[round(p['relative_normal_velocity_mps'],3)for p in r['patches']],patch_excess_mm=[[round(1000*v,1)for v in p['edge_excess_m']]for p in r['patches']],first=r['first_intersections'][:2])for r in results],indent=2))
