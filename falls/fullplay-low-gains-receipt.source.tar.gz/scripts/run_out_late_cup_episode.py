"""In-process driver for the64Dscalar late-reach learner; scores are evaluation only."""
from pathlib import Path
import sys,json,tempfile

def run_training_rollout(config,phase_policy,output=None):
    cfg=dict(config);temporary=None
    sys.path.insert(0,str(Path(cfg['frozen_root'])/'scripts'))
    import probe_out_native_lower as runner
    import run_out_contact_repair as contact
    if output is None:
        temporary=tempfile.TemporaryDirectory(prefix='out-late-cup-');output=Path(temporary.name)/'episode'
    saved=sys.argv;runner.PHASE_POLICY=phase_policy
    args=['run_out_contact_repair.py','--case',cfg.get('model_case','pair25'),'--duration',str(cfg.get('duration_s',10.)),'--timestep',str(cfg.get('timestep_s',.001)),'--output',str(output)]
    for key in ['frozen_root','profile','source','amp_source','reference']:args+=['--'+key.replace('_','-'),str(cfg[key])]
    if cfg.get('fixed_servo',True):args+=['--fixed-servo']
    if cfg.get('break_release_delay_s')is not None:args+=['--break-release-delay',str(cfg['break_release_delay_s'])]
    try:
        sys.argv=args;contact.main()
        return json.loads((Path(output)/'trial/report.json').read_text())
    finally:
        sys.argv=saved;runner.PHASE_POLICY=None
        if temporary is not None:temporary.cleanup()

def main():
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--config',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();run_training_rollout(json.loads(a.config.read_text()),None,a.output)
if __name__=='__main__':main()
