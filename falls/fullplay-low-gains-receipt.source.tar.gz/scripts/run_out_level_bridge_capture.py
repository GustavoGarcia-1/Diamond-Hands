"""Three predeclared native-hand readiness variants after verified two-pad entry."""
import argparse
from copy import deepcopy
import json
from pathlib import Path

import probe_out_native_lower as runner
from run_out_pad7_screen import argv


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ['source', 'amp-source', 'profile', 'output']:
        parser.add_argument('--'+key, type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    donor = json.loads(args.profile.read_text())
    variants = [
        dict(name='open-early-close', finger_preload=0., thumb_opposition_preload=0., delay_s=0.),
        dict(name='partial-middle-close', finger_preload=.15, thumb_opposition_preload=.5, delay_s=.10),
        dict(name='ready-late-close', finger_preload=.3, thumb_opposition_preload=.5, delay_s=.16),
    ]
    protocol = dict(scope=__doc__, variants=variants,
        meaning='A finite coordinated readiness screen, not a learned controller or isolated single-factor causal comparison.',
        unchanged='Throw, route, arm targets, cameras, gains, actuator rate limits, materials and scoring criteria.',
        capture=[.85, .85, .85, .85, .7448576176015584, .5221050911171039, .6587504088976122],
        ramp_s=.2, training=False)
    (args.output/'protocol.json').write_text(json.dumps(protocol, indent=2)+'\n')
    rows = []
    for index, variant in enumerate(variants):
        profile = deepcopy(donor)
        profile['native_grip']['preload'] = [variant['finger_preload']]*4+[variant['thumb_opposition_preload'], .10442101822342079, .13175008177952244]
        profile['native_grip']['capture'] = protocol['capture']
        profile['native_grip']['digit_delay_s'] = [variant['delay_s']]*7
        profile['native_grip']['ramp_s'] = protocol['ramp_s']
        profile['research_scope'] = 'Three coordinated readiness variants on the verified level two-pad inlet. No learned or catch qualification claim.'
        path = args.output/f'profile-{index:02d}.json'
        path.write_text(json.dumps(profile, indent=2)+'\n')
        output = args.output/f'case-{index:02d}'
        runner.main(argv(args, path, output))
        report = json.loads((output/'report.json').read_text())
        rows.append(dict(case=index, variant=variant, visual_gate_s=report['visual_closure_s'],
            anatomical=report['anatomical_score']))
        (args.output/'summary.json').write_text(json.dumps(rows, indent=2)+'\n')
        print(json.dumps(rows[-1]), flush=True)


if __name__ == '__main__':
    main()
