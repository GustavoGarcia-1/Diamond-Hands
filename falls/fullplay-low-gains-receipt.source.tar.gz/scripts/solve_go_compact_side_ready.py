"""Compact hands-down FK proposals near the final side cup; no dynamics."""
from pathlib import Path
import json,time
import numpy as np,mujoco
from scipy.optimize import least_squares
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
P=Path('reports/catch-repair-20261114');O=P/'go-side-cup';cup=json.load(open(O/'refined-balanced-candidate.json'));xml=(P/'contact-model/study-linux/artifacts/study/original20-gain0.5/scene.xml').read_text().replace('/workspace/g1-receiver-runs/catch-repair-contact-model-20261114-r1/source/src/g1_receiver/_vendor/g1_runtime',str(DEFAULT_RUNTIME_ROOT)).replace('/workspace/g1-receiver-runs/out-scrimmage-20261113/source/aero-source','/tmp/g1-aero-source');m=mujoco.MjModel.from_xml_string(xml);d=mujoco.MjData(m);a=np.load(P/'validation/protected-witness-linux/witness/offline-robot-qpos.npz');base=a['qpos'][np.argmin(abs(a['timestamps_s']-5.18))].copy();q=np.load(P/'out-cup/right-up-margin-dry-r1/artifacts/trial/offline-robot-qpos.npz');native=q['qpos'][np.argmin(abs(q['timestamps_s']-6.2))]
for j in range(m.njnt):
 n=m.joint(j).name
 if n.startswith('aero_'):
  other=n.replace('left','TEMP').replace('right','left').replace('TEMP','right');base[int(m.jnt_qposadr[j])]=native[int(m.jnt_qposadr[m.joint(other).id])]
base[int(m.joint('waist_yaw_joint').qposadr[0])]=cup['waist_yaw_rad'];ids=np.array([m.joint(n).id for n in cup['arm_order']]);addresses=m.jnt_qposadr[ids];lo=m.jnt_range[ids,0]+.08;hi=m.jnt_range[ids,1]-.08;seed=np.clip(cup['arm_targets_rad'],lo+1e-7,hi-1e-7);pads=[m.geom('aero_'+s+'_palm_collision_7').id for s in ['left','right']];d.qpos[:]=base;d.qpos[addresses]=seed;mujoco.mj_kinematics(m,d);pelvis=d.xpos[m.body('pelvis').id].copy();F=d.xmat[m.body('pelvis').id].reshape(3,3);yaw=np.arctan2(F[1,0],F[0,0]);Y=np.array([[np.cos(yaw),-np.sin(yaw),0],[np.sin(yaw),np.cos(yaw),0],[0,0,1.]]);cupcenter=np.array(cup['cup_center_pelvis_yaw_frame_m']);targets0=[{k:np.array(v)for k,v in row.items()}for row in cup['actual_fk']];pairs=[(58,163),(58,165),(56,163),(60,165),(54,42),(161,42)];results=[]
def fk(q):
 d.qpos[:]=base;d.qpos[addresses]=q;mujoco.mj_kinematics(m,d);return [dict(pos=d.geom_xpos[g]+m.geom_size[g,0]*d.geom_xmat[g].reshape(3,3)[:,0],normal=d.geom_xmat[g].reshape(3,3)[:,0].copy(),long=d.geom_xmat[g].reshape(3,3)[:,2].copy())for g in pads]
for center in [np.array([.24,-.18,.26]),np.array([.25,-.20,.28]),np.array([.28,-.20,.28])]:
 targets=[{**r,'pos':r['pos']+Y@(center-cupcenter)}for r in targets0]
 def obj(q):
  f=fk(q);v=[]
  for a,b in zip(f,targets):v.extend(150*(a['pos']-b['pos']));v.extend(1.2*(a['normal']-b['normal']));v.extend(.8*(a['long']-b['long']))
  for g,h in pairs:v.append(300*max(0,.012-mujoco.mj_geomDistance(m,d,g,h,.03,None)))
  v.extend(.45*(q-seed));return v
 fit=least_squares(obj,seed,bounds=(lo,hi),max_nfev=160);f=fk(fit.x);delta=seed-fit.x;results.append(dict(center_pelvis_yaw_frame_m=center.tolist(),arm_order=cup['arm_order'],arm_targets_rad=fit.x.tolist(),cup_arm_targets_rad=seed.tolist(),position_error_m=[float(np.linalg.norm(a['pos']-b['pos']))for a,b in zip(f,targets)],maximum_joint_travel_rad=float(np.max(abs(delta))),rms_joint_travel_rad=float(np.sqrt(np.mean(delta**2))),quintic_min_duration_for_peak_3rad_s=float(1.875*np.max(abs(delta))/3),min_joint_margin_rad=float(np.min(np.minimum(fit.x-m.jnt_range[ids,0],m.jnt_range[ids,1]-fit.x))),actual_fk=[{k:v.tolist()for k,v in r.items()}for r in f],offline_only=True))
(O/'compact-side-proposals.json').write_text(json.dumps(dict(offline_only=True,not_dynamic_reachability=True,no_runtime_qpos_injection=True,results=results),indent=2)+'\n');print(json.dumps([{k:r[k]for k in['center_pelvis_yaw_frame_m','position_error_m','maximum_joint_travel_rad','quintic_min_duration_for_peak_3rad_s','min_joint_margin_rad']}for r in results],indent=2))
