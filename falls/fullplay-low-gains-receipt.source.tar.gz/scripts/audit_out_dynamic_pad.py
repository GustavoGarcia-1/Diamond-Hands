"""Offline finite palm-pad error from archived full robot/ball poses only."""
import argparse
import json
from pathlib import Path

import mujoco
import numpy as np

from g1_receiver.aero import make_aero_scene
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--trial', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--start', type=float, default=6.18)
    parser.add_argument('--end', type=float, default=6.23)
    parser.add_argument('--free-flight', action='store_true', help='Diagnostic: replace ball pose by measured release extrapolation, keeping the recorded robot.')
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    model = mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT, args.source))
    data = mujoco.MjData(model)
    ball = model.geom('football_surface').id
    poses = np.load(args.trial/'offline-robot-qpos.npz')
    release = json.loads((args.trial/'report.json').read_text())['release']
    ball_address = int(model.joint('football_free').qposadr[0])
    rows = []
    for stamp, qpos in zip(poses['timestamps_s'], poses['qpos']):
        if not args.start-1e-8 <= stamp <= args.end+1e-8:
            continue
        data.qpos[:] = qpos
        if args.free_flight:
            elapsed = float(stamp)-release['release_time_s']
            predicted = np.array(release['release_xyz_m'])+elapsed*np.array(release['release_velocity_mps'])
            predicted[2] -= 4.905*elapsed**2
            data.qpos[ball_address:ball_address+7] = np.r_[predicted, release['release_quaternion_wxyz']]
        mujoco.mj_kinematics(model, data)
        center = data.geom_xpos[ball]
        ball_rotation = data.geom_xmat[ball].reshape(3, 3)
        shape = ball_rotation @ np.diag(model.geom_size[ball]**2) @ ball_rotation.T
        hands = []
        for side, sign in [('left', 1), ('right', -1)]:
            geom = model.geom(f'aero_{side}_palm_collision_7').id
            rotation = data.geom_xmat[geom].reshape(3, 3)
            body_normal = sign*data.body(f'aero_{side}_palm').xmat.reshape(3, 3)[:, 1]
            axis = int(np.argmax(np.abs(rotation.T@body_normal)))
            normal = np.sign((rotation.T@body_normal)[axis])*rotation[:, axis]
            face = data.geom_xpos[geom]+model.geom_size[geom, axis]*normal
            radius = float(np.sqrt(normal@shape@normal))
            support = center-shape@normal/radius
            local_support = rotation.T@(support-face)
            tangent_axes = [i for i in range(3) if i != axis]
            excess = np.maximum(0., np.abs(local_support[tangent_axes])-model.geom_size[geom, tangent_axes])
            hands.append(dict(side=side, face_world_m=face.tolist(), normal_world=normal.tolist(),
                face_axis=axis, normal_gap_m=float(normal@(center-face)-radius),
                center_plane_distance_m=float(normal@(center-face)),
                ellipsoid_support_radius_m=radius, tangent_axes=tangent_axes,
                support_tangent_m=local_support[tangent_axes].tolist(),
                finite_half_extents_m=model.geom_size[geom, tangent_axes].tolist(),
                support_outside_patch_m=float(np.linalg.norm(excess)),
                exact_geom_gap_m=float(mujoco.mj_geomDistance(model, data, ball, geom, .2, None))))
        rows.append(dict(time_s=float(stamp), ball_center_m=center.tolist(), hands=hands))
    result = dict(scope='Offline diagnostic only; archived full qpos contains ball truth. Never controller/reward input.',
        temporal_convention='Post-integration qpos. Recorded contact witness belongs to pre-integration geometry one physics step earlier.',
        interpretation='Negative normal gap crosses the infinite front plane. Tangent support outside the finite patch can still miss the actual pad; exact_geom_gap uses the complete thin box.',
        trial=str(args.trial), rows=rows)
    result['ball_source'] = 'Measured release ballistic extrapolation; recorded robot remains contact-affected. Local geometry diagnostic, not a counterfactual rollout.' if args.free_flight else 'Recorded physical trajectory'
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    for target in [args.start, 6.2, 6.21, args.end]:
        row = min(rows, key=lambda r: abs(r['time_s']-target))
        print(json.dumps(row))


if __name__ == '__main__':
    main()
