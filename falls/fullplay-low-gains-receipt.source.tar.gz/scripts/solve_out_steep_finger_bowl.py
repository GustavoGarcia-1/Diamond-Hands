"""Offline exact-facet/native-hand IK proposal; never used by online policy."""
import argparse,json
from pathlib import Path
import numpy as np,mujoco
from scipy.optimize import least_squares
from g1_receiver.aero import make_aero_scene
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT

def main():
 p=argparse.ArgumentParser()
 for n in ['source','trial','profile','output']:p.add_argument('--'+n,type=Path,required=True)
 p.add_argument('--seed-file',type=Path);p.add_argument('--flight',type=float,default=1.0);p.add_argument('--seeds',type=int,default=3);p.add_argument('--iterations',type=int,default=220);a=p.parse_args()
 m=mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT,a.source));d=mujoco.MjData(m);v=np.load(a.trial/'view.npz');idx=np.argmin(abs(v['timestamps_s']-6.2));d.qpos[:]=v['qpos'][idx];mujoco.mj_forward(m,d);template=d.qpos.copy();profile=json.loads(a.profile.read_text());names=profile['mirrored_side_cup']['arm_order'];adr=np.array([m.joint(n).qposadr[0]for n in names]);seed=d.qpos[adr].copy();lim=np.array([m.joint(n).range for n in names]);lo=lim[:,0]+.035;hi=lim[:,1]-.035
 for i,n in enumerate(names):
  if 'elbow'in n:lo[i]=max(lo[i],.2)
 C0=np.array(profile['play']['field_catch_window_m']);origin=np.array(profile['play']['quarterback_origin_m']);ball=int(m.geom('football_surface').id);ba=int(m.joint('football_free').qposadr[0]);A=np.diag(np.array([.142,.085,.085])**2);velocity=np.array([-.897359,.778846,-.037919]);hand={s:[g for g in range(m.ngeom)if m.body(int(m.geom_bodyid[g])).name.startswith('aero_'+s+'_')and(m.geom_contype[g]or m.geom_conaffinity[g])]for s in ['left','right']};pairs=np.array([(i,j)for i in hand['left']for j in hand['right']],int);allhand=np.array(hand['left']+hand['right']);pads=[int(m.geom(s+'_palm_collision_7').id)if mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_GEOM,s+'_palm_collision_7')>=0 else -1 for s in ['left','right']]
 # Actual collision geom names are aero-prefixed in compiled scenes.
 pads=[]
 for s in ['left','right']:
  pads.append(next(g for g in hand[s]if m.geom(g).name and m.geom(g).name.endswith('palm_collision_7')))
 near=np.array([g for g in range(m.ngeom)if g!=ball and m.geom_bodyid[g]>0 and(m.geom_contype[g]or m.geom_conaffinity[g])],int)
 def gaparray(pairs,threshold=.02):
  lower=np.linalg.norm(d.geom_xpos[pairs[:,0]]-d.geom_xpos[pairs[:,1]],axis=1)-m.geom_rbound[pairs[:,0]]-m.geom_rbound[pairs[:,1]];out=np.full(len(pairs),threshold)
  for k in np.flatnonzero(lower<threshold):out[k]=mujoco.mj_geomDistance(m,d,int(pairs[k,0]),int(pairs[k,1]),threshold,None)
  return out
 def calc(x):
  d.qpos[adr]=x[:14];d.qpos[ba:ba+7]=np.r_[x[14:],[1.,0.,0.,0.]];mujoco.mj_kinematics(m,d);points=[];N=[];F=[];long=[];width=[]
  for s,g in zip(['left','right'],pads):
   R=d.geom_xmat[g].reshape(3,3);n=R[:,0];points.append(d.geom_xpos[g]+m.geom_size[g,0]*n);N.append(n);long.append(R[:,2]);width.append(R[:,1]);F.append(d.body('aero_'+s+'_palm').xmat.reshape(3,3)[:,2])
  N=np.array(N);P=np.array(points);F=np.array(F);long=np.array(long);width=np.array(width);support=(A@N.T).T;support/=np.sqrt(np.sum(support*N,1))[:,None];error=x[14:]-support-P;inter=gaparray(pairs);ballpairs=np.column_stack([np.full(len(near),ball),near]);ballgaps=gaparray(ballpairs);bv=(x[14:]-origin)/a.flight+np.array([0,0,-4.905*a.flight]);vn=(bv-velocity)@N.T
  return P,N,F,long,width,error,inter,ballgaps,vn
 def residual(x):
  P,N,F,L,W,E,I,B,V=calc(x);return np.r_[(E/.008).ravel(),np.maximum(0.,.1-F[:,2])/.03,np.maximum(0.,.56-L[:,2])/.03,np.maximum(0.,.81-N[:,2])/.03,np.maximum(0.,.63-(.965749*N[:,2]-.259478*L[:,2]))/.03,np.maximum(0.,V+.2)/.5,np.maximum(0.,-2.90-V)/.5,np.maximum(0.,.006-I)/.001,np.maximum(0.,-B)/.001,.025*(x[:14]-seed),(x[14:]-C0)/.4]
 rng=np.random.default_rng(173);best=None
 for i in range(a.seeds):
  start=(np.r_[json.loads(a.seed_file.read_text())['arm_targets_rad'],json.loads(a.seed_file.read_text())['ball_center_world_m']] if a.seed_file else np.r_[seed,C0])if best is None else best.x+rng.normal(0,.15,17);bounds=(np.r_[lo,C0+[-.30,-.30,-.12]],np.r_[hi,C0+[.30,.30,.15]]);start=np.clip(start,bounds[0]+1e-6,bounds[1]-1e-6);fit=least_squares(residual,start,bounds=bounds,max_nfev=a.iterations,diff_step=1e-5)
  if best is None or np.linalg.norm(fit.fun)<np.linalg.norm(best.fun):best=fit
  print('seed',i,'cost',np.linalg.norm(fit.fun),flush=True)
 P,N,F,L,W,E,I,B,V=calc(best.x);r=dict(static_only=True,template=str(a.trial),template_time_s=float(v['timestamps_s'][idx]),flight_s=a.flight,arm_order=names,arm_targets_rad=best.x[:14].tolist(),ball_center_world_m=best.x[14:].tolist(),facet_centers=P.tolist(),facet_normals=N.tolist(),finger_axes=F.tolist(),facet_long_axes=L.tolist(),facet_width_axes=W.tolist(),support_center_error_m=np.linalg.norm(E,axis=1).tolist(),per_hand_normal_speed_mps=V.tolist(),min_interhand_gap_m=float(I.min()),min_ball_hand_or_body_gap_m=float(B.min()),predeclared=dict(pad_up_min=.80,finger_up_min=.1,pad_long_up_min=.55,body_palm_up_min=.60,support_target_error_max_m=.008,interhand_gap_min_m=.005,ball_geometry_gap_min_m=-.001,normal_velocity_mps=[-3.,-.1],joint_margin_min_rad=.035),eligible_static=bool(N[:,2].min()>=.80 and F[:,2].min()>=.1 and L[:,2].min()>=.55 and (.965749*N[:,2]-.259478*L[:,2]).min()>=.60 and np.linalg.norm(E,axis=1).max()<=.008 and I.min()>=.005 and B.min()>=-.001 and V.min()>=-3 and V.max()<=-.1));a.output.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
if __name__=='__main__':main()
