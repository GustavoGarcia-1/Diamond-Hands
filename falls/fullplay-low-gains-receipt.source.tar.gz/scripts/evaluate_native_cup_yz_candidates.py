"""Fixed-plane Y/Z robustness for the two predeclared half-gain candidates.

Reuse existing identical zero-Y and19456-Y trials; do not repeat them.
"""
import argparse,json,hashlib
from pathlib import Path
import numpy as np
from stable_baselines3 import PPO
from g1_receiver.native_cup_training import NativeCatchEnv
CAMERAS=dict(sensor_retention_camera_position=(6,-2.5,2.4),sensor_retention_camera_target=(7,0,1),sensor_retention_pose_camera_position=(3.5,0,1.4),sensor_retention_pose_camera_target=(6.5,0,.9))

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for n in ['profile','source','amp-source','models-root','reuse-y-root','output']:p.add_argument('--'+n,type=Path,required=True)
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);donor=json.loads(a.profile.read_text());rows=[];models={}
 for key in [19456,23168]:
  path=a.models_root/f'checkpoint-{key:08d}.zip';models[key]=(PPO.load(path,device='cuda'),hashlib.sha256(path.read_bytes()).hexdigest())
 for label,delta in [('minus2cm',-.02),('plus2cm',.02)]:
  for controller in ['zero','half']:
   path=a.reuse_y_root/label/controller/'episode-0001/trial/report.json';report=json.loads(path.read_text());rows.append(dict(axis='y',delta_m=delta,controller=controller,checkpoint=None if controller=='zero'else 19456,reused_from=str(path),inference_device='cuda',anatomical=report['anatomical_score']))
 (a.output/'predeclared-jobs.json').write_text(json.dumps(dict(reused='zero-Y and19456-Y from fixed-plane prior archive',new_jobs='zero-Z±2cm;23168-Y/Z±2cm;19456-Z±2cm',selection='no reward ranking; retain per-perturbation physical gates/impact'),indent=2))
 jobs=[('z',d,None)for d in [-.02,.02]]+[('y',d,23168)for d in [-.02,.02]]+[('z',d,23168)for d in [-.02,.02]]+[('z',d,19456)for d in [-.02,.02]]
 for axis,delta,key in jobs:
  label=f'{axis}{delta:+.2f}-'+('zero'if key is None else str(key));out=a.output/label;out.mkdir();profile=json.loads(json.dumps(donor));profile['play']['quarterback_target_m'][1 if axis=='y'else 2]+=delta;path=out/'profile.json';path.write_text(json.dumps(profile,indent=2)+'\n')
  unchanged=json.loads(json.dumps(profile));unchanged['play']['quarterback_target_m']=donor['play']['quarterback_target_m'];assert unchanged==donor
  env=NativeCatchEnv(path,a.source,a.amp_source,evaluation_dir=out/'rollout',duration=9.,**CAMERAS)
  try:
   obs,_=env.reset(seed=173);total=0.
   while True:
    action=np.zeros(20,np.float32)if key is None else models[key][0].predict(obs,deterministic=True)[0]*np.float32(.5)
    obs,reward,done,_,info=env.step(action);total+=reward
    if done:break
   if not np.isclose(total,info['sensor_return'],atol=1e-9):raise RuntimeError('ledger mismatch')
   report=json.loads((out/'rollout/episode-0001/trial/report.json').read_text());row=dict(axis=axis,delta_m=delta,controller='zero'if key is None else'half',checkpoint=key,model_sha256=None if key is None else models[key][1],inference_device='cuda',catchplane_axis_cameras_unchanged=True,anatomical=report['anatomical_score'],legacy=report['quarterback_pass_score'],sensor=info,returned_reward=total);rows.append(row);(a.output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
  finally:env.close()
if __name__=='__main__':main()
