"""Analytic finite-patch target correction, then offline whole-hand entry test."""
from pathlib import Path
import importlib.util,json,hashlib
import numpy as np,mujoco
from scipy.optimize import minimize
from g1_receiver.scrimmage_throw import ScrimmagePass
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
P=Path('reports/catch-repair-20261114/contact-model');out=P/'go-inlet';scene=P/'study-linux/artifacts/study/original20-gain0.5/scene.xml';xml=scene.read_text().replace('/workspace/g1-receiver-runs/catch-repair-contact-model-20261114-r1/source/src/g1_receiver/_vendor/g1_runtime',str(DEFAULT_RUNTIME_ROOT)).replace('/workspace/g1-receiver-runs/out-scrimmage-20261113/source/aero-source','/tmp/g1-aero-source');m=mujoco.MjModel.from_xml_string(xml);d=mujoco.MjData(m);pose=np.load('reports/catch-repair-20261114/validation/protected-witness-linux/witness/offline-robot-qpos.npz');ts=pose['timestamps_s'];qs=pose['qpos'];i=np.argmin(abs(ts-5.18));j=np.argmin(abs(ts-5.16));vel=np.zeros(m.nv);mujoco.mj_differentiatePos(m,vel,ts[i]-ts[j],qs[j],qs[i]);ball=m.geom('football_surface').id;ba=int(m.joint('football_free').qposadr[0]);pads=[m.geom('aero_'+side+'_palm_collision_7').id for side in ['left','right']];geoms=np.array([g for g in range(m.ngeom)if g!=ball and m.geom_bodyid[g]>0 and(m.geom_contype[g]or m.geom_conaffinity[g])]);profile=json.load(open('reports/catch-form-20261114/overnight-grip/screen-r1/artifacts/screen/give4-thumb-ready-profile.json'));origin=np.array(profile['play']['quarterback_origin_m']);original=np.array(profile['play']['quarterback_target_m']);results=[]
def robot(t):
 d.qpos[:]=qs[np.argmin(abs(ts-t))]if t<=5.18 else qs[i]
 if t>5.18:mujoco.mj_integratePos(m,d.qpos,vel,t-ts[i])
 mujoco.mj_kinematics(m,d)
robot(5.2);frames=[d.geom_xmat[g].reshape(3,3).copy()for g in pads];faces=[d.geom_xpos[g].copy()+m.geom_size[g,0]*F[:,0]for g,F in zip(pads,frames)]
def plan_and_support(aim,T,level):
 plan=ScrimmagePass(tuple(origin),tuple(aim),T,align_ball_to_launch=not level,horizontal_distance_only=True).plan(5.2-T);R=np.empty(9);mujoco.mju_quat2Mat(R,np.array(plan.release_quaternion_wxyz));R=R.reshape(3,3);S=R@np.diag(m.geom_size[ball]**2)@R.T
 # Continuousplan aim correctedforsemiimplicitgravity is actualterminalcenter.
 center=np.array(aim)-np.array([0,0,4.905*.001*T]);support=[center-S@F[:,0]/np.sqrt(F[:,0]@S@F[:,0])for F in frames];return plan,support
for T in [.7,.8,.9,1.,1.2,1.4]:
 for level in [False,True]:
  def constraints(aim):
   _,ss=plan_and_support(aim,T,level);v=[]
   for g,F,face,s in zip(pads,frames,faces,ss):
    delta=s-face;n=delta@F[:,0];xy=F[:,1:].T@delta;v.extend([n,.002-n]);v.extend((m.geom_size[g,1:]-.002-xy).tolist());v.extend((m.geom_size[g,1:]-.002+xy).tolist())
   return np.array(v)
  fit=minimize(lambda aim:float(np.sum((aim-original)**2)),original+np.array([.02,0,.07]),constraints=[dict(type='ineq',fun=constraints)],bounds=list(zip(original-.12,original+.12)),method='SLSQP',options=dict(maxiter=300,ftol=1e-13))
  record=dict(flight_s=T,world_level_x=level,fit_success=bool(fit.success),fit_message=fit.message,aim_m=fit.x.tolist(),shift_m=(fit.x-original).tolist(),min_constraint=float(constraints(fit.x).min()))
  if fit.success:
   plan,support=plan_and_support(fit.x,T,level);first={};minimum={};q=np.array(plan.release_quaternion_wxyz)
   for t in np.arange(4.95,5.2001,.001):
    robot(t);dt=t-(5.2-T);center=np.array(origin)+dt*np.array(plan.release_velocity_mps);center[2]-=4.905*(dt*dt+.001*dt);d.qpos[ba:ba+7]=np.r_[center,q];mujoco.mj_kinematics(m,d);low=np.linalg.norm(d.geom_xpos[geoms]-center,axis=1)-m.geom_rbound[geoms]-m.geom_rbound[ball]
    for g in geoms[low<.02]:
     gap=float(mujoco.mj_geomDistance(m,d,ball,int(g),.02,None));r=dict(geom=m.geom(int(g)).name or f'geom-{g}',body=m.body(int(m.geom_bodyid[g])).name,time_s=float(t),gap_m=gap)
     if g not in minimum or gap<minimum[g]['gap_m']:minimum[int(g)]=r
     if gap<=0 and g not in first:first[int(g)]=r
   record.update(quaternion_wxyz=q.tolist(),first_intersections=sorted(first.values(),key=lambda x:x['time_s']),minimum_gaps=sorted(minimum.values(),key=lambda x:x['gap_m']),finite_support_points_m=[s.tolist()for s in support],arrival_velocity_mps=list(plan.intercept_velocity_mps))
  results.append(record)
(out/'finite-patch-fit.json').write_text(json.dumps(dict(offline_only=True,not_physical_catch=True,criteria='bothsupportpointsonpositivepadfacewithin0..2mmnormalgap,2mmfiniteedgemargin; targetshift≤12cm/axis',results=results),indent=2)+'\n');print(json.dumps([dict(T=r['flight_s'],level=r['world_level_x'],success=r['fit_success'],shift_mm=[round(1000*x,2)for x in r['shift_m']],first=r.get('first_intersections',[])[:3])for r in results],indent=2))
