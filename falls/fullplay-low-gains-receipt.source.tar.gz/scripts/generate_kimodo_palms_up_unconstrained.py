"""One offline native-G1 arm-pose proposal using the already authorized r4 cache."""
import argparse,hashlib,importlib,json,os,runpy,subprocess,sys
from pathlib import Path
PIN='e1c219c99b4b94ba48be1fb6a1cbc64ecee4c954'
REVISIONS={'nvidia/Kimodo-G1-RP-v1':'3020ad8c419c244e0429d360163730c63c4ed011','meta-llama/Meta-Llama-3-8B-Instruct':'8afb486c1db24fe5011ec46dfbe5b5dccdb575c2','McGill-NLP/LLM2Vec-Meta-Llama-3-8B-Instruct-mntp':'31474e395ada192e8ed1586db6be79fb3b70c9c0','McGill-NLP/LLM2Vec-Meta-Llama-3-8B-Instruct-mntp-supervised':'baa8ebf04a1c2500e61288e7dad65e8ae42601a7'}
PROMPT='A humanoid robot catches a football over the left shoulder with both hands at shoulder height. The palms face upward, elbows stay below the wrists, and fingers point outward.'
def digest(path):
 h=hashlib.sha256()
 with path.open('rb')as f:
  for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cached-work',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
 for key in ['HF_TOKEN','HUGGING_FACE_HUB_TOKEN']:os.environ.pop(key,None)
 os.environ.update(HF_HOME=str(a.cached_work/'hf-cache'),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TEXT_ENCODER_URL='local',HF_HUB_DISABLE_PROGRESS_BARS='1',HF_HUB_DISABLE_TELEMETRY='1')
 actual=subprocess.check_output(['git','-C',str(a.cached_work/'kimodo'),'rev-parse','HEAD'],text=True).strip()
 if actual!=PIN:raise RuntimeError('cached source pin mismatch')
 paths={repo:a.cached_work/'hf-cache/hub'/('models--'+repo.replace('/','--'))/'snapshots'/rev for repo,rev in REVISIONS.items()}
 for repo,path in paths.items():
  if not path.is_dir():raise RuntimeError('required pinned snapshot unavailable offline: '+repo)
 manifest={repo:dict(revision=REVISIONS[repo],path=str(path),files={str(f.relative_to(path)):dict(bytes=f.stat().st_size,sha256=digest(f))for f in sorted(path.rglob('*'))if f.is_file()})for repo,path in paths.items()}
 (a.output/'model-files.json').write_text(json.dumps(manifest,indent=2)+'\n')
 checkpoints=a.output/'checkpoints';checkpoints.mkdir();(checkpoints/'Kimodo-G1-RP-v1').symlink_to(paths['nvidia/Kimodo-G1-RP-v1'],target_is_directory=True);os.environ['CHECKPOINT_DIR']=str(checkpoints)
 loader=importlib.import_module('kimodo.model.load_model');loader.TEXT_ENCODER_PRESETS['llm2vec']['kwargs']['base_model_name_or_path']=str(paths['McGill-NLP/LLM2Vec-Meta-Llama-3-8B-Instruct-mntp']);loader.TEXT_ENCODER_PRESETS['llm2vec']['kwargs']['peft_model_name_or_path']=str(paths['McGill-NLP/LLM2Vec-Meta-Llama-3-8B-Instruct-mntp-supervised'])
 import torch
 if not torch.cuda.is_available():raise RuntimeError('existing CUDA runtime unavailable')
 constraints=[];constraint=a.output/'constraints.json';constraint.write_text(json.dumps(constraints,indent=2))
 command=['kimodo_gen',PROMPT,'--model','kimodo-g1-rp','--duration','5.0','--num_samples','1','--seed','173','--output',str(a.output/'catch-reference'),'--save_example_dir']
 protocol=dict(command=command,prompt=PROMPT,frames=150,fps=30,source_commit=PIN,model_revisions=REVISIONS,cuda_device=torch.cuda.get_device_name(0),runtime_prefix=sys.prefix,offline=True,authentication_used=False,weights_downloaded=False,physics_claim=False,controller_transfer=False,constraints_used=False,retry_reason='stationaryRoot2D empty-frame failure; identicalprompt/seed withoutrootconstraint',fingers='NativeG1 has no Aero finger joints; outward finger direction only a palm-longitudinal-axis diagnostic')
 (a.output/'generation-protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
 with(a.output/'pip-freeze.txt').open('w')as f:subprocess.run([sys.executable,'-m','pip','freeze'],stdout=f,check=True)
 sys.argv=command;runpy.run_module('kimodo.scripts.generate',run_name='__main__')
 files={str(f.relative_to(a.output)):dict(bytes=f.stat().st_size,sha256=digest(f))for f in a.output.rglob('*')if f.is_file()and'checkpoints'not in f.relative_to(a.output).parts};(a.output/'output-hashes.json').write_text(json.dumps(files,indent=2)+'\n')
if __name__=='__main__':main()
