"""Bounded fixed-throw experiments using the protected native lower-cup runner."""
import argparse,json,subprocess,sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for n in ('source','amp-source'):p.add_argument('--'+n,required=True)
 p.add_argument('--profiles',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
 p.add_argument('--runner',choices=('scripts/probe_lower_cup_native_confirm.py','scripts/probe_lower_cup_visual_absorb.py','scripts/probe_lower_cup_native_observed.py','scripts/probe_lower_cup_compliant.py','scripts/probe_lower_cup_impedance.py'),default='scripts/probe_lower_cup_native_confirm.py')
 p.add_argument('--duration',type=float,default=8.)
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);protocol=json.loads((a.profiles/'protocol.json').read_text());(a.output/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
 def run(item):
  i,row=item;d=a.output/f'case-{i:02d}'
  cmd=[sys.executable,a.runner,'--source',a.source,'--amp-source',a.amp_source,'--profile',str(a.profiles/row['profile']),'--output',str(d),'--walk-speed','1','--handoff-depth','1.3','--initial-yaw','-.7','--duration',str(a.duration),'--record-anatomical','--reference-physics-sha256','173bf57168f5f97d0471d7bfa0a05e067a00f1e27a385994f57f21998a30af15']
  with (a.output/f'case-{i:02d}.log').open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  return dict(**row,command=cmd,exit_code=r.returncode,report=json.loads((d/'report.json').read_text())if(d/'report.json').exists()else None)
 with ThreadPoolExecutor(max_workers=2)as pool:rows=list(pool.map(run,enumerate(protocol['cases'])))
 (a.output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
 if any(r['exit_code']for r in rows):raise SystemExit(1)
if __name__=='__main__':main()
