"""Offline simultaneous finite physical-pad contact seeds on measured dynamic capture frames."""
from pathlib import Path
import json
from dataclasses import replace
import numpy as np,mujoco
from scipy.optimize import minimize
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
from g1_receiver.scrimmage_throw import ScrimmagePass
P=Path('reports/catch-repair-20261114/contact-model');O=P/'go-inlet';base=O/'armwrap-calibration-linux/artifacts/study';xml=(P/'study-linux/artifacts/study/original20-gain0.5/scene.xml').read_text().replace('/workspace/g1-receiver-runs/catch-repair-contact-model-20261114-r1/source/src/g1_receiver/_vendor/g1_runtime',str(DEFAULT_RUNTIME_ROOT)).replace('/workspace/g1-receiver-runs/out-scrimmage-20261113/source/aero-source','/tmp/g1-aero-source');m=mujoco.MjModel.from_xml_string(xml);d=mujoco.MjData(m);ball=m.geom('football_surface').id;ba=int(m.joint('football_free').qposadr[0]);pads=[m.geom('aero_'+s+'_palm_collision_7').id for s in['left','right']];geoms=np.array([g for g in range(m.ngeom)if g!=ball and m.geom_bodyid[g]>0 and(m.geom_contype[g]or m.geom_conaffinity[g])]);p=json.load(open('reports/catch-form-20261114/overnight-grip/screen-r1/artifacts/screen/give4-thumb-ready-profile.json'))['play'];origin=np.array(p['quarterback_origin_m']);original=np.array(p['quarterback_target_m']);results=[]
def plan(aim,T,mode):
 q=ScrimmagePass(tuple(origin),tuple(aim),T,align_ball_to_launch=mode=='launch',horizontal_distance_only=True).plan(5.2-T)
 if mode=='impact':
  axis=np.array(q.intercept_velocity_mps);yaw=.5*np.arctan2(axis[1],axis[0]);pitch=-.5*np.arctan2(axis[2],np.linalg.norm(axis[:2]));sy,cy,sp,cp=np.sin(yaw),np.cos(yaw),np.sin(pitch),np.cos(pitch);q=replace(q,release_quaternion_wxyz=(cy*cp,-sy*sp,cy*sp,sy*cp))
 return q
for scale in[0.,.5]:
 poses=np.load(base/f'grasp-scale-{scale}/offline-robot-qpos.npz');times=poses['timestamps_s'];qs=poses['qpos'];targetq=qs[np.argmin(abs(times-5.2))].copy()
 for T,mode in[(1.6,'launch'),(.8,'level'),(1.6,'impact')]:
  def place(aim,t=5.2):
   q=plan(aim,T,mode);d.qpos[:]=targetq if t==5.2 else qs[np.argmin(abs(times-t))];dt=t-(5.2-T);c=np.array(origin)+dt*np.array(q.release_velocity_mps);c[2]-=4.905*(dt*dt+.001*dt);d.qpos[ba:ba+7]=np.r_[c,q.release_quaternion_wxyz];mujoco.mj_kinematics(m,d);return q,c
  def cons(aim):
   _,c=place(aim);out=[]
   for g in pads:
    gap=mujoco.mj_geomDistance(m,d,ball,g,.4,None);n=d.geom_xmat[g].reshape(3,3)[:,0];face=d.geom_xpos[g]+m.geom_size[g,0]*n;out.extend([gap,.002-gap,(c-face)@n-.02])
   return np.array(out)
  fit=minimize(lambda aim:float(np.sum((aim-original)**2)),original+np.array([.04,0,.09]),method='SLSQP',bounds=list(zip(original-.15,original+.15)),constraints=[dict(type='ineq',fun=cons)],options=dict(maxiter=250,ftol=1e-12));r=dict(scale=scale,flight_s=T,mode=mode,success=bool(fit.success),message=fit.message,aim_m=fit.x.tolist(),shift_m=(fit.x-original).tolist(),min_constraint=float(cons(fit.x).min()))
  if fit.success:
   q,c=place(fit.x);patch=[]
   for g in pads:
    segment=np.zeros(6);gap=mujoco.mj_geomDistance(m,d,ball,g,.4,segment);F=d.geom_xmat[g].reshape(3,3);local=F.T@(segment[3:]-d.geom_xpos[g]);d.qpos[ba+2]+=.001;mujoco.mj_kinematics(m,d);approach_segment=np.zeros(6);approach_gap=mujoco.mj_geomDistance(m,d,ball,g,.4,approach_segment);normal=(approach_segment[:3]-approach_segment[3:])/max(abs(approach_gap),1e-9);d.qpos[ba+2]-=.001;mujoco.mj_kinematics(m,d);patch.append(dict(geom=m.geom(g).name,gap_m=float(gap),nearest_pad_local_m=local.tolist(),positive_face_x_m=float(m.geom_size[g,0]),normal_dot_receiving_face_from_1mm_up_probe=float(normal@F[:,0])))
   first={};minimum={}
   for t in np.arange(4.95,5.2001,.001):
    _,c=place(fit.x,float(t));low=np.linalg.norm(d.geom_xpos[geoms]-c,axis=1)-m.geom_rbound[geoms]-m.geom_rbound[ball]
    for g in geoms[low<.02]:
     gap=float(mujoco.mj_geomDistance(m,d,ball,int(g),.02,None));entry=dict(geom=m.geom(int(g)).name or f'geom-{g}',body=m.body(int(m.geom_bodyid[g])).name,time_s=float(t),gap_m=gap)
     if g not in minimum or gap<minimum[g]['gap_m']:minimum[int(g)]=entry
     if gap<=0 and g not in first:first[int(g)]=entry
   r.update(patches=patch,quaternion_wxyz=list(q.release_quaternion_wxyz),first_intersections=sorted(first.values(),key=lambda x:x['time_s']),minimum_gaps=sorted(minimum.values(),key=lambda x:x['gap_m']))
  results.append(r)
(O/'armwrap-finite-box-fits.json').write_text(json.dumps(dict(offline_only=True,not_catch_evidence=True,criteria='bothfinitephysicalpad7boxesdistance0..2mm;ballcenter>20mmreceivingfrontside;aimshift≤15cm/axis; no optimization of reportedphysicalscore',results=results),indent=2)+'\n');print(json.dumps([dict(scale=r['scale'],T=r['flight_s'],mode=r['mode'],success=r['success'],shift_mm=[round(1000*x,1)for x in r['shift_m']],patches=r.get('patches'),first=r.get('first_intersections',[])[:3])for r in results],indent=2))
