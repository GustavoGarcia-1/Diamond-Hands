"""Offline recorded-pose FK for fixed fixture calibration; never a runtime sensor."""
import argparse,json
from pathlib import Path
import mujoco,numpy as np
from g1_receiver.aero import make_aero_scene
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for name in ['source','trial','output']:p.add_argument('--'+name,type=Path,required=True)
 p.add_argument('--times',type=float,nargs='+',default=[4.,5.,5.2,6.,7.]);a=p.parse_args();v=np.load(a.trial/'view.npz');r=json.loads((a.trial/'report.json').read_text());m=mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT,a.source));d=mujoco.MjData(m);rows=[]
 for t in a.times:
  i=np.argmin(abs(v['timestamps_s']-t));d.qpos[:]=v['qpos'][i];mujoco.mj_kinematics(m,d);hands=[]
  for side,sign in [('left',1),('right',-1)]:
   b=d.body('aero_'+side+'_palm');R=b.xmat.reshape(3,3);hands.append(dict(side=side,face_world_m=(b.xpos+R@np.array([-.0025,sign*.017,.07225])).tolist(),normal_world=(sign*R[:,1]).tolist(),finger_axis_world=R[:,2].tolist(),face_height_above_shoulder_m=float((b.xpos+R@np.array([-.0025,sign*.017,.07225]))[2]-d.body(side+'_shoulder_pitch_link').xpos[2])))
  rows.append(dict(time_s=float(v['timestamps_s'][i]),hands=hands))
 result=dict(source=str(a.trial),offline_recorded_pose_calibration_only=True,minimum_upright_cosine=r['minimum_upright_cosine'],poses=rows,self_geometry=r.get('interhand_geometry_audit'),host_gains_sha256=r.get('host_gains_sha256'))
 a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
