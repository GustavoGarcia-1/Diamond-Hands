"""Analytic finite-facet seed and bounded whole-body unimpeded sweep; no physics rollout."""
from pathlib import Path
import json,time
import numpy as np,mujoco
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
from g1_receiver.scrimmage_throw import ScrimmagePass
P=Path('reports/catch-repair-20261114');O=P/'go-side-cup';candidate=json.load(open(O/'refined-balanced-candidate.json'));template=json.load(open(P/'out-cup/right-up-margin-transfer-geometry.json'));source_profile=json.load(open(P/'out-cup/right-up-margin-entry-profile.json'));s=(P/'contact-model/study-linux/artifacts/study/original20-gain0.5/scene.xml').read_text().replace('/workspace/g1-receiver-runs/catch-repair-contact-model-20261114-r1/source/src/g1_receiver/_vendor/g1_runtime',str(DEFAULT_RUNTIME_ROOT)).replace('/workspace/g1-receiver-runs/out-scrimmage-20261113/source/aero-source','/tmp/g1-aero-source');m=mujoco.MjModel.from_xml_string(s);d=mujoco.MjData(m);go=np.load(P/'validation/protected-witness-linux/witness/offline-robot-qpos.npz');k=np.argmin(abs(go['timestamps_s']-5.18));j=np.argmin(abs(go['timestamps_s']-5.16));base=go['qpos'][k].copy();outposes=np.load(P/'out-cup/right-up-margin-dry-r1/artifacts/trial/offline-robot-qpos.npz');outq=outposes['qpos'][np.argmin(abs(outposes['timestamps_s']-6.2))];d.qpos[:]=outq;mujoco.mj_kinematics(m,d);outpel=d.xpos[m.body('pelvis').id].copy();theta=template['pelvis_yaw_rad'];Yout=np.array([[np.cos(theta),-np.sin(theta),0],[np.sin(theta),np.cos(theta),0],[0,0,1]]);oldcenter=Yout.T@(np.array(source_profile['play']['field_catch_window_m'])-outpel);S=np.diag([1,-1,1]);phi=candidate['cup_common_yaw_rotation_rad'];C=np.array([[np.cos(phi),-np.sin(phi),0],[np.sin(phi),np.cos(phi),0],[0,0,1]]);mean=np.mean([S@np.array(h['facet_center_pelvis_yaw_frame_m'])for h in template['hands']],axis=0);relative_seed=np.array(candidate['cup_center_pelvis_yaw_frame_m'])+C@(S@oldcenter-mean);axis_local=C@S@(Yout.T@np.array([1,0,0.]))
for jn in range(m.njnt):
 n=m.joint(jn).name
 if n.startswith('aero_'):
  opposite=n.replace('left','TEMP').replace('right','left').replace('TEMP','right');base[int(m.jnt_qposadr[jn])]=outq[int(m.jnt_qposadr[m.joint(opposite).id])]
base[int(m.joint('waist_yaw_joint').qposadr[0])]=candidate['waist_yaw_rad']
for n,v in zip(candidate['arm_order'],candidate['arm_targets_rad']):base[int(m.joint(n).qposadr[0])]=v
d.qpos[:]=base;mujoco.mj_kinematics(m,d);pelvis=d.xpos[m.body('pelvis').id].copy();F=d.xmat[m.body('pelvis').id].reshape(3,3);gyaw=np.arctan2(F[1,0],F[0,0]);Y=np.array([[np.cos(gyaw),-np.sin(gyaw),0],[np.sin(gyaw),np.cos(gyaw),0],[0,0,1.]]);seed=pelvis+Y@relative_seed;axis=Y@axis_local;ball=m.geom('football_surface').id;ba=int(m.joint('football_free').qposadr[0]);pads=[m.geom('aero_'+s+'_palm_collision_7').id for s in ['left','right']];yaw=np.arctan2(axis[1],axis[0]);quat=np.array([np.cos(yaw/2),0,0,np.sin(yaw/2)]);Rb=np.array([[np.cos(yaw),-np.sin(yaw),0],[np.sin(yaw),np.cos(yaw),0],[0,0,1.]]);shape=Rb@np.diag(m.geom_size[ball]**2)@Rb.T;frames=[d.geom_xmat[g].reshape(3,3).copy()for g in pads];faces=[d.geom_xpos[g].copy()+m.geom_size[g,0]*F[:,0]for g,F in zip(pads,frames)];N=np.array([F[:,0]for F in frames]);supports=[shape@n/np.sqrt(n@shape@n)for n in N];rhs=np.array([n@(face+s)for n,face,s in zip(N,faces,supports)]);center=seed+N.T@np.linalg.solve(N@N.T,rhs-N@seed);null=np.cross(N[0],N[1]);null/=np.linalg.norm(null);low,high=-.05,.05;coeff=[]
for F,face,s in zip(frames,faces,supports):
 for direction,limit in [(F[:,1],.042-.010),(F[:,2],.013-.005)]:
  a=float(direction@null);b=float(direction@(center-s-face));coeff.append((a,b,limit))
  if abs(a)>1e-8:bounds=sorted([(-limit-b)/a,(limit-b)/a]);low=max(low,bounds[0]);high=min(high,bounds[1])
  elif abs(b)>limit:low=1;high=0
ok=low<=high;lam=float(np.clip(-sum(a*b/l**2 for a,b,l in coeff)/sum(a*a/l**2 for a,b,l in coeff),low,high))if ok else 0.;center+=lam*null;footprints=[]
for F,face,s in zip(frames,faces,supports):
 delta=center-s-face;off=F[:,1:].T@delta;footprints.append(dict(normal_gap_m=float(delta@F[:,0]),width_offset_m=float(off[0]),finger_offset_m=float(off[1]),width_margin_m=float(.042-abs(off[0])),finger_margin_m=float(.013-abs(off[1]))))
# Approximate quiet-at-contact body translation, measured preimpact pelvis speed; no pose replay during control.
bodyvel=(go['qpos'][k,:3]-go['qpos'][j,:3])/(go['timestamps_s'][k]-go['timestamps_s'][j]);geoms=np.array([g for g in range(m.ngeom)if g!=ball and m.geom_bodyid[g]>0 and(m.geom_contype[g]or m.geom_conaffinity[g])]);rows=[];started=time.monotonic()
for T in [.7,.85,1.,1.2]:
 aim=center+np.array([0,0,4.905*.001*T]);plan=ScrimmagePass((0,-1.8288,1.4),tuple(aim),T,horizontal_distance_only=True,align_ball_to_launch=False).plan(5.2-T);first={};minimum={}
 for relative in np.arange(-.25,.0001,.0025):
  if time.monotonic()-started>45:break
  d.qpos[:]=base;d.qpos[:3]+=relative*bodyvel;elapsed=T+relative;ballcenter=np.array(plan.release_xyz_m)+elapsed*np.array(plan.release_velocity_mps);ballcenter[2]-=4.905*(elapsed**2+.001*elapsed);d.qpos[ba:ba+7]=np.r_[ballcenter,quat];mujoco.mj_kinematics(m,d);lower=np.linalg.norm(d.geom_xpos[geoms]-ballcenter,axis=1)-m.geom_rbound[geoms]-m.geom_rbound[ball]
  for g in geoms[lower<.03]:
   gap=float(mujoco.mj_geomDistance(m,d,ball,int(g),.03,None));record=dict(geom=m.geom(int(g)).name or f'geom-{g}',body=m.body(int(m.geom_bodyid[g])).name,relative_time_s=float(relative),gap_m=gap)
   if g not in minimum or gap<minimum[g]['gap_m']:minimum[int(g)]=record
   if gap<=0 and g not in first:first[int(g)]=record
 vn=[float((np.array(plan.intercept_velocity_mps)-bodyvel)@n)for n in N];rows.append(dict(flight_s=T,initial_quaternion_wxyz=quat.tolist(),aim_m=aim.tolist(),relative_normal_velocity_mps=vn,first_intersections=sorted(first.values(),key=lambda x:x['relative_time_s']),minimum_gaps=sorted(minimum.values(),key=lambda x:x['gap_m'])))
report=dict(offline_only=True,no_catch_claim=True,seed_world_m=seed.tolist(),seed_relative_pelvis_yaw_frame_m=relative_seed.tolist(),center_world_m=center.tolist(),major_axis_world=axis.tolist(),finite_margin_requirements=dict(width_m=.010,finger_m=.005),finite_margin_interval_exists=ok,interval_m=[low,high],footprints=footprints,quiet_body_velocity_mps=bodyvel.tolist(),sweeps=rows,elapsed_s=time.monotonic()-started);(O/'incoming-clearance.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(margins_ok=ok,footprints=footprints,axis=axis.tolist(),sweeps=[dict(T=r['flight_s'],vn=r['relative_normal_velocity_mps'],first=r['first_intersections'][:4])for r in rows]),indent=2))
