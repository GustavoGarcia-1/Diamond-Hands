"""Closed-loop arm/native-action ablations of one frozen learned checkpoint."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import numpy as np
from stable_baselines3 import PPO
from g1_receiver.native_cup_training import NativeCatchEnv
from g1_receiver.native_cup_continuation import CAMERAS, mutate_throw_only
from g1_receiver.native_cup_residual_rl import OBS_SCHEMA


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('source', 'amp-source', 'profile', 'model', 'output'):
        p.add_argument('--'+name, type=Path, required=True)
    p.add_argument('--native-gains', type=float, nargs='+',
                   help='Optional diagnostic: keep arm gain0.5 and test listed native group gains')
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    model = PPO.load(a.model, device='cuda')
    assert model.observation_space.shape == (169,) and model.action_space.shape == (20,)
    assert model.receiver_sensor_schema == OBS_SCHEMA
    digest = sha256(a.model.read_bytes()).hexdigest()
    assert digest == 'fcd915e0578115ba300ca697744699a534d2d6896209f03b06474097cc91acc5'
    donor = json.loads(a.profile.read_text())
    fixtures = [('nominal', (0., 0.)), ('y-minus', (-.02, 0.)), ('y-plus', (.02, 0.)),
                ('z-minus', (0., -.02)), ('z-plus', (0., .02))]
    masks = dict(arms_only=np.r_[np.ones(14), np.zeros(6)].astype(np.float32),
                 native_only=np.r_[np.zeros(14), np.ones(6)].astype(np.float32))
    if a.native_gains is not None:
        if not all(np.isfinite(g) and 0 <= g <= .75 for g in a.native_gains):
            p.error('native gains must be finite and in[0,.75]')
        masks = {f'arms0.5-native{g:g}':np.r_[np.ones(14), np.full(6, g/.5)].astype(np.float32)
            for g in a.native_gains}
    protocol = dict(model_sha256=digest, action_gain=.5, action_masks={k:v.tolist() for k,v in masks.items()},
        fixtures=fixtures, seed=173, inference_device='cuda', duration_s=9., actual_training=False,
        scope='Closed-loop diagnostic: policy sees applied masked action history; nominal scripted arm/hand commands remain. No weights, physical parameters, sensors or score thresholds change.',
        reference='Full and zero evaluations are independently archived; no new baseline inferred from a score.',
        promotion='No realism claim unless every unchanged physical-quality gate passes.')
    (a.output/'protocol.json').write_text(json.dumps(protocol, indent=2)+'\n')
    rows = []
    for label, mask in masks.items():
        for fixture, delta in fixtures:
            out = a.output/label/fixture
            out.mkdir(parents=True)
            profile = out/'profile.json'
            profile.write_text(json.dumps(mutate_throw_only(donor, delta), indent=2)+'\n')
            env = NativeCatchEnv(profile, a.source, a.amp_source, duration=9., evaluation_dir=out/'rollout', **CAMERAS)
            try:
                obs, _ = env.reset(seed=173)
                total = 0.
                while True:
                    action = model.predict(obs, deterministic=True)[0]*np.float32(.5)*mask
                    obs, reward, done, _, info = env.step(action)
                    total += reward
                    if done:
                        break
                assert np.isclose(total, info['sensor_return'], atol=1e-9)
                report = json.loads((out/'rollout/episode-0001/trial/report.json').read_text())
                rows.append(dict(component=label, fixture=fixture, delta_yz_m=delta,
                    anatomical=report['anatomical_score'], sensor=info, returned_reward=total))
                (a.output/'summary.json').write_text(json.dumps(rows, indent=2)+'\n')
                print(json.dumps(dict(component=label, fixture=fixture, completed=len(rows))), flush=True)
            finally:
                env.close()


if __name__ == '__main__':
    main()
