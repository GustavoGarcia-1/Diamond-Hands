"""Diagnostic unimpeded fixture sweep against recorded robot poses plus proposed arms."""
import argparse,json
from pathlib import Path
import numpy as np,mujoco
from g1_receiver.aero import make_aero_scene
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT

def main():
 p=argparse.ArgumentParser()
 for n in ['source','trial','proposal','profile','output']:p.add_argument('--'+n,type=Path,required=True)
 p.add_argument('--recorded-arms',action='store_true');a=p.parse_args();r=json.loads(a.proposal.read_text());profile=json.loads(a.profile.read_text());m=mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT,a.source));d=mujoco.MjData(m);q=np.load(a.trial/'offline-robot-qpos.npz');print(q.files);times=q[q.files[0]];poses=q[q.files[1]];adr=np.array([m.joint(n).qposadr[0]for n in r['arm_order']]);ba=int(m.joint('football_free').qposadr[0]);bg=int(m.geom('football_surface').id);geoms=[g for g in range(m.ngeom)if g!=bg and m.geom_bodyid[g]>0 and(m.geom_contype[g]or m.geom_conaffinity[g])];T=profile['play']['flight_s'] if a.recorded_arms else r['flight_s'];C=np.array(profile['play']['field_catch_window_m'] if a.recorded_arms else r['ball_center_world_m']);origin=np.array(profile['play']['quarterback_origin_m']);arrival=6.2;release=arrival-T;vel=(C-origin)/T+np.array([0.,0.,4.905*T]);first=[];near=[]
 for t in np.arange(release,arrival+.0001,.001):
  d.qpos[:]=poses[np.argmin(abs(times-t))];
  if not a.recorded_arms:d.qpos[adr]=r['arm_targets_rad']
  elapsed=t-release;ball=origin+vel*elapsed+np.array([0,0,-4.905*elapsed*elapsed]);d.qpos[ba:ba+7]=np.r_[ball,[1,0,0,0]];mujoco.mj_kinematics(m,d)
  for g in geoms:
   if np.linalg.norm(d.geom_xpos[g]-ball)>m.geom_rbound[g]+m.geom_rbound[bg]+.01:continue
   dist=mujoco.mj_geomDistance(m,d,bg,g,.02,None)
   if dist<0:
    entry=dict(time_s=float(t),before_arrival_s=float(arrival-t),geom_id=g,geom=m.geom(g).name,body=m.body(int(m.geom_bodyid[g])).name,penetration_m=float(-dist));near.append(entry)
    if not any(e['geom_id']==g for e in first):first.append(entry)
 result=dict(diagnostic_only=True,actual_dynamic_realization_not_yet_known=True,static_proposal=str(a.proposal),full_incoming_from_release_s=float(release),first_intersections=sorted(first,key=lambda x:x['time_s']),max_overlap_before_arrival_m=max([x['penetration_m']for x in near],default=0));a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
