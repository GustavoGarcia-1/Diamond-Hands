"""Read-only static interpolation audit including commanded torso yaw."""
import argparse,json
from pathlib import Path
import mujoco,numpy as np
from g1_receiver.aero import make_aero_scene
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT

def main():
 p=argparse.ArgumentParser()
 for n in ['source','input','output']:p.add_argument('--'+n,type=Path,required=True)
 a=p.parse_args();doc=json.loads(a.input.read_text());op,cl=doc['rows'][:2];m=mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT,a.source));d=mujoco.MjData(m);d.qpos[:]=m.qpos0;adr=[m.joint(n).qposadr[0]for n in op['arm_order']];waist=m.joint('waist_yaw_joint').qposadr[0];sides={}
 for side in ['left','right']:
  sides[side]=[i for i in range(m.ngeom)if (mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_BODY,int(m.geom_bodyid[i]))or'').startswith('aero_'+side+'_')and(m.geom_contype[i]or m.geom_conaffinity[i])]
 proximal=[g for g in range(m.ngeom)if any(m.body(int(m.geom_bodyid[g])).name.startswith(side+'_'+part)for side in('left','right')for part in('shoulder_roll','shoulder_yaw','elbow','wrist'))and(m.geom_contype[g]or m.geom_conaffinity[g])]
 torso=[i for i in range(m.ngeom)if(mujoco.mj_id2name(m,mujoco.mjtObj.mjOBJ_BODY,int(m.geom_bodyid[i]))or'')in ['torso_link','head_link']and(m.geom_contype[i]or m.geom_conaffinity[i])];rows=[]
 ready=np.array(json.loads(Path('reports/catch-form-20261114/overnight-grip/runtime-ready.json').read_text())['ready'])
 for phase,q0,q1,y0,y1 in [('stage',ready,np.array(op['arm_targets_rad']),0.,op['torso_yaw_rad']),('wrap',np.array(op['arm_targets_rad']),np.array(cl['arm_targets_rad']),op['torso_yaw_rad'],cl['torso_yaw_rad'])]:
  for u in np.linspace(0,1,41):
   d.qpos[adr]=(1-u)*q0+u*q1;d.qpos[waist]=(1-u)*y0+u*y1;mujoco.mj_forward(m,d);gap=min(float(mujoco.mj_geomDistance(m,d,i,j,.1,None))for i in sides['left']for j in sides['right']);bodygap=min(float(mujoco.mj_geomDistance(m,d,i,j,.1,None))for i in sides['left']+sides['right']for j in torso);up=[float(sign*d.body('aero_'+side+'_palm').xmat.reshape(3,3)[2,1])for side,sign in [('left',1),('right',-1)]];left_arm=sides['left']+[g for g in proximal if m.body(int(m.geom_bodyid[g])).name.startswith('left_')];right_arm=sides['right']+[g for g in proximal if m.body(int(m.geom_bodyid[g])).name.startswith('right_')];opposite_arm_gap=min(float(mujoco.mj_geomDistance(m,d,i,j,.1,None))for i in left_arm for j in right_arm);proximal_gap=min(float(mujoco.mj_geomDistance(m,d,i,j,.1,None))for i in proximal for j in torso);rows.append(dict(opposite_arm_gap_m=opposite_arm_gap,proximal_arm_torso_gap_m=proximal_gap,phase=phase,fraction=float(u),interhand_gap_m=gap,hand_torso_gap_m=bodygap,palm_up_cos=up))
 result=dict(static_only=True,source=str(a.input),minimum_opposite_arm_m=min(x['opposite_arm_gap_m']for x in rows),minimum_proximal_arm_torso_m=min(x['proximal_arm_torso_gap_m']for x in rows),minimum_interhand_m=min(x['interhand_gap_m']for x in rows),minimum_hand_torso_m=min(x['hand_torso_gap_m']for x in rows),minimum_wrap_up_cos=min(min(x['palm_up_cos'])for x in rows if x['phase']=='wrap'),rows=rows);a.output.write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items()if k!='rows'})
if __name__=='__main__':main()
