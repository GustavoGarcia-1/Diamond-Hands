"""Offline measured-thumb FK graft; never a controller or physical-catch claim."""
from pathlib import Path
import json,argparse
import numpy as np,mujoco
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
from g1_receiver.scrimmage_throw import ScrimmagePass
from g1_receiver.lower_cup_grip import NativeHandCalibration
parser=argparse.ArgumentParser();parser.add_argument('--dry-study',default='precurl-dry');parser.add_argument('--output-name',default='precurl-shape-audit.json');args=parser.parse_args();P=Path('reports/catch-repair-20261114/contact-model');out=P/'go-inlet';xml=(P/'study-linux/artifacts/study/original20-gain0.5/scene.xml').read_text().replace('/workspace/g1-receiver-runs/catch-repair-contact-model-20261114-r1/source/src/g1_receiver/_vendor/g1_runtime',str(DEFAULT_RUNTIME_ROOT)).replace('/workspace/g1-receiver-runs/out-scrimmage-20261113/source/aero-source','/tmp/g1-aero-source');m=mujoco.MjModel.from_xml_string(xml);d=mujoco.MjData(m);cal=NativeHandCalibration.from_model(m);original=np.load('reports/catch-repair-20261114/validation/protected-witness-linux/witness/offline-robot-qpos.npz');times=original['timestamps_s'];qs=original['qpos'];i=np.argmin(abs(times-5.18));j=np.argmin(abs(times-5.16));vel=np.zeros(m.nv);mujoco.mj_differentiatePos(m,vel,times[i]-times[j],qs[j],qs[i]);ball=m.geom('football_surface').id;ba=int(m.joint('football_free').qposadr[0]);hands=np.array([g for g in range(m.ngeom)if g!=ball and m.geom_bodyid[g]>0 and(m.geom_contype[g]or m.geom_conaffinity[g])]);profile=json.load(open('reports/catch-form-20261114/overnight-grip/screen-r1/artifacts/screen/give4-thumb-ready-profile.json'));plan=ScrimmagePass(tuple(profile['play']['quarterback_origin_m']),tuple(profile['play']['quarterback_target_m']),1.6,horizontal_distance_only=True).plan(3.6);records=[]
for label in ['baseline','original-opposition','opposition-0.5']:
 graft={};telemetry=None;calibration=None
 if label!='baseline':
  root=out/(args.dry_study+'-linux')/'artifacts/study'/label;calibration=json.load(open(root/'dry-calibration.json'));dry=np.load(root/'offline-robot-qpos.npz');k=np.argmin(abs(dry['timestamps_s']-5.18));dryq=dry['qpos'][k];native=np.load(root/'trial/trace.npz')['native_hand'];nk=np.argmin(abs(native[:,0]-5.18));telemetry=cal.fractions(native[nk:nk+1,1:15])[0].tolist()
  for side in ['left','right']:
   for axis in ['cmc_flex','mcp','ip']:
    address=int(m.joint('aero_'+side+'_'+side+'_thumb_'+axis).qposadr[0]);graft[address]=float(dryq[address])
   if label=='opposition-0.5':
    phase=np.load(out/'thumb-flex-linux/artifacts/study/opposition-0.5-gain0.5/offline-robot-qpos.npz');pk=np.argmin(abs(phase['timestamps_s']-5.18));address=int(m.joint('aero_'+side+'_'+side+'_thumb_cmc_abd').qposadr[0]);graft[address]=float(phase['qpos'][pk,address])
 def robot(t):
  d.qpos[:]=qs[np.argmin(abs(times-t))]if t<=5.18 else qs[i]
  if t>5.18:mujoco.mj_integratePos(m,d.qpos,vel,t-times[i])
  for address,value in graft.items():d.qpos[address]=value
  mujoco.mj_kinematics(m,d)
 robot(5.18);roof=[]
 for side in ['left','right']:
  pad=m.geom('aero_'+side+'_palm_collision_7').id;F=d.geom_xmat[pad].reshape(3,3);normal=F[:,0];face=d.geom_xpos[pad]+m.geom_size[pad,0]*normal;tip=m.geom('aero_'+side+'_th_tip').id;R=d.geom_xmat[tip].reshape(3,3);center=d.geom_xpos[tip];roof.append(dict(side=side,thumbtip_center_above_pad_m=float((center-face)@normal),thumbtip_highest_box_corner_above_pad_m=float((center-face)@normal+abs(R.T@normal)@m.geom_size[tip]),thumb_flex_joint_angles_rad=[float(d.qpos[int(m.joint('aero_'+side+'_'+side+'_thumb_'+axis).qposadr[0])])for axis in['cmc_flex','mcp','ip']]))
 first={};minimum={}
 for t in np.arange(4.95,5.2001,.001):
  robot(t);dt=t-3.6;center=np.array(plan.release_xyz_m)+dt*np.array(plan.release_velocity_mps);center[2]-=4.905*(dt*dt+.001*dt);d.qpos[ba:ba+7]=np.r_[center,plan.release_quaternion_wxyz];mujoco.mj_kinematics(m,d);lower=np.linalg.norm(d.geom_xpos[hands]-center,axis=1)-m.geom_rbound[hands]-m.geom_rbound[ball]
  for g in hands[lower<.02]:
   gap=float(mujoco.mj_geomDistance(m,d,ball,int(g),.02,None));r=dict(geom=m.geom(int(g)).name or f'geom-{g}',body=m.body(int(m.geom_bodyid[g])).name,time_s=float(t),gap_m=gap)
   if g not in minimum or gap<minimum[g]['gap_m']:minimum[int(g)]=r
   if gap<=0 and g not in first:first[int(g)]=r
 records.append(dict(label=label,actual_dry_no_ball_robot_contacts=not calibration['ball_robot_contacts']if calibration else None,native_encoder_fractions_at518=telemetry,roof=roof,first_intersections=sorted(first.values(),key=lambda x:x['time_s']),minimum_gaps=sorted(minimum.values(),key=lambda x:x['gap_m'])))
(out/args.output_name).write_text(json.dumps(dict(offline_only=True,no_runtime_qpos_injection=True,not_catch_evidence=True,method='Measured drythreeflexjointangles grafted to actualoriginal5.18arm/opposition frame; .5oppositionusesmeasuredsamephaseoppositionfrompriorflextrial. Fullcoupleddynamicsnotproved.',records=records),indent=2)+'\n');print(json.dumps([dict(label=r['label'],roof=r['roof'],first=r['first_intersections'][:3],minimum=r['minimum_gaps'][:2])for r in records],indent=2))
