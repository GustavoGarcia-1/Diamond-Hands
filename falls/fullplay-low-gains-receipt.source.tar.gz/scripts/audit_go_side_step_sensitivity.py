"""Read-only FK comparison of measured trajectories under explicitly different integration steps."""
import json,re
from pathlib import Path
import numpy as np,mujoco
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
P=Path('reports/catch-repair-20261114/go-side-cup');rows=[]
for r in sorted((P/'timestep-linux/artifacts/study').glob('dt-*')):
 if not r.is_dir():continue
 xml=re.sub(r'/workspace/g1-receiver-runs/[^" ]+/source/src/g1_receiver/_vendor/g1_runtime',str(DEFAULT_RUNTIME_ROOT),(r/'scene.xml').read_text()).replace('/workspace/g1-receiver-runs/out-scrimmage-20261113/source/aero-source','/tmp/g1-aero-source');m=mujoco.MjModel.from_xml_string(xml);d=mujoco.MjData(m);q=np.load(r/'actual-state.npz')['time_qpos'];samples=[]
 for t in[4.5,4.56,4.58,5.0,5.18,5.2]:
  k=np.argmin(abs(q[:,0]-t));d.qpos[:]=q[k,1:];mujoco.mj_kinematics(m,d);faces=[]
  for side in['left','right']:
   g=m.geom('aero_'+side+'_palm_collision_7').id;F=d.geom_xmat[g].reshape(3,3);faces.append(dict(center_m=(d.geom_xpos[g]+m.geom_size[g,0]*F[:,0]).tolist(),normal=F[:,0].tolist()))
  samples.append(dict(time_s=float(q[k,0]),pelvis_m=d.qpos[:3].tolist(),ball_center_m=d.xpos[m.body('football').id].tolist()if mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,'football')>=0 else d.qpos[-7:-4].tolist(),faces=faces))
 rows.append(dict(case=r.name,samples=samples))
reference=next(r for r in rows if r['case']=='dt-0.001')
for r in rows:
 for s,ref in zip(r['samples'],reference['samples']):s['face_shift_from_1ms_m']=[(np.array(f['center_m'])-np.array(b['center_m'])).tolist()for f,b in zip(s['faces'],ref['faces'])]
(P/'timestep-fk-diagnosis.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps([dict(case=r['case'],sample5p18=r['samples'][-2])for r in rows],indent=2))
