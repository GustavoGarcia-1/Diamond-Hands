"""Scoped contact-model study on an immutable Out controller and grip fixture."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import numpy as np
from probe_ball_hand_contact_model import add_pairs


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('frozen-root', 'profile', 'source', 'amp-source', 'output', 'reference'):
        p.add_argument('--'+name, type=Path, required=True)
    p.add_argument('--case', choices=['original', 'pair20', 'pair5', 'pair25'])
    p.add_argument('--timestep', type=float, choices=[.001, .0005, .00025], default=.001)
    p.add_argument('--duration', type=float, default=8.)
    p.add_argument('--fixed-servo', action='store_true', help='Keep body PD update period at1ms while varying physics timestep')
    p.add_argument('--break-release-delay', type=float,
                   help='Experimental machine release delay from the RGB-D-triggered route break')
    a = p.parse_args()
    if a.break_release_delay is not None and not 1. <= a.break_release_delay <= 4.:
        p.error('break-relative release delay must be1..4s')
    a.output.mkdir(parents=True, exist_ok=False)
    if a.case is None:
        files = sorted(f for folder in ('src', 'scripts') for f in (a.frozen_root/folder).rglob('*')
                       if f.is_file() and '__pycache__' not in f.parts)
        hashes = {str(f.relative_to(a.frozen_root)): hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
        with tarfile.open(a.output/'frozen-runtime.tar.gz', 'x:gz') as archive:
            for f in files:
                archive.add(f, arcname=str(f.relative_to(a.frozen_root)))
        (a.output/'frozen-runtime-hashes.json').write_text(json.dumps(hashes, indent=2)+'\n')
        results = []
        for case in ('original', 'pair20', 'pair5', 'pair25'):
            command = [sys.executable, str(Path(__file__).resolve()), '--case', case]
            for name in ('frozen_root', 'profile', 'source', 'amp_source', 'reference'):
                command += ['--'+name.replace('_', '-'), str(getattr(a, name))]
            command += ['--output', str(a.output/case)]
            command += ['--timestep', str(a.timestep), '--duration', str(a.duration)]
            if a.fixed_servo:
                command.append('--fixed-servo')
            if a.break_release_delay is not None:
                command += ['--break-release-delay', str(a.break_release_delay)]
            subprocess.run(command, check=True)
            if case in ('original', 'pair20'):
                checks = {}
                for name in ('trace.npz', 'view.npz', 'anatomical-contact.npz', 'interhand-geometry.npz'):
                    with np.load(a.output/case/'trial'/name) as current, np.load(a.reference/name) as old:
                        checks[name] = {key: bool(np.array_equal(current[key], old[key], equal_nan=True))
                                        if old[key].dtype.kind not in 'US' else bool(np.array_equal(current[key], old[key]))
                                        for key in old.files}
                (a.output/case/'exact.json').write_text(json.dumps(checks, indent=2)+'\n')
                if not all(all(v.values()) for v in checks.values()):
                    raise RuntimeError('Original or pair20 differs; stop before altered contact models')
            report = json.loads((a.output/case/'trial/report.json').read_text())
            results.append(dict(case=case, original_model=case=='original',
                                model_calibrated=False, anatomical=report['anatomical_score']))
            (a.output/'summary.json').write_text(json.dumps(results, indent=2)+'\n')
        return

    sys.path[:0] = [str(a.frozen_root/'scripts'), str(a.frozen_root/'src')]
    import mujoco
    from g1_receiver.hand_route_plant import HandRoutePlant
    from g1_receiver.anatomical_catch_eval import physics_fingerprint
    from g1_receiver.locomotion import CONTROL_DT
    import probe_out_native_lower as runner
    original_init = HandRoutePlant.__init__
    original_step = HandRoutePlant.step
    original_run = runner.run
    metadata = {}
    tau = {'original': .02, 'pair20': .02, 'pair5': .005, 'pair25': .0025}[a.case]

    def patched_init(self, *args, **kwargs):
        setup = kwargs.get('scene_setup')
        def scene_setup(scene):
            if setup:
                setup(scene)
            if a.case != 'original':
                metadata.update(add_pairs(scene, tau))
            if a.timestep != .001:
                scene.find('option').set('timestep', str(a.timestep))
        kwargs['scene_setup'] = scene_setup
        original_init(self, *args, **kwargs)
        m = self.model
        assert tau >= 2*m.opt.timestep
        extended = dict(base=physics_fingerprint(m), pair_geom1=m.pair_geom1.tolist(),
                        pair_geom2=m.pair_geom2.tolist(), pair_dim=m.pair_dim.tolist(),
                        pair_solref=m.pair_solref.tolist(), pair_solimp=m.pair_solimp.tolist(),
                        pair_friction=m.pair_friction.tolist(), pair_margin=m.pair_margin.tolist(),
                        pair_gap=m.pair_gap.tolist(), enableflags=int(m.opt.enableflags),
                        disableflags=int(m.opt.disableflags), ccd_iterations=int(m.opt.ccd_iterations),
                        ccd_tolerance=float(m.opt.ccd_tolerance))
        metadata.update(timeconstant_s=tau, physics_timestep_s=float(m.opt.timestep),
                        actual_evaluation_callback_hz=1./float(m.opt.timestep),
                        body_pd_update_hz=1000. if a.fixed_servo else 1./float(m.opt.timestep),
                        original_model=a.case=='original' and a.timestep==.001, material_calibrated=False,
                        unchanged_controller=a.break_release_delay is None,
                        receiver_controller_unchanged=True,
                        machine_release_protocol_changed=a.break_release_delay is not None,
                        quality_gates_unchanged=True,
                        extended_model=extended,
                        extended_model_sha256=hashlib.sha256(json.dumps(extended, sort_keys=True).encode()).hexdigest(),
                        scene_xml_sha256=hashlib.sha256(self.scene_xml.encode()).hexdigest(),
                        mujoco_version=mujoco.__version__,
                        warning='Legacy model fingerprint omits pair mappings; use this extended identity. Changed models are not the original reference.')
        (a.output/'scene.xml').write_text(self.scene_xml)
        (a.output/'contact-model.json').write_text(json.dumps(metadata, indent=2)+'\n')

    def fixed_servo_step(self, command, *, closure=0., hand_target_rad=None, post_step=None):
        if self.model.opt.timestep == .001:
            return original_step(self, command, closure=closure, hand_target_rad=hand_target_rad, post_step=post_step)
        command.validate(29)
        if ((command.target_position < self.joint_ranges[:, 0]).any()
                or (command.target_position > self.joint_ranges[:, 1]).any()):
            raise ValueError('body command exceeds a joint range')
        if hand_target_rad is None:
            self.actuation.set_closure(self.data, closure, dt_s=CONTROL_DT)
        else:
            self.actuation.set_targets(self.data, hand_target_rad, dt_s=CONTROL_DT)
        stride = round(.001/self.model.opt.timestep)
        if not np.isclose(stride*self.model.opt.timestep, .001):
            raise ValueError('physics step must divide fixed1ms servo period')
        for substep in range(self.substeps):
            if substep % stride == 0:
                sensed = self.data.sensordata
                effort = (command.kp*(command.target_position-sensed[self._q])
                          - command.kd*sensed[self._dq]+command.feedforward_torque)
                self.data.ctrl[self.body_actuators] = np.clip(effort, self._effort_min, self._effort_max)
            mujoco.mj_step(self.model, self.data)
            if post_step is not None:
                post_step(self.data)
        mujoco.mj_forward(self.model, self.data)

    def phase_triggered_run(plant, policy, cut, **kwargs):
        delivery = kwargs.get('delivery')
        if delivery is None:
            raise ValueError('phase-triggered release requires a configured fixed machine')
        original_observe = delivery.observe
        delivery.profile = dict(delivery.profile)
        delivery.profile['release_s'] = 1e6  # No camera-observed break means no throw.
        metadata['machine_release_protocol'] = dict(
            trigger='RGB-D route-break command event; no exact pelvis/ball/contact input',
            delay_s=a.break_release_delay, fixed_origin_and_launch_velocity=True,
            observed_break_s=None, commanded_release_s=None)
        def observe(plant, now, pose, poses):
            if cut.break_at_s is not None and delivery.release is None:
                scheduled = float(cut.break_at_s)+a.break_release_delay
                delivery.profile['release_s'] = scheduled
                metadata['machine_release_protocol'].update(observed_break_s=float(cut.break_at_s),
                                                            commanded_release_s=scheduled)
            return original_observe(plant, now, pose, poses)
        delivery.observe = observe
        try:
            return original_run(plant, policy, cut, **kwargs)
        finally:
            metadata['machine_release_protocol']['actual_release_s'] = (
                None if delivery.release is None else float(delivery.release.release_time_s))
            delivery.observe = original_observe

    HandRoutePlant.__init__ = patched_init
    if a.fixed_servo:
        HandRoutePlant.step = fixed_servo_step
    if a.break_release_delay is not None:
        runner.run = phase_triggered_run
    sys.argv = ['probe_out_native_lower.py', '--source', str(a.source), '--amp-source', str(a.amp_source),
                '--output', str(a.output/'trial'), '--duration', str(a.duration), '--approach-handoff-depth-m', '2.1',
                '--cut-speed', '1.4', '--blend-s', '.5', '--turn-s', '.4', '--hold-straight-s', '0',
                '--depth-feedback-gain', '4', '--camera-start-s', '.8', '--stopping-lookahead-s', '.55',
                '--reverse-speed', '0', '--approach-speed', '.48', '--horizontal-pass-distance',
                '--pass-profile', str(a.profile), '--record-poses', '--record-anatomical',
                '--reference-physics-sha256', '173bf57168f5f97d0471d7bfa0a05e067a00f1e27a385994f57f21998a30af15']
    try:
        runner.main()
    finally:
        HandRoutePlant.__init__ = original_init
        HandRoutePlant.step = original_step
        runner.run = original_run
        (a.output/'contact-model.json').write_text(json.dumps(metadata, indent=2)+'\n')


if __name__ == '__main__':
    main()
