"""Offline exact thin-box receiving-face FK; distinct from palm-body ±Y."""
import argparse,json
from pathlib import Path
import numpy as np,mujoco
from g1_receiver.aero import make_aero_scene
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT

def main():
 p=argparse.ArgumentParser()
 for n in ['source','trial','output']:p.add_argument('--'+n,type=Path,required=True)
 p.add_argument('--times',type=float,nargs='+',default=[5.2]);p.add_argument('--full-rate',action='store_true');a=p.parse_args();m=mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT,a.source));d=mujoco.MjData(m);v=np.load(a.trial/('offline-robot-qpos.npz' if a.full_rate else 'view.npz'));rows=[];names=['aero_'+s+'_palm_collision_7'for s in ['left','right']]
 for t in a.times:
  i=np.argmin(abs(v['timestamps_s']-t));d.qpos[:]=v['qpos'][i];mujoco.mj_kinematics(m,d);hands=[]
  for s,sign,name in zip(['left','right'],[1,-1],names):
   g=int(m.geom(name).id);R=d.geom_xmat[g].reshape(3,3);body=d.body('aero_'+s+'_palm');bodyN=sign*body.xmat.reshape(3,3)[:,1];axis=int(np.argmax(abs(R.T@bodyN)));face_sign=float(np.sign((R.T@bodyN)[axis]));normal=face_sign*R[:,axis];point=d.geom_xpos[g]+m.geom_size[g,axis]*normal;hands.append(dict(side=s,face_world_m=point.tolist(),normal_world=normal.tolist(),finger_axis_world=R[:,2].tolist(),body_palm_up_cos=float(bodyN[2]),actual_pad_up_cos=float(normal[2]),face_height_above_shoulder_m=float(point[2]-d.body(s+'_shoulder_pitch_link').xpos[2]),facet_geom=name,facet_axis=axis,facet_sign=face_sign,finite_in_plane_half_extents_m=[float(m.geom_size[g,1]),float(m.geom_size[g,2])]))
  rows.append(dict(time_s=float(v['timestamps_s'][i]),hands=hands))
 result=dict(source=str(a.trial),calibration_kind='native_palm_box7_front_facet',offline_only=True,facet_geom_names=names,poses=rows);a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(rows,indent=2))
if __name__=='__main__':main()
