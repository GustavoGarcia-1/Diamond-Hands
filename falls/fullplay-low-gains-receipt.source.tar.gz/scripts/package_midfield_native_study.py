"""Add verified midpoint-field presentation to the preserved native-study ZIP."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
from zipfile import ZipFile
import imageio_ffmpeg
from package_held_routes import framehash, zip_bytes, safe, ROUTES

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT/'artifacts/him-open-build-native-study-20261114-r2/project.zip'
BASE_SHA = 'f96b6883aec980d5ec36b28ff112234de56de6f27c2f46e8dc97da2ddb0418d0'
PREFIX = 'experiments/native-cup-19456'
NATIVE = ROOT/'reports/catch-form-20261114/overnight-lower/native-rl'
RENDER = ROOT/'reports/midfield-presentation-20261114-r2'


def digest(data):
    return sha256(data).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    out = a.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    assert digest(BASE.read_bytes()) == BASE_SHA
    with ZipFile(BASE) as z:
        old = json.loads(z.read('MANIFEST.json'))
        assert z.testzip() is None
        files = {safe(name):z.read(name) for name in old}
        assert all(digest(files[n]) == h for n,h in old.items())
    def add(path, name):
        files[safe(name)] = path.read_bytes()
    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    frames, segments = [], []
    start = 0.
    for route in ('go', 'out', 'slant'):
        source = RENDER/route/'full-play.mp4'
        target = out/f'{route}-held.mp4'
        shutil.copyfile(source, target)
        hashes = framehash(target, ffmpeg)
        duration = len(hashes)/25.
        segments.append(dict(route=route, file=target.name, sha256=digest(target.read_bytes()),
            frame_count=len(hashes), start_s=start, end_s=start+duration, duration_s=duration))
        frames.extend(row['sha256'] for row in hashes)
        start += duration
        add(target, f'videos/{target.name}')
    playlist = out/'concat-inputs.txt'
    playlist.write_text(''.join("file '"+str(out/s['file']).replace("'", "'\\''")+"'\n" for s in segments))
    video = out/'full-play.mp4'
    subprocess.run([ffmpeg, '-v', 'error', '-nostdin', '-f', 'concat', '-safe', '0', '-i', str(playlist),
        '-map', '0:v:0', '-c', 'copy', '-an', '-fflags', '+bitexact', '-movflags', '+faststart', str(video)], check=True)
    assert [r['sha256'] for r in framehash(video, ffmpeg)] == frames
    assert len(frames) == 762 and abs(start-30.48) < 1e-8
    concat = dict(order=['go','out','slant'], method='H264 stream copy; complete plays; cuts only between routes',
        width=1280, height=720, fps=25, frame_count=len(frames), duration_s=start, segments=segments,
        decoded_frame_order_and_pixels_identical=True, full_video_sha256=digest(video.read_bytes()))
    files['concat-manifest.json'] = (json.dumps(concat, indent=2)+'\n').encode()
    add(video, 'videos/full-play.mp4')
    for name in ('full-play.mp4', 'contact-sheet.jpg', 'video-verification.json'):
        add(RENDER/'native-learned'/name, f'{PREFIX}/{name}')
    qualification = json.loads(files[f'{PREFIX}/qualification.json'])
    qualification.update(video_sha256=digest(files[f'{PREFIX}/full-play.mp4']),
        render_only='Original archived poses; dark background; machine at the actual field midpoint; fixed uninterrupted camera')
    files[f'{PREFIX}/qualification.json'] = (json.dumps(qualification, indent=2)+'\n').encode()
    for name in ('manifest.json', 'framing-audit.json'):
        add(RENDER/name, f'presentation/{name}')
    for route in ('go','out','slant','native-baseline','native-learned'):
        for name in ('presentation.json','video-verification.json','contact-sheet.jpg'):
            add(RENDER/route/name, f'presentation/{route}/{name}')
    add(ROOT/'src/g1_receiver/stadium.py', 'presentation/stadium.py')
    for name in ('render_aero_stadium.py','encode_receiver_replay.py','verify_field_replay.py'):
        add(ROOT/'scripts'/name, f'presentation/{name}')
    files['presentation/render.py'] = b'''"""Load the renderer overlay without changing frozen controller modules."""
from pathlib import Path
import importlib.util, runpy, sys
here=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('g1_receiver.stadium',here/'stadium.py')
module=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=module
spec.loader.exec_module(module)
runpy.run_path(str(here/'render_aero_stadium.py'),run_name='__main__')
'''
    commands = []
    for row in json.loads((RENDER/'manifest.json').read_text())['replays']:
        route = row['route']
        trial = ROUTES[route]['expected'] if route in ROUTES else f'{PREFIX}/evidence/'+('baseline' if route=='native-baseline' else 'learned-cpu')+'/trial'
        original = row['render_command']
        command = ['presentation/render.py', '--source', 'aero-source', '--input', trial+'/view.npz',
            '--report', trial+'/report.json', '--output', 'FRESH_OUTPUT/'+route+'/full-play.npz']
        command += original[original.index('--quarterback'):]
        commands.append(dict(route=route, arguments=command))
    files['presentation/commands.json'] = (json.dumps(commands, indent=2)+'\n').encode()
    files['presentation/README.md'] = b'''# Midfield presentation

Only the spectator field and camera changed. The measured passing-machine
origin is now the field's 50-yard midpoint; robot and football poses remain
byte-for-byte identical to the archived physics. All five plays use a fixed,
uninterrupted camera. The main Go/Out/Slant MP4 contains762 untouched decoded
frames at25fps (30.48s), with cuts only between full plays.

The original controller source stays frozen. render.py loads only stadium.py
as an explicit rendering overlay. From this ZIP's root, use PYTHONPATH=src
and the project's mjpython on macOS (python with MUJOCO_GL=egl on Linux),
followed by an argument list in commands.json. Replace FRESH_OUTPUT with a
new destination. Encode each full-play.npz using encode_receiver_replay.py.
Rendering never executes a controller or changes its physics trace. Pixel
identity across platforms is not promised; pose/time identity is required.

framing-audit.json checks conservative actor/machine bounding spheres against
the fixed camera frustum. It is not an occlusion proof. Contact sheets were
also inspected. The primary possession/impact/form qualifications still apply.
'''
    files['README.md'] += b'\n## Midfield presentation update\n\nThe field now places the machine at the 50-yard midpoint. The complete videos\nuse fixed cameras and unchanged archived poses. See presentation/README.md.\nAll original simulation controller sources and physical evidence remain intact.\n'
    for name in ('gain-finegrid-summary.json','component-ablation-summary.json','component-ablation-interpretation.json','ccd-sensitivity-summary.json'):
        add(NATIVE/name, f'{PREFIX}/diagnostics/{name}')
    add(ROOT/'src/g1_receiver/collision_fingerprint.py', f'{PREFIX}/diagnostics/collision_fingerprint.py')
    files[f'{PREFIX}/diagnostics/README.md'] = b'''# Additional diagnostics

These post-hoc evaluations do not change the selected checkpoint or claims.
Nominal retention persists across gains0.4--0.6, while lateral trials fail.
At gain0.5, arms-only/native-only/combined nominal CUDA holds are2.026/0.907/
3.178s, against zero1.457s. Component interactions differ across perturbations.
Every variant still fails the10mm impact guard.

The original v1 physics fingerprint omits CCD algorithm flags/tolerance/
iterations. The optional helper includes them without changing old scores.
Default flags0/0,35iterations and1e-6tolerance reproduce selected traces.
Whole-episode legacy MPR sensitivity worsens both baseline and learned holds;
it is not adopted and correctly fails the extended default-reference gate.
No alternative collision algorithm establishes realistic catch quality.
'''
    # Only presentation artifacts may change relative to the audited r2 base.
    allowed = {'README.md','concat-manifest.json',*(f'videos/{r}-held.mp4' for r in ('go','out','slant')),
        'videos/full-play.mp4',*(f'{PREFIX}/{n}' for n in ('full-play.mp4','contact-sheet.jpg','video-verification.json','qualification.json'))}
    changed = [n for n,h in old.items() if digest(files[n]) != h]
    assert set(changed) <= allowed, changed
    manifest = {n:digest(data) for n,data in sorted(files.items())}
    files['MANIFEST.json'] = (json.dumps(manifest, indent=2, sort_keys=True)+'\n').encode()
    target = out/'project.zip'
    zip_bytes(target, files)
    with ZipFile(target) as z:
        assert z.testzip() is None
        assert all(digest(z.read(n)) == h for n,h in manifest.items())
    shutil.copyfile(RENDER/'native-learned/full-play.mp4', out/'native-lower-study.mp4')
    (out/'caption.txt').write_bytes(files['caption.txt'])
    (out/'native-lower-study-notes.txt').write_bytes(files[f'{PREFIX}/README.md'])
    total = target.stat().st_size+video.stat().st_size
    assert total < 100_000_000
    receipt = dict(base_sha256=BASE_SHA, project_sha256=digest(target.read_bytes()), project_bytes=target.stat().st_size,
        primary_video_sha256=digest(video.read_bytes()), combined_bytes=total, changed_r2_members=changed,
        all_controller_and_physical_evidence_members_unchanged=True, pose_and_timestamp_identity_verified=True,
        full_decoded_concat_order_verified=True, all_member_hashes_and_crc_verified=True,
        no_new_physical_quality_pass=True, arena_submitted=False)
    (out/'package-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
