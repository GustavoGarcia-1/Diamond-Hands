"""Protected baseline and three preload activation sources, no machine clock input."""
from pathlib import Path
from copy import deepcopy
from concurrent.futures import ProcessPoolExecutor,as_completed
import argparse,json,multiprocessing as mp
import probe_lower_cup_native_observed as observed
import probe_lower_cup_native_witness as protected
from run_native_cup_grip_screen import exact
REFERENCE='173bf57168f5f97d0471d7bfa0a05e067a00f1e27a385994f57f21998a30af15'

def run(job):
 root,donor,source,amp,name=job;p=deepcopy(donor);p['native_grip']['preload_source']=name;path=root/(name+'-profile.json');path.write_text(json.dumps(p,indent=2)+'\n');args=observed.build_parser().parse_args(['--source',str(source),'--amp-source',str(amp),'--profile',str(path),'--output',str(root/name),'--walk-speed','1','--handoff-depth','1.3','--initial-yaw','-.7','--duration','8','--record-anatomical','--reference-physics-sha256',REFERENCE]);r=observed.run(args);return dict(source=name,anatomical=r['anatomical_score'],geometry=r['interhand_geometry_audit'],host_gains_sha256=r['host_gains_sha256'])
def main():
 p=argparse.ArgumentParser()
 for n in ['source','amp-source','profile','output','reference']:p.add_argument('--'+n,type=Path,required=True)
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);donor=json.loads(a.profile.read_text());args=protected.build_parser().parse_args(['--source',str(a.source),'--amp-source',str(a.amp_source),'--profile',str(a.profile),'--output',str(a.output/'protected'),'--walk-speed','1','--handoff-depth','1.3','--initial-yaw','-.7','--duration','8','--record-anatomical','--reference-physics-sha256',REFERENCE]);protected.run(args);m=exact(a.reference,a.output/'protected');(a.output/'preflight.json').write_text(json.dumps(m,indent=2)+'\n');rows=[]
 with ProcessPoolExecutor(max_workers=2,mp_context=mp.get_context('spawn'))as pool:
  for f in as_completed([pool.submit(run,(a.output,donor,a.source,a.amp_source,n))for n in ['rgbd_flight','visual_ready','route_ready']]):rows.append(f.result());(a.output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
if __name__=='__main__':main()
