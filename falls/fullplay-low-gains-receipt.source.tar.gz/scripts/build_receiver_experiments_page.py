"""Export reviewed development measurements without changing their scores."""
from pathlib import Path
import hashlib
import json
import shutil
import tarfile

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'reports/catch-repair-20261114'
OUT = ROOT / 'site/dist/experiments'


def read(path):
    return json.loads(path.read_text())


def main():
    OUT.mkdir(exist_ok=True)
    go = read(BASE / 'validation/go-side-cup-independent.json')
    rows = []
    for r in go['rows']:
        s = r['score']
        rows.append(dict(case=r['case'], control_s=s['longest_clean_bilateral_s'],
                         endpoint=s['final_bilateral_fraction'],
                         final_hold=s['physics_checks']['final_anatomical_hand_hold'],
                         excluded_s=s['first_excluded_support_s'],
                         overlap_mm=-1000*s['minimum_ball_contact_distance_m'],
                         form=s['form']['pass'], reference_model=s['physics_reference_match'],
                         peak_force=r['peak_force'], source=r['source'],
                         report_sha256=r['report_sha256']))
    stress = {}
    for policy in ('zero', 'model'):
        for r in read(BASE / f'sensor-realism/{policy}-linux/artifacts/study/summary.json'):
            s = r['physical_evaluation_only']['anatomical_score']
            stress.setdefault(r['case'], {})[policy] = dict(
                control_ms=1000*s['longest_clean_bilateral_s'],
                endpoint=s['final_bilateral_fraction'], overlap_mm=-1000*s['minimum_ball_contact_distance_m'],
                reward=r['sensor_evaluation']['returned_reward'],
                coverage=r['sensor_evaluation']['sensor_coverage'])
    receipt = read(BASE / 'late-reach-training/r2-linux/artifacts/study/ppo/receipt.json')
    data = dict(go=rows, throw_offsets=read(BASE/'go-side-cup/fixedplane-summary.json'),
                timesteps=read(BASE/'go-side-cup/timestep-summary.json'),
                latency=read(BASE/'go-side-cup/camera-latency-summary.json'),
                out_stress=stress, training=receipt,
                limitations=go['limitations'])
    (OUT/'results.json').write_text(json.dumps(data, indent=2)+'\n')
    files = {
        'go-independent-audit.json': BASE/'validation/go-side-cup-independent.json',
        'go-reproduction.md': BASE/'go-side-cup/README.md',
        'go-profile.json': BASE/'go-side-cup/confirmed-thumb30-profile.json',
        'go-source.tar.gz': BASE/'go-side-cup/causal-source-linux/artifacts/source-freeze/frozen-source.tar.gz',
        'go-source-manifest.json': BASE/'go-side-cup/causal-source-linux/artifacts/source-freeze/manifest.json',
        'go-compact.json': BASE/'go-side-cup/causal-source-linux/artifacts/source-freeze/compact.json',
        'go-cup.json': BASE/'go-side-cup/causal-source-linux/artifacts/source-freeze/cup.json',
        'sensor-protocol.json': BASE/'sensor-realism/protocol-v1.json',
        'sensor-zero-results.json': BASE/'sensor-realism/zero-linux/artifacts/study/summary.json',
        'sensor-model-results.json': BASE/'sensor-realism/model-linux/artifacts/study/summary.json',
        'out-training-receipt.json': BASE/'late-reach-training/r2-linux/artifacts/study/ppo/receipt.json',
        'out-model.zip': BASE/'late-reach-training/r2-linux/artifacts/study/ppo/final.zip',
        'out-runtime.tar.gz': BASE/'sensor-realism/model-linux/artifacts/study/runtime-source.tar.gz',
        'out-runtime-hashes.json': BASE/'sensor-realism/model-linux/artifacts/study/runtime-hashes.json',
        'sensor-paired-audit.json': BASE/'validation/sensor-stress-paired/audit.json',
        'go-media-verification.json': BASE/'go-side-cup/full-play-11s/media-verification.json',
    }
    manifest = {}
    for name, path in files.items():
        shutil.copyfile(path, OUT/name)
        manifest[name] = dict(source=str(path.relative_to(ROOT)),
                              sha256=hashlib.sha256(path.read_bytes()).hexdigest(), bytes=path.stat().st_size)
    evidence = []
    for r in go['rows']:
        base = ROOT/r['source']
        for name in ('report.json', 'anatomical-contact.npz', 'anatomical-form.json',
                     'anatomical-metadata.json', 'trace.npz', 'view.npz'):
            evidence.append((base/'trial'/name, f"{r['case']}/trial/{name}"))
        for name in ('controller-receipt.json', 'scene.xml', 'ball-contact-witness.npz'):
            evidence.append((base/name, f"{r['case']}/{name}"))
    for name in ('causal-pass-receipt.json', 'thumb-timing-receipt.json',
                 'causal-confirm-receipt.json', 'confirmation-comparison.json',
                 'fixedplane-receipt.json', 'fixedplane-summary.json',
                 'timestep-summary.json', 'camera-latency-summary.json'):
        evidence.append((BASE/'go-side-cup'/name, name))
    # Reports + sampled poses and contact traces support independent scoring.
    # The large full-rate state archive is a separate, explicitly named download.
    archive = OUT/'go-evidence.tar.gz'
    with tarfile.open(archive, 'w:gz') as tar:
        for path, name in evidence:
            tar.add(path, arcname=name)
    manifest[archive.name] = dict(sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), bytes=archive.stat().st_size,
                                 files={name: hashlib.sha256(path.read_bytes()).hexdigest() for path, name in evidence})
    path = BASE/'go-side-cup/causal-confirm-linux/artifacts/study/confirm-11s/actual-state.npz'
    shutil.copyfile(path, OUT/'go-11s-actual-state.npz')
    manifest['go-11s-actual-state.npz'] = dict(source=str(path.relative_to(ROOT)),
        sha256=hashlib.sha256(path.read_bytes()).hexdigest(), bytes=path.stat().st_size)
    supplement = BASE/'reproduction'
    archive = OUT/'reproduction-supplement.tar.gz'
    with tarfile.open(archive, 'w:gz') as tar:
        for path in sorted(supplement.iterdir()):
            if path.is_file():
                tar.add(path, arcname=path.name)
    shutil.copyfile(supplement/'README.md', OUT/'reproduction-notes.md')
    for path in (archive, OUT/'reproduction-notes.md'):
        manifest[path.name] = dict(sha256=hashlib.sha256(path.read_bytes()).hexdigest(), bytes=path.stat().st_size)
    (OUT/'downloads.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print(json.dumps(dict(cases=len(rows), sensor_pairs=len(stress), downloads=len(files))))


if __name__ == '__main__':
    main()
