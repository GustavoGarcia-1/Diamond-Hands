"""Historical natural missed-possession Go: matched full-play IMU landing study."""
import argparse,json,hashlib,types,sys
from dataclasses import replace
from pathlib import Path
import numpy as np,mujoco
from g1_receiver.fall_supervisor import FallSupervisor,FallConfig
from g1_receiver.runtime import RobotObservation,SkillGoal
from g1_receiver.running_policy import AmpRunningPolicy
from g1_receiver.pass_control import PassGrip
from g1_receiver.routes import Route
import evaluate_aero_receiver as old
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--amp-source',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--low-gains',action='store_true');a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
# Separate evaluation driver copy: permit observation after fall, never falsify IMU to controller.
source=Path(old.__file__).read_text();needle='1. - 2. * (imu_x ** 2 + imu_y ** 2) < .54';assert source.count(needle)==1;source=source.replace(needle,'1. - 2. * (imu_x ** 2 + imu_y ** 2) < -2.');runner=types.ModuleType('receiver_fall_full_duration');runner.__file__=str(Path(old.__file__));sys.modules[runner.__name__]=runner;exec(compile(source,old.__file__,'exec'),runner.__dict__)
reference=json.loads(a.reference.read_text());settings=dict(reference['play']);settings['grip']=PassGrip(**settings['grip']);settings['finish_s']=12.;play=runner.Play(**settings);route=Route(play.route,tuple(map(tuple,reference['waypoints_m'])),play.speed);cameras={}
for name,arg in [('pass','pass_camera'),('track','tracking_camera'),('finish','finish_camera')]:
 s=reference['camera_surveys'][name];pos=np.array(s['position_m']);cameras[arg]=(pos,pos+np.array(s['rotation'])[:,2])
summary=[]
for mode,stiffness in ([('crouch_tuck',.5),('crouch_tuck',.25)]if a.low_gains else [('baseline',1.),('balance_abort',1.),('crouch_tuck',1.)]):
 label=mode if stiffness==1. else mode+'-kp'+str(stiffness)
 plant=runner.make_plant(a.source,route,**cameras);original=plant.step;forces=[];actual=[];motion=[];commandlog=[];supervisor=None;floor=plant.model.geom('floor').id;ball=plant.model.geom('football_surface').id;group={};foot={}
 for i in range(plant.model.ngeom):
  if i==ball or plant.model.geom_bodyid[i]==0:continue
  body=plant.model.body(int(plant.model.geom_bodyid[i])).name;mesh=plant.model.mesh(int(plant.model.geom_dataid[i])).name if plant.model.geom_type[i]==mujoco.mjtGeom.mjGEOM_MESH else'';group[i]='head'if'head'in mesh else'hand'if body.startswith('aero_')else'torso'if body=='torso_link'else'other';foot[i]=body.endswith('ankle_roll_link')
 def step(command,*,closure=0.,post_step=None,hand_target_rad=None):
  global supervisor
  obs=RobotObservation(plant.timestamp_s,*plant.observe(),np.zeros(29),None)
  if mode!='baseline':
   if supervisor is None:supervisor=FallSupervisor(plant.joint_names,plant.joint_ranges,command.target_position,FallConfig(mode=mode,severe_upright_cos=.84 if mode=='crouch_tuck'else .95,warning_upright_cos=.96 if mode=='crouch_tuck'else .985,warning_gyro_rad_s=1.8 if mode=='crouch_tuck'else .35))
   triggered=supervisor.observe(obs)
   if triggered and mode=='balance_abort':command=plant.wbc.act(obs,SkillGoal(base_velocity=np.zeros(3),base_height=.74),upper_target=command.target_position)
   command=supervisor.apply(obs,command)
   if supervisor.triggered_at is not None and stiffness<1:
    phase=float(np.clip((obs.timestamp-supervisor.triggered_at)/.15,0,1));blend=phase*phase*(3-2*phase);command=replace(command,kp=command.kp*(1-(1-stiffness)*blend))
  commandlog.append(np.r_[obs.timestamp,command.target_position,command.kp,command.kd])
  def audit(data):
   if post_step:post_step(data)
   f=np.zeros(4);nf=0.;work=np.zeros(6)
   for j,c in enumerate(data.contact):
    x,y=map(int,c.geom);g=y if x==floor else x if y==floor else-1
    if g not in group:continue
    mujoco.mj_contactForce(plant.model,data,j,work);f[['head','hand','torso','other'].index(group[g])]+=max(0.,work[0]);nf+=0 if foot[g]else max(0.,work[0])
   forces.append(np.r_[data.time,f,nf]);actual.append(np.r_[data.time,data.ctrl[plant.body_actuators]]);b=data.qpos[plant.base:plant.base+7];motion.append(np.r_[data.time,b[:3],1-2*(b[4]**2+b[5]**2),data.qvel[plant.base:plant.base+6]])
  return original(command,closure=closure,post_step=audit,hand_target_rad=hand_target_rad)
 plant.step=step
 try:r=runner.run_play(plant,AmpRunningPolicy(plant.joint_names,plant.joint_ranges,a.amp_source),play,route,output=a.output/label,record_poses=True)
 finally:plant.close()
 f=np.array(forces);m=np.array(motion);u=np.array(actual);tail=m[m[:,0]>=10];standing=bool(len(tail)>1000 and((tail[:,3]>.65)&(tail[:,4]>.9)&(np.linalg.norm(tail[:,5:7],axis=1)<.15)&(np.linalg.norm(tail[:,8:11],axis=1)<.35)).all());metrics={name:dict(peak_sum_normal_n=float(f[:,i+1].max()),first_contact_s=float(f[np.flatnonzero(f[:,i+1]>.1)[0],0])if(f[:,i+1]>.1).any()else None)for i,name in enumerate(['head','hand','torso','other'])};d=dict(mode=mode,label=label,fall_body_stiffness_fraction=stiffness,fall_gain_transition_s=.15,damping_retained=True,native_hand_gains_unchanged=True,trigger_s=None if supervisor is None else supervisor.triggered_at,duration_s=float(m[-1,0]),stable_standing_final2s=standing,impacts=metrics,actual_torque_caps_respected=bool(np.all(u[:,1:]>=plant._effort_min-1e-9)and np.all(u[:,1:]<=plant._effort_max+1e-9)),warning_count=sum(int(w.number)for w in plant.data.warning),evaluation_stop_removed_only=True,no_midplay_pose_overwrite=True,actual_machine_split_m=3.45,historical_route_not_qualified=True)
 np.savez_compressed(a.output/label/'landing-audit.npz',floor_forces=f,motion=m,actual_body_control=u,command_target_kp_kd=np.array(commandlog));(a.output/label/'landing-report.json').write_text(json.dumps(d,indent=2)+'\n');summary.append(d);(a.output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(mode,flush=True)
