"""Offline commanded ellipsoid sweep against recorded robot poses, never actor input."""
import argparse,json
from pathlib import Path
import mujoco,numpy as np
from g1_receiver.aero import make_aero_scene
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
from g1_receiver.scrimmage_throw import ScrimmagePass
from g1_receiver.anatomical_catch_eval import AnatomicalContactAudit
from run_flat_cup_support_vector import seed

def main():
 p=argparse.ArgumentParser()
 for name in ['source','trial','profile','calibration','output']:p.add_argument('--'+name,type=Path,required=True)
 p.add_argument('--primary-hand',choices=['left','right']);p.add_argument('--arrival',type=float);p.add_argument('--projected',action='store_true');p.add_argument('--flights',type=float,nargs='+',default=[.5,.65,.8,1.,1.2,1.4,1.6]);a=p.parse_args();
 global seed
 if a.projected:
  from g1_receiver.offline_cup_fixture import projected_cup_seed as seed
 if a.primary_hand:
  from g1_receiver.offline_cup_fixture import one_palm_seed
  seed=lambda profile,flight,calibration:one_palm_seed(profile,flight,calibration,a.primary_hand)
 profile=json.loads(a.profile.read_text());arrival=a.arrival if a.arrival is not None else float(profile.get('offline_fixture_arrival_s',5.2));cal=json.loads(a.calibration.read_text());v=np.load(a.trial/'offline-robot-qpos.npz');m=mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT,a.source));d=mujoco.MjData(m);audit=AnatomicalContactAudit(m);ball=int(m.geom('football_surface').id);ba=int(m.joint('football_free').qposadr[0]);bodies=np.array([i for i in range(m.ngeom)if m.geom_bodyid[i]>0 and i!=ball and(m.geom_contype[i]or m.geom_conaffinity[i])and audit.kind[i]not in ['finger','thumb','palmar_candidate']],int);rows=[]
 for T in a.flights:
  point,n,description=seed(profile,T,cal)
  for depth in [-.01,0.,.01]:
   target=point+depth*n;plan=ScrimmagePass(tuple(profile['play']['quarterback_origin_m']),tuple(target),T,horizontal_distance_only=True).plan(arrival-T);minimum=(.05,None,None);first=None
   for now,q in zip(v['timestamps_s'],v['qpos']):
    if now<arrival-T or now>arrival+1e-8:continue
    dt=now-plan.release_time_s;center=np.array(plan.release_xyz_m)+dt*np.array(plan.release_velocity_mps)+np.array([0,0,-4.905*dt*dt]);d.qpos[:]=q;d.qpos[ba:ba+7]=np.r_[center,plan.release_quaternion_wxyz];mujoco.mj_kinematics(m,d)
    lower=np.linalg.norm(d.geom_xpos[bodies]-center,axis=1)-m.geom_rbound[bodies]-m.geom_rbound[ball]
    for g in bodies[lower<min(.05,minimum[0])]:
     distance=float(mujoco.mj_geomDistance(m,d,ball,int(g),.5,None))
     if distance<minimum[0]:minimum=(distance,float(now),int(g))
     if distance<0 and first is None:first=dict(time_s=float(now),geom=m.geom(int(g)).name,body=m.body(int(m.geom_bodyid[g])).name)
   gap,t,g=minimum;rows.append(dict(flight_s=T,normal_depth_m=depth,target_m=target.tolist(),minimum_excluded_body_gap_through_arrival_m=gap,minimum_time_s=t,minimum_geom=None if g is None else m.geom(g).name,minimum_body=None if g is None else m.body(int(m.geom_bodyid[g])).name,first_predicted_overlap=first,predeclared_positive10mm_body_clearance=gap>=.01))
 result=dict(offline_planning_only=True,body_sweep_until_s=arrival,positive_distances_capped_at_m=.05,not_physics_or_catch_score=True,robot_source=str(a.trial),robot_pose_rate_hz=1000,ball_command_model='free ellipsoid ballistic, unchanged launch quaternion',excludes_anatomical_fingers_thumbs_and_palmar_candidates_from_body_obstruction=True,rows=rows);a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(rows,indent=2))
if __name__=='__main__':main()
