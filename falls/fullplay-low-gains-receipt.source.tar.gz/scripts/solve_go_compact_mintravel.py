"""Compact elbows-bent ready posture minimizing travel to the side cup, without fixing palm orientation."""
from pathlib import Path
import json
import mujoco,numpy as np
from scipy.optimize import least_squares
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
P=Path('reports/catch-repair-20261114');O=P/'go-side-cup';cup=json.load(open(O/'refined-balanced-candidate.json'));x=(P/'contact-model/study-linux/artifacts/study/original20-gain0.5/scene.xml').read_text().replace('/workspace/g1-receiver-runs/catch-repair-contact-model-20261114-r1/source/src/g1_receiver/_vendor/g1_runtime',str(DEFAULT_RUNTIME_ROOT)).replace('/workspace/g1-receiver-runs/out-scrimmage-20261113/source/aero-source','/tmp/g1-aero-source');m=mujoco.MjModel.from_xml_string(x);d=mujoco.MjData(m);a=np.load(P/'validation/protected-witness-linux/witness/offline-robot-qpos.npz');base=a['qpos'][np.argmin(abs(a['timestamps_s']-5.18))].copy();base[int(m.joint('waist_yaw_joint').qposadr[0])]=cup['waist_yaw_rad'];ids=np.array([m.joint(n).id for n in cup['arm_order']]);ad=m.jnt_qposadr[ids];qcup=np.array(cup['arm_targets_rad']);lo=m.jnt_range[ids,0]+.08;hi=m.jnt_range[ids,1]-.08;pads=[m.geom('aero_'+s+'_palm_collision_7').id for s in['left','right']];torso=[g for g in range(m.ngeom)if m.body(int(m.geom_bodyid[g])).name=='torso_link'and(m.geom_contype[g]or m.geom_conaffinity[g])];native=[g for g in range(m.ngeom)if m.body(int(m.geom_bodyid[g])).name in['aero_left_palm','aero_right_palm']and(m.geom_contype[g]or m.geom_conaffinity[g])];pairs=[(g,t)for g in native for t in torso]+[(58,163),(58,165),(54,42),(161,42)];start=qcup.copy();start[[3,10]]+=.5;start=np.clip(start,lo+1e-5,hi-1e-5)
def obj(q):
 d.qpos[:]=base;d.qpos[ad]=q;mujoco.mj_kinematics(m,d);pelvis=d.xpos[m.body('pelvis').id];v=[]
 for g in pads:
  F=d.geom_xmat[g].reshape(3,3);p=d.geom_xpos[g]+m.geom_size[g,0]*F[:,0]-pelvis;v.extend([150*max(0,p[2]-.28),150*max(0,.15-p[2]),100*max(0,p[0]-.33),100*max(0,.16-p[0]),150*max(0,-.32-p[1]),150*max(0,p[1]-.12)])
 for index in[3,10]:v.append(12*max(0,.9-q[index]))
 for g,h in pairs:v.append(300*max(0,.012-mujoco.mj_geomDistance(m,d,g,h,.03,None)))
 delta=q-qcup;v.extend(delta);v.extend(1.8*delta**2);return v
fit=least_squares(obj,start,bounds=(lo,hi),max_nfev=160);obj(fit.x);pelvis=d.xpos[m.body('pelvis').id].copy();faces=[]
for g in pads:
 F=d.geom_xmat[g].reshape(3,3);faces.append((d.geom_xpos[g]+m.geom_size[g,0]*F[:,0]-pelvis).tolist())
delta=qcup-fit.x;report=dict(offline_only=True,no_dynamic_claim=True,arm_order=cup['arm_order'],arm_targets_rad=fit.x.tolist(),cup_arm_targets_rad=qcup.tolist(),faces_relative_pelvis_world_m=faces,elbows_rad=fit.x[[3,10]].tolist(),maximum_joint_travel_rad=float(max(abs(delta))),quintic_min_duration_for_peak3_rad_s=float(1.875*max(abs(delta))/3),minimum_joint_margin_rad=float(np.min(np.minimum(fit.x-m.jnt_range[ids,0],m.jnt_range[ids,1]-fit.x))),clearance_pairs=[dict(g=g,h=h,distance_m=float(mujoco.mj_geomDistance(m,d,g,h,.05,None)))for g,h in pairs]);(O/'compact-mintravel.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k]for k in['faces_relative_pelvis_world_m','elbows_rad','maximum_joint_travel_rad','quintic_min_duration_for_peak3_rad_s','minimum_joint_margin_rad']},indent=2))
