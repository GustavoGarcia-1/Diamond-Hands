"""Offline actual recorded-cup velocity versus declared ballistic arrival."""
import argparse,json
from pathlib import Path
import mujoco,numpy as np
from g1_receiver.aero import make_aero_scene
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
from g1_receiver.scrimmage_throw import ScrimmagePass
from run_flat_cup_support_vector import seed

def main():
 p=argparse.ArgumentParser()
 for n in ['source','trial','profile','calibration','output']:p.add_argument('--'+n,type=Path,required=True)
 p.add_argument('--primary-hand',choices=['left','right']);p.add_argument('--arrival',type=float);p.add_argument('--projected',action='store_true');p.add_argument('--flights',type=float,nargs='+',default=[.4,.5,.6,.65,.7,.75,.8,.85,.9,1.,1.2,1.4,1.6]);a=p.parse_args();
 global seed
 if a.projected:
  from g1_receiver.offline_cup_fixture import projected_cup_seed as seed
 if a.primary_hand:
  from g1_receiver.offline_cup_fixture import one_palm_seed
  seed=lambda profile,flight,calibration:one_palm_seed(profile,flight,calibration,a.primary_hand)
 cal=json.loads(a.calibration.read_text());profile=json.loads(a.profile.read_text());arrival=a.arrival if a.arrival is not None else float(profile.get('offline_fixture_arrival_s',5.2));v=np.load(a.trial/'offline-robot-qpos.npz');m=mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT,a.source));d=mujoco.MjData(m);coords=[]
 for t,q in zip(v['timestamps_s'],v['qpos']):
  if not arrival-.06<=t<=arrival+1e-8:continue
  d.qpos[:]=q;mujoco.mj_kinematics(m,d);points=[]
  for side,sign in [('left',1),('right',-1)]:
   b=d.body('aero_'+side+'_palm');R=b.xmat.reshape(3,3)
   if cal.get('calibration_kind')=='native_palm_box7_front_facet':
    g=int(m.geom('aero_'+side+'_palm_collision_7').id);G=d.geom_xmat[g].reshape(3,3);points.append(d.geom_xpos[g]+m.geom_size[g,0]*G[:,0])
   else:points.append(b.xpos+R@np.array([-.0025,sign*.017,.07225]))
  coords.append((t,*np.asarray(points).ravel()))
 history=np.array(coords);t=history[:,0]-history[:,0].mean();per_hand_vel=(t@history[:,1:]/(t@t)).reshape(2,3);vel=per_hand_vel.mean(0);profile=json.loads(a.profile.read_text());cal=json.loads(a.calibration.read_text());rows=[]
 for T in a.flights:
  point,N,description=seed(profile,T,cal);plan=ScrimmagePass(tuple(profile['play']['quarterback_origin_m']),tuple(point),T,horizontal_distance_only=True).plan(arrival-T);hand_normals=np.array([h['normal_world']for h in min(cal['poses'],key=lambda r:abs(r['time_s']-arrival))['hands']]);per_hand_vn=np.einsum('ij,ij->i',np.array(plan.intercept_velocity_mps)-per_hand_vel,hand_normals);rows.append(dict(per_hand_normal_arrival_mps=per_hand_vn.tolist(),flight_s=T,target_m=point.tolist(),mean_normal_world=N.tolist(),relative_arrival_normal_mps=float((np.array(plan.intercept_velocity_mps)-vel)@N)))
 result=dict(offline_only=True,actual_per_hand_velocity_ols_mps=per_hand_vel.tolist(),actual_cup_velocity_ols_mps=vel.tolist(),velocity_window_s=[arrival-.06,arrival],source=str(a.trial),rows=rows);a.output.write_text(json.dumps(result,indent=2)+'\n');print([(r['flight_s'],round(r['relative_arrival_normal_mps'],3))for r in rows])
if __name__=='__main__':main()
