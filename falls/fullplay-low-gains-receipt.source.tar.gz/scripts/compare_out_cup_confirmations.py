"""Exact physics-array confirmation and duration-prefix comparison."""
import argparse,json
from pathlib import Path
import numpy as np

def main():
 p=argparse.ArgumentParser();p.add_argument('--baseline',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True);p.add_argument('--prefix',action='store_true');p.add_argument('--output',type=Path,required=True);a=p.parse_args();rows=[]
 for f in sorted(a.baseline.glob('*.npz')):
  x=np.load(f);y=np.load(a.candidate/f.name);assert set(x.files)==set(y.files)
  for k in x.files:
   u=x[k];v=y[k]
   if a.prefix and u.ndim and v.shape[0]>=u.shape[0]:v=v[:u.shape[0]]
   same=u.shape==v.shape and np.array_equal(u,v,equal_nan=True)if u.dtype.kind in 'fc'else u.shape==v.shape and np.array_equal(u,v)
   rows.append(dict(file=f.name,array=k,exact=bool(same)))
 result=dict(mode='duration prefix'if a.prefix else'exact full arrays',all_exact=all(x['exact']for x in rows),arrays=rows);a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'all_exact':result['all_exact'],'arrays':len(rows),'failures':[x for x in rows if not x['exact']]}));assert result['all_exact']
if __name__=='__main__':main()
