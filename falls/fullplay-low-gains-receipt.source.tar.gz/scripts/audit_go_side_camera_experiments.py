"""Passive physical equality, actual arm velocity and commanded-effort comparison."""
from pathlib import Path
import argparse,json,re
import numpy as np,mujoco
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
p=argparse.ArgumentParser();p.add_argument('--prefix',default='camera-latency');a=p.parse_args();P=Path('reports/catch-repair-20261114/go-side-cup');rows=[];ref=P/'thumb-timing-linux/artifacts/study/experimental2p5-thumb30';arm_names=json.load(open(P/'upperarm-x35-y20.json'))['arm_order']
for r in sorted((P/(a.prefix+'-linux')/'artifacts/study').glob('latency-*')):
 if not r.is_dir():continue
 meta=json.load(open(r/'controller-receipt.json'));xml=re.sub(r'/workspace/g1-receiver-runs/[^" ]+/source/src/g1_receiver/_vendor/g1_runtime',str(DEFAULT_RUNTIME_ROOT),(r/'scene.xml').read_text()).replace('/workspace/g1-receiver-runs/out-scrimmage-20261113/source/aero-source','/tmp/g1-aero-source');m=mujoco.MjModel.from_xml_string(xml);addresses=[int(m.jnt_dofadr[m.joint(n).id])for n in arm_names];x=np.load(r/'actual-state.npz');v=x['time_qvel'];cue=meta['actual_cue_s'];duration=meta.get('actual_sensor_adaptive_reach_duration_s',meta['reach_duration_s']);windows={}
 for name,start,end in [('pre_reach',cue-.3,cue),('reach',cue,cue+duration),('final200ms_before_nominal_arrival_including_impact',5.,5.2),('last200ms_before_actual_first_contact',5.198-.2,5.198-.001)]:
  sample=v[(v[:,0]>=start)&(v[:,0]<=end),1:][:,addresses];windows[name]=dict(max_abs_arm_joint_velocity_rad_s=float(abs(sample).max()),rms_arm_joint_velocity_rad_s=float(np.sqrt(np.mean(sample**2))))
 controls=x['time_control'];exact={}
 for name in ['actual-state.npz','ball-contact-witness.npz','trial/trace.npz','trial/view.npz','trial/anatomical-contact.npz']:
  old=np.load(ref/name);new=np.load(r/name);exact[name]=all(np.array_equal(old[k],new[k],equal_nan=True)if old[k].dtype.kind not in 'US'else np.array_equal(old[k],new[k])for k in old.files)
 rows.append(dict(case=r.name,actual_sensor_cue_s=cue,actual_reach_duration_s=duration,velocity=windows,actual_max_abs_first29_body_control_nm=abs(controls[:,1:30]).max(axis=0).tolist(),exact_vs_selected_nominal=exact))
(P/(a.prefix+'-physical-diagnostics.json')).write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
