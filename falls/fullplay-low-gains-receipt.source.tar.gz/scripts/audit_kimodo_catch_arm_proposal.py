"""Offline native-G1 CSV arm proposal audit. Never steps physics or controls a robot."""
import argparse,json,hashlib
from pathlib import Path
from types import SimpleNamespace
import mujoco,numpy as np
from g1_receiver.aero import make_aero_scene
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
from g1_receiver._vendor.g1_runtime.pool.wbc import BODY_NAMES
from g1_receiver.catch_form import CatchFormEvaluator,CatchFormContext
from g1_receiver.observable import ARM_JOINTS

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for n in ['csv','source','criteria','output']:p.add_argument('--'+n,type=Path,required=True)
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);criteria=json.loads(a.criteria.read_text());mapping=json.loads(Path('reports/motion-compatibility-20261113/kimodo-pilot/body-mapping.json').read_text());assert mapping['names_bijective'];assert all(max(r[k]for r in mapping['rows'])<1e-12 for k in ['axis_error','zero_ref_error_rad','parent_frame_quaternion_error','parent_frame_translation_error_m'])
 frames=np.loadtxt(a.csv,delimiter=',');assert frames.shape==(150,36)and np.isfinite(frames).all();model=mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT,a.source));data=mujoco.MjData(model);form=CatchFormEvaluator(model,tuple(BODY_NAMES));enc=np.array([model.joint(n).qposadr[0]for n in BODY_NAMES]);limits=np.array([model.joint(n).range.copy()for n in BODY_NAMES]);arm=np.array([list(BODY_NAMES).index(n)for n in ARM_JOINTS]);base=int(model.joint('floating_base_joint').qposadr[0]);palms=[model.body('aero_'+s+'_palm').id for s in ['left','right']];elbows=[model.body(s+'_elbow_link').id for s in ['left','right']];wrists=[model.body(s+'_wrist_yaw_link').id for s in ['left','right']];hands=[[g for g in range(model.ngeom)if(model.geom_contype[g]or model.geom_conaffinity[g])and(model.body(int(model.geom_bodyid[g])).name or'').startswith('aero_'+s+'_')]for s in ['left','right']];nearest=np.empty(6)
 qnative=np.empty((150,29))
 for r in mapping['rows']:qnative[:,list(BODY_NAMES).index(r['name'])]=frames[:,r['csv_column']]
 violation=np.maximum(limits[:,0]-qnative,0)+np.maximum(qnative-limits[:,1],0);rows=[]
 for i,qraw in enumerate(qnative):
  for mode in ['native-full-body-reference','arm-only-raw-fixed-waist','arm-only-clipped-fixed-waist']:
   q=qraw.copy()if mode=='native-full-body-reference'else np.zeros(29)
   if mode!='native-full-body-reference':q[arm]=qraw[arm]
   if mode=='arm-only-clipped-fixed-waist':q[arm]=np.clip(q[arm],limits[arm,0],limits[arm,1])
   imu=frames[i,3:7]if mode=='native-full-body-reference'else np.array([1.,0,0,0]);imu=imu/np.linalg.norm(imu);obs=SimpleNamespace(timestamp=i/30.,joint_position=q,imu_quat_wxyz=imu);metrics=form.evaluate(obs,CatchFormContext(over_shoulder=True,phase='receive'))['metrics'];data.qpos[:]=model.qpos0;data.qpos[base:base+7]=np.r_[0.,0.,2.,imu];data.qpos[enc]=q;mujoco.mj_forward(model,data)
   base_rotation=np.empty(9);mujoco.mju_quat2Mat(base_rotation,imu);base_rotation=base_rotation.reshape(3,3);finger=np.array([base_rotation.T@data.xmat[b].reshape(3,3)@np.array([0.,0.,1.])for b in palms]);elbow_below=np.array([data.xpos[w,2]-data.xpos[e,2]for e,w in zip(elbows,wrists)]);faces=np.array(metrics['palm_face_centers_relative_pelvis_m']);up=np.array(metrics['palm_up_cos']);height=np.array(metrics['palm_face_height_above_shoulders_m']);gap=float(np.linalg.norm(faces[0]-faces[1]));clear=min(float(mujoco.mj_geomDistance(model,data,l,r,.5,nearest))for l in hands[0]for r in hands[1]);margin=float(np.min(np.minimum(q[arm]-limits[arm,0],limits[arm,1]-q[arm])));checks=dict(palms_up=bool(up.min()>=criteria['min_bilateral_palm_up_cos']),height_band=bool(height.min()>=criteria['face_height_above_shoulders_m'][0]and height.max()<=criteria['face_height_above_shoulders_m'][1]),elbows_below_wrists=bool(elbow_below.min()>=criteria['min_elbow_below_wrist_m']),finger_direction_proxy=bool(finger[:,0].min()>=criteria['min_finger_longitudinal_body_forward_cos']),face_gap=bool(criteria['face_gap_m'][0]<=gap<=criteria['face_gap_m'][1]),interhand_clearance=bool(clear>=criteria['min_static_interhand_collision_gap_m']),joint_margin=bool(margin>=criteria['min_arm_joint_margin_rad']))
   rows.append(dict(frame=i,time_s=i/30.,mode=mode,palm_up_cos=up.tolist(),face_height_above_shoulders_m=height.tolist(),elbows_below_wrists_m=elbow_below.tolist(),palm_longitudinal_forward_cos=finger[:,0].tolist(),face_gap_m=gap,min_interhand_geom_gap_m=clear,min_arm_joint_margin_rad=margin,raw_arm_max_limit_violation_rad=float(violation[i,arm].max()),checks=checks,qualified_static_form_seed=bool(all(checks.values())),arm_order=list(ARM_JOINTS),arm_targets_rad=q[arm].tolist()))
 (a.output/'all-frame-metrics.json').write_text(json.dumps(rows,indent=2)+'\n');summary=[]
 for mode in ['native-full-body-reference','arm-only-raw-fixed-waist','arm-only-clipped-fixed-waist']:
  subset=[r for r in rows if r['mode']==mode];qualified=[r for r in subset if r['qualified_static_form_seed']];ranked=sorted(subset,key=lambda r:(r['qualified_static_form_seed'],min(r['palm_up_cos'])) ,reverse=True);summary.append(dict(mode=mode,qualified_frame_count=len(qualified),maximum_bilateral_min_palm_up=max(min(r['palm_up_cos'])for r in subset),best_frames=ranked[:3]))
 result=dict(csv_sha256=hashlib.sha256(a.csv.read_bytes()).hexdigest(),frames=150,fps=30,joint_names=list(BODY_NAMES),native_csv_raw_radians_not_offsets=True,all29_limit_violating_frames=int(np.any(violation>1e-6,axis=1).sum()),arm_limit_violating_frames=int(np.any(violation[:,arm]>1e-6,axis=1).sum()),maximum_raw_limit_violation_rad=float(violation.max()),root_displacement_m=(frames[-1,:3]-frames[0,:3]).tolist(),summary=summary,scope='offline staticFK proposal only; no physical steps, no control/root/leg transfer, no catch or balance claim',fingers='not generated; actualAero restfinger collision geometry and rigid palm+Z direction proxy only')
 (a.output/'measured.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(frames=150,arm_violations=result['arm_limit_violating_frames'],modes=[dict(mode=x['mode'],qualified=x['qualified_frame_count'],max_minup=x['maximum_bilateral_min_palm_up'])for x in summary]),indent=2))
if __name__=='__main__':main()
