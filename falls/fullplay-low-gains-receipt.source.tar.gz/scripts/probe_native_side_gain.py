"""Native sensor residual on immutable QB-side geometry; zero equality first."""
import json
from pathlib import Path
import numpy as np
import probe_native_cup_side_residual as runner
from g1_receiver.native_cup_residual_rl import NativeCupAudit,compare_reference,OBS_SCHEMA

def main():
 p=runner.build_parser();p.add_argument('--model',type=Path);p.add_argument('--require-exact',action='store_true');p.add_argument('--gain',type=float,default=0.);p.add_argument('--device',choices=['cpu','cuda'],default='cpu');p.add_argument('--reference-trace',type=Path);p.add_argument('--reference-view',type=Path);a=p.parse_args()
 if not 0<=a.gain<=1:p.error('gain must lie0..1')
 if a.gain and a.model is None:p.error('nonzero gain requires model')
 policy=None
 if a.model is not None:
  from stable_baselines3 import PPO
  model=PPO.load(a.model,device=a.device)
  if model.observation_space.shape!=(169,)or model.action_space.shape!=(20,)or model.receiver_sensor_schema!=OBS_SCHEMA:raise RuntimeError('native169D/20D model required')
  policy=lambda observation:model.predict(observation,deterministic=True)[0]*np.float32(a.gain)
 out=a.output;out.mkdir(parents=True,exist_ok=False);a.output=out/'trial';audit=NativeCupAudit(json.loads(a.profile.read_text()),policy=policy);runner.run(a,native_residual_callback=audit);bonus=audit.finish();summary=audit.save(out,bonus);summary.update(inference_device=a.device,action_gain=a.gain,external_machine_preload_clock='commanded release event unchanged; integration unverified')
 equality={}
 for label,current,reference in [('trace',a.output/'trace.npz',a.reference_trace),('view',a.output/'view.npz',a.reference_view)]:
  if reference:
   equality[label]=compare_reference(current,reference)
   if (a.gain==0 or a.require_exact) and not equality[label]['protected_reference_arrays_exact']:raise RuntimeError('zero side '+label+' mismatch')
 if equality:(out/'physical-equality.json').write_text(json.dumps(equality,indent=2)+'\n')
 (out/'sensor-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
