"""Matched original20ms versus explicitly different2.5ms numerical contact assumption."""
import argparse,concurrent.futures,json,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();
for k in['root','profile','compact','cup','source','amp-source','output']:p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
def run(spec):
 tau,delay=spec
 profile=json.loads(a.profile.read_text());profile["native_grip"]["digit_delay_s"][4:]=[delay]*3
 profile_path=a.output/f"profile-{int(delay*100):02}.json"
 if not profile_path.exists():profile_path.write_text(json.dumps(profile,indent=2))
 label=('original20'if tau==.02 else'experimental2p5')+f'-thumb{int(delay*100):02}';cmd=[sys.executable,str(a.root/'scripts/probe_go_side_causal_pass.py'),'--frozen-root',str(a.root),'--profile',str(profile_path),'--compact',str(a.compact),'--cup',str(a.cup),'--source',str(a.source),'--amp-source',str(a.amp_source),'--output',str(a.output/label),'--timeconstant',str(tau),'--cue-lead','.65','--reach-duration','.45']
 with(a.output/(label+'.log')).open('w')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 return dict(label=label,contact_timeconstant_s=tau,command=cmd,exit_code=r.returncode)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:rows=list(pool.map(run,[(.02,.3),(.0025,.3),(.02,.4),(.0025,.4)]))
(a.output/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
if any(r['exit_code']for r in rows):raise RuntimeError('failedtrialspreserved')
