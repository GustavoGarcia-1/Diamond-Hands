"""Finite-cup native-ready calibration; no catch scores or runtime geometry feedback."""
import argparse,json
from pathlib import Path
from copy import deepcopy
import probe_lower_cup_side_clear as runner
REFERENCE='173bf57168f5f97d0471d7bfa0a05e067a00f1e27a385994f57f21998a30af15'
def main():
 p=argparse.ArgumentParser()
 for n in ['source','amp-source','profile','output']:p.add_argument('--'+n,type=Path,required=True)
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);donor=json.loads(a.profile.read_text());rows=[]
 for i,preload in enumerate([0.,.5]):
  profile=deepcopy(donor);profile['native_grip']['preload'][:4]=[preload]*4;profile['play']['quarterback_target_m'][1]+=5.;profile['offline_dry_grasp_command_s']=5.02;profile['offline_evaluation_robot_qpos']=True;path=a.output/f'profile-{i:02d}.json';path.write_text(json.dumps(profile,indent=2)+'\n');args=runner.build_parser().parse_args(['--source',str(a.source),'--amp-source',str(a.amp_source),'--profile',str(path),'--output',str(a.output/f'case-{i:02d}'),'--walk-speed','1','--handoff-depth','1.3','--initial-yaw','-.7','--duration','7','--record-anatomical','--reference-physics-sha256',REFERENCE]);r=runner.run(args);rows.append(dict(case=i,normalized_native_finger_preload=preload,minimum_upright_cosine=r['minimum_upright_cosine'],self_geometry=r['interhand_geometry_audit'],not_catch_evidence=True));(a.output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
if __name__=='__main__':main()
