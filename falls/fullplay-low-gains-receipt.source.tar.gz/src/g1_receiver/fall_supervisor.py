"""Simulation-only IMU protective supervision, without pose/contact oracles.

Balance abort stops the commanded walk and retains the existing WBC. Crouch/tuck
is a separate failed/successful research candidate, not a learned get-up skill.
"""
from dataclasses import dataclass, replace
import numpy as np

@dataclass(frozen=True)
class FallConfig:
    mode: str = 'balance_abort'
    severe_upright_cos: float = .95
    warning_upright_cos: float = .985
    warning_gyro_rad_s: float = .35
    confirm_samples: int = 2
    max_target_velocity_rad_s: float = 2.5
    max_target_acceleration_rad_s2: float = 10.

class FallSupervisor:
    def __init__(self,names,joint_ranges,nominal,config=FallConfig()):
        if config.mode not in ('balance_abort','crouch_tuck'):raise ValueError('unknown supervision mode')
        self.names=tuple(names);self.ranges=np.asarray(joint_ranges,float);self.config=config;self.protective=np.asarray(nominal,float).copy()
        for side,sign in [('left',1),('right',-1)]:
            for joint,value in [('hip_pitch',-.65),('hip_roll',0.),('hip_yaw',0.),('knee',1.3),('ankle_pitch',-.65),('ankle_roll',0.),('shoulder_pitch',-.30),('shoulder_roll',sign*.20),('shoulder_yaw',0.),('elbow',1.25),('wrist_roll',0.),('wrist_pitch',0.),('wrist_yaw',0.)]:self.protective[self.names.index(side+'_'+joint+'_joint')]=value
        for n in ['waist_yaw_joint','waist_roll_joint','waist_pitch_joint']:self.protective[self.names.index(n)]=0.
        self.protective=np.clip(self.protective,self.ranges[:,0],self.ranges[:,1]);self.last_time=None;self.count=0;self.triggered_at=None;self.previous=None;self.start=None;self.transition_s=None;self.rows=[];self.latest=None
    def observe(self,obs):
        now=float(obs.timestamp)
        if self.last_time is not None and abs(now-self.last_time)<1e-10:return self.triggered_at is not None
        dt=.02 if self.last_time is None else now-self.last_time
        if not 0<dt<=.041:raise ValueError('causal50Hz supervision required')
        q=np.asarray(obs.imu_quat_wxyz,float).copy();g=np.asarray(obs.imu_gyro,float)
        if q.shape!=(4,)or g.shape!=(3,)or not np.isfinite(np.r_[now,q,g]).all()or np.linalg.norm(q)<1e-8:raise ValueError('finite timestamped IMU required')
        q/=np.linalg.norm(q);up=float(1.-2.*(q[1]**2+q[2]**2));rate=float(np.linalg.norm(g[:2]));warning=up<self.config.severe_upright_cos or(up<self.config.warning_upright_cos and rate>self.config.warning_gyro_rad_s);self.count=self.count+1 if warning else 0
        if self.triggered_at is None and self.count>=self.config.confirm_samples:self.triggered_at=now
        self.last_time=now;self.latest=(now,up,rate,warning);return self.triggered_at is not None
    def apply(self,obs,command):
        self.observe(obs);target=np.asarray(command.target_position,float)
        if self.triggered_at is not None and self.config.mode=='crouch_tuck':
            if self.start is None:
                self.start=(target if self.previous is None else self.previous).copy();distance=float(abs(self.protective-self.start).max());self.transition_s=max(.35,1.875*distance/self.config.max_target_velocity_rad_s,np.sqrt(5.773503*distance/self.config.max_target_acceleration_rad_s2))
            u=float(np.clip((obs.timestamp-self.triggered_at)/self.transition_s,0.,1.));alpha=u**3*(10.-15.*u+6.*u*u);target=self.start+alpha*(self.protective-self.start);command=replace(command,target_position=np.clip(target,self.ranges[:,0],self.ranges[:,1]),status='imu_crouch_tuck_abort')
        elif self.triggered_at is not None:command=replace(command,status='imu_balance_abort')
        self.previous=np.asarray(command.target_position).copy();now,up,rate,warning=self.latest;self.rows.append(dict(time_s=now,imu_upright_cos=up,imu_tilt_rate_rad_s=rate,warning=warning,triggered_at_s=self.triggered_at,mode=self.config.mode,target_rad=self.previous.tolist()));return command
