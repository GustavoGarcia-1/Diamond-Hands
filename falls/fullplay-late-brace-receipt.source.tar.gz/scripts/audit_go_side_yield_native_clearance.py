"""Offline full-native-surface check of commanded yield path, not runtime input."""
exec(open('scripts/audit_go_side_yield_static.py').read().split('for t in np.arange')[0])
states=np.load(P/'thumb-timing-linux/artifacts/study/experimental2p5-thumb30/actual-state.npz')['time_qpos'];path=json.load(open(P/'yield-static-path.json'))['rows'];body_addresses={int(m.joint(n).qposadr[0])for n in BODY_NAMES};native=[int(m.jnt_qposadr[j])for j in range(m.njnt)if m.jnt_type[j]!=mujoco.mjtJoint.mjJNT_FREE and int(m.jnt_qposadr[j])not in body_addresses];d=mujoco.MjData(m);rows=[]
for stamp in[5.18,6.5]:
 k=np.argmin(abs(states[:,0]-stamp));finger=states[k,1:][native]
 for phase in path:
  d.qpos[:]=m.qpos0;d.qpos[:7]=np.r_[0.,0.,.759,sensor['imu_quat_wxyz']];
  for n,v in zip(BODY_NAMES,sensor['joint_position']):d.qpos[int(m.joint(n).qposadr[0])]=v
  for n,v in zip(cup['arm_order'],phase['target14']):d.qpos[int(m.joint(n).qposadr[0])]=v
  d.qpos[native]=finger;mujoco.mj_forward(m,d);contacts=[]
  for c in d.contact:
   g,h=map(int,c.geom)
   if m.geom_bodyid[g]>0 and m.geom_bodyid[h]>0 and 'football'not in[m.body(int(m.geom_bodyid[g])).name,m.body(int(m.geom_bodyid[h])).name]:contacts.append(dict(g=m.geom(g).name,h=m.geom(h).name,gap_m=float(c.dist)))
  rows.append(dict(native_source_time_s=stamp,path_time_s=phase['time_s'],contacts=contacts))
(P/'yield-static-native-audit.json').write_text(json.dumps(dict(offline_only=True,rows=rows),indent=2)+'\n');print('phases',len(rows),'contactphases',sum(bool(r['contacts'])for r in rows))
