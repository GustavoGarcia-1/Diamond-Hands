"""Static commanded path proposal, not a catch or runtime privileged input."""
from pathlib import Path
import json,re
from types import SimpleNamespace
import numpy as np,mujoco
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
from g1_receiver._vendor.g1_runtime.pool.wbc import BODY_NAMES
from g1_receiver.go_side_visual_yield import VisualCupYield
P=Path('reports/catch-repair-20261114/go-side-cup');r=P/'close-pose-calibration-linux/artifacts/study/confirm-9s';xml=re.sub(r'/workspace/g1-receiver-runs/[^" ]+/source/src/g1_receiver/_vendor/g1_runtime',str(DEFAULT_RUNTIME_ROOT),(r/'scene.xml').read_text()).replace('/workspace/g1-receiver-runs/out-scrimmage-20261113/source/aero-source','/tmp/g1-aero-source');m=mujoco.MjModel.from_xml_string(xml);sensor=min(json.load(open(r/'sensor-observations.json')),key=lambda x:abs(x['time_s']-5.18));target=np.array(sensor['joint_position']);cup=json.load(open(P/'upperarm-x35-y20.json'));idx=[BODY_NAMES.index(n)for n in cup['arm_order']];target[idx]=cup['arm_targets_rad'];servo=VisualCupYield(gain=1.);servo.bind(m,list(BODY_NAMES));servo.start=0.;servo.shift=np.array([.0436,.0136,-.0654]);servo.packet=SimpleNamespace(joint_position=sensor['joint_position'],imu_quat_wxyz=sensor['imu_quat_wxyz']);rows=[]
for t in np.arange(0,.401,.02):
 out=servo.apply(target,float(t),1.);P0,_,_=servo.geometry(target[idx]);Q,_,_=servo.geometry(out[idx]);rows.append(dict(time_s=float(t),target14=out[idx].tolist(),facet_shift_m=(Q-P0).tolist(),clearance_m=servo.clearance(out[idx]),joint_margin_rad=float(np.minimum(out[idx]-servo.ranges[:,0],servo.ranges[:,1]-out[idx]).min())))
(P/'yield-static-path.json').write_text(json.dumps(dict(calibration_only=True,not_a_physical_rollout=True,native_finger_state='restmodel;fullnativeactualgeometrymustbeaudi tedoffline',rows=rows),indent=2)+'\n');print(rows[-1])
