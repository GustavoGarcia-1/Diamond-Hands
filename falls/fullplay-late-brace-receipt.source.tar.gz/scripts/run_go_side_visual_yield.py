"""Matched original20ms versus explicitly different2.5ms numerical contact assumption."""
import argparse,concurrent.futures,json,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();
for k in['root','profile','compact','cup','source','amp-source','output','reference']:p.add_argument('--'+k,type=Path,required=True)
a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
def run(spec):
 gain,latency=spec
 tau=.0025
 label=f'yield-{gain:g}-latency-{latency:g}';cmd=[sys.executable,str(a.root/'scripts/probe_go_side_visual_yield.py'),'--frozen-root',str(a.root),'--profile',str(a.profile),'--compact',str(a.compact),'--cup',str(a.cup),'--source',str(a.source),'--amp-source',str(a.amp_source),'--output',str(a.output/label),'--timeconstant',str(tau),'--cue-lead','.65','--reach-duration','.45','--yield-gain',str(gain),'--camera-latency',str(latency)]
 with(a.output/(label+'.log')).open('w')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 return dict(label=label,contact_timeconstant_s=tau,command=cmd,exit_code=r.returncode)
rows=[run((0.,0.))]
import numpy as np
checks={}
for name in ['actual-state.npz','ball-contact-witness.npz','trial/trace.npz','trial/view.npz','trial/anatomical-contact.npz']:
 x=np.load(a.reference/name);y=np.load(a.output/'yield-0-latency-0'/name);checks[name]={k:bool(np.array_equal(x[k],y[k],equal_nan=True))if x[k].dtype.kind not in 'US'else bool(np.array_equal(x[k],y[k]))for k in x.files}
(a.output/'zero-exact.json').write_text(json.dumps(checks,indent=2))
if not all(all(c.values())for c in checks.values()):raise RuntimeError('STOP:zero yield anchor differs')
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:rows+=list(pool.map(run,[(1.,0.),(1.,.04)]))
(a.output/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
if any(r['exit_code']for r in rows):raise RuntimeError('failedtrialspreserved')
