"""Matched constant phase-rate controls, independent of the PPO optimizer."""
import argparse
import json
from pathlib import Path
import sys
import numpy as np


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    config = json.loads(a.config.read_text())
    config.pop('sensor_domains', None)
    runtime = Path(config['frozen_root'])
    sys.path[:0] = [str(runtime/'src'), str(runtime/'scripts')]
    from g1_receiver.late_reach_rl import LateReachEnv
    a.output.mkdir(parents=True, exist_ok=False)
    (a.output/'protocol.json').write_text(json.dumps(dict(
        actions=[-1., -.5, 0., .5, 1.],
        interpretation='Normalized constant actions; phase-rate multiplier1+0.35*action. Visual activation and relative servo unchanged.',
        selection='All five prescribed controls reported; no action selection from physical truth.',
        model='Frozen R3b zero-preflight runtime and profile; experimental2.5ms contact model.'), indent=2)+'\n')
    results = []
    for action in (-1., -.5, 0., .5, 1.):
        out = a.output/f'action-{action:+.2f}'
        env = LateReachEnv(config, 'run_out_late_cup_episode', evaluation_dir=out)
        try:
            obs, info = env.reset(seed=173)
            total = 0.
            while True:
                obs, reward, done, _, info = env.step(np.array([action], dtype=np.float32))
                total += reward
                if done:
                    break
            assert abs(total-info['sensor_return']) < 1e-9
            report = json.loads((out/'episode-0001/trial/report.json').read_text())
            results.append(dict(action=action, sensor_return=total, coverage=info['sensor_coverage'],
                                physical_evaluation_only=report['anatomical_score']))
            (a.output/'summary.json').write_text(json.dumps(results, indent=2)+'\n')
            print(json.dumps(dict(action=action, completed=len(results))), flush=True)
        finally:
            env.close()


if __name__ == '__main__':
    main()
