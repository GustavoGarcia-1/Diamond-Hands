"""Passive sensor-only ellipsoid/mount distance proposal; truth labels joined ONLY afterward.
No classifier/reward/gates are trained or changed. Uncertainty assumptions are not calibrated.
"""
from pathlib import Path
import json,re
import numpy as np,mujoco
from scipy.optimize import least_squares
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
from g1_receiver._vendor.g1_runtime.pool.wbc import BODY_NAMES
from g1_receiver.perception import _components
P=Path('reports/catch-repair-20261114/go-side-cup');r=P/'onboard-observability-r3-linux/artifacts/study/confirm-11s';dataset=json.load(open(r/'onboard-observations.json'));records=dataset['rows'];images=np.load(r/'onboard-keyframes.npz');intr=dataset['intrinsics'];xml=re.sub(r'/workspace/g1-receiver-runs/[^" ]+/source/src/g1_receiver/_vendor/g1_runtime',str(DEFAULT_RUNTIME_ROOT),(r/'scene.xml').read_text()).replace('/workspace/g1-receiver-runs/out-scrimmage-20261113/source/aero-source','/tmp/g1-aero-source');m=mujoco.MjModel.from_xml_string(xml);d=mujoco.MjData(m);ball=m.geom('football_surface').id;ballq=int(m.joint('football_free').qposadr[0]);mounts=[g for g in range(m.ngeom)if 'tetheria_mount_collision'in m.geom(g).name];dofs=[int(m.joint(n).dofadr[0])for n in BODY_NAMES];rows=[]
def axis(theta,phi):return np.array([np.cos(theta)*np.cos(phi),np.sin(theta)*np.cos(phi),np.sin(phi)])
def quat_for_axis(n):
 if n[0]<0:n=-n
 w=np.sqrt((1+n[0])/2);return np.r_[w,0,-n[2]/(2*w),n[1]/(2*w)]
def skew(v):return np.array([[0,-v[2],v[1]],[v[2],0,-v[0]],[-v[1],v[0],0]])
for stamp,rgb,depth in zip(images['time_s'],images['rgb'],images['depth_m']):
 record=min(records,key=lambda v:abs(v['time_s']-stamp));R=np.array(record['camera_rotation_fk']);camera=np.array(record['camera_position_fk_m']);color=rgb.astype(np.int16);mask=(color[:,:,0]>=90)&(color[:,:,0]-color[:,:,1]>=22)&(color[:,:,1]-color[:,:,2]>=12);components=list(_components(mask));result=dict(time_s=float(stamp),valid_detection=record['valid'],sensor_only_fit=True)
 if not record['valid']or not components:rows.append(result);continue
 pixels=max(components,key=len);yy,xx=pixels.T;zz=depth[yy,xx];ok=np.isfinite(zz)&(zz>=.2)&(zz<=6);pixels=pixels[ok][::max(1,np.count_nonzero(ok)//500)];yy,xx=pixels.T;zz=depth[yy,xx];points_camera=np.column_stack(((xx-intr['cx'])*zz/intr['fx'],(yy-intr['cy'])*zz/intr['fy'],zz));points=points_camera@R.T+camera;mean=np.median(points,axis=0);ray=mean-camera;ray/=np.linalg.norm(ray);seed=mean+.085*ray;_,vectors=np.linalg.eigh(np.cov(points.T));n=vectors[:,-1];theta=np.arctan2(n[1],n[0]);phi=np.arcsin(np.clip(n[2],-1,1))
 def residual(x):
  v=points-x[:3];a=axis(*x[3:]);long=v@a;return .085*(np.sqrt(long**2/.142**2+(np.sum(v*v,axis=1)-long**2)/.085**2)-1)
 fit=least_squares(residual,np.r_[seed,theta,phi],bounds=(np.r_[seed-.15,-np.inf,-np.inf],np.r_[seed+.15,np.inf,np.inf]),loss='soft_l1',f_scale=.002,max_nfev=150);center=fit.x[:3];a=axis(*fit.x[3:]);d.qpos[:]=m.qpos0;d.qpos[:7]=[0,0,0,1,0,0,0]
 for name,value in zip(BODY_NAMES,record['joint_position']):d.qpos[int(m.joint(name).qposadr[0])]=value
 d.qpos[ballq:ballq+7]=np.r_[center,quat_for_axis(a)];mujoco.mj_kinematics(m,d);mujoco.mj_comPos(m,d);distances=[]
 for g in mounts:
  witness=np.zeros(6);gap=float(mujoco.mj_geomDistance(m,d,ball,g,.5,witness));distances.append((gap,g,witness))
 gap,g,closest=min(distances,key=lambda v:v[0]);jp=np.zeros((3,m.nv));jr=np.zeros_like(jp);jc=np.zeros_like(jp);jcr=np.zeros_like(jp);mujoco.mj_jac(m,d,jp,jr,closest[3:],int(m.geom_bodyid[g]));mujoco.mj_jac(m,d,jc,jcr,camera,m.body('torso_link').id);relative_J=jp-(jc-skew(center-camera)@jcr);fk_sigma=.002*float(np.linalg.norm(relative_J[:,dofs],ord=2));base_sigma=float(np.sqrt(np.linalg.eigvalsh(np.array(record['covariance_m2'])).max()));calibration_sigma=np.hypot(.005,np.linalg.norm(center-camera)*np.deg2rad(.5));sigma=float(np.sqrt(base_sigma**2+calibration_sigma**2+fk_sigma**2+.005**2));result.update(fit_success=bool(fit.success),fit_rms_m=float(np.sqrt(np.mean(residual(fit.x)**2))),surface_points=len(points),estimated_center_receiver_m=center.tolist(),estimated_major_axis_receiver=a.tolist(),estimated_min_mount_clearance_m=gap,nearest_mount=m.geom(g).name,reported_rgbd_sigma_m=base_sigma,assumed_mount_calibration_sigma_m=float(calibration_sigma),assumed_encoder_fk_sigma_m=fk_sigma,assumed_ball_radius_sigma_m=.005,combined_sigma_proxy_m=sigma,illustrative_clearance_3sigma_interval_m=[gap-3*sigma,gap+3*sigma],confident_mount_clearance_3sigma=bool(gap-3*sigma>0));rows.append(result)
# Labels below are independent passive physics evidence; NEVER fit inputs.
witness=np.load(r/'ball-contact-witness.npz');w=witness['ball_contact_witness'];names=witness['geom_names'];mountrows=w[np.array(['tetheria_mount_collision'in str(names[int(g)])for g in w[:,1]])&(w[:,4]>1e-9)]
for result in rows:
 near=mountrows[abs(mountrows[:,0]-result['time_s'])<=.002]if len(mountrows)else []
 result['offline_label_mount_force_near_frame']=bool(len(near));result['offline_label_basis']='exactcontact ONLY after sensor estimation, ±2ms window'
summary=[]
for label,selector in [('secure_clock',lambda x:6.317<=x['time_s']<10.402),('mount_support_label',lambda x:x['offline_label_mount_force_near_frame'])]:
 sample=[x for x in rows if selector(x)and x.get('fit_success')];summary.append(dict(group=label,n=len(sample),median_clearance_m=float(np.median([x['estimated_min_mount_clearance_m']for x in sample]))if sample else None,range_clearance_m=[min(x['estimated_min_mount_clearance_m']for x in sample),max(x['estimated_min_mount_clearance_m']for x in sample)]if sample else None,confident_positive_count=sum(x['confident_mount_clearance_3sigma']for x in sample),median_combined_sigma_m=float(np.median([x['combined_sigma_proxy_m']for x in sample]))if sample else None))
output=dict(passive_only=True,no_reward_or_classifier=True,known_shape_prior_radii_m=[.142,.085,.085],uncertainty_assumptions_not_measured_calibration=dict(mount_position_std_m=.005,mount_angle_std_deg=.5,encoder_std_rad=.002,ball_radius_std_m=.005,depth_covariance_floor_from_unchanged_detector=True),limitations=['partialview shape/occlusion bias not fully covered by sigma proxy','camera/mount/FK calibration hypothetical, not hardware verified','positive visibility is not legitimate hand retention','native finger joints not observed or used for mount FK'],summary=summary,rows=rows);(P/'onboard-mount-observability.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps(summary,indent=2))
