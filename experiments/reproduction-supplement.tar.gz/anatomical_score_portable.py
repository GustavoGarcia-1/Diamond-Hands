"""Unmodified anatomical-v1 score definitions exported for offline rescore only."""
from dataclasses import dataclass,asdict
import numpy as np

SCHEMA='aero-anatomical-catch-v1-predeclared-20261114'

GROUPS=('left_finger','left_thumb','left_palmar','right_finger','right_thumb','right_palmar','excluded_hand','torso','floor','other')

COLUMNS=('timestamp_s','ball_x_m','ball_y_m','ball_z_m','ball_floor_contact','applied_ball_load',*(g+'_normal_n'for g in GROUPS),*(g+'_vertical_n'for g in GROUPS),'interhand_self_normal_n','minimum_interhand_distance_m','minimum_ball_contact_distance_m')

INDEX={name:i for i,name in enumerate(COLUMNS)}

@dataclass(frozen=True)
class AnatomicalCatchCriteria:
    min_initial_free_flight_s:float=.020
    min_normal_per_hand_n:float=.10
    min_continuous_retention_s:float=.75
    final_window_s:float=.25
    final_bilateral_fraction:float=.90
    max_final_gap_s:float=.025
    support_force_tolerance_n:float=1e-9
    min_mean_vertical_hand_weight_fraction:float=.80
    form_before_contact_s:float=.020
    form_after_contact_s:float=.200
    min_palm_up_cos:float=.60
    max_face_height_above_shoulder_m:float=.15
    min_form_fraction:float=.80
    max_form_sample_gap_s:float=.050
    max_interhand_penetration_m:float=.005
    max_ball_penetration_m:float=.010
    min_upright_cosine:float=.90
    def __post_init__(self):
        if not np.isfinite(list(asdict(self).values())).all()or min(asdict(self).values())<=0:raise ValueError('positive finite anatomical criteria required')
        if self.final_bilateral_fraction>1 or self.min_form_fraction>1 or self.min_palm_up_cos>1:raise ValueError('invalid fraction/cosine criteria')

def _runs(mask):
    e=np.flatnonzero(np.diff(np.r_[False,mask,False]));return list(zip(e[::2],e[1::2]))

def score_anatomical_catch(arrays,*,release_time_s,finish_time_s,ball_weight_n,form_rows=None,motion=None,required_intercept_height_above_shoulder_m=None,height_exception_basis=None,physics_reference_match=None,verified_free_ball=None,criteria=None):
    c=criteria or AnatomicalCatchCriteria();verified=bool(arrays.get('anatomical_free_joint_verified',False))if verified_free_ball is None else bool(verified_free_ball);rows=np.asarray(arrays['anatomical_contact'],float)
    if rows.ndim!=2 or rows.shape[1]!=len(COLUMNS)or not len(rows)or not np.isfinite(rows).all():raise ValueError('finite anatomical physics trace required')
    if not np.isfinite([release_time_s,finish_time_s,ball_weight_n]).all()or ball_weight_n<=0:raise ValueError('finite release/end and positive weight required')
    t=rows[:,0];dt=float(np.median(np.diff(t)))if len(t)>1 else .001;clock=bool(dt>0 and np.allclose(np.diff(t),dt,rtol=0,atol=1e-7)and abs(t[0]-release_time_s-dt)<=1e-7 and abs(t[-1]-finish_time_s)<=1e-7)
    n=rows[:,6:6+len(GROUPS)];v=rows[:,6+len(GROUPS):6+2*len(GROUPS)];left=n[:,:3].sum(1);right=n[:,3:6].sum(1);bilateral=(left>=c.min_normal_per_hand_n)&(right>=c.min_normal_per_hand_n)
    bad=(n[:,6:].sum(1)>c.support_force_tolerance_n)|rows[:,4].astype(bool)|rows[:,5].astype(bool);first_bad=np.flatnonzero(bad);cutoff=int(first_bad[0])if len(first_bad)else len(t);clean=bilateral.copy();clean[cutoff:]=False
    a,b=max(_runs(clean),key=lambda ab:ab[1]-ab[0],default=(0,0));duration=float((b-a)*dt);initial=max(1,round(c.min_initial_free_flight_s/dt));free=bool(len(t)>=initial and not rows[:initial,4:6].any()and n[:initial].sum(1).max()<=c.support_force_tolerance_n and rows[:initial,3].min()>=.15)
    hits=np.flatnonzero((left+right)>=c.min_normal_per_hand_n);first_contact=float(t[hits[0]])if len(hits)else None;last_count=max(1,round(c.final_window_s/dt));tail=clean[-last_count:];gaps=_runs(~tail);maxgap=max((j-i)*dt for i,j in gaps)if gaps else 0.;fraction=float(tail.mean());final=bool(len(t)>=last_count and tail[-1]and fraction>=c.final_bilateral_fraction and maxgap<=c.max_final_gap_s+1e-8)
    vertical_fraction=float(v[a:b,:6].sum(1).mean()/ball_weight_n)if b>a else None;deep_self=bool(np.min(rows[:,INDEX['minimum_interhand_distance_m']]) < -c.max_interhand_penetration_m);deep_ball=bool(np.min(rows[:,INDEX['minimum_ball_contact_distance_m']]) < -c.max_ball_penetration_m);form={'available':False,'pass':False};height_limit=c.max_face_height_above_shoulder_m
    if required_intercept_height_above_shoulder_m is not None:
        if not height_exception_basis or not np.isfinite(required_intercept_height_above_shoulder_m):raise ValueError('height exception requires explicit predeclared trajectory basis')
        height_limit=max(height_limit,float(required_intercept_height_above_shoulder_m)+.05)
    if form_rows is not None and first_contact is not None:
        selected=[r for r in form_rows if first_contact-c.form_before_contact_s-1e-8<=r['time_s']<=first_contact+c.form_after_contact_s+1e-8]
        if selected:
            ft=np.array([r['time_s']for r in selected]);metrics=[r.get('metrics',r)for r in selected];up=np.array([r['palm_up_cos']for r in metrics]);height=np.array([r['palm_face_height_above_shoulders_m']for r in metrics]);coverage=bool(len(ft)>=3 and ft[0]<=first_contact+.005 and ft[-1]>=first_contact+c.form_after_contact_s-c.max_form_sample_gap_s and np.diff(ft).max(initial=0)<=c.max_form_sample_gap_s)
            finite=bool(np.isfinite(up).all()and np.isfinite(height).all());proper=(up.min(1)>=c.min_palm_up_cos)&(height.max(1)<=height_limit);form={'available':True,'sample_count':len(ft),'clock_coverage_ok':coverage,'finite':finite,'both_up_fraction':float((up.min(1)>=c.min_palm_up_cos).mean()),'both_height_fraction':float((height.max(1)<=height_limit).mean()),'joint_form_fraction':float(proper.mean()),'height_limit_above_shoulder_m':height_limit,'height_exception_basis':height_exception_basis,'pass':bool(coverage and finite and proper.mean()>=c.min_form_fraction)}
    upright=None
    if motion is not None and first_contact is not None:
        m=np.asarray(motion,float);window=m[(m[:,0]>=first_contact-1e-8)&(m[:,0]<=finish_time_s+1e-8)];upright=bool(len(window)and np.isfinite(window).all()and window[:,4].min()>=c.min_upright_cosine)
    physics_checks={'physics_clock_and_endpoint':clock,'initial_free_flight':free,'verified_free_joint_no_attachment':verified,'continuous_anatomical_bilateral_075s':duration+1e-8>=c.min_continuous_retention_s,'final_anatomical_hand_hold':final,'no_excluded_floor_body_or_applied_support':not bool(bad.any()),'load_bearing_hands':vertical_fraction is not None and vertical_fraction>=c.min_mean_vertical_hand_weight_fraction,'no_deep_interhand_penetration':not deep_self,'no_deep_ball_penetration':not deep_ball}
    control=all(physics_checks.values());quality_checks={**physics_checks,'acquisition_lower_palms_up_form':form['pass'],'upright_through_finish':upright is True,'reference_physics_verified':physics_reference_match is True}
    return {'version':SCHEMA,'intended_form':'over_shoulder_lower_upward_cradle','criteria':asdict(c),'anatomical_hand_control':bool(control),'realistic_lower_catch':bool(all(quality_checks.values())),'physics_checks':physics_checks,'quality_checks':quality_checks,'first_anatomical_contact_s':first_contact,'first_excluded_support_s':None if not len(first_bad)else float(t[cutoff]),'longest_clean_bilateral_s':duration,'longest_clean_start_s':float(t[a])if b>a else None,'longest_clean_end_s':float(t[b-1])if b>a else None,'final_bilateral_fraction':fraction,'final_max_gap_s':float(maxgap),'mean_vertical_hand_weight_fraction_in_long_hold':vertical_fraction,'form':form,'upright':upright,'physics_reference_match':physics_reference_match,'peak_interhand_self_normal_n':float(rows[:,INDEX['interhand_self_normal_n']].max()),'minimum_interhand_distance_m':float(rows[:,INDEX['minimum_interhand_distance_m']].min()),'minimum_ball_contact_distance_m':float(rows[:,INDEX['minimum_ball_contact_distance_m']].min()),'peak_ball_normal_n_by_group':dict(zip(GROUPS,n.max(0).tolist())),'gait_evaluated_separately':True,'legacy_strict_score_unchanged':True}
