import json
from pathlib import Path
from antioch.client import Client,targeting
from antioch.transport import exit_code_of
out=Path(__file__).parent
code=r'''
import sys,platform,json,subprocess,importlib.metadata as md,hashlib,pathlib,os
mods={}
for name in ['numpy','mujoco','torch','onnxruntime','gymnasium','stable_baselines3','PIL','OpenGL','glfw','scipy']:
 try:
  x=__import__(name);mods[name]={'version':getattr(x,'__version__',None),'file':getattr(x,'__file__',None)}
 except Exception as e:mods[name]={'error':type(e).__name__}
def command(args):
 p=subprocess.run(args,capture_output=True,text=True);return {'exit':p.returncode,'stdout':p.stdout.strip(),'stderr':p.stderr.strip()}
assets={}
for label,base in [('aero','/workspace/g1-receiver-runs/out-scrimmage-20261113/source/aero-source'),('amp','/workspace/g1-receiver-runs/out-scrimmage-20261113/amp')]:
 p=pathlib.Path(base);files={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest()for f in sorted(p.rglob('*'))if f.is_file()and'.git'not in f.parts and'__pycache__'not in f.parts};assets[label]={'root':base,'files':files,'git_head':command(['git','-C',base,'rev-parse','HEAD'])}
print(json.dumps({'python':sys.version,'executable':sys.executable,'prefix':sys.prefix,'base_prefix':sys.base_prefix,'platform':platform.platform(),'machine':platform.machine(),'modules':mods,'distributions':sorted([{'name':d.metadata['Name'],'version':d.version}for d in md.distributions()],key=lambda d:d['name'].lower()),'pip_freeze':command([sys.executable,'-m','pip','freeze','--all']),'pip_check':command([sys.executable,'-m','pip','check']),'gpu':command(['nvidia-smi','--query-gpu=name,driver_version','--format=csv,noheader']),'assets':assets}))
'''
c=Client();r=targeting.resolve_session(c,session='ses-3A0R1JMJWD4E7ENS2SEQQZRYS0',any_project=True,fresh=True)
with targeting.attach_agent(c,r.session,'sim')as a:
 x=a.run(['/workspace/g1-receiver-runs/receiver-uniform173-supervised-20261111/.venv/bin/python','-c',code],cwd='/tmp',timeout=90,environment={'PYTHONDONTWRITEBYTECODE':'1'})
 if exit_code_of(x)!=0:raise RuntimeError(x.stderr.decode())
 data=json.loads(x.stdout.decode());(out/'worker-environment.json').write_text(json.dumps(data,indent=2)+'\n')
 (out/'requirements-observed-freeze.txt').write_text(data['pip_freeze']['stdout']+'\n')
 print(json.dumps({'modules':data['modules'],'pip_check':data['pip_check'],'asset_file_counts':{k:len(v['files'])for k,v in data['assets'].items()}}))
