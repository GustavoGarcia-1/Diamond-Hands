"""Compare House of Dextra control and fingertip contact in a fixed catch fixture."""

from __future__ import annotations

import argparse
from copy import deepcopy
from dataclasses import dataclass
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import mujoco
import numpy as np

from probe_dextra_hand import (
    COMMAND_SPEED_RAD_S,
    UPSTREAM_REVISION,
    UPSTREAM_URDF,
    make_fixture_tree,
    verify_source_urdf,
)

BALL_START_X = -0.28
BALL_CENTER_Z = 1.0
PALM_HALF_SPACING_M = 0.155
FLEXION_RAD = 0.60
PULL_FORCE_N = 2.0
PULL_DURATION_S = 0.30
SIM_DURATION_S = 1.25
BACKSTOP_FACE_X = 0.165
HAND_SIDES = ("left", "right")
POSES = (
    (-0.085, -PALM_HALF_SPACING_M, "0.7071067811865476 0.7071067811865476 0 0"),
    (0.085, PALM_HALF_SPACING_M, "0 0 0.7071067811865476 0.7071067811865476"),
)
INCOMING_SPEEDS_MPS = (0.7, 1.5, 3.0, 5.5)
LATERAL_OFFSETS_M = (-0.02, 0.0, 0.02)
SCHEDULED_CLOSE_OFFSET_S = -0.10
LATE_CLOSE_OFFSET_S = 0.15
HARD_FRICTION = "0.60 0.60 0.005 0.0001 0.0001"
COMPLIANT_FRICTION = "0.95 0.95 0.005 0.0001 0.0001"


@dataclass(frozen=True)
class Variant:
    name: str
    close: bool
    compliant: bool


VARIANTS = (
    Variant("open_compliant", False, True),
    Variant("closing_rigid", True, False),
    Variant("closing_compliant", True, True),
)


def make_paired_fixture(urdf: Path, compliant: bool) -> mujoco.MjModel:
    root = make_fixture_tree(urdf)
    root.set("model", "dextra_paired_retention_fixture")
    root.find("option").attrib.update(gravity="0 0 -9.81", cone="elliptic")
    world = root.find("worldbody")
    hand = world.find("body[@name='palm']")
    world.remove(hand)
    for geom in world.findall("geom"):
        world.remove(geom)
    football = world.find("body[@name='football']")
    football.set("pos", f"{BALL_START_X} 0 {BALL_CENTER_Z}")
    football.find("geom").set("friction", "0.6 0.005 0.0001")
    ET.SubElement(world, "geom", name="fixture_deck", type="box", pos="-0.12 0 0.900",
                  size="0.55 0.025 0.015", friction="0.05 0.001 0.0001", priority="2")
    ET.SubElement(world, "geom", name="fixture_backstop", type="box", pos=f"{BACKSTOP_FACE_X + 0.10} 0 1.000",
                  size="0.10 0.025 0.055", friction="0.05 0.001 0.0001", priority="2", solref="0.020 1.1")
    actuators = root.find("actuator")
    original_actuators = list(actuators)
    actuators.clear()
    contact = ET.SubElement(root, "contact")
    for side, (x, y, quat) in zip(HAND_SIDES, POSES, strict=True):
        copy = deepcopy(hand)
        world.append(copy)
        copy.attrib.update(pos=f"{x} {y} {BALL_CENTER_Z}", quat=quat)
        for body in copy.iter("body"):
            body.set("name", f"{side}_{body.attrib['name']}")
            for geom_index, geom in enumerate(body.findall("geom")):
                geom.set("name", f"{body.attrib['name']}_{geom_index}")
                geom.set("friction", "0.6 0.005 0.0001")
                if geom.get("contype") != "0" and body.attrib["name"].endswith("_finger_tip"):
                    ET.SubElement(
                        contact, "pair", geom1="football_surface", geom2=geom.attrib["name"],
                        friction=COMPLIANT_FRICTION if compliant else HARD_FRICTION,
                        solref="0.030 1.10" if compliant else "0.010 1.00",
                        solimp="0.85 0.95 0.004" if compliant else "0.95 0.99 0.001",
                    )
        for joint in copy.iter("joint"):
            joint.set("name", f"{side}_{joint.attrib['name']}")
        for original in original_actuators:
            actuator = deepcopy(original)
            actuator.set("name", f"{side}_{original.attrib['name']}")
            actuator.set("joint", f"{side}_{original.attrib['joint']}")
            actuators.append(actuator)
    return mujoco.MjModel.from_xml_string(ET.tostring(root, encoding="unicode"))


def run_case(
    model: mujoco.MjModel,
    variant: Variant,
    speed: float,
    lateral_offset: float,
    close_offset_s: float = SCHEDULED_CLOSE_OFFSET_S,
) -> dict:
    data = mujoco.MjData(model)
    ball_geom = model.geom("football_surface").id
    ball_body = model.body("football").id
    free_joint = model.joint("football_free")
    position = data.qpos[free_joint.qposadr[0]:free_joint.qposadr[0] + 3]
    velocity = data.qvel[free_joint.dofadr[0]:free_joint.dofadr[0] + 3]
    position[1] = lateral_offset
    velocity[0] = speed
    palm_ids = [model.body(f"{side}_palm").id for side in HAND_SIDES]
    hand_lookup = {palm_id: side for side, palm_id in enumerate(palm_ids)}
    deck_id = model.geom("fixture_deck").id
    stop_id = model.geom("fixture_backstop").id
    support_ids = {deck_id, stop_id}
    geom_root = model.body_rootid[model.geom_bodyid]
    flexion = np.array([not model.actuator(index).name.endswith("_palm_joint") for index in range(model.nu)])
    nominal_arrival_s = -BALL_START_X / speed
    close_s = max(0.0, nominal_arrival_s + close_offset_s)
    pull_start_s = nominal_arrival_s + 0.40
    pull_end_s = pull_start_s + PULL_DURATION_S
    first_hand_contact_s = None
    first_stop_contact_s = None
    peak_normal_force = np.zeros(2)
    peak_net_force = np.zeros(2)
    peak_net_moment = np.zeros(2)
    peak_support_normal_force = 0.0
    peak_backstop_normal_force = 0.0
    peak_hand_fixture_normal_force = 0.0
    peak_actuator_effort = 0.0
    max_ball_x = float(position[0])
    max_backstop_overlap = 0.0
    max_hand_overlap = 0.0
    incoming_axis_impulse_to_hands = np.zeros(2)
    incoming_axis_impulse_to_backstop = 0.0
    peak_exit_speed = 0.0
    pull_samples = 0
    pull_bilateral_samples = 0
    pull_band_samples = 0
    x_at_pull_start = None
    pull_min_x = None
    pull_end_x = None
    wrench = np.zeros(6)
    dt = model.opt.timestep
    for _ in range(round(SIM_DURATION_S / dt)):
        t = float(data.time)
        pulling = pull_start_s <= t < pull_end_s
        if variant.close:
            data.ctrl[flexion] = np.clip((t - close_s) * COMMAND_SPEED_RAD_S, 0.0, FLEXION_RAD)
        data.xfrc_applied[ball_body, 0] = -PULL_FORCE_N if pulling else 0.0
        mujoco.mj_step(model, data)
        max_ball_x = max(max_ball_x, float(position[0]))
        normal = np.zeros(2)
        force = np.zeros((2, 3))
        moment = np.zeros((2, 3))
        support_normal = 0.0
        backstop_normal = 0.0
        hand_fixture_normal = 0.0
        peak_actuator_effort = max(peak_actuator_effort, float(np.max(np.abs(data.actuator_force))))
        for contact_index, candidate in enumerate(data.contact):
            geom1, geom2 = candidate.geom
            if geom1 == ball_geom:
                other_geom, sign = geom2, 1.0
            elif geom2 == ball_geom:
                other_geom, sign = geom1, -1.0
            else:
                if (geom1 in support_ids and geom_root[geom2] in hand_lookup) or (
                    geom2 in support_ids and geom_root[geom1] in hand_lookup
                ):
                    mujoco.mj_contactForce(model, data, contact_index, wrench)
                    hand_fixture_normal += wrench[0]
                continue
            mujoco.mj_contactForce(model, data, contact_index, wrench)
            if wrench[0] <= 0.0:
                continue
            contact_to_world = candidate.frame.reshape(3, 3).T
            contact_force = sign * (contact_to_world @ wrench[:3])
            if other_geom == stop_id and first_stop_contact_s is None:
                first_stop_contact_s = t
            if other_geom == stop_id:
                max_backstop_overlap = max(max_backstop_overlap, -float(candidate.dist))
                backstop_normal += wrench[0]
                if t < pull_start_s:
                    incoming_axis_impulse_to_backstop += float(contact_force[0]) * dt
            if other_geom in support_ids:
                support_normal += wrench[0]
            root_id = geom_root[other_geom]
            if root_id not in hand_lookup:
                continue
            if first_hand_contact_s is None:
                first_hand_contact_s = t
            max_hand_overlap = max(max_hand_overlap, -float(candidate.dist))
            side = hand_lookup[root_id]
            lever = candidate.pos - data.xpos[palm_ids[side]]
            normal[side] += wrench[0]
            force[side] += contact_force
            moment[side] += np.cross(lever, contact_force) + sign * (contact_to_world @ wrench[3:])
        peak_normal_force = np.maximum(peak_normal_force, normal)
        peak_net_force = np.maximum(peak_net_force, np.linalg.norm(force, axis=1))
        peak_net_moment = np.maximum(peak_net_moment, np.linalg.norm(moment, axis=1))
        peak_support_normal_force = max(peak_support_normal_force, support_normal)
        peak_backstop_normal_force = max(peak_backstop_normal_force, backstop_normal)
        peak_hand_fixture_normal_force = max(peak_hand_fixture_normal_force, hand_fixture_normal)
        if t < pull_start_s and (first_hand_contact_s is not None or first_stop_contact_s is not None):
            peak_exit_speed = max(peak_exit_speed, -float(velocity[0]))
            incoming_axis_impulse_to_hands += force[:, 0] * dt
        if pulling:
            x = float(position[0])
            if x_at_pull_start is None:
                x_at_pull_start = x
            pull_end_x = x
            pull_min_x = x if pull_min_x is None else min(pull_min_x, x)
            pull_samples += 1
            pull_bilateral_samples += int(np.all(normal > 0.1))
            pull_band_samples += int(abs(x) <= 0.05 and abs(position[1]) <= 0.04)
    warning_count = sum(warning.number for warning in data.warning)
    if warning_count or not pull_samples or not np.isfinite(data.qpos).all():
        raise RuntimeError(f"invalid fixture run {variant.name}, {speed=}, {lateral_offset=}")
    if max_ball_x >= BACKSTOP_FACE_X or peak_hand_fixture_normal_force > 0.01:
        raise RuntimeError(f"invalid fixture geometry {variant.name}, {speed=}, {lateral_offset=}")
    bilateral_fraction = pull_bilateral_samples / pull_samples
    in_band_fraction = pull_band_samples / pull_samples
    outward_displacement = x_at_pull_start - pull_min_x
    return {
        "variant": variant.name,
        "incoming_speed_mps": speed,
        "lateral_offset_m": lateral_offset,
        "close_offset_from_nominal_arrival_s": close_offset_s if variant.close else None,
        "close_start_s": close_s if variant.close else None,
        "pull_start_s": pull_start_s,
        "first_hand_contact_s": first_hand_contact_s,
        "first_backstop_contact_s": first_stop_contact_s,
        "peak_actuator_effort_nm": peak_actuator_effort,
        "peak_hand_normal_sum_by_side_n": peak_normal_force.tolist(),
        "peak_hand_net_force_by_side_n": peak_net_force.tolist(),
        "peak_hand_contact_moment_about_palm_by_side_nm": peak_net_moment.tolist(),
        "peak_deck_and_backstop_normal_sum_n": peak_support_normal_force,
        "peak_backstop_normal_sum_n": peak_backstop_normal_force,
        "incoming_axis_impulse_to_hands_before_pull_by_side_ns": incoming_axis_impulse_to_hands.tolist(),
        "incoming_axis_impulse_to_backstop_before_pull_ns": incoming_axis_impulse_to_backstop,
        "peak_hand_fixture_interference_normal_sum_n": peak_hand_fixture_normal_force,
        "max_backstop_contact_overlap_m": max_backstop_overlap,
        "max_hand_contact_overlap_m": max_hand_overlap,
        "max_ball_x_m": max_ball_x,
        "peak_outward_speed_before_pull_mps": peak_exit_speed,
        "x_at_pull_start_m": x_at_pull_start,
        "x_at_pull_end_m": pull_end_x,
        "final_ball_speed_mps": float(np.linalg.norm(velocity)),
        "outward_displacement_during_pull_m": outward_displacement,
        "bilateral_contact_fraction_during_pull": bilateral_fraction,
        "capture_band_fraction_during_pull": in_band_fraction,
        "retained_against_pull": bilateral_fraction >= 0.85 and in_band_fraction >= 0.95 and outward_displacement <= 0.03,
    }


def evaluate(urdf: Path) -> dict:
    digest = verify_source_urdf(urdf)
    models = {compliant: make_paired_fixture(urdf, compliant) for compliant in (False, True)}
    results = [
        run_case(models[variant.compliant], variant, speed, offset)
        for speed in INCOMING_SPEEDS_MPS
        for offset in LATERAL_OFFSETS_M
        for variant in VARIANTS
    ]
    late_closure_results = [
        run_case(models[variant.compliant], variant, speed, 0.0, LATE_CLOSE_OFFSET_S)
        for speed in INCOMING_SPEEDS_MPS
        for variant in VARIANTS
        if variant.close
    ]
    return {
        "evidence": "paired fixed-palm MuJoCo fixture with deck, backstop and external pull",
        "upstream_revision": UPSTREAM_REVISION,
        "urdf_sha256": digest,
        "mujoco_version": mujoco.__version__,
        "palm_center_spacing_m": 2 * PALM_HALF_SPACING_M,
        "palm_poses_xyz_m_quat_wxyz": [
            {"xyz_m": [x, y, BALL_CENTER_Z], "quat_wxyz": list(map(float, quat.split()))}
            for x, y, quat in POSES
        ],
        "flexion_rad": FLEXION_RAD,
        "pull_force_n": PULL_FORCE_N,
        "pull_duration_s": PULL_DURATION_S,
        "side_order": list(HAND_SIDES),
        "results": results,
        "late_closure_results": late_closure_results,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("codesign_source", type=Path, help="local root of the pinned upstream co-design repository")
    args = parser.parse_args()
    print(json.dumps(evaluate(args.codesign_source / UPSTREAM_URDF), indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
