"""Exercise the upstream Dextra hand on a fixed MuJoCo test fixture."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import mujoco
import numpy as np

from g1_receiver.dextra import (
    COMMAND_SPEED_RAD_S,
    UPSTREAM_REVISION,
    UPSTREAM_URDF,
    add_position_actuator,
    import_dextra_urdf,
    verify_source_urdf,
)
from g1_receiver.sim import add_flight_scene

TIMESTEP_S = 0.001
FLEXION_TARGET_RAD = 0.50
FIXTURE_BALL_START_M = (0.045, 0.0, 0.65)
FIXTURE_BALL_SPEED_MPS = 0.7


def make_fixture_tree(urdf: Path) -> ET.Element:
    """Keep the URDF's transforms, inertias and separate collision meshes."""
    model = import_dextra_urdf(urdf)
    model.set("model", "dextra_fixed_palm_fixture")
    world = model.find("worldbody")
    palm = world.find("body[@name='palm']")
    palm.set("pos", "0 0 1")
    ET.SubElement(model, "option", timestep=str(TIMESTEP_S), integrator="implicitfast", gravity="0 0 0")
    add_flight_scene(model, world, FIXTURE_BALL_START_M)

    # The imported URDF joint efforts are generic 10 Nm. Use the paper's
    # simulation torque cap and a nominal gain within its randomized range.
    actuators = ET.SubElement(model, "actuator")
    for joint in palm.iter("joint"):
        add_position_actuator(actuators, joint)
    if len(actuators) != 20:
        raise ValueError(f"expected 20 Dextra joints, found {len(actuators)}")
    return model


def run_probe(urdf: Path) -> dict:
    urdf_sha256 = verify_source_urdf(urdf)
    model = mujoco.MjModel.from_xml_string(ET.tostring(make_fixture_tree(urdf), encoding="unicode"))
    ball_geom = model.geom("football_surface").id
    floor_geom = model.geom("floor").id
    backdrop_geom = model.geom("backdrop").id
    hand_geom_ids = set(range(model.ngeom)) - {floor_geom, backdrop_geom, ball_geom}
    joints = model.actuator_trnid[:, 0]
    joint_qpos = model.jnt_qposadr[joints]
    flexion = np.array([not model.joint(int(i)).name.endswith("_palm_joint") for i in joints])

    data = mujoco.MjData(model)
    mujoco.mj_forward(model, data)
    palm_id = model.body("palm").id
    hand_bodies = model.body_rootid == palm_id
    hand_mass = float(model.body_subtreemass[palm_id])
    hand_com_from_palm = (data.subtree_com[palm_id] - data.xpos[palm_id]).tolist()
    body_com_xy = data.xipos[hand_bodies, :2] - data.xpos[palm_id, :2]
    palm_z_in_principal_axes = data.ximat[hand_bodies].reshape(-1, 3, 3)[:, 2, :]
    hand_inertia_about_palm_z = float(
        np.sum(model.body_inertia[hand_bodies] * palm_z_in_principal_axes**2)
        + model.body_mass[hand_bodies] @ np.sum(body_com_xy**2, axis=1)
    )
    initial_self_contacts = sum(
        set(contact.geom) <= hand_geom_ids for contact in data.contact
    )
    initial_positions = data.qpos[joint_qpos].copy()
    time_to_90pct_s = None
    peak_actuator_effort = 0.0
    for step in range(500):
        command = min(FLEXION_TARGET_RAD, COMMAND_SPEED_RAD_S * (step + 1) * TIMESTEP_S)
        data.ctrl[flexion] = command
        mujoco.mj_step(model, data)
        flexion_motion = (data.qpos[joint_qpos] - initial_positions)[flexion]
        peak_actuator_effort = max(peak_actuator_effort, float(np.max(np.abs(data.actuator_force))))
        if time_to_90pct_s is None and np.min(flexion_motion) >= 0.9 * FLEXION_TARGET_RAD:
            time_to_90pct_s = float(data.time)
    closure_warnings = sum(warning.number for warning in data.warning)

    # Run a separate contact check from the open pose. The fixture suppresses
    # gravity so the ball follows a repeatable line towards the fixed palm.
    mujoco.mj_resetData(model, data)
    ball_dof = model.joint("football_free").dofadr[0]
    data.qvel[ball_dof + 2] = FIXTURE_BALL_SPEED_MPS
    first_contact_s = None
    peak_normal_force = 0.0
    contact_links = set()
    wrench = np.zeros(6)
    for _ in range(800):
        mujoco.mj_step(model, data)
        for contact_index, contact in enumerate(data.contact):
            ids = set(contact.geom)
            if ball_geom not in ids:
                continue
            others = (ids - {ball_geom}) & hand_geom_ids
            if not others:
                continue
            if first_contact_s is None:
                first_contact_s = float(data.time - model.opt.timestep)
            (geom_id,) = others
            contact_links.add(model.body(int(model.geom_bodyid[geom_id])).name)
            mujoco.mj_contactForce(model, data, contact_index, wrench)
            peak_normal_force = max(peak_normal_force, float(wrench[0]))

    impact_warnings = sum(warning.number for warning in data.warning)
    if closure_warnings or impact_warnings or time_to_90pct_s is None or peak_normal_force <= 0:
        raise RuntimeError("Dextra fixture failed to exercise flexion and ball contact cleanly")
    return {
        "model": "House of Dextra lego_hand_v2, fixed palm",
        "urdf_sha256": urdf_sha256,
        "mujoco_version": mujoco.__version__,
        "hand_joints": model.nu,
        "hand_meshes": model.nmesh,
        "hand_geoms": len(hand_geom_ids),
        "hand_collision_geoms": sum(bool(model.geom_contype[geom]) for geom in hand_geom_ids),
        "hand_mass_as_modeled_kg": hand_mass,
        "open_hand_center_of_mass_from_palm_m": hand_com_from_palm,
        "open_hand_inertia_about_palm_z_kg_m2": hand_inertia_about_palm_z,
        "initial_hand_self_contacts": initial_self_contacts,
        "flexion_target_rad": FLEXION_TARGET_RAD,
        "flexion_minimum_travel_at_0_5_s_rad": float(min(flexion_motion)),
        "flexion_maximum_travel_at_0_5_s_rad": float(max(flexion_motion)),
        "all_flexion_joints_reach_90pct_target_s": time_to_90pct_s,
        "peak_actuator_effort_during_flexion_nm": peak_actuator_effort,
        "ball_fixture_speed_mps": FIXTURE_BALL_SPEED_MPS,
        "ball_first_contact_s": first_contact_s,
        "ball_contact_links": sorted(contact_links),
        "ball_peak_single_contact_normal_force_n": peak_normal_force,
        "ball_end_velocity_mps": data.qvel[ball_dof:ball_dof + 3].tolist(),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("codesign_source", type=Path, help="local root of the upstream co-design repository")
    args = parser.parse_args()
    urdf = args.codesign_source / UPSTREAM_URDF
    if not urdf.is_file():
        parser.error(f"missing source URDF {urdf}")
    print(json.dumps(run_probe(urdf), indent=2))


if __name__ == "__main__":
    main()
