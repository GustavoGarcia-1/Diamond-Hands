"""Bounded lower-cup fixed-QB aim/closure screen; posthoc metrics never control."""
from pathlib import Path
from copy import deepcopy
from types import SimpleNamespace
import argparse,json,traceback
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
import mujoco
import probe_go_cup as runner
from g1_receiver.aero import make_aero_scene
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
from g1_receiver._vendor.g1_runtime.pool.wbc import BODY_NAMES
from g1_receiver.catch_form import CatchFormEvaluator

def summarize(trial,source):
 arrays=np.load(trial/'trace.npz');c=arrays['contact'];report=json.loads((trial/'report.json').read_text());dt=report['physics_step_s'];bad=(c[:,4]!=0)|(c[:,5]>1e-9)|(c[:,12:15].max(1)>1e-9);idx=np.flatnonzero(bad);cut=int(idx[0])if len(idx)else len(c);bands={}
 for name,left,right in [('strict_tip_palm',c[:,6]+c[:,7],c[:,9]+c[:,10]),('native_finger_links',c[:,6:9].sum(1),c[:,9:12].sum(1))]:
  mask=(left>=.1)&(right>=.1);mask[cut:]=False;e=np.flatnonzero(np.diff(np.r_[False,mask,False]));periods=[dict(start_s=float(c[s,0]),end_s=float(c[t-1,0]+dt),duration_s=float(c[t-1,0]-c[s,0]+dt))for s,t in zip(e[::2],e[1::2])];bands[name]=max(periods,key=lambda z:z['duration_s'],default=dict(start_s=None,end_s=None,duration_s=0.))
 model=mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT,source));fk=CatchFormEvaluator(model,list(BODY_NAMES));enc=np.array([model.joint(n).qposadr[0]for n in BODY_NAMES]);base=model.joint('floating_base_joint').qposadr[0];v=np.load(trial/'view.npz');original_tip=report['strict_score']['first_tip_contact_s'];native=np.flatnonzero(c[:,6:12].sum(1)>1e-9);tip=float(c[native[0],0])if len(native)else original_tip;start=bands['native_finger_links']['start_s'];form=[];entry=[]
 for t,q in zip(v['timestamps_s'],v['qpos']):
  if tip is None or t<tip or t>max(tip+.25,(start or tip)+.75):continue
  metrics=fk.evaluate(SimpleNamespace(timestamp=float(t),joint_position=q[enc],imu_quat_wxyz=q[base+3:base+7]))['metrics'];row=[float(t),*metrics['palm_up_cos'],*metrics['palm_face_height_above_shoulders_m']]
  if t<=tip+.25:entry.append(row)
  if start is not None and start<=t<=start+.75:form.append(row)
 def stats(rows):
  if not rows:return None
  r=np.array(rows);return dict(samples=len(r),palm_up_min=r[:,1:3].min(0).tolist(),palm_up_mean=r[:,1:3].mean(0).tolist(),face_above_shoulders_min_m=r[:,3:5].min(0).tolist(),face_above_shoulders_max_m=r[:,3:5].max(0).tolist())
 motion=arrays['motion'];velocity=np.gradient(motion[:,1:3],motion[:,0],axis=0);forward=(velocity*np.column_stack((np.cos(motion[:,5]),np.sin(motion[:,5])))).sum(1);after=motion[:,0]>=tip if tip is not None else np.zeros(len(motion),bool);minimum_forward=float(forward[after].min())if after.any()else None
 hold=stats(form);entry_stats=stats(entry);qualified=bool(bands['native_finger_links']['duration_s']>=.75 and not bad.any()and hold and min(hold['palm_up_min'])>=.6 and max(hold['face_above_shoulders_max_m'])<=.12 and report['minimum_upright_cosine']>=.9)
 qualified150=bool(bands['native_finger_links']['duration_s']>=.75 and not bad.any()and hold and min(hold['palm_up_min'])>=.6 and max(hold['face_above_shoulders_max_m'])<=.15 and report['minimum_upright_cosine']>=.9)
 return dict(preliminary_native_region_score_only=True,requires_1khz_anatomical_surface_confirmation=True,first_tip_s=original_tip,first_native_hand_s=tip,first_nonhand_support_s=None if cut==len(c)else float(c[cut,0]),whole_episode_clean=bool(not bad.any()),bands=bands,entry_form=entry_stats,hold_first750ms_form=hold,qualified_lower_palms_up_120mm=qualified,qualified_lower_palms_up_150mm=qualified150,minimum_upright_cosine=report['minimum_upright_cosine'],minimum_posthand_body_forward_speed_mps=minimum_forward,native_band_reaches_finish=bool(bands['native_finger_links']['end_s']is not None and bands['native_finger_links']['end_s']>=c[-1,0]-.002),maximum_stem_error_m=report['max_stem_error_m'],peak_nonhand_n=report['strict_score']['peak_nonhand_body_normal_force_n'],legacy_short=report['quarterback_pass_score'],final_retention_original=report['strict_score']['retention'])

def execute(job):
 root,profile,source,amp,index,parameters=job;out=root/f'case-{index:02d}';profile=deepcopy(profile);z,curl,arm=parameters;play=profile['play'];play['quarterback_target_m'][2]+=z;play['field_catch_window_m'][2]+=z;play['grip_actuation_delay_s']=curl;play['grasp_joint_lead_s']=curl-arm;path=root/f'profile-{index:02d}.json';path.write_text(json.dumps(profile,indent=2)+'\n')
 try:
  args=runner.build_parser().parse_args(['--source',str(source),'--amp-source',str(amp),'--profile',str(path),'--output',str(out),'--walk-speed','1','--handoff-depth','1.3','--initial-yaw','-.7','--duration',str(profile.get('_experiment_duration_s',7.0))]);runner.run(args);result=summarize(out,source)
 except BaseException as e:result=dict(error=repr(e),traceback=traceback.format_exc())
 result.update(case=index,aim_z_delta_m=z,curl_delay_s=curl,arm_delay_s=arm,profile=str(path));(root/f'score-{index:02d}.json').write_text(json.dumps(result,indent=2)+'\n');return result

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for n in ['source','amp-source','profile','output']:p.add_argument('--'+n,type=Path,required=True)
 p.add_argument('--workers',type=int,default=2);a=p.parse_args()
 if not 1<=a.workers<=2:raise ValueError('one or two workers only')
 a.output.mkdir(parents=True,exist_ok=False);profile=json.loads(a.profile.read_text());parameters=[(z,curl,arm)for z in (-.02,-.04,-.06)for curl in (0.,.08,.16)for arm in (.04,.10)];jobs=[(a.output,profile,a.source,a.amp_source,i,v)for i,v in enumerate(parameters)];rows=[]
 with ProcessPoolExecutor(max_workers=a.workers)as pool:
  for future in as_completed([pool.submit(execute,j)for j in jobs]):
   row=future.result();rows.append(row);(a.output/'summary.json').write_text(json.dumps(sorted(rows,key=lambda x:x['case']),indent=2)+'\n');print(json.dumps(row),flush=True)
if __name__=='__main__':main()
