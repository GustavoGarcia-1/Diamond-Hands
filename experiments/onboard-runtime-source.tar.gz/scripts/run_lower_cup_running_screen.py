"""Matched seven-second no-ball AMP tests using the verified lower ready pose."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('source','amp-source','profile'):
        p.add_argument('--'+name,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
    cases=[('ready-reference',False,0.),('lower',True,0.),('lower-half-centered',True,.5),('lower-centered',True,1.)]
    (a.output/'protocol.json').write_text(json.dumps({
        'scope':'No-ball locomotion only; no grasp/catch claim',
        'eligibility':{'duration_s':7.,'minimum_upright_cosine':.90,
                       'maximum_surveyed_stem_error_m':.5,'minimum_forward_speed_mps':.8,
                       'minimum_recurrent_flights':2,'minimum_flight_clearance_m':.005,
                       'minimum_flight_duration_s':.025},
        'cases':cases,'profile':a.profile,
        'fixed':'Same AMP checkpoint, reset-only yaw -.7rad, gains, route, speed command and simulation; no truth enters control',
        'centering':'Subtract known upper target offset/rate from measured arm encoder observation only, optional frozen-policy adaptation; no learning'
    },indent=2)+'\n')
    def run(spec):
        label,raised,centering=spec
        cmd=[sys.executable,'scripts/probe_amp_high_cup.py','--source',a.source,'--amp-source',a.amp_source,
             '--profile',a.profile,'--output',str(a.output/label),'--centering',str(centering)]
        if raised:cmd.append('--raise-cup')
        with (a.output/(label+'.log')).open('w') as log:
            result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=120)
        report=a.output/label/'report.json'
        return dict(case=label,exit_code=result.returncode,command=cmd,
                    report=json.loads(report.read_text()) if report.exists() else None)
    with ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(run,cases))
    (a.output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
    if any(row['exit_code'] for row in rows):raise SystemExit(1)

if __name__=='__main__':main()
