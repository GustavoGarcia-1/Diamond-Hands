"""Measure both Aero hands on the free-base G1 with the official tendon model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import mujoco
import numpy as np

from g1_receiver.aero import (
    DEFAULT_MOUNTS, FINGERTIP_GEOMS, MESH_SET_SHA256, PALM_BODIES,
    UPSTREAM_REVISION, XML_SHA256, aero_ready_joint_targets,
)
from g1_receiver.dextra_physical_eval import DextraContactAudit, TRACE_COLUMNS
from g1_receiver.hand_route_plant import HandRoutePlant
from g1_receiver.runtime import RobotObservation, SkillGoal


def probe(source: Path) -> dict:
    plant = HandRoutePlant(source, hand_model="aero", survey_camera=False)
    try:
        return probe_plant(plant)
    finally:
        plant.close()


def probe_plant(plant: HandRoutePlant) -> dict:
    model, data = plant.model, plant.data
    audit = DextraContactAudit(model, palms=PALM_BODIES, fingertip_geoms=FINGERTIP_GEOMS)
    tip_ids = np.array([[model.geom(name).id for name in names] for names in FINGERTIP_GEOMS])
    palm_ids = np.array([model.body(name).id for name in PALM_BODIES])
    hand = plant.actuation.hand_actuators
    ready = aero_ready_joint_targets(plant.nominal, plant.joint_names)
    hand_bodies = np.array([model.body(int(i)).name.startswith("aero_") for i in model.geom_bodyid])
    hit = [TRACE_COLUMNS.index(f"{side}_tip_normal_n") for side in ("left", "right")]
    stage = {}
    for with_ball in (False, True):
        # Starts the test ball in free flight. All subsequent updates use WBC and tendon commands.
        position = (.50, 0.0, 1.24) if with_ball else (8.0, 4.0, .085)
        plant.reset(release_position_m=position, joint_positions=ready, closure=.75 if with_ball else 0.0)
        snapshots = []
        forceful_interference = np.zeros(1, dtype=int)
        minimum_upright = 1.0

        def record(data):
            for contact in data.contact:
                geom1, geom2 = contact.geom
                if (contact.efc_address >= 0 and contact.dist < -.001
                        and (hand_bodies[geom1] or hand_bodies[geom2])
                        and audit.ball_geom not in (geom1, geom2)):
                    forceful_interference[0] += 1
            if with_ball:
                audit.record(data)

        for tick in range(50):
            observation = RobotObservation(plant.timestamp_s, *plant.observe(), np.zeros(29), None)
            command = plant.wbc.act(observation, SkillGoal(), upper_target=ready)
            closure = .75 if with_ball or tick >= 15 else 0.0
            plant.step(command, closure=closure, post_step=record)
            minimum_upright = min(minimum_upright, float(data.body("pelvis").xmat[8]))
            if tick in (14, 49):
                palm_frame_tips = (data.geom_xpos[tip_ids] - data.xpos[palm_ids][:, None, :]) @ data.xmat[palm_ids].reshape(2, 3, 3)
                snapshots.append((data.actuator_length[hand].copy(), palm_frame_tips))
        traces = audit.trace()
        stage[with_ball] = {
            "warnings": sum(warning.number for warning in data.warning),
            "minimum_upright_cosine": minimum_upright,
            "deep_hand_robot_or_floor_contact_points": int(forceful_interference[0]),
            "tendon_or_angle_change_by_hand": (snapshots[1][0] - snapshots[0][0]).reshape(2, 7).tolist(),
            "max_tip_travel_in_palm_frame_m_by_hand": np.linalg.norm(snapshots[1][1] - snapshots[0][1], axis=2).max(axis=1).tolist(),
            "initial_ball_center_m": position,
            "peak_normal_tip_force_by_hand_n": np.max(traces[:, hit], axis=0).tolist() if with_ball else None,
            "bilateral_force_samples": int(np.count_nonzero(np.all(traces[:, hit] >= 0.10, axis=1))) if with_ball else None,
        }
    if (stage[False]["warnings"] or stage[True]["warnings"]
            or stage[False]["deep_hand_robot_or_floor_contact_points"]
            or min(stage[False]["max_tip_travel_in_palm_frame_m_by_hand"]) <= .04
            or min(stage[True]["peak_normal_tip_force_by_hand_n"]) <= .1
            or not stage[True]["bilateral_force_samples"]):
        raise RuntimeError(f"Aero articulation/contact smoke failed: {stage}")
    return {
        "evidence": "free-base G1 standing and native Aero tendon actuation/contact smoke",
        "mujoco": mujoco.__version__,
        "menagerie_revision": UPSTREAM_REVISION,
        "xml_sha256": XML_SHA256,
        "mesh_set_sha256": MESH_SET_SHA256,
        "body_motor_count": len(plant.body_actuators),
        "hand_motor_count": len(hand),
        "simulated_hand_mount_mass_kg_by_side": [
            float(model.body_subtreemass[model.body(f"aero_{side}_tetheria_mount").id])
            for side in ("left", "right")
        ],
        "joint_couplings": model.neq,
        "tendons": model.ntendon,
        "mounts": [vars(mount) for mount in DEFAULT_MOUNTS],
        "unloaded": stage[False],
        "free_ball": stage[True],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    args = parser.parse_args()
    print(json.dumps(probe(args.source), indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
