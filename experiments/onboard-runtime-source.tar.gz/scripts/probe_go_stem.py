"""Matched fixed-quarterback Go speed and camera-surveyed stem probe."""
import argparse
from dataclasses import fields
import json
from pathlib import Path
import numpy as np
import evaluate_aero_receiver as runner
from g1_receiver.pass_control import PassGrip
from g1_receiver.routes import Route
from g1_receiver.running_policy import AmpRunningPolicy

def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--reference',type=Path,default=Path('reports/quarterback-pass/offset-fixed-controlled/report.json'))
    cli.add_argument('--output',type=Path,required=True)
    cli.add_argument('--source',type=Path,default=Path('/tmp/g1-aero-source'))
    cli.add_argument('--amp-source',type=Path,default=Path('/tmp/g1-pretrained-run-legged'))
    cli.add_argument('--speed',type=float,default=2.)
    cli.add_argument('--stem-gain',type=float,default=0.)
    cli.add_argument('--stem-limit',type=float,default=.35)
    cli.add_argument('--upper-fraction',type=float,default=1.)
    cli.add_argument('--no-pass',action='store_true')
    cli.add_argument('--early-survey',action='store_true')
    cli.add_argument('--closure',type=float)
    cli.add_argument('--hold-scale',type=float,default=1.)
    cli.add_argument('--hold-delay',type=float)
    cli.add_argument('--lateral-trim',type=float,default=0.)
    cli.add_argument('--brake-depth',type=float,default=0.)
    cli.add_argument('--brake-blend',type=float,default=.65)
    cli.add_argument('--stabilize-palms',type=float,default=0.)
    cli.add_argument('--follow-ball',type=float,default=0.)
    cli.add_argument('--velocity-heading-gain',type=float,default=0.)
    cli.add_argument('--stabilize-grasp',type=float,default=0.)
    cli.add_argument('--stabilize-grasp-delay',type=float,default=.18)
    cli.add_argument('--duration',type=float)
    cli.add_argument('--record-poses',action='store_true')
    args=cli.parse_args()
    if args.output.exists(): raise FileExistsError(args.output)
    reference=json.loads(args.reference.read_text())
    settings={k:v for k,v in reference['play'].items() if k in {f.name for f in fields(runner.Play)}}
    settings.update(speed=args.speed,imu_stem_gain=args.stem_gain,imu_stem_limit=args.stem_limit,
                    upper_fraction=args.upper_fraction,lateral_trim=args.lateral_trim,
                    stabilize_palms=args.stabilize_palms,follow_ball_gain=args.follow_ball)
    settings['imu_velocity_heading_gain']=args.velocity_heading_gain
    settings.update(stabilize_grasp=args.stabilize_grasp,
                    stabilize_grasp_delay_s=args.stabilize_grasp_delay)
    if args.duration is not None: settings['finish_s']=args.duration
    if args.no_pass:
        settings.update(release_s=None,quarterback_origin_m=None,quarterback_target_m=None,
                        field_catch_window_m=None,finish_s=6.)
    settings['grip']=PassGrip(**settings['grip'])
    if args.closure is not None:
        settings['closure']=args.closure
        settings['hold_curls']=(args.closure,args.closure)
    if settings.get('hold_offsets_rad') is not None:
        settings['hold_offsets_rad']=tuple(args.hold_scale*v for v in settings['hold_offsets_rad'])
    if args.hold_delay is not None: settings['hold_delay_s']=args.hold_delay
    if args.brake_depth:
        settings.update(brake_x_m=args.brake_depth,brake_blend_s=args.brake_blend,
                        brake_timeout_s=5.1,brake_no_terminal_correction=True,finish_s=7.)
    play=runner.Play(**settings)
    route=Route(play.route,tuple(map(tuple,reference['waypoints_m'])),play.speed)
    cameras={}
    for name,arg in [('pass','pass_camera'),('track','tracking_camera'),('finish','finish_camera')]:
        sensor=reference['camera_surveys'][name]; position=np.asarray(sensor['position_m'])
        cameras[arg]=(position,position+np.asarray(sensor['rotation'])[:,2])
    if args.early_survey:
        cameras['tracking_camera']=((.65,.15,1.37),(4.2,0.,.8))
        cameras['finish_camera']=((5.1,1.5,1.5),(9.1,0.,.82))
    plant=runner.make_plant(args.source,route,**cameras)
    try:
        policy=AmpRunningPolicy(plant.joint_names,plant.joint_ranges,args.amp_source)
        report=runner.run_play(plant,policy,play,route,output=args.output,record=False,
                               record_poses=args.record_poses)
    finally: plant.close()
    with np.load(args.output/'trace.npz') as trace:
        motion=trace['motion']; contact=trace['contact']
    from g1_receiver.in_stride_eval import CONTACT_INDEX,NORMAL_COLUMNS
    longest=0.
    if len(contact):
        normals=contact[:,NORMAL_COLUMNS]
        both=(normals[:,:2].sum(axis=1)>=.1)&(normals[:,3:5].sum(axis=1)>=.1)
        bad=(normals[:,6:].sum(axis=1)>1e-9)|(contact[:,CONTACT_INDEX['ball_floor_contact']]>0)|(contact[:,CONTACT_INDEX['applied_ball_load']]>0)
        badidx=np.flatnonzero(bad)
        if len(badidx):both[badidx[0]:]=False
        edges=np.flatnonzero(np.diff(np.r_[False,both,False]));longest=float((edges[1::2]-edges[::2]).max(initial=0)*.001)
    selected=motion[motion[:,0]<=4.54]
    steady=selected[selected[:,0]>=2.]
    result={'speed_command_mps':args.speed,'stem_gain':args.stem_gain,
            'upper_fraction':args.upper_fraction,'no_pass':args.no_pass,'early_survey':args.early_survey,
            'lateral_trim':args.lateral_trim,
            'longest_clean_bilateral_whole_trace_s':longest,
            'max_abs_stem_error_m':float(np.abs(selected[:,2]).max()),
            'final_xy_m':selected[-1,1:3].tolist(),
            'mean_forward_speed_after_2s_mps':float((steady[-1,1]-steady[0,1])/(steady[-1,0]-steady[0,0])) if len(steady)>1 else None,
            'minimum_upright':float(selected[:,4].min()),'duration_s':float(motion[-1,0]),
            'receive':report.get('quarterback_pass_score'),'running':report.get('running_score')}
    (args.output/'stem-score.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
if __name__=='__main__': main()
