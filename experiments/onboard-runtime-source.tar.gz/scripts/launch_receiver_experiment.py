"""Snapshot current Python sources and start one bounded job on the existing worker."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import tarfile

from antioch.client import Client, targeting
from antioch.client.service import copy_path
from antioch.transport import exit_code_of

ROOT = Path(__file__).resolve().parents[1]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run-id', required=True)
    p.add_argument('--receipt', type=Path, required=True)
    group = p.add_mutually_exclusive_group(required=True)
    group.add_argument('--module')
    group.add_argument('--script')
    p.add_argument('--input', type=Path, action='append', default=[])
    p.add_argument('--wall-seconds', type=int, default=1800)
    p.add_argument('arguments', nargs=argparse.REMAINDER)
    args = p.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9_-]+', args.run_id) or not 1 <= args.wall_seconds <= 7200:
        p.error('require a safe unique run ID and a bounded duration up to 7200 seconds')
    if args.receipt.exists():
        raise FileExistsError(args.receipt)
    files = sorted(set([f for base in ('src', 'scripts') for f in (ROOT/base).rglob('*.py')
                        if '__pycache__' not in f.parts] + [x.resolve() for x in args.input]))
    hashes = {str(f.relative_to(ROOT)): hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
    args.receipt.parent.mkdir(parents=True, exist_ok=True)
    archive = args.receipt.with_suffix('.source.tar.gz')
    with tarfile.open(archive, 'x:gz') as tar:
        for name in hashes:
            tar.add(ROOT/name, arcname=name)
    archive_hash = hashlib.sha256(archive.read_bytes()).hexdigest()
    session = json.loads((ROOT/'reports/tmux-setup.json').read_text())['session']
    base = '/workspace/g1-receiver-runs/' + args.run_id
    staged = '/workspace/g1-receiver-tmux-20261113'
    c = Client()
    resolved = targeting.resolve_session(c, session=session, any_project=True, fresh=True)
    with targeting.attach_agent(c, resolved.session, 'sim') as agent:
        def run(command):
            result = agent.run(command, cwd='/tmp', timeout=90)
            if exit_code_of(result) != 0:
                raise RuntimeError(result.stderr.decode())
            return result.stdout.decode()
        run(['python3', '-c',
             'import pathlib,shutil,sys;b=pathlib.Path(sys.argv[1]);b.mkdir();'
             '(b/"artifacts").mkdir();shutil.copytree(sys.argv[2],b/"source")', base, staged])
        remote_archive = base + '/source-overlay.tar.gz'
        transfer = '/workspace/project/' + args.run_id + '-source-overlay.tar.gz'
        copy_path(agent, ROOT, local=archive.resolve(), remote=transfer,
                  download=False, cwd='/tmp', warn=lambda _: None)
        run(['mv', transfer, remote_archive])
        verify = '''import hashlib,json,pathlib,sys,tarfile
b=pathlib.Path(sys.argv[1]);p=b/'source-overlay.tar.gz'
assert hashlib.sha256(p.read_bytes()).hexdigest()==sys.argv[2]
with tarfile.open(p) as t:t.extractall(b/'source',filter='data')
for name,digest in json.loads(sys.argv[3]).items():
 assert hashlib.sha256((b/'source'/name).read_bytes()).hexdigest()==digest,name
print('Verified current source overlay')
'''
        run(['python3', '-c', verify, base, archive_hash, json.dumps(hashes)])
        replacements = {'{OUTPUT}': base+'/artifacts', '{ROOT}': base+'/source',
                        '{SOURCE}': '/workspace/g1-receiver-runs/out-scrimmage-20261113/source/aero-source',
                        '{AMP}': '/workspace/g1-receiver-runs/out-scrimmage-20261113/amp'}
        arguments = args.arguments[1:] if args.arguments[:1] == ['--'] else args.arguments
        arguments = [__import__('functools').reduce(lambda v, kv: v.replace(*kv),
                                                   replacements.items(), s) for s in arguments]
        entry = ['-m', args.module] if args.module else [args.script]
        config = {'wall_seconds': args.wall_seconds, 'snapshot_sha256': archive_hash,
                  'command': ['/workspace/g1-receiver-runs/receiver-uniform173-supervised-20261111/.venv/bin/python',
                              *entry, *arguments]}
        run(['python3', '-c', 'import pathlib,sys;pathlib.Path(sys.argv[1]).write_text(sys.argv[2])',
             base+'/launch.json', json.dumps(config)])
        handle = agent.exec(['python3', base+'/source/scripts/remote_worker.py', base],
                            cwd='/tmp', timeout_s=30, drop_unread=True).handle
        receipt = {'session': session, 'remote_root': base, 'command_handle': handle,
                   'launch': config, 'inputs': hashes, 'base_snapshot': 'reports/tmux-setup.json',
                   'source_archive': str(archive), 'source_archive_sha256': archive_hash}
        args.receipt.write_text(json.dumps(receipt, indent=2)+'\n')
        print(json.dumps({k: receipt[k] for k in ('session','remote_root','command_handle')}))


if __name__ == '__main__':
    main()
