"""Measure repeated airborne phases from a pinned G1 running policy in MuJoCo."""

from __future__ import annotations

import argparse
from hashlib import sha256
import json
from pathlib import Path

import mujoco
import numpy as np

from g1_receiver.dextra import dextra_ready_joint_targets
from g1_receiver.aero import aero_ready_joint_targets
from g1_receiver.hand_route_plant import HandRoutePlant
from g1_receiver.locomotion import cradle_joint_targets
from g1_receiver.running_policy import AmpRunningPolicy, CHECKPOINT_SHA256, CONFIG_SHA256, CONTROL_PERIOD_S, UPSTREAM_REVISION
from g1_receiver.running_catch_eval import FootContactRecorder
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT, RobotObservation, SkillGoal
from g1_receiver.training import _plant_xml


class BarePlant:
    def __init__(self):
        self.model = mujoco.MjModel.from_xml_string(_plant_xml(DEFAULT_RUNTIME_ROOT))
        self.data = mujoco.MjData(self.model)
        joints = self.model.actuator_trnid[:, 0]
        self.joint_names = [self.model.joint(int(joint)).name for joint in joints]
        self.joint_ranges = self.model.jnt_range[joints]
        self.qpos = self.model.jnt_qposadr[joints]
        self.position_sensor = self._sensor_ids("encoder_q")
        self.velocity_sensor = self._sensor_ids("encoder_dq")
        self.quat_sensor = self._sensor_slice("receiver_orientation")
        self.gyro_sensor = self._sensor_slice("receiver_gyro")
        self.base = int(self.model.joint("floating_base_joint").qposadr[0])
        self.ball = int(self.model.joint("football_free").qposadr[0])
        self.substeps = round(CONTROL_PERIOD_S / self.model.opt.timestep)

    def _sensor_ids(self, prefix):
        return np.array([self.model.sensor(f"pilot_{prefix}_{index}").adr[0] for index in range(29)])

    def _sensor_slice(self, name):
        sensor = self.model.sensor(name)
        return slice(sensor.adr[0], sensor.adr[0] + sensor.dim[0])

    @property
    def timestamp_s(self):
        return float(self.data.time)

    def reset(self, *, joint_positions):
        mujoco.mj_resetData(self.model, self.data)
        self.data.qpos[self.qpos] = joint_positions
        self.data.qpos[self.base:self.base + 7] = (0., 0., .79, 1., 0., 0., 0.)
        self.data.qpos[self.ball:self.ball + 3] = (18., 12., .085)
        mujoco.mj_forward(self.model, self.data)

    def observe(self):
        return tuple(self.data.sensordata[index].copy() for index in (self.position_sensor, self.velocity_sensor, self.quat_sensor, self.gyro_sensor))

    def step(self, command, *, post_step):
        for _ in range(self.substeps):
            q, dq, _, _ = self.observe()
            torque = command.kp * (command.target_position - q) - command.kd * dq
            self.data.ctrl[:] = np.clip(torque, *self.model.actuator_ctrlrange.T)
            mujoco.mj_step(self.model, self.data)
            post_step(self.data)
        mujoco.mj_forward(self.model, self.data)

    def close(self):
        pass


def run(plant, policy, speed, duration, arm_fraction, settle_s, yaw_gain, lateral_trim, hand_model, heading_rad,
        shoulder_pitch_offset=0., viewer=None):
    model, data = plant.model, plant.data
    policy.reset()
    nominal = policy.nominal.copy()
    posture = {"bare": cradle_joint_targets, "dextra": dextra_ready_joint_targets,
               "aero": aero_ready_joint_targets}[hand_model]
    upper = posture(nominal, plant.joint_names)
    for side in ("left", "right"):
        upper[plant.joint_names.index(f"{side}_shoulder_pitch_joint")] += shoulder_pitch_offset
    nominal[policy.arm_indices] += arm_fraction * (upper[policy.arm_indices] - nominal[policy.arm_indices])
    plant.reset(joint_positions=nominal)
    pelvis = data.body("pelvis")
    floor = model.geom("floor").id
    robots = model.body_rootid[model.geom_bodyid] == pelvis.id
    geom_side = np.zeros(model.ngeom, dtype=int)
    for side, name in ((1, "left"), (2, "right")):
        geom_side[model.geom_bodyid == model.body(f"{name}_ankle_roll_link").id] = side
    samples = []
    wrench = np.zeros(6)
    feet = FootContactRecorder(model)
    images = []
    image_times = []
    if viewer is not None:
        camera = mujoco.MjvCamera()
        camera.azimuth, camera.elevation, camera.distance = 103., -10., 2.85

    def audit(state):
        feet.record(state)
        support = np.zeros(3, dtype=bool)
        for index, contact in enumerate(state.contact):
            a, b = contact.geom
            other = b if a == floor else (a if b == floor else -1)
            if other >= 0 and robots[other]:
                mujoco.mj_contactForce(model, state, index, wrench)
                if wrench[0] >= .01:
                    support[geom_side[other]] = True
        samples.append((state.time, *pelvis.xpos, pelvis.xmat[8], *support))

    for tick in range(round(duration / CONTROL_PERIOD_S)):
        now = plant.timestamp_s
        velocity = min(speed, 1.8 * max(0., now - settle_s))
        observation = RobotObservation(now, *plant.observe(), np.zeros(29), None)
        w, x, y, z = observation.imu_quat_wxyz
        yaw = np.arctan2(2. * (w * z + x * y), 1. - 2. * (y * y + z * z))
        heading_error = np.arctan2(np.sin(heading_rad - yaw), np.cos(heading_rad - yaw))
        yaw_rate = np.clip(yaw_gain * heading_error, -.75, .75)
        command = policy.act(observation, SkillGoal(base_velocity=np.array([velocity, lateral_trim * velocity / speed, yaw_rate])),
                             upper_target=upper, arm_override_fraction=arm_fraction)
        plant.step(command, post_step=audit)
        if viewer is not None and tick % 2 == 1:
            camera.lookat[:] = (*pelvis.xpos[:2], .76)
            viewer.update_scene(data, camera=camera)
            images.append(viewer.render())
            image_times.append(plant.timestamp_s)
        if not np.isfinite(data.qpos).all() or pelvis.xpos[2] < .45 or pelvis.xmat[8] < .5:
            break
    rows = np.array(samples)
    foot_trace = feet.arrays()
    steady_mask = rows[:, 0] >= settle_s + speed / 1.8 + .40
    steady = rows[steady_mask]
    contact = foot_trace["foot_floor_contact"][steady_mask]
    airborne = ~foot_trace["robot_floor_contact"][steady_mask]
    clear = np.all(foot_trace["sole_clearance_m"][steady_mask] >= .005, axis=1)
    edges = np.flatnonzero(np.diff(np.r_[False, airborne, False]))
    bursts = []
    qualifying = []
    for start, end in zip(edges[::2], edges[1::2], strict=True):
        if start == 0 or end == len(steady):
            continue
        before, after = contact[start - 1], contact[end]
        if before.sum() == after.sum() == 1 and not np.array_equal(before, after):
            changes = np.flatnonzero(np.diff(np.r_[False, clear[start:end], False]))
            contiguous = (changes[1::2] - changes[::2]).max(initial=0) * model.opt.timestep
            bursts.append(contiguous)
            if contiguous >= .025:
                qualifying.append({"takeoff_s": float(steady[start, 0]), "both_soles_clear_s": float(contiguous)})
    bursts = np.asarray(bursts)
    velocity = float((steady[-1, 1] - steady[0, 1]) / (steady[-1, 0] - steady[0, 0])) if len(steady) > 1 else None
    warnings = sum(warning.number for warning in data.warning)
    report = {
        "command_mps": speed, "arm_override_fraction": arm_fraction, "settle_s": settle_s,
        "elapsed_s": float(rows[-1, 0]), "forward_displacement_m": float(rows[-1, 1] - rows[0, 1]),
        "lateral_displacement_m": float(rows[-1, 2] - rows[0, 2]),
        "peak_abs_lateral_displacement_m": float(np.max(np.abs(rows[:, 2] - rows[0, 2]))),
        "imu_yaw_feedback_gain": yaw_gain, "heading_rad": heading_rad, "lateral_trim_mps": lateral_trim,
        "shoulder_pitch_offset_rad": shoulder_pitch_offset,
        "steady_mean_forward_speed_mps": velocity, "minimum_pelvis_height_m": float(rows[:, 3].min()),
        "minimum_upright_cosine": float(rows[:, 4].min()), "warning_count": warnings,
        "full_horizon": bool(np.isclose(rows[-1, 0], duration)),
        "steady_nonfoot_floor_contact_s": float(np.count_nonzero(steady[:, 5]) * model.opt.timestep),
        "steady_airborne_phases_at_least_20ms_s": bursts[bursts >= .02].tolist(),
        "steady_airborne_phases_at_least_25ms": qualifying,
        "steady_airborne_fraction": float(airborne.mean()) if len(airborne) else None,
    }
    report["sustained_airborne_running"] = bool(report["full_horizon"] and not warnings and velocity is not None
                                                and velocity >= .8 and report["steady_nonfoot_floor_contact_s"] == 0.
                                                and np.count_nonzero(bursts >= .02) >= 3)
    return report, rows, foot_trace, images, image_times


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("upstream_checkout", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--codesign-source", type=Path)
    parser.add_argument("--aero-source", type=Path)
    parser.add_argument("--speeds", nargs="+", type=float, default=[1.2, 1.6, 2., 2.4])
    parser.add_argument("--arm-fractions", nargs="+", type=float, default=[0.])
    parser.add_argument("--duration", type=float, default=6.)
    parser.add_argument("--settle", type=float, default=.4)
    parser.add_argument("--yaw-gain", type=float, default=0., help="hold initial field heading from IMU yaw")
    parser.add_argument("--lateral-trims", type=float, nargs="+", default=[0.])
    parser.add_argument("--headings", type=float, nargs="+", default=[0.])
    parser.add_argument("--shoulder-pitch-offset", type=float, default=0.)
    parser.add_argument("--record", action="store_true")
    args = parser.parse_args()
    if args.codesign_source is not None and args.aero_source is not None:
        parser.error("select either Dextra or Aero hands")
    if (not all(0 < speed <= 2.5 for speed in args.speeds)
            or not all(0 <= fraction <= 1 for fraction in args.arm_fractions)
            or not 0 <= args.settle <= 2 or not 3 <= args.duration <= 12 or not 0 <= args.yaw_gain <= 8
            or not all(-1 <= trim <= 1 for trim in args.lateral_trims)
            or not all(-np.pi <= heading <= np.pi for heading in args.headings)
            or not -.4 <= args.shoulder_pitch_offset <= .4):
        parser.error("invalid speed, duration, settle or override")
    args.output.mkdir(parents=True, exist_ok=False)
    if args.aero_source is not None:
        hand_model = "aero"
        plant = HandRoutePlant(args.aero_source, survey_camera=False, hand_model=hand_model)
    elif args.codesign_source is not None:
        hand_model = "dextra"
        plant = HandRoutePlant(args.codesign_source, survey_camera=False)
    else:
        hand_model = "bare"
        plant = BarePlant()
    policy = AmpRunningPolicy(plant.joint_names, plant.joint_ranges, args.upstream_checkout)
    viewer = None
    if args.record:
        plant.model.vis.global_.offwidth = 800
        plant.model.vis.global_.offheight = 448
        viewer = mujoco.Renderer(plant.model, height=448, width=800)
    report = {
        "evidence_class": "free_base_simulation_running_development",
        "upstream_revision": UPSTREAM_REVISION, "checkpoint_sha256": CHECKPOINT_SHA256, "config_sha256": CONFIG_SHA256,
        "runner_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
        "hand_model": hand_model, "duration_s": args.duration,
        "physics_step_s": float(plant.model.opt.timestep), "control_period_s": CONTROL_PERIOD_S,
        "airborne_phase_definition": "both soles clear at least 5 mm without a floor constraint, bracketed by opposite single-foot contacts",
        "cases": [],
    }
    try:
        for speed in args.speeds:
            for fraction in args.arm_fractions:
                for trim in args.lateral_trims:
                    for heading in args.headings:
                        row, trace, foot_trace, images, image_times = run(
                            plant, policy, speed, args.duration, fraction, args.settle, args.yaw_gain, trim,
                            hand_model, heading, args.shoulder_pitch_offset, viewer,
                        )
                        trace_path = args.output / f"case-{len(report['cases']):02d}.npz"
                        np.savez_compressed(trace_path, samples=trace, columns=("time_s", "pelvis_x_m", "pelvis_y_m", "pelvis_z_m", "upright_cosine", "nonfoot_floor", "left_foot_floor", "right_foot_floor"), **foot_trace)
                        if images:
                            np.savez_compressed(trace_path.with_stem(f"{trace_path.stem}-video"), rgb=images,
                                                timestamps_s=image_times)
                        report["cases"].append({**row, "trace": trace_path.name, "trace_sha256": sha256(trace_path.read_bytes()).hexdigest()})
                        (args.output / "report.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
                        print(row, flush=True)
    finally:
        if viewer is not None:
            viewer.close()
        plant.close()


if __name__ == "__main__":
    main()
