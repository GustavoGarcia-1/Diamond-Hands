"""Package the compact-hand receiver evidence and pinned MuJoCo assets."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from g1_receiver.aero import MODEL_DIR, _load_source

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = (
    "audit_dextra_moving_release",
    "audit_receiver_all_routes",
    "audit_receiver_checkpoints",
    "audit_receiver_walk_terminal_cap",
    "encode_receiver_replay",
    "evaluate_dextra_in_stride",
    "evaluate_aero_receiver",
    "fetch_aero_hand",
    "probe_g1_aero",
    "probe_aero_amp_braking",
    "probe_aero_amp_slant",
    "probe_aero_out",
    "probe_qb_arm_trim",
    "probe_receiver_running",
    "replay_aero_amp_lead_contact",
    "rescore_aero_receiver",
    "render_aero_stadium",
    "run_out_scrimmage_batch",
    "remote_worker",
)
EVIDENCE = {
    "aero-moving-wrist-optics": ("README.md", "visual_short_pass.py"),
    "aero-moving-wrist-optics/ballistic-backup-0452-recorded": (
        "report.json", "trace.npz", "replay.mp4", "aero-lob-catch.mp4", "catch-frame.png", "manifest.json",
    ),
    "aero-moving-wrist-optics/visual-short-world-recorded": ("report.json", "trace.npz", "replay.mp4"),
    "receiver-amp-aero-imu-short-3.60-clear-optics-early-recorded": (
        "report.json", "trace.npz", "replay.mp4", "offline-score.json",
    ),
    "receiver-amp-run-aero-replay": ("report.json", "case-00.npz", "aero-running-gait.mp4"),
    "aero-amp-route-finishcam": ("report.json", "trace.npz", "route-replay.mp4", "offline-score.json"),
    "aero-amp-braking/first-feedback": ("report.json", "trace.npz", "replay.mp4"),
    "amp-aero-physics-screen": ("README.md", "capture-pinned-401-gen16.json", "reproduce_optical.py"),
    "amp-aero-physics-screen/rgbd-401-hold-proof": (
        "report.json", "trace.npz", "aero-running-catch.mp4", "offline-score.json",
    ),
    "amp-aero-physics-screen/rgbd-401-settled": (
        "report.json", "trace.npz", "aero-run-catch-stop.mp4", "offline-score.json", "catch-frame.png",
    ),
    "amp-aero-retention-search": ("settled-401-handoff.json",),
    "aero-stadium": ("README.md", "stadium-go-catch.mp4", "go-catch.png", "scrimmage-quarterback.mp4",
                     "scrimmage-release.png", "scrimmage-flight.png", "scrimmage-contact.png"),
    "aero-stadium/go-archived-poses": ("report.json", "trace.npz", "view.npz"),
    "aero-stadium/out-development": ("out-route.mp4",),
    "aero-amp-slant": ("TWO-STEP.md",),
    "aero-amp-slant/two-step-contact-recorded": ("report.json", "trace.npz", "replay.mp4"),
    "football-out-approach/short": ("report.json", "trace.npz"),
    "football-out-approach/depth-feedback-3": ("report.json", "trace.npz"),
    "football-out-approach/pass-central": ("report.json", "trace.npz"),
    "out-scrimmage/profiles": ("early.json", "middle.json", "late.json", "simple.json"),
    "quarterback-pass": ("README.md", "camera_throw.py", "offset-controlled-profile.json"),
    "quarterback-pass/offset-fixed-controlled": ("report.json", "trace.npz", "offline-score.json", "view.npz"),
    "quarterback-pass/offset-arm-trim": ("report.json", "trace.npz"),
    "quarterback-pass/offset-arm-trim-align-y": ("report.json", "trace.npz"),
    "quarterback-pass/offset-arm-trim-align-y-recorded": (
        "report.json", "trace.npz", "view.npz", "offline-score.json", "stadium-replay.mp4", "COMPARISON.md",
    ),
}


def package(output, hand_source):
    _load_source(hand_source)
    if hand_source.name != MODEL_DIR:
        hand_source /= MODEL_DIR
    files = {
        path.relative_to(ROOT).as_posix(): path
        for path in (ROOT / "src/g1_receiver").rglob("*")
        if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc"
    }
    project_files = [
        "pyproject.toml", "uv.lock", "docs/aero-running-receiver.md", "docs/aero-integration.md",
        "docs/running-policy.md", "docs/full-size-football-routes.md",
        "scripts/package_aero_receiver.py", "reports/aero-g1-assembly-smoke.json",
        *(f"scripts/{name}.py" for name in SCRIPTS),
        *(f"reports/{folder}/{name}" for folder, names in EVIDENCE.items() for name in names),
    ]
    files.update({name: ROOT / name for name in project_files})
    files.update({f"aero-source/{MODEL_DIR}/{path.relative_to(hand_source)}": path
                  for path in hand_source.rglob("*") if path.is_file()})
    manifest = {}
    with ZipFile(output, "x", ZIP_DEFLATED, compresslevel=6) as archive:
        for name, path in sorted(files.items()):
            if path.is_symlink():
                raise ValueError(f"linked file is outside the artifact contract: {path}")
            data = path.read_bytes()
            manifest[name] = sha256(data).hexdigest()
            archive.writestr(name, data)
        readme = (
            b"# Compact-hand G1 receiver\n\n"
            b"Start with the [verified trials](docs/aero-running-receiver.md). "
            b"The pinned Aero hand assets are in `aero-source/`. "
            b"The running adapter uses an external checkpoint described in [running-policy.md](docs/running-policy.md).\n"
        )
        archive.writestr("README.md", readme)
        manifest["README.md"] = sha256(readme).hexdigest()
        archive.writestr("MANIFEST.json", json.dumps(manifest, indent=2) + "\n")
    with ZipFile(output) as archive:
        if archive.testzip() is not None or any(
            sha256(archive.read(name)).hexdigest() != digest for name, digest in manifest.items()
        ):
            raise ValueError("packaged evidence failed digest verification")


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--output", type=Path, required=True)
    cli.add_argument("--hand-source", type=Path, required=True)
    args = cli.parse_args()
    package(args.output, args.hand_source)
