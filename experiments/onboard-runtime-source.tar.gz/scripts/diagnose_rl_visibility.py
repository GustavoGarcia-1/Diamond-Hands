"""Evaluation-only replay sensor visibility audit; never feeds replay truth to RL."""
import argparse,json
from pathlib import Path
from dataclasses import asdict
import numpy as np,mujoco
from PIL import Image
from evaluate_aero_receiver import fixed_camera
from evaluate_dextra_in_stride import RearMarkerLocalizer
from g1_receiver.hand_route_plant import HandRoutePlant
from g1_receiver.aero_residual_rl import CupSensors
from g1_receiver.runtime import RobotObservation

cli=argparse.ArgumentParser(description=__doc__)
cli.add_argument('--reference',type=Path,default=Path('reports/quarterback-pass/offset-fixed-controlled'))
cli.add_argument('--source',type=Path,default=Path('/tmp/g1-aero-source'))
cli.add_argument('--output',type=Path,required=True)
cli.add_argument('--variant',choices=('initial','overhead-rear'),default='initial')
args=cli.parse_args();args.output.mkdir(parents=True,exist_ok=False)
r=json.loads((args.reference/'report.json').read_text());z=np.load(args.reference/'view.npz');poses={};definitions={}
for name in ('pass','track','finish'):
 s=r['camera_surveys'][name];p=np.array(s['position_m']);definitions[name]=(p.tolist(),(p+np.array(s['rotation'])[:,2]).tolist())
definitions.update(behind_left=((7.,1.,2.8),(10.1,3.4,1.2)),behind_right=((7.,5.6,2.8),(10.1,3.4,1.2)),overhead=((9.8,3.0,4.),(10.,3.4,.9)),near_rear=((8.4,2.1,1.9),(10.2,3.4,1.1)))
if args.variant=='overhead-rear':
 definitions={k:v for k,v in definitions.items() if k in ('pass','track','finish','overhead')}
 definitions.update(overhead_rear=((8.2,3.,3.8),(10.2,3.4,1.)),upper_right=((9.,5.5,3.3),(10.3,3.4,1.)),overhead_late=((10.7,3.,4.),(11.,3.7,1.1)))
def setup(scene):
 backdrop=scene.find("./worldbody/geom[@name='backdrop']")
 if backdrop is not None:backdrop.set('pos','17.6 0 2')
 for name,(p,target) in definitions.items():poses[name]=fixed_camera(scene,name,p,target)
plant=HandRoutePlant(args.source,hand_model='aero',rear_markers=True,scene_setup=setup);plant.cameras.update(poses)
tracker=RearMarkerLocalizer(allow_synthetic_fixture=True,max_range_m=8.)
modes={name:CupSensors(plant.model,plant.joint_names) for name in definitions}
modes.update({name+'_baseline_pose':CupSensors(plant.model,plant.joint_names) for name in definitions if name not in ('pass','track','finish')})
modes.update({name+'_bestpose':CupSensors(plant.model,plant.joint_names) for name in definitions if name not in ('pass','track','finish')})
rows=[];lastbaseline=None
try:
 for t,q in zip(z['timestamps_s'],z['qpos']):
  if t<3.98:continue
  plant.data.qpos[:]=q;plant.data.qvel[:]=0;plant.data.time=float(t);mujoco.mj_forward(plant.model,plant.data)
  obs=RobotObservation(float(t),*plant.observe(),np.zeros(29),None)
  captures={name:plant.capture(name) for name in definitions}
  measured={name:tracker.estimate(*capture) for name,capture in captures.items()}
  if measured['track'] is not None:lastbaseline=measured['track']
  elif measured['finish'] is not None:lastbaseline=measured['finish']
  for name,processor in modes.items():
   camera=name.replace('_baseline_pose','').replace('_bestpose','');frame,survey=captures[camera]
   pose=lastbaseline if name=='pass' or name.endswith('_baseline_pose') else measured[camera]
   if name.endswith('_bestpose'):
    available=[p for p in measured.values() if p is not None and p.z_std_m is not None]
    pose=min(available,key=lambda p:max(float(p.covariance[0,0]),float(p.covariance[1,1]),p.z_std_m**2)) if available else None
   ball=processor.detector.detect(frame,survey)
   processor.update(obs,pose,frame,survey)
   rejection=[]
   if ball is None:rejection.append('ball_missing')
   if pose is None:rejection.append('pose_missing')
   else:
    if not pose.fresh(t,.08):rejection.append('pose_stale')
    if abs(t-pose.timestamp_s)>.04:rejection.append('pose_time_skew')
    if pose.z_m is None or pose.z_std_m is None:rejection.append('pose_no_z')
   if not processor.valid and not rejection:rejection.append('covariance_or_frame_gate')
   rows.append({'time_s':float(t),'mode':name,'ball_detected':ball is not None,'pose_detected_now':measured[camera] is not None,'pose_age_s':None if pose is None else float(t-pose.timestamp_s),'valid':processor.valid,'rejection':rejection,'cup_error_m':processor.e.tolist() if processor.valid else None,'sigma_m':processor.sigma.tolist(),'speed_mps':float(np.linalg.norm(processor.vel)) if processor.velocity_valid else None,'dwell_s':processor.dwell})
  if abs(t-4.56)<.005 or abs(t-4.8)<.005:
   for name,(frame,_) in captures.items():Image.fromarray(frame.rgb).save(args.output/f'{name}-{t:.2f}.png')
 summary={}
 for name,proc in modes.items():
  selected=[x for x in rows if x['mode']==name and 4.5<=x['time_s']<=5.3]
  valid=[x for x in selected if x['valid']]
  summary[name]={'catch_frames':len(selected),'catch_valid':len(valid),'ball_detected':sum(x['ball_detected'] for x in selected),'pose_detected_now':sum(x['pose_detected_now'] for x in selected),'min_cup_distance_m':None if not valid else min(float(np.linalg.norm(x['cup_error_m'])) for x in valid),'max_dwell_s':proc.max_dwell,'rejections':{why:sum(why in x['rejection'] for x in selected) for why in ('ball_missing','pose_missing','pose_stale','pose_time_skew','pose_no_z','covariance_or_frame_gate')}}
 payload={'reference':str(args.reference),'camera_definitions':definitions,'evaluation_method':'Archive qpos only reconstructs rendered sensor scenes; CupSensors sees captured RGB-D, estimated marker pose and encoder/IMU packets only. qvel unavailable, set zero for reconstruction; reward uses causal measured cup displacement history.','summary':summary,'frames':rows}
 (args.output/'audit.json').write_text(json.dumps(payload,indent=2)+'\n');print(json.dumps(summary,indent=2),flush=True)
finally:plant.close()
