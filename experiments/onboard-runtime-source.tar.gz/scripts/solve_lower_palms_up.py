"""Static, independently oriented bilateral Aero IK; never mutates a live plant."""
from pathlib import Path
import argparse,json
import mujoco
import numpy as np
from scipy.optimize import least_squares
from g1_receiver.aero import make_aero_scene
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
from g1_receiver._vendor.g1_runtime.pool.wbc import BODY_NAMES

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--half-gap',type=float,default=.07);p.add_argument('--finger-inward-deg',type=float,default=0.);p.add_argument('--inward-normal-deg',type=float,default=0.);a=p.parse_args()
 model=mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT,a.source));d=mujoco.MjData(model)
 names=list(BODY_NAMES);indices=[names.index(f'{s}_{j}_joint')for s in ('left','right')for j in ('shoulder_roll','shoulder_yaw','shoulder_pitch','elbow','wrist_roll','wrist_pitch','wrist_yaw')]
 adr=np.array([model.joint(names[i]).qposadr[0]for i in indices]);limits=np.array([model.joint(names[i]).range for i in indices]);base=model.joint('floating_base_joint').qposadr[0]

 true_limits=limits.copy()
 # Mechanical joint range alone permits backwards elbows; require a slightly
 # bent positive elbow and outward shoulder roll for this human-form prototype.
 for i,name in enumerate([names[j] for j in indices]):
  if 'elbow' in name: limits[i]=[.25,1.8]
  if name=='left_shoulder_roll_joint': limits[i,0]=max(.05,limits[i,0])
  if name=='right_shoulder_roll_joint': limits[i,1]=min(-.05,limits[i,1])
 d.qpos[:]=model.qpos0;d.qpos[base:base+7]=[0,0,0,1,0,0,0];mujoco.mj_kinematics(model,d)
 shoulder=np.mean([d.body(f'{s}_shoulder_pitch_link').xpos for s in ('left','right')],axis=0)
 theta=np.deg2rad(20);N=np.array([-np.sin(theta),0,np.cos(theta)]);F=np.array([np.cos(theta),0,np.sin(theta)])
 desired=[]
 for side_sign in (1,-1):
  angle=-side_sign*np.deg2rad(a.finger_inward_deg)
  fingers=F*np.cos(angle)+np.cross(N,F)*np.sin(angle)
  normal=N*np.cos(np.deg2rad(a.inward_normal_deg))+np.array([0,-side_sign*np.sin(np.deg2rad(a.inward_normal_deg)),0])
  fingers=fingers-normal*(fingers@normal);fingers/=np.linalg.norm(fingers)
  palm_axis=normal*side_sign
  desired.append(np.column_stack((np.cross(palm_axis,fingers),palm_axis,fingers)))
 faces=[np.array([-.0025,y,.07225])for y in (.017,-.017)]
 def geometry(q):
  d.qpos[adr]=q;mujoco.mj_kinematics(model,d);r=[];c=[]
  for s,off in zip(('left','right'),faces):
   b=d.body('aero_'+s+'_palm');R=b.xmat.reshape(3,3);r.append(R.copy());c.append(b.xpos+R@off)
  return np.array(c),r
 rows=[];rng=np.random.default_rng(173)
 for forward in (.28,.36,.44):
  target=np.array([[forward,a.half_gap,shoulder[2]+.08],[forward,-a.half_gap,shoulder[2]+.08]])
  def residual(q):
   c,r=geometry(q)
   return np.r_[((c-target)/.025).ravel(),*((r[i]-desired[i]).ravel()/1.2 for i in range(2))]
  best=None
  for seed in range(12):
   x=np.clip(model.qpos0[adr] if seed==0 else rng.uniform(limits[:,0],limits[:,1]),limits[:,0]+1e-6,limits[:,1]-1e-6)
   fit=least_squares(residual,x,bounds=(limits[:,0]+1e-6,limits[:,1]-1e-6),max_nfev=350)
   if best is None or np.linalg.norm(fit.fun)<np.linalg.norm(best.fun):best=fit
  c,r=geometry(best.x);normals=np.array([r[0]@np.array([0,1,0]),r[1]@np.array([0,-1,0])]);error=np.linalg.norm(c-target,axis=1)
  pinkies=[]
  for side in ('left','right'):
   bid=model.body(f'aero_{side}_{side}_pinky_f_link').id
   pinkies.append(d.xpos[bid].copy())
  true_margin=float(np.minimum(best.x-true_limits[:,0],true_limits[:,1]-best.x).min())
  rows.append(dict(pinky_mcp_centers_relative_pelvis_m=np.asarray(pinkies).tolist(),pinky_mcp_separation_m=float(np.linalg.norm(pinkies[0]-pinkies[1])),minimum_physical_joint_margin_rad=true_margin,forward_m=forward,target_faces_relative_pelvis_m=target.tolist(),actual_faces_relative_pelvis_m=c.tolist(),position_error_m=error.tolist(),palm_up_cos=normals[:,2].tolist(),normals=normals.tolist(),finger_axes=[R[:,2].tolist()for R in r],arm_order=[names[i]for i in indices],arm_targets_rad=best.x.tolist(),minimum_joint_margin_rad=float(np.minimum(best.x-limits[:,0],limits[:,1]-best.x).min()),feasible_static=bool(max(error)<.02 and min(normals[:,2])>=.707)))
 a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(dict(source_script_sha256=__import__('hashlib').sha256(Path(__file__).read_bytes()).hexdigest(),tolerances=dict(max_face_error_m=.02,min_palm_up_cos=.707,face_height_above_shoulder_m=.08,face_half_gap_m=a.half_gap,finger_inward_deg=a.finger_inward_deg,inward_normal_deg=a.inward_normal_deg,elbow_range_rad=[.25,1.8],outward_shoulder_roll_min_rad=.05),static_only=True,no_dynamic_claim=True,rows=rows),indent=2)+'\n');print(json.dumps(rows))
if __name__=='__main__':main()
