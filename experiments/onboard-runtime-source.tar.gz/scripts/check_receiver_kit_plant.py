"""Run the exported receiver against the published HIM MuJoCo plant on the host."""

from __future__ import annotations

import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys
from time import perf_counter

import mujoco
import numpy as np

from g1_receiver.locomotion import SURVEY_CAMERA_FOV_Y_DEG, SURVEY_CAMERA_POSITION_M, survey_camera_rotation
from g1_receiver.observable import ACTION_SIZE
from g1_receiver.perception import CameraIntrinsics, RGBDFrame, RigidPose
from g1_receiver.receiver_deploy import NumpyReceiverActor, ReceiverController
from g1_receiver.routes import make_route
from g1_receiver.sim import HEIGHT, WIDTH


def run(Plant, exported: Path, receipt: dict, *, neutral_arms: bool) -> dict:
    trial = receipt["trial"]
    route = make_route(trial["route"], scale=trial["route_scale"], speed_mps=.30)
    actor = (lambda _: np.zeros(ACTION_SIZE)) if neutral_arms else NumpyReceiverActor(exported / "actor.npz")
    controller = ReceiverController(actor, route, allow_synthetic_fixture=True)
    plant = Plant(scene=exported / "environment/scene.xml")
    if plant.joint_names != receipt["joint_order"] or plant.joint_names != controller.wbc.names:
        raise ValueError("joint order differs between export, controller and official kit")
    renderer = mujoco.Renderer(plant.model, height=HEIGHT, width=WIDTH)
    focal = HEIGHT / (2 * np.tan(np.deg2rad(SURVEY_CAMERA_FOV_Y_DEG / 2)))
    intrinsics = CameraIntrinsics(focal, focal, (WIDTH - 1) / 2, (HEIGHT - 1) / 2)
    camera_rotation = survey_camera_rotation()
    camera_origin = np.array(SURVEY_CAMERA_POSITION_M)
    ball_geom = plant.model.geom("football_surface").id
    ball_body = plant.model.body("football").id
    route_index = 1
    first_contact = None
    ground_contact = False
    final_support_ticks = 0
    timings = []
    lower, upper = controller.wbc.ranges.T
    max_joint_excess = 0.
    min_upright = 1.
    camera_blind_stop_verified = False
    rng = np.random.default_rng(85178)
    try:
        for tick in range(260):
            now = float(plant.data.time)
            if tick % 2 == 0:
                renderer.update_scene(plant.data, camera="survey_rgbd")
                rgb = renderer.render()
                renderer.enable_depth_rendering()
                try:
                    depth = renderer.render()
                finally:
                    renderer.disable_depth_rendering()
                if rng.random() < trial["dropout_probability"]:
                    depth.fill(0.)
                elif trial["depth_noise_m"]:
                    noise = rng.normal(0., trial["depth_noise_m"])
                    depth = np.where(depth > 0., np.maximum(0., depth + noise), 0.)
                frame = RGBDFrame(now, "camera_optical", rgb, depth, intrinsics)
                survey = RigidPose(now, "camera_optical", "field", camera_rotation, camera_origin,
                                   "synthetic_fixture")
                controller.ingest_rgbd(frame, survey, now_s=now)
            imu = plant.data.sensordata[plant.gyro_adr:plant.gyro_adr + 3]
            started = perf_counter()
            command = controller.tick(now, (plant.q(), plant.dq(), plant.data.xquat[plant.base], imu))
            timings.append((perf_counter() - started) * 1000)
            target = command.target_position
            max_joint_excess = max(max_joint_excess, float(np.max(lower - target)), float(np.max(target - upper)))
            plant.apply({"q": target, "dq": np.zeros(29), "kp": command.kp, "kd": command.kd,
                         "tau": command.feedforward_torque})
            for _ in range(plant.substeps):
                plant.step_physics()
                contacts = {
                    contact.geom2 if contact.geom1 == ball_geom else contact.geom1
                    for contact in plant.data.contact if ball_geom in (contact.geom1, contact.geom2)
                }
                ground_contact |= plant.floor in contacts
                supported = bool(contacts & plant.robot_geoms)
                if supported and first_contact is None:
                    first_contact = float(plant.data.time)
                final_support_ticks = final_support_ticks + 1 if supported else 0
            mujoco.mj_forward(plant.model, plant.data)
            min_upright = min(min_upright, float(plant.data.xmat[plant.base, 8]))
            if route_index < len(route.waypoints):
                start, goal = np.array(route.waypoints[route_index - 1:route_index + 1])
                if np.linalg.norm(plant.data.xpos[plant.base, :2] - goal) <= min(.05, .1 * np.linalg.norm(goal - start)):
                    route_index += 1
            if plant.fallen():
                break
        endpoint_error = float(np.linalg.norm(plant.data.xpos[plant.base, :2] - route.waypoints[-1]))
        final_tol = min(.05, .1 * np.linalg.norm(np.subtract(*route.waypoints[-2:])))
        route_complete = route_index == len(route.waypoints) and endpoint_error <= final_tol
        final_height = float(plant.data.xpos[ball_body, 2])
        support = final_support_ticks * plant.model.opt.timestep
        retained = not ground_contact and support >= 2. and min_upright >= .90 and final_height > .70
        if not neutral_arms:
            # Discard the next frames while keeping the IMU/encoder clock live.
            last_upper = controller.upper.copy()
            for _ in range(25):
                now += plant.dt
                controller.tick(now, (plant.q(), plant.dq(), plant.data.xquat[plant.base], imu))
            camera_blind_stop_verified = (
                not controller.drive.any() and not controller.drive_target.any()
                and np.allclose(controller.upper, last_upper, atol=.18)
            )
        return {
            "commands": len(timings), "command_p95_ms": float(np.quantile(timings, .95)),
            "max_joint_target_excess_rad": max_joint_excess, "fallen": plant.fallen(),
            "first_robot_contact_s": first_contact, "any_floor_contact": ground_contact,
            "final_continuous_support_s": support, "retained": bool(retained),
            "waypoints_reached": route_index - 1, "endpoint_error_m": endpoint_error,
            "route_complete": bool(route_complete),
            "combined": bool(route_complete and retained),
            "stale_camera_stop_checked": camera_blind_stop_verified,
        }
    finally:
        renderer.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--kit", type=Path, required=True)
    parser.add_argument("--export", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    kit = args.kit.resolve()
    manifest = json.loads((kit / "KIT_FILES.json").read_text())
    if any(sha256((kit / name).read_bytes()).hexdigest() != checksum for name, checksum in manifest.items()):
        raise ValueError("public builder kit files differ from their manifest")
    sys.path[:0] = [str(kit / "containers/sim"), str(kit / "robot_safety")]
    from plant import Plant

    receipt = json.loads((args.export / "export.json").read_text())
    for relative, key in (("actor.npz", "actor_sha256"), ("environment/scene.xml", "scene_sha256")):
        if sha256((args.export / relative).read_bytes()).hexdigest() != receipt[key]:
            raise ValueError(f"export hash mismatch: {relative}")
    report = {
        "evidence_class": "host_direct_him_plant_simulation",
        "limitations": ["Direct plant PD path", "No ROS transport or checker handoff", "Synthetic RGB-D"],
        "kit_revision": json.loads((kit / "arena/release.json").read_text())["revision"],
        "export": receipt,
        "learned_arms": run(Plant, args.export, receipt, neutral_arms=False),
        "neutral_arms": run(Plant, args.export, receipt, neutral_arms=True),
    }
    with args.output.open("x") as handle:
        json.dump(report, handle, indent=2, allow_nan=False)
        handle.write("\n")
    print(json.dumps({key: report[key] for key in ("learned_arms", "neutral_arms")}, indent=2))


if __name__ == "__main__":
    main()
