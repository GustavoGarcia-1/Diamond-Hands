"""Build a deterministic source/runtime demo archive from an explicit allowlist."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
VENDOR = Path('src/g1_receiver/_vendor/g1_runtime')
FIXED_FILES = (
    'README.md', 'pyproject.toml', 'uv.lock',
    'docs/checklist.md', 'docs/hardware-qualification.md',
    'docs/learning-contract.md', 'docs/simulation.md',
    'docs/supermimic-adaptation.md', 'docs/antioch-runtime.md',
    'docs/receiver-ppo-repair.md', 'docs/dextra-integration.md',
    'reports/dextra-fixed-palm.json', 'reports/receiver-ppo-guard-smoke-1024/report.json',
    'reports/receiver-fresh-paired-cases.json', 'reports/receiver-fresh-paired-audit.json',
    'reports/receiver-fresh-paired-teacher.json', 'reports/receiver-route-control-development.json',
    'reports/receiver-route-control-extended.json',
    'reports/receiver-hybrid-slant-replay/report.json', 'reports/receiver-hybrid-go-replay/report.json',
    'reports/best-ppo12288-moving-replay/report.json',
    'reports/antioch-final-uniform173/run/manifest.json',
    'reports/antioch-final-uniform173/run/ppo-000012288.zip',
    'reports/perception-validation.json', 'reports/contact-audit.json',
    'reports/antioch-receiver-capacity.json', 'reports/receiver-launch-review.json',
    'reports/receiver-policy-bc-replay/report.json',
    'reports/antioch-receiver-live.json', 'reports/antioch-receiver-launch-plan.json',
    'reports/antioch-receiver-first-attempt.json',
    'reports/antioch-receiver-uniform173-retry.json',
    'reports/antioch-receiver-sgs173-retry.json',
    'reports/antioch-receiver-uniform271-retry.json',
    'reports/visual-slant-diagnostic/visual-moving-catch-comparison.json',
    'reports/moving-contact-audit.json', 'reports/moving-catch-grid.json',
    'reports/ppo-route-pilot/report.json',
    'reports/ppo-route-pilot/uniform-training.json',
    'reports/ppo-route-pilot/sgs-training.json',
    'reports/ppo-route-pilot/uniform.zip', 'reports/ppo-route-pilot/sgs.zip',
    'reports/visual-retention-validation.json',
    'reports/visual-extended/visual-catch-comparison.json',
    'reports/visual-moving-fast/visual-moving-catch-comparison.json',
    'reports/visual-footfalls/visual-moving-catch-comparison.json',
    'reports/visual-go-arrival/visual-moving-catch-comparison.json',
    'reports/visual-go-arrival/visual-moving-catch-02-vision-truth.npz',
    'reports/visual-go-arrival/visual-moving-catch-02-disabled-truth.npz',
    'reports/visual-go-arrival/visual-moving-catch-02-vision-controller.npz',
    'reports/visual-go-arrival/visual-moving-catch-02-disabled-controller.npz',
    'reports/ppo-catch-timing/report.json',
    'reports/ppo-catch-timing/uniform-training.json',
    'reports/ppo-catch-timing/sgs-training.json',
    'reports/ppo-catch-timing/uniform.zip', 'reports/ppo-catch-timing/sgs.zip',
)


def selected_files():
    selected = {Path(name) for name in FIXED_FILES}
    # Only source modules, tests, and named project scripts; never caches or captures.
    for directory in ('src/g1_receiver', 'tests'):
        selected.update(path.relative_to(ROOT) for path in (ROOT/directory).rglob('*.py'))
    selected.update(Path('scripts')/name for name in (
        'package_demo.py', 'validate_perception.py', 'sweep_moving_catch.py',
        'compare_visual_catch.py', 'compare_receiver_route_control.py',
        'probe_dextra_hand.py', 'backup_receiver_run.py'))
    selected.add(VENDOR/'ASSET-MANIFEST.json')
    selected.add(VENDOR/'NOTICE.txt')
    manifest = json.loads((ROOT/VENDOR/'ASSET-MANIFEST.json').read_text())
    for item in manifest['files']:
        relative = Path(item['path'])
        if relative.is_absolute() or '..' in relative.parts:
            raise ValueError('unsafe runtime manifest path')
        path = ROOT/VENDOR/relative
        if hashlib.sha256(path.read_bytes()).hexdigest() != item['sha256']:
            raise ValueError(f'runtime hash mismatch: {relative}')
        selected.add(VENDOR/relative)
    for relative in selected:
        path = ROOT/relative
        if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(ROOT):
            raise ValueError(f'missing or unsafe bundle file: {relative}')
        if any(part.startswith('.') or part == '__pycache__' for part in relative.parts):
            raise ValueError(f'hidden/cache path rejected: {relative}')
    return sorted(selected)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT/'artifacts/g1-receiver-demo.zip')
    args = parser.parse_args()
    contents = {str(path): (ROOT/path).read_bytes() for path in selected_files()}
    metadata = {
        'schema': 'receiver-demo-bundle-v1',
        'status': 'simulation prototype; not a qualified hardware deployment',
        'files': [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                  for name, data in contents.items()],
        'excluded': ['credentials and configuration directories', 'virtual environments',
                     'caches', 'raw camera recordings', 'website build', 'large replay media'],
    }
    contents['BUNDLE-MANIFEST.json'] = (json.dumps(metadata, indent=2)+'\n').encode()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, data in sorted(contents.items()):
            entry = zipfile.ZipInfo('g1-receiver/'+name, date_time=(1980, 1, 1, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, data)
    with zipfile.ZipFile(args.output) as archive:
        assert archive.testzip() is None
        for name, data in contents.items():
            assert archive.read('g1-receiver/'+name) == data
    digest = hashlib.sha256(args.output.read_bytes()).hexdigest()
    args.output.with_suffix(args.output.suffix+'.sha256').write_text(f'{digest}  {args.output.name}\n')
    print(json.dumps({'archive': str(args.output), 'files': len(contents),
                      'bytes': args.output.stat().st_size, 'sha256': digest}, indent=2))


if __name__ == '__main__':
    main()
