"""Fresh ZIP extraction and exact three-route simulation reproduction."""
from __future__ import annotations
import argparse,hashlib,json,os,shutil,stat,subprocess,sys,tempfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path,PurePosixPath
from zipfile import ZipFile
import numpy as np

def sha(data):return hashlib.sha256(data).hexdigest()
def safe(name):
 p=PurePosixPath(name)
 if not name or p.is_absolute() or '..' in p.parts or '\\' in name:raise ValueError(f'unsafe ZIP member {name!r}')
 return p.as_posix()
def differences(a,b,path=''):
 if type(a) is not type(b):return [path or '<root>']
 if isinstance(a,dict):
  result=[]
  for key in sorted(set(a)|set(b)):
   child=f'{path}.{key}' if path else key
   result.extend([child] if key not in a or key not in b else differences(a[key],b[key],child))
  return result
 if isinstance(a,list):
  if len(a)!=len(b):return [path+'.length']
  return [key for i,(x,y)in enumerate(zip(a,b,strict=True))for key in differences(x,y,f'{path}[{i}]')]
 return [] if a==b else [path]

def arrays_equal(a,b):
 if a.shape!=b.shape or a.dtype!=b.dtype:return False
 return bool(np.array_equal(a,b,equal_nan=True)) if a.dtype.kind in 'fc' else bool(np.array_equal(a,b))

def verify(args):
 archive_path=args.zip.resolve();output=args.output.resolve();output.mkdir(parents=True,exist_ok=False);digest=sha(archive_path.read_bytes())
 if args.expected_sha256 is not None:assert digest==args.expected_sha256,'ZIP hash differs from launch receipt'
 checkout=Path(tempfile.mkdtemp(prefix='held-routes-extract-'));result={'zip_sha256':digest,'dependency_environment':sys.prefix,'dependency_installation':'Reused validated environment; all controller source and Aero assets freshly extracted from ZIP','report_normalization_policy':'none unless --allow-profile-path-normalization is explicit; physics arrays are never normalized'}
 try:
  with ZipFile(archive_path) as archive:
   names=archive.namelist();assert len(names)==len(set(names));manifest=json.loads(archive.read('MANIFEST.json'));assert set(names)==set(manifest)|{'MANIFEST.json'};assert archive.testzip() is None
   for info in archive.infolist():
    name=safe(info.filename);assert not stat.S_ISLNK(info.external_attr>>16),'ZIP symlinks forbidden';assert not name.startswith(('.venv/','node_modules/'))
    if name!='MANIFEST.json':assert sha(archive.read(name))==manifest[name],name
   archive.extractall(checkout)
  assert not (checkout/'.venv').exists();(checkout/'.venv').symlink_to(Path(sys.prefix).resolve(),target_is_directory=True);routes=json.loads((checkout/'ROUTES.json').read_text());selected=args.routes or ['go','out','slant'];assert set(selected)<=set(routes);result.update(all_member_hashes_valid=True,member_count=len(names));environment={**os.environ,'MUJOCO_GL':'egl','PYOPENGL_PLATFORM':'egl','OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'}
  def run_route(route):
   config=routes[route];trial=output/route;command=['sh',f'run-{route}.sh',str(args.amp_source.resolve()),str(trial)];row={'command':command,'expected_evidence':config['expected']}
   try:
    controller=(checkout/config['controller']).resolve();proof_env={**environment,'PYTHONPATH':os.pathsep.join([str(controller/'src'),str(controller/'scripts')])};entry=Path(config['entry']).stem;proof_code="import importlib,json,hashlib; g=importlib.import_module('g1_receiver'); p=importlib.import_module("+repr(entry)+"); print(json.dumps({'package_file':g.__file__,'entry_file':p.__file__,'entry_sha256':hashlib.sha256(open(p.__file__,'rb').read()).hexdigest()}))";proof=json.loads(subprocess.check_output([str(checkout/'.venv/bin/python'),'-c',proof_code],cwd=checkout,env=proof_env,text=True,timeout=60));assert Path(proof['package_file']).resolve().is_relative_to(controller/'src');assert Path(proof['entry_file']).resolve()==controller/'scripts'/config['entry'];entry_member=(Path(config['controller'])/'scripts'/config['entry']).as_posix();assert proof['entry_sha256']==manifest[entry_member];row['source_isolation']=proof
    with (output/f'{route}.log').open('w') as log:subprocess.run(command,cwd=checkout,env=environment,stdout=log,stderr=subprocess.STDOUT,timeout=args.trial_timeout_s,check=True)
    expected=checkout/config['expected'];arrays={};npz_hashes={}
    for name in ('trace.npz','view.npz'):
     with np.load(expected/name,allow_pickle=False) as a,np.load(trial/name,allow_pickle=False) as b:
      assert set(a.files)==set(b.files),(route,name,'array keys');arrays[name]={key:arrays_equal(a[key],b[key])for key in a.files}
     npz_hashes[name]=dict(expected=sha((expected/name).read_bytes()),actual=sha((trial/name).read_bytes()))
    expected_report=json.loads((expected/'report.json').read_text());actual_report=json.loads((trial/'report.json').read_text());raw_differences=differences(expected_report,actual_report);normalizations=[]
    if raw_differences and args.allow_profile_path_normalization and raw_differences==['profile_source']:
     profile_hash=sha((checkout/config['profile']).read_bytes());assert expected_report.get('profile_sha256')==actual_report.get('profile_sha256')==profile_hash
     normalizations.append(dict(field='profile_source',expected=expected_report['profile_source'],actual=actual_report['profile_source'],reason='same verified profile bytes at another package path'));actual_report['profile_source']=expected_report['profile_source']
    row.update(array_matches=arrays,npz_sha256=npz_hashes,report_raw_differences=raw_differences,report_path_normalizations=normalizations,complete_report_matches=expected_report==actual_report,physics_arrays_exact=all(all(x.values())for x in arrays.values()));row['passed']=row['physics_arrays_exact'] and row['complete_report_matches']
   except Exception as exc:row.update(passed=False,error_type=type(exc).__name__,error=str(exc))
   return route,row
  with ThreadPoolExecutor(max_workers=min(args.workers,len(selected))) as pool:rows=dict(pool.map(run_route,selected))
  result.update(routes=rows,all_routes_passed=all(x['passed']for x in rows.values()),max_concurrent_subprocesses=args.workers)
  (output/'verification.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
  if not result['all_routes_passed']:raise SystemExit(1)
  return result
 finally:shutil.rmtree(checkout)

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--zip',type=Path,required=True);p.add_argument('--amp-source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--expected-sha256');p.add_argument('--routes',nargs='+',choices=('go','out','slant'));p.add_argument('--workers',type=int,default=3);p.add_argument('--trial-timeout-s',type=int,default=240);p.add_argument('--allow-profile-path-normalization',action='store_true');a=p.parse_args()
 if not 1<=a.workers<=3 or not 30<=a.trial_timeout_s<=300:p.error('verification permits1–3workers and30–300spertrial')
 verify(a)
if __name__=='__main__':main()
