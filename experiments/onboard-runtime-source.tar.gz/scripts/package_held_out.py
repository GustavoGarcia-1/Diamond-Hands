"""Package frozen, independently reproduced Out controller and trace evidence."""
from hashlib import sha256
import json
from pathlib import Path
import shutil
import tarfile
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = Path('reports/out-scrimmage/left-turn-20261113')
VIDEO = ROOT/'reports/receiver-slot-20261113/out-tight'
OUTPUT = ROOT/'artifacts/him-open-build-held-out-20261113'
CAPTION = '''Simulated Unitree G1 with Aero hands turns left and catches while moving forward. Starting two yards beside a fixed midfield passing machine, it receives a 6.316 m, 1.077 s free-physics pass and holds it with both hands for 2.926 s through the eight-second finish. No body/floor support or applied ball loads. An exact Linux rerun matches every pose and trace array. The gait stays grounded; stem drift is 0.611 m and turn overshoot 0.453 m. It does not stop. Pretrained locomotion plus scripted RGB-D grip; no demonstrated learned catch improvement or hardware result.\n'''
README = '''# G1 football receiver — verified forward-left held catch

The primary full-play MP4 shows an uncut eight-second simulation with a green
field, dark background and passing machine at the physical release location.
See caption.txt for measured results and limits. This is a moving held catch,
with a grounded gait; it does not establish a running-gait Out or completed stop.
The selected controller is frozen from the exact Linux confirmation job.

## Reproduce

Install Python 3.12 and uv, then:

    uv sync --locked --python 3.12 --extra training --extra test --extra video

Fetch the pinned external AMP checkpoint and YAML using docs/running-policy.md.
Its adapter checks the artifact hashes. The Aero model is included under
aero-source. On headless Linux use MUJOCO_GL=egl. Run:

    sh run-out.sh /tmp/g1-pretrained-run-legged reports/out-reproduction

Use a fresh output directory. The selected Linux rerun matches all archived
arrays exactly; other platforms can produce different trajectories and must
be reported separately. Independent evaluation and exact-match records are in
reports/independent-validation-out-overhead-20261113. Full controller commands,
profile, original trace, confirmation trace and source hashes are included.

## Evidence and inputs

Selected Out: reports/out-scrimmage/left-turn-20261113/overhead-pass-linux/artifacts/out/case-07.
Adjacent profile-07.json specifies the throw and hand trajectory. The full
8 s trace has no applied ball load, floor or nonhand support. The short receive
check is 308 ms at 0.517 m/s relative speed; the later continuous two-hand hold
is 2.926 s at 0.0875 m/s. The robot moves forward after the left turn, with no
negative body-forward frames. No recurrent airborne phases qualify.

Original Go fallback: reports/quarterback-pass/offset-fixed-controlled. It has
254 ms control and qualified running, but 3.25 m lateral drift and an eventual
drop/fall. It uses a different formation and is not the primary video.

Runtime inputs are surveyed RGB-D, IMU and joint encoders. Contact and exact
simulator poses are evaluation/rendering only. Hand motion and route transitions
are calibrated scripts around pretrained policies. The locally trained residual
policies have not established improvement and are not used in the primary play.

Read SENSOR_CONTRACT.md and docs/hardware-qualification.md. No connected hardware
was tested. RGB-D and Aero hand integration, a Linux ARM64 runtime image, and HIM
builder safety/counterfactual checks remain unverified. This is a simulation
submission package, not a hardware-qualified controller image.
'''
RUN = '''#!/bin/sh
set -eu
cd "$(dirname "$0")"
held_amp=${1:?provide pinned AMP checkout}
held_output=${2:?provide fresh output directory}
export PYTHONPATH=src:scripts
.venv/bin/python scripts/probe_aero_out.py --source aero-source --amp-source "$held_amp" \\
 --output "$held_output" --duration 8 --approach-handoff-depth-m 2.1 \\
 --cut-speed 1.4 --blend-s .5 --turn-s .4 --hold-straight-s 0 \\
 --depth-feedback-gain 4 --camera-start-s .8 --stopping-lookahead-s .55 \\
 --reverse-speed 0 --approach-speed .48 --horizontal-pass-distance \\
 --pass-profile reports/out-scrimmage/left-turn-20261113/overhead-pass-linux/artifacts/out/profile-07.json --record-poses
'''

def main():
    OUTPUT.mkdir(parents=True, exist_ok=False)
    frozen=ROOT/EVIDENCE/'frozen-held-source.tar.gz'
    source_manifest=json.loads((ROOT/EVIDENCE/'frozen-held-source-manifest.json').read_text())
    assert sha256(frozen.read_bytes()).hexdigest()==source_manifest['archive_sha256']
    files={}
    with tarfile.open(frozen) as archive:
        for member in archive:
            name=member.name
            assert member.isfile() and not Path(name).is_absolute() and '..' not in Path(name).parts
            data=archive.extractfile(member).read()
            assert sha256(data).hexdigest()==source_manifest['manifest'][name]
            files[name]=data
    def add(path, name=None):
        path=Path(path)
        assert path.is_file() and not path.is_symlink()
        files[name or path.relative_to(ROOT).as_posix()]=path.read_bytes()
    for folder in (EVIDENCE/'overhead-pass-linux/artifacts/out/case-07',
                   EVIDENCE/'overhead-confirm-linux/artifacts/out/case-00',
                   Path('reports/independent-validation-out-overhead-20261113'),
                   Path('reports/quarterback-pass/offset-fixed-controlled')):
        for path in (ROOT/folder).rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts:add(path)
    for name in ('overhead-pass-linux/artifacts/out/profile-07.json',
                 'frozen-held-source-manifest.json','overhead-confirmation.json',
                 'held-candidate-audit.json','overhead-pass-receipt.json','overhead-confirm-receipt.json',
                 'README.md','reproduce-held.sh'):
        add(ROOT/EVIDENCE/name)
    for name in ('SENSOR_CONTRACT.md','docs/running-policy.md','docs/aero-integration.md',
                 'docs/hardware-qualification.md','scripts/package_held_out.py'):
        add(ROOT/name)
    # Presentation-only updates do not change the frozen controller/plant.
    render_overrides=('src/g1_receiver/stadium.py','src/g1_receiver/stadium_quarterback.py',
                      'scripts/render_aero_stadium.py','scripts/encode_receiver_replay.py','scripts/verify_field_replay.py')
    for name in render_overrides:add(ROOT/name)
    from g1_receiver.aero import MODEL_DIR, _load_source
    hand=Path('/tmp/g1-aero-source');_load_source(hand)
    source=hand if hand.name==MODEL_DIR else hand/MODEL_DIR
    for path in source.rglob('*'):
        if path.is_file():add(path,f'aero-source/{MODEL_DIR}/{path.relative_to(source).as_posix()}')
    for name in ('video-verification.json','contact-sheet.jpg'):
        add(VIDEO/name,'reports/submission-video/'+name)
    files.update({'README.md':README.encode(),'run-out.sh':RUN.encode(),'caption.txt':CAPTION.encode()})
    manifest={name:sha256(data).hexdigest() for name,data in sorted(files.items())}
    target=OUTPUT/'project.zip'
    with ZipFile(target,'x',ZIP_DEFLATED,compresslevel=6) as archive:
        for name,data in sorted(files.items()):archive.writestr(name,data)
        archive.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
    with ZipFile(target) as archive:
        assert archive.testzip() is None
        assert all(sha256(archive.read(name)).hexdigest()==digest for name,digest in manifest.items())
    shutil.copyfile(VIDEO/'full-play.mp4',OUTPUT/'full-play.mp4')
    (OUTPUT/'caption.txt').write_text(CAPTION)
    receipt={'project_sha256':sha256(target.read_bytes()).hexdigest(),
             'video_sha256':sha256((OUTPUT/'full-play.mp4').read_bytes()).hexdigest(),
             'frozen_source_sha256':source_manifest['archive_sha256'],
             'presentation_only_overrides':list(render_overrides),'members':len(files)+1,
             'crc_and_all_member_hashes_verified':True,'source_confirmation':'exact Linux trace and pose match',
             'hardware_qualified':False}
    (OUTPUT/'package-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
