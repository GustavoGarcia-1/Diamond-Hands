"""Encode the untouched spectator frames from an Aero simulation recording."""

import argparse
from pathlib import Path

import imageio_ffmpeg
import numpy as np


def encode(source, target):
    if target.exists():
        raise FileExistsError(target)
    with np.load(source, allow_pickle=False) as recording:
        frames, stamps = recording["rgb"], recording["timestamps_s"]
    if frames.dtype != np.uint8 or frames.ndim != 4 or frames.shape[-1] != 3 or len(stamps) != len(frames):
        raise ValueError("expected timestamped RGB video frames")
    periods = np.diff(stamps)
    if not len(periods) or not np.allclose(periods, periods[0]) or periods[0] <= 0.:
        raise ValueError("video requires a constant, positive frame rate")
    height, width = frames.shape[1:3]
    writer = imageio_ffmpeg.write_frames(
        str(target), (width, height), fps=1. / periods[0], codec="libx264",
        pix_fmt_in="rgb24", pix_fmt_out="yuv420p", macro_block_size=1,
        output_params=["-movflags", "+faststart"],
    )
    writer.send(None)
    try:
        for frame in frames:
            writer.send(frame)
    finally:
        writer.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("target", type=Path)
    args = parser.parse_args()
    encode(args.source, args.target)


if __name__ == "__main__":
    main()
