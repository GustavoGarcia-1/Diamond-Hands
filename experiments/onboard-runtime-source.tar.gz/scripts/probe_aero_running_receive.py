"""Screen AMP arm swing and a bounded motion into the Aero receiving posture."""

import argparse
from hashlib import sha256
import json
from pathlib import Path

import mujoco
import numpy as np

from g1_receiver.aero import PALM_BODIES, aero_ready_joint_targets
from g1_receiver.hand_route_plant import HandRoutePlant
from g1_receiver.run_arm_receive import RunArmReceive
from g1_receiver.running_catch_eval import FootContactRecorder
from g1_receiver.running_policy import AmpRunningPolicy, CHECKPOINT_SHA256, CONTROL_PERIOD_S
from g1_receiver.runtime import RobotObservation, SkillGoal


MOTION_COLUMNS = (
    'time_s', 'pelvis_x_m', 'pelvis_y_m', 'pelvis_z_m', 'upright_cosine', 'arm_override_fraction',
    'left_shoulder_pitch_rad', 'right_shoulder_pitch_rad', 'left_elbow_rad', 'right_elbow_rad',
    'left_palm_body_x_m', 'left_palm_body_y_m', 'left_palm_body_z_m',
    'right_palm_body_x_m', 'right_palm_body_y_m', 'right_palm_body_z_m',
)


def flight_intervals(foot):
    time = foot['foot_time_s']
    contact = foot['foot_floor_contact']
    clearance = np.all(foot['sole_clearance_m'] >= .005, axis=1)
    edges = np.flatnonzero(np.diff(np.r_[False, ~foot['robot_floor_contact'], False]))
    for start, end in zip(edges[::2], edges[1::2], strict=True):
        if start == 0 or end == len(time):
            continue
        left, right = contact[start - 1], contact[end]
        if left.sum() != 1 or right.sum() != 1 or np.array_equal(left, right):
            continue
        segments = np.flatnonzero(np.diff(np.r_[False, clearance[start:end], False]))
        duration = (segments[1::2] - segments[::2]).max(initial=0) * .001
        if duration >= .025:
            yield [float(time[start]), float(time[end]), float(duration)]


def evaluate(plant, policy, running_fraction, trigger, ramp, speed, finish, renderer=None, pump=0., lowered=0.):
    ready = aero_ready_joint_targets(policy.nominal, plant.joint_names)
    arms = RunArmReceive(running_fraction, pump, lowered, ramp)
    shoulder = [plant.joint_names.index(f'{side}_shoulder_pitch_joint') for side in ('left', 'right')]
    elbow = [plant.joint_names.index(f'{side}_elbow_joint') for side in ('left', 'right')]
    plant.reset(joint_positions=arms.initial(policy.nominal, ready, plant.joint_names),
                release_position_m=(22., 13., .085))
    policy.reset()
    feet = FootContactRecorder(plant.model)
    palms = [plant.data.body(name) for name in PALM_BODIES]
    pelvis = plant.data.body('pelvis')
    camera = mujoco.MjvCamera()
    camera.azimuth, camera.elevation, camera.distance = 105., -11., 3.6
    traces, frames, stamps = [], [], []
    ticks = round(finish / CONTROL_PERIOD_S)
    for tick in range(ticks + 1):
        now = plant.timestamp_s
        q, dq, quat, gyro = plant.observe()
        w, x, y, z = quat
        yaw = np.arctan2(2. * (w * z + x * y), 1. - 2. * (y * y + z * z))
        target, fraction = arms.targets(ready, plant.joint_names, q, now, trigger if now >= trigger else None)
        orientation = pelvis.xmat.reshape(3, 3)
        local_palms = np.vstack([(palm.xpos - pelvis.xpos) @ orientation for palm in palms])
        traces.append((now, *pelvis.xpos, orientation[2, 2], fraction, *q[shoulder], *q[elbow], *local_palms.ravel()))
        if renderer is not None and tick % 2 == 0:
            camera.lookat[:] = (*pelvis.xpos[:2] + [.22, 0.], .79)
            renderer.update_scene(plant.data, camera=camera)
            frames.append(renderer.render().copy())
            stamps.append(now)
        if tick == ticks or orientation[2, 2] < .50:
            break
        drive = np.array([min(speed, 1.8 * max(0., now - .4)), 0., np.clip(-1.8 * yaw, -.75, .75)])
        obs = RobotObservation(now, q, dq, quat, gyro, np.zeros(29), None)
        command = policy.act(obs, SkillGoal(base_velocity=drive), upper_target=target, arm_override_fraction=fraction)
        plant.step(command, post_step=feet.record)

    motion = np.asarray(traces)
    foot = feet.arrays()
    t = motion[:, 0]
    run = motion[(t >= 1.5) & (t < trigger)]
    phases = list(flight_intervals(foot))
    reach = motion[np.argmin(abs(t - (trigger + ramp + .08)))]
    pump_degrees = np.degrees(np.ptp(run[:, 6:8], axis=0)) if len(run) > 2 else None
    correlation = np.corrcoef(run[:, 6], run[:, 7])[0, 1] if len(run) > 2 else np.nan
    warning_count = int(sum(w.number for w in plant.data.warning))
    report = dict(running_fraction=running_fraction, trigger_s=trigger, ramp_s=ramp, command_speed_mps=speed,
                  encoder_pump_rad=pump, lowered_shoulders_rad=lowered,
                  actual_finish_s=float(t[-1]), minimum_upright_cosine=float(motion[:, 4].min()),
                  shoulder_pitch_excursion_deg=None if pump_degrees is None else pump_degrees.tolist(),
                  shoulder_pitch_correlation=float(correlation) if np.isfinite(correlation) else None,
                  qualified_flights_s=phases, flights_before_raise=sum(end <= trigger for _, end, _ in phases),
                  flights_after_raise=sum(start >= trigger + ramp for start, _, _ in phases),
                  reach_sample_s=float(reach[0]), reach_pelvis_xyz_m=reach[1:4].tolist(),
                  reach_palm_body_xyz_m=reach[10:].reshape(2, 3).tolist(), warnings=warning_count)
    return report, motion, foot, frames, stamps


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--amp-source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--case', nargs=4, type=float, action='append', required=True,
                        metavar=('ARM_FRACTION', 'TRIGGER_S', 'RAMP_S', 'SPEED_MPS'))
    parser.add_argument('--finish', type=float, default=5.4)
    parser.add_argument('--record', action='store_true')
    parser.add_argument('--pump', type=float, default=0.)
    parser.add_argument('--lowered', type=float, default=0.)
    args = parser.parse_args()
    if not -.35 <= args.pump <= .35 or not 0. <= args.lowered <= .5:
        parser.error('invalid shoulder offsets')
    for fraction, trigger, ramp, speed in args.case:
        if not (0. <= fraction <= 1. and 1.6 <= trigger and .12 <= ramp <= .9 and 1. <= speed <= 2.5
                and trigger + ramp + .08 <= args.finish <= 8.):
            parser.error('invalid arm profile or finish time')
    args.output.mkdir(parents=True, exist_ok=False)
    plant = HandRoutePlant(args.source, hand_model='aero', survey_camera=False)
    policy = AmpRunningPolicy(plant.joint_names, plant.joint_ranges, args.amp_source)
    renderer = None
    try:
        if args.record:
            backdrop = plant.model.geom('backdrop').id
            if plant.model.geom_contype[backdrop] or plant.model.geom_conaffinity[backdrop]:
                raise ValueError('expected a visual-only backdrop')
            plant.model.geom_group[backdrop] = 5
            plant.model.vis.global_.offwidth = 640
            plant.model.vis.global_.offheight = 360
            renderer = mujoco.Renderer(plant.model, height=360, width=640)
        reports = []
        for index, case in enumerate(args.case):
            report, motion, foot, frames, stamps = evaluate(plant, policy, *case, args.finish, renderer,
                                                           args.pump, args.lowered)
            path = args.output / f'case-{index:02d}.npz'
            np.savez_compressed(path, motion=motion, motion_columns=MOTION_COLUMNS, **foot)
            if frames:
                np.savez_compressed(path.with_stem(f'{path.stem}-view'), rgb=frames, timestamps_s=stamps)
            reports.append(dict(**report, checkpoint_sha256=CHECKPOINT_SHA256,
                                trace=path.name, trace_sha256=sha256(path.read_bytes()).hexdigest()))
            (args.output / 'report.json').write_text(json.dumps(reports, indent=2, allow_nan=False) + '\n')
            print(report, flush=True)
    finally:
        if renderer is not None:
            renderer.close()
        plant.close()


if __name__ == '__main__':
    main()
