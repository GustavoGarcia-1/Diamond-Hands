"""Development comparison of learned arm control with three ways to follow a route."""

from __future__ import annotations

import argparse
from dataclasses import asdict, replace
from hashlib import file_digest
import json
from pathlib import Path

import numpy as np
from stable_baselines3 import PPO
import torch

from g1_receiver.observable import ACTION_LIMITS
from g1_receiver.receiver_env import EPISODE_S, POLICY_HZ, sample_trial
from g1_receiver.receiver_physical_eval import PhysicalAuditReceiverEnv
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
from g1_receiver.train_receiver import _source_snapshot

DRIVE_FRACTIONS = {"learned_drive": 1., "blended_drive": .3, "route_follower": 0.}


def route_action(env) -> np.ndarray:
    pose = env.state.receiver
    if pose is None:
        return np.zeros(3)
    cosine, sine = np.cos(pose.yaw_rad), np.sin(pose.yaw_rad)
    body_velocity = np.array([[cosine, sine], [-sine, cosine]]) @ env.field_command
    return np.clip(np.r_[body_velocity, 0.] / ACTION_LIMITS[:3], -1., 1.)


def evaluate(model, trial, seed, learned_drive_fraction, max_steps, recording=None):
    env = PhysicalAuditReceiverEnv(DEFAULT_RUNTIME_ROOT)
    try:
        observation, _ = env.reset(seed=seed, options={"trial": trial})
        frames, times, camera_frames, camera_times = [], [], [], []

        def capture():
            if recording is None:
                return
            env.plant.renderer.update_scene(env.plant.data, camera="overview")
            frames.append(env.plant.renderer.render().copy())
            times.append(env.plant.timestamp_s)
            if env._last_camera is not None:
                frame = env._last_camera[0]
                if not camera_times or frame.timestamp_s > camera_times[-1]:
                    camera_frames.append(frame.rgb.copy())
                    camera_times.append(frame.timestamp_s)

        capture()
        for _ in range(max_steps):
            action, _ = model.predict(observation, deterministic=True)
            if learned_drive_fraction < 1:
                action[:3] = (learned_drive_fraction * action[:3]
                              + (1 - learned_drive_fraction) * route_action(env))
            # The diagnostic can continue past the training time limit.
            # Actions still use fresh sensor history, and reward is discarded.
            observation, _, terminated, _, info = env.step(action)
            capture()
            if terminated:
                break

        if recording is not None:
            recording.mkdir(parents=True, exist_ok=False)
            np.savez_compressed(recording / "overview.npz", rgb=frames, timestamps_s=times)
            if camera_times:
                np.savez_compressed(recording / "camera-rgb.npz", rgb=camera_frames,
                                    timestamps_s=camera_times)
            np.savez_compressed(recording / "physical.npz", samples=env.sampled_truth())

        result = env.physical_summary()
        path = env.sampled_truth()[:, 5:7]
        next_waypoint = 1
        for position in path:
            if next_waypoint < len(env.route.waypoints):
                start, goal = np.asarray(env.route.waypoints[next_waypoint - 1:next_waypoint + 1])
                tolerance = min(.05, .1 * np.linalg.norm(goal - start))
                if np.linalg.norm(position - goal) <= tolerance:
                    next_waypoint += 1
        route_complete = (
            next_waypoint == len(env.route.waypoints)
            and np.linalg.norm(path[-1] - goal) <= tolerance
            and result["min_upright_cosine"] >= .90
        )
        return {
            **result,
            "evidence_class": "development_simulator_truth_evaluation_only",
            "ordered_route_complete": bool(route_complete),
            "route_and_retention": bool(route_complete and result["retained_sim_support_2s"]),
            "visual_retention": info["retained_visual_proxy"],
            "elapsed_s": float(env.plant.timestamp_s),
        }
    finally:
        env.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--duration", type=float, default=EPISODE_S)
    parser.add_argument("--mode", choices=DRIVE_FRACTIONS)
    parser.add_argument("--case", type=int, choices=range(6))
    parser.add_argument("--recording", type=Path)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists")
    if not np.isfinite(args.duration) or not EPISODE_S <= args.duration <= 6.:
        parser.error(f"duration must be between {EPISODE_S} and 6 seconds")
    if args.recording is not None and (args.mode is None or args.case is None):
        parser.error("recording requires a single mode and case")
    max_steps = round(args.duration * POLICY_HZ)
    manifest = json.loads((args.checkpoint.parent / "manifest.json").read_text())
    if manifest["source_sha256"] != _source_snapshot(None, DEFAULT_RUNTIME_ROOT):
        parser.error("simulation source differs from the checkpoint manifest")
    with args.checkpoint.open("rb") as stream:
        checkpoint_hash = file_digest(stream, "sha256").hexdigest()
    torch.set_num_threads(1)
    model = PPO.load(args.checkpoint, device="cpu")
    rng = np.random.default_rng(83173)
    trials = [
        replace(sample_trial(rng, "moving", nominal=index == 0),
                route=route, route_scale=scale, suite="route_control_development")
        for route in ("go", "slant")
        for index, scale in enumerate((.16, .18, .20))
    ]
    cases = list(range(len(trials))) if args.case is None else [args.case]
    modes = DRIVE_FRACTIONS if args.mode is None else [args.mode]
    results = {
        mode: [evaluate(model, trials[index], 85173 + index, DRIVE_FRACTIONS[mode],
                        max_steps, args.recording) for index in cases]
        for mode in modes
    }
    payload = {
        "checkpoint_sha256": checkpoint_hash,
        "evidence_class": "paired_route_control_development",
        "diagnostic_horizon_s": max_steps / POLICY_HZ,
        "cases": cases,
        "trials": [asdict(trials[index]) for index in cases],
        "results": results,
    }
    with args.output.open("x") as stream:
        json.dump(payload, stream, indent=2, allow_nan=False)
        stream.write("\n")


if __name__ == "__main__":
    main()
