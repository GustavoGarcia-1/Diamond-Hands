"""Deterministic nominal checkpoint audit using frozen sensor-only route envs.

Physical arrays/form are read only after an episode ends. They never enter PPO.
No policy is selected by this script; evidence is archived for independent review.
"""
from pathlib import Path
import argparse,json,time,hashlib
import numpy as np
from stable_baselines3 import PPO
import torch
torch.set_num_threads(1)
from g1_receiver.go_catch_form_rl import FORM_OBSERVATION_SIZE,FORM_OBSERVATION_SCHEMA

def physical_summary(directory, common_windows=None):
 trial=directory/'episode-0001'/'trial';report=json.loads((trial/'report.json').read_text());arrays=np.load(trial/'trace.npz');a=arrays['contact'];dt=float(report.get('physics_step_s',.001));left=a[:,6]+a[:,7];right=a[:,9]+a[:,10]
 clean=(left>=.1)&(right>=.1)&(a[:,4]==0)&(a[:,5]<=1e-9)&(a[:,12:15].max(axis=1)<=1e-9)
 edges=np.flatnonzero(np.diff(np.r_[False,clean,False]));intervals=[dict(start_s=float(a[s,0]),end_s=float(a[e-1,0]+dt),duration_s=float(a[e-1,0]-a[s,0]+dt))for s,e in zip(edges[::2],edges[1::2])]
 longest=max((x['duration_s']for x in intervals),default=0.)
 support=(a[:,4]!=0)|(a[:,5]>1e-9)|(a[:,12:15].max(axis=1)>1e-9);first_support=np.flatnonzero(support);cutoff=int(first_support[0])if len(first_support)else len(a);before=clean.copy();before[cutoff:]=False;ee=np.flatnonzero(np.diff(np.r_[False,before,False]));before_longest=max((float(a[e-1,0]-a[b,0]+dt)for b,e in zip(ee[::2],ee[1::2])),default=0.)
 episode_clean=bool((a[:,4]==0).all()and(a[:,5]<=1e-9).all()and(a[:,12:15].max(axis=1)<=1e-9).all());strict=report['strict_score'];tip=strict.get('first_tip_contact_s');form=json.loads((directory/'episode-0001'/'form-samples.json').read_text());entry=[r['metrics']for r in form if tip is not None and tip<=r['time_s']<=tip+.2]
 out=dict(longest_clean_bilateral_s=longest,longest_clean_bilateral_interpretation='instantaneously support-free band only; reject as cleanreceive if after firstsupport',longest_bilateral_before_first_nonhand_support_s=before_longest,first_nonhand_support_s=None if cutoff==len(a)else float(a[cutoff,0]),legacy_short_receive_score=report.get('quarterback_pass_score'),clean_intervals=intervals,whole_episode_no_floor_body_or_applied_load=episode_clean,held750ms_clean_episode=bool(episode_clean and longest>=.75),minimum_upright_cosine=report['minimum_upright_cosine'],first_tip_contact_s=tip,peak_nonhand_body_normal_n=strict['peak_nonhand_body_normal_force_n'],first_floor_s=strict['first_floor_contact_s'],final_retention=strict.get('retention'),evidence_class=report.get('evidence_class','experimental_slant_walking_receive'),report=str(trial/'report.json'))
 if entry:
  up=np.array([r['palm_up_cos']for r in entry]);height=np.array([r['palm_face_height_above_head_top_m']for r in entry]);out['entry_first200ms_form']=dict(samples=len(entry),minimum_bilateral_palm_up_cos=up.min(axis=0).tolist(),mean_bilateral_palm_up_cos=up.mean(axis=0).tolist(),fraction_both_up_at_least060=float((up>=.60).all(axis=1).mean()),mean_face_height_above_head_m=height.mean(axis=0).tolist())
 def form_stats(metrics):
  up=np.array([r['palm_up_cos']for r in metrics]);height=np.array([r['palm_face_height_above_head_top_m']for r in metrics]);return dict(samples=len(metrics),minimum_bilateral_palm_up_cos=up.min(axis=0).tolist(),mean_bilateral_palm_up_cos=up.mean(axis=0).tolist(),fraction_both_up_at_least060=float((up>=.60).all(axis=1).mean()),fraction_both_up_preferred0707=float((up>=.707).all(axis=1).mean()),mean_face_height_above_head_m=height.mean(axis=0).tolist())
 contact_metrics=[r['metrics']for r in form if tip is not None and abs(r['time_s']-tip)<=.02000001]
 if contact_metrics:out['actual_contact_plusminus20ms_form']=form_stats(contact_metrics)
 for name,window in (common_windows or {}).items():
  metrics=[r['metrics']for r in form if window[0]<=r['time_s']<=window[1]]
  if metrics:out[name+'_fixedclock_form']=dict(window_s=window,**form_stats(metrics))
 motion=arrays['motion'];view=np.load(trial/'view.npz');tt=view['timestamps_s'];q=view['qpos'][:,3:7];w,x,y,z=q.T;forward=np.column_stack((1-2*(y*y+z*z),2*(x*y+w*z)));forward/=np.linalg.norm(forward,axis=1)[:,None];velocity=np.column_stack([np.interp(tt,motion[:,0],np.gradient(motion[:,i],motion[:,0]))for i in (1,2)]);mask=tt>=tip if tip is not None else np.zeros(len(tt),dtype=bool)
 if mask.any():out['minimum_posttip_body_forward_speed_mps']=float((velocity*forward).sum(axis=1)[mask].min())
 out['upright_forward_held_receive']=bool(out['held750ms_clean_episode'] and out['minimum_upright_cosine']>=.9 and (out['final_retention'] or {}).get('hands_only_retention_at_finish',False) and out.get('minimum_posttip_body_forward_speed_mps',-1.)>0.)
 return out

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for name in ('training','profile','source','amp-source','output'):p.add_argument('--'+name,type=Path,required=True)
 p.add_argument('--route',choices=('go','slant'),required=True);p.add_argument('--duration',type=float,required=True);p.add_argument('--models',type=Path,nargs='+');p.add_argument('--inference-device',choices=('cpu','cuda'),default='cpu')
 for name in ('sensor-retention-camera-position','sensor-retention-camera-target','sensor-retention-pose-camera-position','sensor-retention-pose-camera-target'):p.add_argument('--'+name,type=float,nargs=3)
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
 if a.inference_device=='cuda'and not torch.cuda.is_available():raise RuntimeError('explicit CUDA inference requested but unavailable')
 if a.route=='go':from g1_receiver.go_catch_form_training import GoCatchFormEnv as Env
 else:from g1_receiver.slant_catch_form_training import SlantCatchFormEnv as Env
 models=a.models or[a.training/'initial.zip',*sorted(a.training.glob('checkpoint-????????.zip')),a.training/'final.zip'];models=list(dict.fromkeys(models));manifest=[dict(path=str(m),sha256=hashlib.sha256(m.read_bytes()).hexdigest())for m in models];(a.output/'models.json').write_text(json.dumps(manifest,indent=2)+'\n');rows=[]
 for item in manifest:
  checkpoint=Path(item['path']);started=time.monotonic();env=None
  try:
   model=PPO.load(checkpoint,device=a.inference_device)
   if model.observation_space.shape!=(FORM_OBSERVATION_SIZE,)or getattr(model,'receiver_sensor_schema',None)!=FORM_OBSERVATION_SCHEMA:raise ValueError('checkpoint sensor schema mismatch')
   directory=a.output/checkpoint.stem
   env=Env(a.profile,a.source,a.amp_source,evaluation_dir=directory,duration=a.duration,sensor_retention_camera_position=a.sensor_retention_camera_position,sensor_retention_camera_target=a.sensor_retention_camera_target,sensor_retention_pose_camera_position=a.sensor_retention_pose_camera_position,sensor_retention_pose_camera_target=a.sensor_retention_pose_camera_target)
   observation,_=env.reset(seed=173);total=0.
   while True:
    action=model.predict(observation,deterministic=True)[0];observation,reward,done,_,info=env.step(action);total+=reward
    if done:break
   env.close();env=None
   if not np.isclose(total,info['sensor_return'],atol=1e-9):raise RuntimeError('ledger mismatch')
   row=dict(model=str(checkpoint),model_sha256=item['sha256'],inference_device=a.inference_device,elapsed_s=time.monotonic()-started,sensor_return=total,**physical_summary(directory,{'receive':[8.68,9.28],'late':[10.,12.88]}if a.route=='go'else{'receive':[6.2,6.8],'late':[7.2,9.5]}))
  except BaseException as error:row=dict(model=str(checkpoint),model_sha256=item['sha256'],inference_device=a.inference_device,error=repr(error),elapsed_s=time.monotonic()-started)
  finally:
   if env is not None:env.close()
  rows.append(row);(a.output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
if __name__=='__main__':main()
