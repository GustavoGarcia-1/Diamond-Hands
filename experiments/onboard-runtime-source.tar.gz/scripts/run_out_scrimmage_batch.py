"""Sweep surveyed Out passes and save each trial as soon as it completes."""

import argparse
from concurrent.futures import ThreadPoolExecutor
from itertools import product
import json
import os
from pathlib import Path
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--amp-source", type=Path, required=True)
    parser.add_argument("--profile", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--refine-receive", action="store_true",
                        help="vary receiving pose and hand closure near a selected throw")
    args = parser.parse_args()
    if not 1 <= args.workers <= 4:
        parser.error("use between one and four render workers")
    root = Path(__file__).resolve().parents[1]
    profile = json.loads(args.profile.read_text())
    if args.refine_receive:
        cases = list(product((-.06, 0., .06), (-.045, 0., .045),
                             (-.025, 0., .025), (-.15, 0., .15), (.78, .92)))
    else:
        cases = list(product((-.08, 0., .08), (-.07, 0., .07), (.10, .16, .22), (0.,), (None,)))
    args.output.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1")

    def run_case(case):
        index, (outside_offset, height_offset, lead, pitch_offset, curl) = case
        case_dir = args.output / f"case-{index:02d}"
        case_dir.mkdir(exist_ok=True)
        result_dir = case_dir / "trial"
        if (result_dir / "report.json").is_file():
            return json.loads((result_dir / "report.json").read_text())
        spec = json.loads(json.dumps(profile))
        play = spec["play"]
        target = play["quarterback_target_m"]
        target[1] += outside_offset
        target[2] += height_offset
        play["field_catch_window_m"] = target
        if args.refine_receive:
            play["grip"]["lead_s"] = float(play["grip"]["lead_s"]) + lead
            for shoulder_pitch in (2, 9):
                play["grasp_offsets_rad"][shoulder_pitch] += pitch_offset
            play["closure"] = curl
        else:
            play["grip"]["lead_s"] = lead
        profile_path = case_dir / "profile.json"
        profile_path.write_text(json.dumps(spec, indent=2) + "\n")
        command = [
            sys.executable, str(root / "scripts/probe_aero_out.py"),
            "--source", str(args.source.resolve()), "--amp-source", str(args.amp_source.resolve()),
            "--output", str(result_dir.resolve()), "--pass-profile", str(profile_path.resolve()),
            "--approach-handoff-depth-m", "2.9", "--hold-straight-s", ".03", "--blend-s", ".5",
            "--turn-s", ".55", "--depth-feedback-gain", "3", "--duration", "6", "--record-poses",
        ]
        with (case_dir / "rollout.log").open("ab") as log:
            subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
        return json.loads((result_dir / "report.json").read_text())

    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        summaries = []
        for index, (case, trial) in enumerate(zip(cases, pool.map(run_case, enumerate(cases)), strict=True)):
            score = trial["quarterback_pass_score"] or {}
            summary = {"case": index, "lateral_offset_m": case[0], "height_offset_m": case[1],
                       "lead_s": case[2], "lead_is_offset": args.refine_receive,
                       "shoulder_pitch_offset_rad": case[3], "closure": case[4], "score": score}
            summaries.append(summary)
            print(json.dumps(summary), flush=True)
    (args.output / "summary.json").write_text(json.dumps(summaries, indent=2) + "\n")


if __name__ == "__main__":
    main()
