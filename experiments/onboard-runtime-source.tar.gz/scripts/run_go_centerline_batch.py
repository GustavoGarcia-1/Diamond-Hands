"""Compare centerline throws and sensor-only grasp-frame stabilization."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys

p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
p.add_argument('--source',required=True);p.add_argument('--amp-source',required=True);a=p.parse_args()
a.output.mkdir(parents=True,exist_ok=False)
cases=[(flight,blend) for flight in (1.2,1.4,1.6) for blend in (0.,.5,1.)]
def run(item):
 i,(flight,blend)=item;out=a.output/f'case-{i:02d}'
 cmd=[sys.executable,'scripts/probe_go_stem.py','--reference',f'reports/aero-rl-20261113/centerline-flight-{flight:.1f}.json',
      '--source',a.source,'--amp-source',a.amp_source,'--output',str(out),'--duration','7','--record-poses',
      '--stabilize-grasp',str(blend),'--stabilize-grasp-delay','.18']
 with (a.output/f'case-{i:02d}.log').open('w') as log:
  result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=240)
 score=json.loads((out/'stem-score.json').read_text()) if result.returncode==0 else None
 return dict(case=i,flight_s=flight,stabilize_grasp=blend,command=cmd,exit_code=result.returncode,score=score)
with ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(run,enumerate(cases)))
(a.output/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
if any(r['exit_code'] for r in results):raise SystemExit(1)
