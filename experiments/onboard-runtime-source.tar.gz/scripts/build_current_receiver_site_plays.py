"""Publish selected recorded centerline attempts as data/assets for the viewer."""
import json
import argparse
from pathlib import Path
import shutil
import numpy as np
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
SITE=ROOT/'site/dist/plays'
VIDEO=ROOT/'reports/receiver-dark-centerline-20261113'
CASES=[
 ('go','reports/aero-rl-20261113/centerline-r2-linux/artifacts/go/case-06',0.,
  [[0,0],[9.144,0]],'Go · centerline pass','Running attempt · catch incomplete',
  'Go: run straight downfield without a cut. Our target receive depth is ten yards.',
  'The machine throws from the field centerline at the line of scrimmage. Brief two-hand contact, then the ball escapes and the receiver falls. The stem still drifts roughly 3.25 m. This is a new centerline throw, separate from the older 254 ms contact replay.'),
 ('out','reports/out-scrimmage/left-turn-20261113/centerline-cup-linux/artifacts/out/case-02',.415,
  [[0,0],[4.572,0],[4.572,4.572]],'Out · forward left turn','Forward left exit · catch incomplete',
  'Out: five yards downfield, then a 90° left turn toward the sideline, facing and moving along the new leg.',
  'Turns left and moves forward instead of backpedaling. Break at 4.602 m; downfield overshoot 0.403 m; approach drift 0.611 m. Brief fingertip grip does not become a controlled catch. Upright through 8 s, with no qualifying running flight phases.'),
 ('slant','reports/aero-amp-slant/retained-20261113/antioch-centerline/artifacts/slant/case-02',np.radians(42.742663),
  [[0,0],[1.1266383880763209,0],[5.369279075195606,-4.242640687119285]],'Slant · centerline pass','Two-step inward cut · missed catch',
  'Slant: take two sustained steps, then cut approximately 45° inward. Inward is right in this formation.',
  'Early inward cut 42.49°, compared with 14.65° under zero steering. The pass comes from the field centerline. Fingertip touch does not become two-hand control; the ball hits the turf and the receiver later falls. The full failed attempt is shown.'),
]

def main():
 parser=argparse.ArgumentParser()
 parser.add_argument('--slot',action='store_true',help='Current two-yard formation and held Out evidence')
 parser.add_argument('--held',action='store_true',help='Use independently verified held Go and Slant extensions')
 args=parser.parse_args()
 if args.held and not args.slot:parser.error('--held requires --slot')
 cases=CASES
 if args.slot:
  replacements={
   'go':('reports/aero-rl-20261113/slot-pocket-linux/artifacts/go/case-11',
         'Go · two-yard split','Running attempt · catch incomplete',
         'Receiver starts two yards beside the midfield passing machine. The 1.4 s programmed throw produces 25 ms of clean two-hand contact, then a drop and fall. Running qualifies; the stem still drifts roughly 3.25 m. The older 254 ms Go is a separate archived formation.'),
   'out':('reports/out-scrimmage/left-turn-20261113/overhead-pass-linux/artifacts/out/case-07',
          'Out · forward left catch','Moving receive · held through finish',
          'Receiver starts two yards beside the midfield passing machine. Left body turn 81.53°; no backward travel after the break. Break depth 4.602 m, overshoot 0.453 m, stem drift 0.611 m. Clean two-hand hold lasts 2.926 s through the eight-second finish. Short receive check: 308 ms at 0.517 m/s relative speed. No floor or body support. The gait stays grounded; the robot continues moving and does not complete the ordered stop.'),
   'slant':('reports/aero-amp-slant/retained-20261113/antioch-slot/artifacts/slant/case-02',
            'Slant · two-yard split','Two-step inward cut · catch incomplete',
            'Receiver starts two yards beside the midfield passing machine. The two-step cut uses pretrained AMP locomotion and scripted steering. Seven milliseconds of two-hand contact does not become a catch; the ball drops. Full 6.5 s trial, minimum upright cosine 0.830. Grasp timing and retention remain under development.')}
  if args.held:
   replacements['go']=(
    'reports/aero-rl-20261113/go-cup-confirm-linux/artifacts/confirm/extended',
    'Go · straight held catch','Straight stem · held through finish',
    'Receiver starts two yards beside the midfield machine, facing 40° inward before the play. Maximum deviation from the fixed straight stem is 0.176 m. Receives at 9.146 m and keeps clean two-hand control for 3.820 s through 12.88 s. Short receive: 318 ms at 0.225 m/s relative speed. No floor or nonhand body support. Pretrained AMP startup hands off to forward walking before the catch; no qualifying running phases at contact and no completed stop. Scripted RGB-D grip, not a demonstrated newly learned catch. Exact rerun and extended prefix reproduce all recorded arrays.')
   replacements['slant']=(
    'reports/aero-amp-slant/retained-20261113/antioch-confirm/artifacts/slant/case-03',
    'Slant · inward held catch','Inward cut · held through finish',
    'Receiver starts two yards beside the midfield machine. Two sustained footfall onsets precede the inward cut: 42.49° early heading change versus 14.65° with zero steering. The route later curves to about 59°, so the intended 45° exit remains imperfect. Running before the receive transitions to forward walking. The 8.779 m free-flight pass produces 186 ms of short control at 0.375 m/s relative speed, then a 2.795 s continuous two-hand hold through 9.5 s. No floor or nonhand body support. No running phases at contact or completed stop. Pretrained locomotion and scripted RGB-D grip; exact reruns and independent checks archived.')
  cases=[]
  for route,source,heading,waypoints,label,delivery,definition,notes in CASES:
   source,label,delivery,notes=replacements[route]
   cases.append((route,source,heading,waypoints,label,delivery,definition,notes))
 plays=[]
 for route,source,heading,waypoints,label,delivery,definition,notes in cases:
  slot_video={'out':'out-tight','slant':'slant-full','go':'go'}
  if args.held:slot_video.update(slant='slant-held-95',go='go-held')
  video_dir=(ROOT/'reports/receiver-slot-20261113'/slot_video[route]) if args.slot else VIDEO/route
  source=ROOT/source;r=json.loads((source/'report.json').read_text());z=np.load(source/'trace.npz');m=z['motion']
  v=np.load(video_dir/'full-play.npz');t=v['timestamps_s'];q=v['qpos']
  a=np.array([np.cos(heading),np.sin(heading)]);n=np.array([-a[1],a[0]]);basis=np.stack([a,n],axis=1)
  origin=np.array(r['release']['release_xyz_m'][:2])@basis
  split=1.8288 if args.slot else 8.128
  assert abs(origin[0])<1e-5 and abs(origin[1]+split)<1e-5,origin
  xy=m[:,1:3]@basis
  path=np.column_stack([t,*[np.interp(t,m[:,0],xy[:,i]) for i in range(2)]]).tolist()
  w,x,y,zz=q[:,3:7].T;yaw=np.arctan2(2*(w*zz+x*y),1-2*(y*y+zz*zz))-heading
  score=r.get('strict_score') or r['catch_score'];throw=r['quarterback_pass_score'];touch=score.get('first_tip_contact_s')
  contact=throw['continuous_two_hand_contact_s'];floor=score.get('first_floor_contact_s')
  stem=route=='go';hold=f'{round(contact*1000)} ms contact' if contact else 'No two-hand control'
  retained=bool(score.get('retention',{}).get('hands_only_retention_at_finish'))
  if args.slot and route=='out':
   audit=json.loads((ROOT/'reports/independent-validation-out-overhead-20261113/measured.json').read_text())
   from hashlib import sha256
   assert sha256((source/'trace.npz').read_bytes()).hexdigest()==audit['trace_sha256']
   assert retained and not audit['external_support_any']
   hold=f"{audit['long_hold']['duration_s']:.3f} s held"
  if args.held and route=='slant':
   audit=json.loads((ROOT/'reports/independent-validation-slant-overhead-20261113/measured.json').read_text())['extension-fast']
   from hashlib import sha256
   assert sha256((source/'trace.npz').read_bytes()).hexdigest()==audit['source_sha256']['trace.npz']
   assert retained and not audit['any_floor_nonhand_or_load']
   hold=f"{audit['long_hold']['sample_duration_s']:.3f} s held"
  if args.held and route=='go':
   audit=json.loads((ROOT/'reports/independent-validation-go-cup-20261113/measured.json').read_text())['extended']
   from hashlib import sha256
   assert sha256((source/'trace.npz').read_bytes()).hexdigest()==audit['source_sha256']['trace.npz']
   assert retained and not audit['any_floor_nonhand_or_load']
   hold=f"{audit['long_hold']['sample_duration_s']:.3f} s held"
  play=dict(route='aero-'+route+'-centerline',label=label,delivery=delivery,waypoints=waypoints,
            motion=path,facing=np.column_stack([t,yaw]).tolist(),firstTouch=None if touch is None else [float(np.interp(touch,m[:,0],xy[:,i])) for i in range(2)],
            launcher=origin.tolist(),release=r['release']['release_time_s'],speed=score.get('pre_tip_speed_mps'),
            airTravel=throw.get('horizontal_flight_m'),error=None,hold=hold,retention='Held' if retained else 'Not retained',definition=definition,notes=notes)
  name=play['route'];plays.append(play)
  shutil.copyfile(video_dir/'full-play.mp4',SITE/(name+'.mp4'))
  poster_at=(9.8 if args.held and route=='go' else 7.4 if args.held and route=='slant'
             else 5.4 if args.slot and route=='out' else r['release']['release_time_s']+.3)
  Image.fromarray(v['rgb'][min(len(t)-1,int(np.searchsorted(t,poster_at)))]).save(SITE/(name+'.webp'),quality=90)
  (SITE/(name+'.json')).write_text(json.dumps({'viewer':play,'report':r,'source':str(source.relative_to(ROOT)),
               'video_verification':json.loads((video_dir/'video-verification.json').read_text())},indent=2)+'\n')
 (SITE/'index.json').write_text(json.dumps(plays,indent=2)+'\n')
 print(json.dumps([dict(route=p['route'],hold=p['hold'],release=p['release']) for p in plays]))

if __name__=='__main__':main()
