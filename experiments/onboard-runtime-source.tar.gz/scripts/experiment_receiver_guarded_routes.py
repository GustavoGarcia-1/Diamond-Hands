"""Compare guarded receiver PPO continuations on 5.2-second development routes."""

from __future__ import annotations

import argparse
from dataclasses import asdict, replace
from functools import partial
from importlib.metadata import version
from pathlib import Path
from time import monotonic

import numpy as np
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv
import torch

from compare_receiver_route_control import DRIVE_FRACTIONS, evaluate
from g1_receiver.receiver_env import POLICY_HZ, ReceiverEnv, sample_trial
from g1_receiver.receiver_ppo_guard import ActorReplayGuard, ReceiverGuardPPO
from g1_receiver.receiver_ppo_smoke import Deadline, file_hash
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
from g1_receiver.train_receiver import _json, _load_demonstrations, _source_snapshot

HORIZON_S = 5.2
FIXTURES = (("go", .16), ("go", .19), ("slant", .17), ("slant", .20))


def summarize(rows: list[dict]) -> dict:
    return {
        "completed": len(rows),
        "full_horizon": sum(row["full_horizon"] for row in rows),
        "visual_retention": sum(row["full_horizon"] and row["visual_retention"] for row in rows),
        "physical_retention": sum(row["full_horizon"] and row["retained_sim_support_2s"] for row in rows),
        "ordered_route_complete": sum(row["full_horizon"] and row["ordered_route_complete"] for row in rows),
        "route_and_retention": sum(row["full_horizon"] and row["route_and_retention"] for row in rows),
        "ball_floor_contacts": sum(row["any_ball_floor_contact"] for row in rows),
        "median_endpoint_error_m": (
            float(np.median([row["final_route_endpoint_error_m"] for row in rows])) if rows else None
        ),
    }


def audit(model, trials, sensor_seed, modes, deadline) -> dict:
    results = {}
    for mode in modes:
        rows = []
        for index, trial in enumerate(trials):
            if monotonic() >= deadline:
                break
            row = evaluate(model, trial, sensor_seed + index, DRIVE_FRACTIONS[mode], round(HORIZON_S * POLICY_HZ))
            rows.append({"case": index, "full_horizon": bool(np.isclose(row["elapsed_s"], HORIZON_S)), **row})
        results[mode] = {
            "cases": rows,
            "all": summarize(rows),
            **{route: summarize([row for row in rows if trials[row["case"]].route == route])
               for route in ("go", "slant")},
        }
    return results


def record_sources(output: Path) -> dict:
    sources = _source_snapshot(output, DEFAULT_RUNTIME_ROOT)
    script = Path(__file__).resolve()
    module_root = script.parent.parent / "src" / "g1_receiver"
    extras = {
        "scripts/experiment_receiver_guarded_routes.py": script,
        "scripts/compare_receiver_route_control.py": script.with_name("compare_receiver_route_control.py"),
        "g1_receiver/receiver_ppo_guard.py": module_root / "receiver_ppo_guard.py",
        "g1_receiver/receiver_ppo_smoke.py": module_root / "receiver_ppo_smoke.py",
    }
    for name, path in extras.items():
        (output / "source" / path.name).write_bytes(path.read_bytes())
        sources[name] = file_hash(path)
    return sources


def run(args) -> None:
    started = monotonic()
    deadline = started + args.wall_seconds
    torch.set_num_threads(1)
    args.output.mkdir(parents=True, exist_ok=False)
    observations = _load_demonstrations(args.bc_data, DEFAULT_RUNTIME_ROOT)["observation"]
    rng = np.random.default_rng(args.dev_seed)
    trials = [replace(sample_trial(rng, "moving"), route=route, route_scale=scale,
                      suite="guarded_route_development") for route, scale in FIXTURES]
    reference = PPO.load(args.initialize, device="cpu")
    if args.steps % reference.n_steps:
        raise ValueError(f"steps must be a multiple of checkpoint rollout size ({reference.n_steps})")
    report = {
        "evidence_class": "multiseed_paired_route_and_catch_development",
        "config": {
            "initialize_sha256": file_hash(args.initialize), "initialize_steps": reference.num_timesteps,
            "bc_data_sha256": file_hash(args.bc_data), "replay_observations": len(observations),
            "actor_kl_budget_per_action": args.max_kl, "train_seeds": args.seeds,
            "development_seed": args.dev_seed, "sensor_seed_base": args.sensor_seed,
            "train_decisions_per_arm": args.steps, "train_rollout_size": reference.n_steps,
            "train_sampler": "frozen_uniform", "train_device": "cpu", "train_workers": 1,
            "development_horizon_s": HORIZON_S, "wall_seconds": args.wall_seconds,
            "development_drive_fractions": DRIVE_FRACTIONS,
        },
        "runtime": {name: version(name) for name in ("mujoco", "gymnasium", "stable-baselines3", "torch")},
        "source_sha256": record_sources(args.output),
        "development_cases": [asdict(trial) for trial in trials],
        "training_pairs": {},
    }
    report_path = args.output / "report.json"
    _json(report_path, report)
    report["reference"] = audit(reference, trials, args.sensor_seed, DRIVE_FRACTIONS, deadline)
    _json(report_path, report)
    print("reference", {name: mode["all"] for name, mode in report["reference"].items()}, flush=True)

    learned_modes = ("learned_drive", "blended_drive")
    vector = DummyVecEnv([partial(ReceiverEnv, DEFAULT_RUNTIME_ROOT)])
    try:
        for seed in args.seeds:
            pair = report["training_pairs"][str(seed)] = {}
            for label, cap in (("unanchored", None), ("anchored", args.max_kl)):
                if monotonic() >= deadline:
                    break
                model = ReceiverGuardPPO.load(args.initialize, env=vector, device="cpu")
                model.verbose = 0
                model.set_random_seed(seed)
                model.replay_guard = ActorReplayGuard(model, observations, cap)
                model.replay_log = []
                model.learn(total_timesteps=args.steps, reset_num_timesteps=False, callback=Deadline(deadline))
                checkpoint = args.output / f"seed-{seed}-{label}.zip"
                model.save(checkpoint)
                pair[label] = {
                    "checkpoint": checkpoint.name, "checkpoint_sha256": file_hash(checkpoint),
                    "collected_decisions": model.num_timesteps - reference.num_timesteps,
                    "updated_decisions": len(model.replay_log) * model.n_steps,
                    "replay_log": model.replay_log,
                }
                _json(report_path, report)
                print(f"seed {seed} {label} trained", pair[label]["updated_decisions"], flush=True)
                pair[label]["development"] = audit(model, trials, args.sensor_seed, learned_modes, deadline)
                _json(report_path, report)
                print(f"seed {seed} {label} audit",
                      {name: mode["all"] for name, mode in pair[label]["development"].items()}, flush=True)
    finally:
        vector.close()

    report["elapsed_seconds"] = monotonic() - started
    report["complete"] = (
        all(mode["all"]["completed"] == len(trials) for mode in report["reference"].values())
        and all(
            len(pair) == 2 and all(
                arm["updated_decisions"] == args.steps
                and all(mode["all"]["completed"] == len(trials) for mode in arm["development"].values())
                for arm in pair.values()
            )
            for pair in report["training_pairs"].values()
        )
    )
    _json(report_path, report)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--initialize", required=True, type=Path)
    parser.add_argument("--bc-data", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--steps", type=int, default=1024)
    parser.add_argument("--seeds", nargs="+", type=int, default=[42271, 42319])
    parser.add_argument("--dev-seed", type=int, default=71931)
    parser.add_argument("--sensor-seed", type=int, default=72017)
    parser.add_argument("--max-kl", type=float, default=.025)
    parser.add_argument("--wall-seconds", type=float, default=660.)
    args = parser.parse_args()
    seeds = (*args.seeds, args.dev_seed, *range(args.sensor_seed, args.sensor_seed + len(FIXTURES)))
    if len(args.seeds) < 2 or len(set(seeds)) != len(seeds) or min(seeds) < 0:
        parser.error("provide at least two distinct training seeds and separate nonnegative development seeds")
    if args.steps <= 0 or not np.isfinite(args.max_kl) or args.max_kl <= 0:
        parser.error("steps and max-kl must be positive")
    if not np.isfinite(args.wall_seconds) or args.wall_seconds <= 0:
        parser.error("wall-seconds must be positive and finite")
    run(args)


if __name__ == "__main__":
    main()
