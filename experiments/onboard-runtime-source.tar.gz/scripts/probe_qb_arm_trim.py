"""Replay an archived fixed-quarterback pass with an opt-in arm-motion trim."""

import argparse
from dataclasses import asdict, fields
import json
from pathlib import Path
from unittest.mock import patch

import numpy as np

import evaluate_aero_receiver as runner
from g1_receiver.pass_control import PassGrip
from g1_receiver.routes import Route
from g1_receiver.run_arm_receive import RunArmReceive
from g1_receiver.running_policy import AmpRunningPolicy


def run(args):
    reference = json.loads(args.reference.read_text())
    settings = {k: v for k, v in reference['play'].items() if k in {f.name for f in fields(runner.Play)}}
    if not settings.get('quarterback_origin_m'):
        raise ValueError('reference needs a fixed quarterback')
    settings['arm_pump'] = True
    settings['grip'] = PassGrip(**settings['grip'])
    if args.target_y_shift:
        for name in ('quarterback_target_m', 'field_catch_window_m'):
            x, y, z = settings[name]
            settings[name] = (x, y + args.target_y_shift, z)
    play = runner.Play(**settings)
    route = Route(play.route, tuple(map(tuple, reference['waypoints_m'])), play.speed)
    cameras = {}
    for name, arg in (('pass', 'pass_camera'), ('track', 'tracking_camera'), ('finish', 'finish_camera')):
        sensor = reference['camera_surveys'][name]
        position = np.asarray(sensor['position_m'])
        aim = position + np.asarray(sensor['rotation'])[:, 2]
        cameras[arg] = (position, aim)
    profile = RunArmReceive(running_fraction=1., pump_rad=args.pump, lowered_rad=args.lowered,
                            raise_duration_s=.22, swing_start_s=2.9)
    plant = runner.make_plant(args.source, route, **cameras)
    try:
        policy = AmpRunningPolicy(plant.joint_names, plant.joint_ranges, args.amp_source)
        with patch.object(runner, 'RunArmReceive', return_value=profile):
            report = runner.run_play(plant, policy, play, route, output=args.output, record=args.record)
    finally:
        plant.close()
    compare(args.reference, args.output, profile, reference, report)


def compare(reference_path, output, profile, reference, report):
    with np.load(reference_path.with_name('trace.npz')) as reference_trace, np.load(output / 'trace.npz') as result_trace:
        reference_motion = reference_trace['motion']
        motion = result_trace['motion']
    time = motion[:, 0]
    reference_position = np.column_stack([np.interp(time, reference_motion[:, 0], reference_motion[:, j])
                                          for j in (1, 2, 3)])
    position_delta = motion[:, 1:4] - reference_position
    receive = report['strict_score']['first_tip_contact_s']
    ref_receive = reference['strict_score']['first_tip_contact_s']
    if ref_receive is None:
        raise ValueError('reference needs a fingertip contact time')
    delta = position_delta[np.argmin(abs(time - (receive or ref_receive)))]
    report['arm_trim_comparison'] = {
        'profile': asdict(profile), 'reference': str(reference_path),
        'pelvis_delta_xyz_m_at_new_or_reference_contact': delta.tolist(),
        'motion_difference_through_reference_contact_m': float(np.linalg.norm(position_delta[time <= ref_receive], axis=1).max()),
        'motion_difference_before_trim_m': float(np.linalg.norm(position_delta[time <= profile.swing_start_s], axis=1).max()),
    }
    (output / 'report.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps(dict(comparison=report['arm_trim_comparison'], visual_ready=report['visual_reach_s'],
                          visual_close=report['visual_closure_s'], pass_score=report['quarterback_pass_score'],
                          running_at_catch=report['running_score']['running_at_catch']), indent=2), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reference', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--amp-source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--pump', type=float, default=.035)
    parser.add_argument('--lowered', type=float, default=.015)
    parser.add_argument('--target-y-shift', type=float, default=0., help='Shift fixed aim and camera receiving window by this field Y offset')
    parser.add_argument('--record', action='store_true')
    run(parser.parse_args())


if __name__ == '__main__':
    main()
