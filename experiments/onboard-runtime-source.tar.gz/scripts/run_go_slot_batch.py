"""Bounded Go baseline sweep with the receiver two yards from the machine."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys

p = argparse.ArgumentParser()
p.add_argument('--output', type=Path, required=True)
p.add_argument('--source', required=True)
p.add_argument('--amp-source', required=True)
a = p.parse_args()
a.output.mkdir(parents=True, exist_ok=False)

def run(item):
    index, flight = item
    out = a.output / f'case-{index:02d}'
    command = [sys.executable, 'scripts/probe_go_stem.py', '--reference',
               f'reports/aero-rl-20261113/slot-flight-{flight:.1f}.json',
               '--source', a.source, '--amp-source', a.amp_source,
               '--output', str(out), '--duration', '7', '--record-poses']
    with (a.output / f'case-{index:02d}.log').open('w') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=300)
    score_path = out / 'stem-score.json'
    return dict(case=index, flight_s=flight, command=command, exit_code=result.returncode,
                score=json.loads(score_path.read_text()) if score_path.exists() else None)

with ThreadPoolExecutor(max_workers=2) as pool:
    results = list(pool.map(run, enumerate((1.0, 1.2, 1.4, 1.6))))
(a.output / 'summary.json').write_text(json.dumps(results, indent=2) + '\n')
if any(result['exit_code'] for result in results):
    raise SystemExit(1)
