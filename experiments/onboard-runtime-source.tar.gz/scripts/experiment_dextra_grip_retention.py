"""Compare bounded grip adjustments after the same vision-timed moving drop."""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass, replace
from hashlib import sha256
import json
from pathlib import Path

import mujoco
import numpy as np

import audit_dextra_moving_release as moving
from g1_receiver.dextra_physical_eval import TRACE_COLUMNS
from g1_receiver.hand_route_plant import HandRoutePlant
from g1_receiver.locomotion import CONTROL_DT


@dataclass(frozen=True)
class GripProfile:
    extra_shoulder_inward_rad: float = 0.
    upward_wrist_roll_rad: float = 0.
    elbow_lift_rad: float = 0.
    shoulder_pitch_rad: float = 0.
    scheduled_delay_s: float = .55
    adaptive: bool = False


PROFILES = {
    "reference": GripProfile(),
    "squeeze": GripProfile(extra_shoulder_inward_rad=.04),
    "wrist_up": GripProfile(upward_wrist_roll_rad=.16),
    "lift_and_roll": GripProfile(upward_wrist_roll_rad=.12, elbow_lift_rad=.06),
    "squeeze_roll": GripProfile(extra_shoulder_inward_rad=.025, upward_wrist_roll_rad=.12),
    "effort_adaptive": GripProfile(extra_shoulder_inward_rad=.04, upward_wrist_roll_rad=.12, adaptive=True),
    "release_squeeze": GripProfile(extra_shoulder_inward_rad=-.035, scheduled_delay_s=.30),
    "wrist_down": GripProfile(upward_wrist_roll_rad=-.10),
    "retreat": GripProfile(elbow_lift_rad=.14, shoulder_pitch_rad=.08, scheduled_delay_s=1.20),
}
RELEASE_S = 2.2
DROP_FORWARD_M = .48
DROP_HEIGHT_M = .49
RAMP_S = .50
ADAPTIVE_REFERENCE_WINDOW_S = (.50, 1.20)
ADAPTIVE_MIN_LOAD_FRACTION = .85
ADAPTIVE_CONFIRM_S = .08


class GripPlant(HandRoutePlant):
    """Leave delivery and route logic unchanged and apply sensed grip adjustments."""

    def __init__(self, codesign_source: Path, profile: GripProfile):
        super().__init__(codesign_source, route_camera_position=moving.ROUTE_CAMERA_M)
        self.profile = profile
        self.effort_addresses = np.array([
            self.model.sensor(f"dextra_effort_{index}").adr[0] for index in range(40)
        ]).reshape(2, 20)
        self.flexion = self.actuation.flexion.reshape(2, 20)
        self.joint_ids = {
            name: [self.joint_names.index(f"{side}_{name}_joint") for side in ("left", "right")]
            for name in ("shoulder_roll", "shoulder_pitch", "wrist_roll", "elbow")
        }
        self.close_s = None
        self.adjust_s = None
        self.last_effort = None
        self.reference = []
        self.reference_effort = None
        self.low_since_s = None
        self.grip_log = []

    def step(self, command, *, closure=0., hand_target_rad=None, post_step=None):
        if closure and self.close_s is None:
            self.close_s = self.timestamp_s
        sensed_efforts = np.abs(self.data.sensordata[self.effort_addresses])
        effort = np.array([sensed_efforts[side, self.flexion[side]].mean() for side in range(2)])
        if self.last_effort is None:
            self.last_effort = effort
        self.last_effort += (1. - np.exp(-CONTROL_DT / .12)) * (effort - self.last_effort)
        if self.close_s is not None and self.adjust_s is None:
            self._update_grip_activation()
        ramp = 0. if self.adjust_s is None else np.clip((self.timestamp_s - self.adjust_s) / RAMP_S, 0., 1.)
        if ramp > 0:
            arm = command.target_position.copy()
            arm[self.joint_ids["shoulder_roll"]] += ramp * self.profile.extra_shoulder_inward_rad * np.array([-1., 1.])
            arm[self.joint_ids["shoulder_pitch"]] += ramp * self.profile.shoulder_pitch_rad
            arm[self.joint_ids["wrist_roll"]] += ramp * self.profile.upward_wrist_roll_rad * np.array([-1., 1.])
            arm[self.joint_ids["elbow"]] -= ramp * self.profile.elbow_lift_rad
            arm = np.clip(arm, self.joint_ranges[:, 0], self.joint_ranges[:, 1])
            command = replace(command, target_position=arm)
        self.grip_log.append((self.timestamp_s, *effort, *self.last_effort, ramp))
        return super().step(command, closure=closure, hand_target_rad=hand_target_rad, post_step=post_step)

    def _update_grip_activation(self) -> None:
        now = self.timestamp_s
        elapsed = now - self.close_s
        if not self.profile.adaptive:
            if self.profile != GripProfile() and elapsed >= self.profile.scheduled_delay_s - 1e-8:
                self.adjust_s = now
            return
        start, end = ADAPTIVE_REFERENCE_WINDOW_S
        if start <= elapsed <= end:
            self.reference.append(self.last_effort.copy())
        elif elapsed > end and self.reference_effort is None and self.reference:
            self.reference_effort = np.median(self.reference, axis=0)
        if self.reference_effort is not None and np.min(self.reference_effort) >= .03:
            weak = np.any(self.last_effort < ADAPTIVE_MIN_LOAD_FRACTION * self.reference_effort)
            if weak and self.low_since_s is None:
                self.low_since_s = now
            elif not weak:
                self.low_since_s = None
            if self.low_since_s is not None and now - self.low_since_s >= ADAPTIVE_CONFIRM_S - 1e-8:
                self.adjust_s = now


def summarize_loss(trace, motion):
    cols = {name: index for index, name in enumerate(TRACE_COLUMNS)}
    floor_hits = trace[trace[:, cols["ball_floor_contact"]] > 0, 0]
    samples = []
    for start, end in ((3.5, 3.7), (5.7, 5.9), (6.1, 6.3)):
        segment = trace[(trace[:, 0] >= start) & (trace[:, 0] < end)]
        if not len(segment):
            continue
        pelvis = np.column_stack([np.interp(segment[:, 0], motion[:, 0], motion[:, index]) for index in (1, 2, 3)])
        normals = [float((segment[:, cols[f"{side}_tip_normal_n"]] + segment[:, cols[f"{side}_palm_normal_n"]]).mean())
                   for side in ("left", "right")]
        samples.append({"time_window_s": [start, end], "mean_ball_minus_pelvis_xyz_m": (segment[:, 1:4] - pelvis).mean(axis=0).tolist(),
                        "mean_palm_tip_normal_n_by_side": normals})
    return {"first_floor_hit_s": float(floor_hits[0]) if len(floor_hits) else None, "time_windows": samples}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("codesign_source", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--profiles", nargs="+", choices=PROFILES, default=list(PROFILES))
    parser.add_argument("--drop-forward", type=float, default=DROP_FORWARD_M)
    args = parser.parse_args()
    if not .40 <= args.drop_forward <= .55:
        parser.error("drop-forward must be 0.40–0.55 m")
    args.output.mkdir(parents=True, exist_ok=False)
    report = {
        "evidence_class": "paired_moving_release_grasp_development_simulation",
        "mujoco_version": mujoco.__version__,
        "release_s": RELEASE_S, "drop_forward_m": args.drop_forward, "drop_height_m": DROP_HEIGHT_M,
        "route_camera_m": moving.ROUTE_CAMERA_M, "horizon_s": moving.HORIZON_S,
        "ramp_s": RAMP_S,
        "adaptive_reference_window_s": ADAPTIVE_REFERENCE_WINDOW_S,
        "adaptive_min_load_fraction": ADAPTIVE_MIN_LOAD_FRACTION, "adaptive_confirm_s": ADAPTIVE_CONFIRM_S,
        "source_sha256": {
            str(Path(__file__).name): sha256(Path(__file__).read_bytes()).hexdigest(),
            str(Path(moving.__file__).name): sha256(Path(moving.__file__).read_bytes()).hexdigest(),
        },
        "results": {},
    }
    for name in args.profiles:
        plant = GripPlant(args.codesign_source, PROFILES[name])
        try:
            result, trace, motion = moving.evaluate(plant, RELEASE_S, args.drop_forward, DROP_HEIGHT_M)
            result.update({"profile": asdict(PROFILES[name]), "adjustment_s": plant.adjust_s,
                           "reference_motor_effort_n_m_by_side": None if plant.reference_effort is None else plant.reference_effort.tolist(),
                           **summarize_loss(trace, motion)})
            trace_path = args.output / f"{name}.npz"
            np.savez_compressed(trace_path, contact=trace, contact_columns=TRACE_COLUMNS, motion=motion,
                                grip=np.array(plant.grip_log), grip_columns=("time_s", "left_effort_n_m", "right_effort_n_m",
                                       "left_filtered_effort_n_m", "right_filtered_effort_n_m", "adjustment_fraction"))
            result["trace_sha256"] = sha256(trace_path.read_bytes()).hexdigest()
            report["results"][name] = result
            (args.output / "report.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
            print(name, result["adjustment_s"], result["moving_hands_only_catch"],
                  result["final_contact"]["hands_only_catch"], result["first_floor_hit_s"],
                  result["endpoint_error_m"], flush=True)
        finally:
            plant.close()


if __name__ == "__main__":
    main()
