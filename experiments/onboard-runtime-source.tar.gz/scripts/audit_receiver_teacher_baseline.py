"""Evaluate the existing visual teacher on the frozen paired checkpoint cases."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from audit_receiver_checkpoints import (
    CASES_NAME, CASES_SHA256, ROOT, build_cases, counts, digest, evaluate, read_json, verify_recovery,
)
from g1_receiver.receiver_env import VisualTeacher
from g1_receiver.receiver_physical_eval import PhysicalAuditReceiverEnv
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT


class TeacherPolicy:
    """Adapter for the same rollout function used with learned policies."""

    def __init__(self, env):
        self.teacher = VisualTeacher(env)

    def predict(self, observation, *, deterministic):
        return self.teacher.action(), None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reports", type=Path, default=ROOT / "reports")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists")

    run, config, provenance = verify_recovery(args.reports)
    manifest = read_json(run / "manifest.json")
    cases_path = args.reports / CASES_NAME
    if digest(cases_path) != CASES_SHA256:
        raise ValueError("challenge plan differs from the predeclared case manifest")
    plan = read_json(cases_path)
    cases, _ = build_cases(plan, config["heldout"])
    rows = []
    env = PhysicalAuditReceiverEnv(DEFAULT_RUNTIME_ROOT)
    try:
        for case in cases:
            row = evaluate(env, TeacherPolicy(env), "visual_teacher", case, plan)
            row["controller"] = row.pop("checkpoint")
            rows.append(row)
            audit = row["physical_audit"]
            print(
                row["case"], row["episode_end"],
                audit["full_horizon_retained_2s"], audit["endpoint_reached"],
                flush=True,
            )
    finally:
        env.close()

    report = {
        "evidence_class": "matched_scripted_visual_teacher_rendered_simulation",
        "case_manifest_sha256": CASES_SHA256,
        "run_manifest_sha256": provenance["run_manifest_sha256"],
        "teacher_source_sha256": manifest["source_sha256"]["g1_receiver/receiver_env.py"],
        "physical_audit_source_sha256": manifest["source_sha256"]["g1_receiver/receiver_physical_eval.py"],
        "shared_audit_script_sha256": digest(Path(__file__).with_name("audit_receiver_checkpoints.py")),
        "baseline_script_sha256": digest(Path(__file__)),
        "summary": {
            "all": counts(rows),
            "by_category": {
                category: counts([row for row in rows if row["category"] == category])
                for category in ("stationary", "go", "slant")
            },
            "by_profile": {
                profile: counts([row for row in rows if row["profile"] == profile])
                for profile in plan["profiles"]
            },
        },
        "rollouts": rows,
    }
    with args.output.open("x") as stream:
        json.dump(report, stream, separators=(",", ":"), allow_nan=False)
        stream.write("\n")
    print(f"Wrote {len(rows)} matched baseline rollouts to {args.output}", flush=True)


if __name__ == "__main__":
    main()
