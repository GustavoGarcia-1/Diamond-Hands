"""Bounded offline-calibrated lower cup fixed-QB entry screen; no online truth control."""
import argparse,json
from pathlib import Path
from copy import deepcopy
import numpy as np
import mujoco
import probe_go_cup as runner
from g1_receiver.aero import make_aero_scene
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT

def main():
 p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--amp-source',type=Path,required=True);p.add_argument('--profile',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True)
 def execute(profile,out,no_pass=False):
  argv=['--source',str(a.source),'--amp-source',str(a.amp_source),'--profile',str(profile),'--output',str(out),'--walk-speed','1','--handoff-depth','1.3','--initial-yaw','-.7','--duration','9.5']
  if no_pass:argv+=['--no-pass']
  return runner.run(runner.build_parser().parse_args(argv))
 calibration_report=execute(a.profile,a.output/'calibration',True)
 if calibration_report['minimum_upright_cosine']<.9 or calibration_report['duration_s']<9.4:raise RuntimeError('no-ball stability preflight failed')
 v=np.load(a.output/'calibration/view.npz');idx=int(np.argmin(abs(v['timestamps_s']-8.88)));m=mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT,a.source));d=mujoco.MjData(m);d.qpos[:]=v['qpos'][idx];mujoco.mj_kinematics(m,d);faces=[];normals=[]
 for side,sign in [('left',1),('right',-1)]:
  b=d.body('aero_'+side+'_palm');R=b.xmat.reshape(3,3);faces.append(b.xpos+R@[-.0025,.017*sign,.07225]);normals.append(R@[0,sign,0])
 target=np.mean(faces,0)+.085*np.mean(normals,0)+[.03,0,0]
 (a.output/'calibration.json').write_text(json.dumps(dict(timestamp_s=float(v['timestamps_s'][idx]),face_centers_m=np.array(faces).tolist(),face_normals=np.array(normals).tolist(),fixed_target_m=target.tolist(),offline_calibration=True),indent=2)+'\n')
 donor=json.loads(a.profile.read_text());rows=[]
 for z in (0.,):
  for flight in (1.1,1.5,1.9):
   lead=.18
   i=len(rows);profile=deepcopy(donor);play=profile['play'];play['flight_s']=flight;play['release_s']=8.88-flight;aim=target+[0,0,z];play['quarterback_target_m']=aim.tolist();play['field_catch_window_m']=aim.tolist();axis=aim[:2]-np.array(play['quarterback_origin_m'])[:2];play['field_approach_axis_xy']=(axis/np.linalg.norm(axis)).tolist();play['grasp_offsets_rad']=[0.]*14;play['grip']['lead_s']=lead;play['grasp_joint_lead_s']=0.;play['pregrip_closure']=.2
   path=a.output/f'profile-{i:02d}.json';path.write_text(json.dumps(profile,indent=2)+'\n');report=execute(path,a.output/f'case-{i:02d}');rows.append(dict(case=i,z_offset_m=z,grip_lead_s=lead,flight_s=flight,report=report))
 (a.output/'screen.json').write_text(json.dumps(rows,indent=2)+'\n')
if __name__=='__main__':main()
