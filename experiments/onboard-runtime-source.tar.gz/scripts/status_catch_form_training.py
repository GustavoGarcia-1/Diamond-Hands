"""Read bounded Antioch training status from one or more saved job receipts."""
import argparse
import json
from pathlib import Path

from antioch.client import Client, targeting


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('receipts', type=Path, nargs='+')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    receipts = [(p, json.loads(p.read_text())) for p in args.receipts]
    sessions = {r['session'] for _, r in receipts}
    if len(sessions) != 1:
        parser.error('all receipts must belong to the same worker session')
    client = Client()
    session = targeting.resolve_session(client, session=next(iter(sessions)), any_project=True, fresh=True)
    code = '''import json,pathlib,sys
results=[]
for root in json.loads(sys.argv[1]):
 p=pathlib.Path(root)/'artifacts'
 row={'remote_root':root,'status':json.loads((p/'status.json').read_text())}
 progress=list(p.glob('*/progress.jsonl'))
 row['progress']=[json.loads(x) for x in progress[0].read_text().splitlines()[-2:]] if progress else []
 row['checkpoints']=[str(x.relative_to(p)) for x in p.glob('*/checkpoint-*.zip')]
 row['final_checkpoint_present']=bool(list(p.glob('*/final.zip')))
 row['completed_training_receipts']=[json.loads(x.read_text()) for x in p.glob('*/receipt.json')]
 if row['status']['phase']=='failed':row['failure_log_tail']=(p/'training.log').read_text()[-4000:]
 results.append(row)
print(json.dumps(results))
'''
    with targeting.attach_agent(client, session.session, 'sim') as agent:
        result = agent.run(['python3', '-c', code, json.dumps([r['remote_root'] for _, r in receipts])],
                           cwd='/tmp', timeout=30)
        rows = json.loads(result.stdout.decode())
    for row, (path, _) in zip(rows, receipts):
        row['local_receipt'] = str(path)
    output = json.dumps(rows, indent=2)+'\n'
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(output)
    print(output, end='')


if __name__ == '__main__':
    main()
