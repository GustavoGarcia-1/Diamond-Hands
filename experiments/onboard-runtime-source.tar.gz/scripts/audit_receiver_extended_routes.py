"""Compare two fixed drive controllers on the frozen 5.2-second receiver audit."""

from __future__ import annotations

import argparse
from importlib.metadata import version
import json
import os
from pathlib import Path
import platform
from statistics import median

import numpy as np
from stable_baselines3 import PPO
import torch

from audit_receiver_checkpoints import (
    POSITION_JITTER_M, ROOT, VELOCITY_JITTER_MPS, digest, read_json, verify_recovery,
)
from compare_receiver_route_control import DRIVE_FRACTIONS, evaluate
from g1_receiver.receiver_env import LOBS, POLICY_HZ, ReceiverTrial
from g1_receiver.routes import make_route

CASES_NAME = "receiver-extended-paired-cases.json"
CASES_SHA256 = "cfb7130d945ae85c660753b711cb8e722e13a27709459e5c60dd153eefed74b9"
COMPARISON_SCRIPT = Path(__file__).with_name("compare_receiver_route_control.py")


def require_digest(path: Path, checksum: str) -> None:
    if digest(path) != checksum:
        raise ValueError(f"{path.name} differs from the fixed evaluation input")


def release_key(row: dict) -> tuple:
    return tuple(row["release_position_m"]), tuple(row["release_velocity_mps"])


def build_cases(plan: dict, reports: Path, original_trials: list[dict]) -> tuple[list[dict], dict]:
    development_path = reports / "receiver-route-control-extended.json"
    fresh_path = reports / "receiver-fresh-paired-cases.json"
    require_digest(development_path, plan["prior_development_report_sha256"])
    require_digest(fresh_path, plan["prior_fresh_cases_sha256"])
    development = read_json(development_path)["trials"]
    fresh = read_json(fresh_path)
    excluded_releases = {release_key(row) for row in [*original_trials, *development, *fresh["throws"].values()]}
    excluded_scales = {
        (row["route"], row["route_scale"]) for row in [*original_trials, *development] if row["route"] is not None
    } | {(route, scale) for route, scales in fresh["route_scales"].items() for scale in scales.values()}
    cases = []
    novelty = {}
    for fixture in plan["fixtures"]:
        fixture_id = fixture["id"]
        position, velocity = release_key(fixture)
        geometry = fixture["route"], fixture["route_scale"]
        in_training = any(
            np.all(np.abs(np.asarray(position) - center) <= POSITION_JITTER_M)
            and np.all(np.abs(np.asarray(velocity) - speed) <= VELOCITY_JITTER_MPS)
            for center, speed in LOBS.values()
        )
        if in_training or (position, velocity) in excluded_releases or geometry in excluded_scales:
            raise ValueError(f"fixture is not fresh: {fixture_id}")
        excluded_releases.add((position, velocity))
        excluded_scales.add(geometry)
        route = make_route(*geometry)
        novelty[fixture_id] = {
            "outside_declared_training_throw_support": True,
            "route_scale": geometry[1],
            "route_length_m": route.length_m,
            "final_waypoint_xy_m": route.waypoints[-1],
        }
        for profile, settings in plan["sensor_profiles"].items():
            trial = ReceiverTrial(
                "moving", position, velocity, route=geometry[0], route_scale=geometry[1], suite=profile, **settings,
            )
            cases.append({
                "case": f"{fixture_id}/{profile}",
                "seed": fixture["seed"],
                "trial": trial,
            })
    return cases, novelty


def counts(rows: list[dict]) -> dict:
    return {
        "rollouts": len(rows),
        "full_horizon": sum(row["full_horizon"] for row in rows),
        "ordered_route_complete": sum(row["ordered_route_complete"] for row in rows),
        "physical_support_2s": sum(row["retained_sim_support_2s"] for row in rows),
        "route_and_retention": sum(row["route_and_retention"] for row in rows),
        "visual_retention": sum(row["visual_retention"] for row in rows),
        "visual_physical_disagreements": sum(
            row["retained_sim_support_2s"] != row["visual_retention"] for row in rows
        ),
        "ball_floor_contacts": sum(row["any_ball_floor_contact"] for row in rows),
        "median_endpoint_error_m": median(row["final_route_endpoint_error_m"] for row in rows),
    }


def summarize(rows: list[dict], profiles: dict) -> dict:
    by_route = {}
    for route in ("go", "slant"):
        route_rows = [row for row in rows if row["route"] == route]
        by_route[route] = {
            "all": counts(route_rows),
            "clean": counts([row for row in route_rows if row["profile"] == "clean"]),
            "stress": counts([row for row in route_rows if row["profile"] != "clean"]),
            "by_profile": {
                profile: counts([row for row in route_rows if row["profile"] == profile]) for profile in profiles
            },
        }
    return {"all": counts(rows), "by_route": by_route}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reports", type=Path, default=ROOT / "reports")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists")

    cases_path = args.reports / CASES_NAME
    require_digest(cases_path, CASES_SHA256)
    plan = read_json(cases_path)
    require_digest(COMPARISON_SCRIPT, plan["shared_comparison_script_sha256"])
    if POLICY_HZ != plan["policy_hz"]:
        raise ValueError("simulator policy cadence differs from the fixed evaluation cadence")
    if any(DRIVE_FRACTIONS[mode] != fraction for mode, fraction in plan["drive_fractions"].items()):
        raise ValueError("shared comparison drive fraction differs from the fixed evaluation")
    run, config, provenance = verify_recovery(args.reports)
    checkpoint = run / provenance["checkpoints"]["ppo_12288"]["filename"]
    require_digest(checkpoint, plan["checkpoint_sha256"])
    cases, novelty = build_cases(plan, args.reports, config["heldout"])

    torch.set_num_threads(1)
    model = PPO.load(checkpoint, device="cpu")
    if model.num_timesteps != 12288:
        raise ValueError("unexpected checkpoint step count")
    steps = round(plan["horizon_s"] * POLICY_HZ)
    rows = {}
    for mode, fraction in plan["drive_fractions"].items():
        rows[mode] = []
        for case in cases:
            trial = case["trial"]
            result = evaluate(model, trial, case["seed"], fraction, steps)
            full = abs(result["elapsed_s"] - plan["horizon_s"]) <= 1e-7
            rows[mode].append({
                **result,
                "evidence_class": "extended_simulator_truth_evaluation_only",
                "case": case["case"],
                "seed": case["seed"],
                "route": trial.route,
                "profile": trial.suite,
                "full_horizon": full,
            })
            print(
                mode, case["case"], "full" if full else "early",
                result["ordered_route_complete"], result["retained_sim_support_2s"],
                result["route_and_retention"], flush=True,
            )
    combined = {
        mode: {row["case"] for row in mode_rows if row["route_and_retention"]}
        for mode, mode_rows in rows.items()
    }
    report = {
        "evidence_class": "fixed_fresh_paired_extended_rendered_simulation",
        "case_manifest_sha256": CASES_SHA256,
        "checkpoint_sha256": plan["checkpoint_sha256"],
        "run_manifest_sha256": provenance["run_manifest_sha256"],
        "source_archive_sha256": provenance["source_archive_sha256"],
        "shared_comparison_script_sha256": plan["shared_comparison_script_sha256"],
        "audit_script_sha256": digest(Path(__file__)),
        "diagnostic_horizon_s": steps / POLICY_HZ,
        "drive_fractions": plan["drive_fractions"],
        "fixtures": novelty,
        "runtime": {
            "platform": platform.platform(),
            "mujoco_gl": os.environ.get("MUJOCO_GL"),
            "policy_device": "cpu",
            "dependencies": {name: version(name) for name in ("mujoco", "stable-baselines3", "torch", "onnxruntime")},
        },
        "metrics": {
            "ordered_route_complete": "Visit physical waypoint regions in order, finish in the final region and keep minimum pelvis upright cosine at least 0.90. The region radius is the smaller of 5 cm and 10% of the incoming leg.",
            "physical_support_2s": "At least two seconds of final robot contact at 50 Hz, no sampled floor contact and the existing physical audit's height and upright thresholds.",
            "route_and_retention": "Both ordered_route_complete and physical_support_2s in the same trial.",
        },
        "limitations": [
            "Six engineered releases and three settings per release. Repeated settings on a release are correlated.",
            "The synthetic fixed view uses isolated axial depth noise or frame delay, nominal friction and zero dropout.",
            "The 5.2 s diagnostic continues the 3.4 s training environment past its time limit using fresh sensor history.",
            "Sampled robot contact may include torso support. Route completion does not require stopping or a post-arrival hold.",
            "All cases are short indoor go or positive-y slant routes. No physical robot, running, varied spins or mirrored slant was evaluated.",
        ],
        "summary": {mode: summarize(mode_rows, plan["sensor_profiles"]) for mode, mode_rows in rows.items()},
        "combined_success_pairs": {
            "both": sorted(combined["route_follower"] & combined["blended_drive"]),
            "route_follower_only": sorted(combined["route_follower"] - combined["blended_drive"]),
            "blended_drive_only": sorted(combined["blended_drive"] - combined["route_follower"]),
            "neither": sorted({case["case"] for case in cases} - combined["route_follower"] - combined["blended_drive"]),
        },
        "rollouts": rows,
    }
    with args.output.open("x") as stream:
        json.dump(report, stream, separators=(",", ":"), allow_nan=False)
        stream.write("\n")
    print(f"Wrote {len(cases)} cases per controller to {args.output}", flush=True)


if __name__ == "__main__":
    main()
