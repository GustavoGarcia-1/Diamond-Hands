"""Matched no-grasp controls using the immutable confirmed route controllers.

Change only finger closure and triggered jaw closure. Preserve the fixed throw,
route, cameras, initial stance, staged open cup, and duration. This tests the
scripted grasp contribution, not whether locomotion or learning is causal.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--source',required=True);p.add_argument('--amp-source',required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
routes={
 'go':dict(root='/workspace/g1-receiver-runs/aero-go-cup-confirm-20261113-r1/source',
   script='scripts/probe_go_cup.py', profile='reports/aero-rl-20261113/go-cup-pass-linux/artifacts/go/profile-07.json',
   flag='--profile',arguments=['--walk-speed','1','--handoff-depth','1.3','--initial-yaw','-.7','--duration','12.88']),
 'out':dict(root='/workspace/g1-receiver-runs/out-left-overhead-confirm-20261114-0123/source',
   script='scripts/probe_aero_out.py',profile='reports/out-scrimmage/left-turn-20261113/overhead-pass-linux/artifacts/out/profile-07.json',
   flag='--pass-profile',arguments=['--duration','8','--approach-handoff-depth-m','2.1','--cut-speed','1.4',
    '--blend-s','.5','--turn-s','.4','--hold-straight-s','0','--depth-feedback-gain','4',
    '--camera-start-s','.8','--stopping-lookahead-s','.55','--reverse-speed','0','--approach-speed','.48',
    '--horizontal-pass-distance','--record-poses']),
 'slant':dict(root='/workspace/g1-receiver-runs/slant-retained-20261113-confirm/source',
   script='scripts/probe_aero_amp_slant.py',profile='reports/aero-amp-slant/retained-20261113/overhead-pass-profile-07.json',
   flag='--pass-profile',arguments=['--two-step','--turn-ramp','.2','--cut-walk-s','1.35','--cut-walk-vx','.65',
    '--cut-arm-override-fraction','0','--cut-arm-recovery-s','.45','--disable-braking','--horizon','9.5',
    '--endpoint','14.1','3.8','--record-poses','--heading','-.85','--cut-walk-vy','-1.5',
    '--post-cut-heading','-.3','--launch-shift','0','0','0'])}

def run(pair):
 name,spec=pair;root=Path(spec['root'])
 original=Path(spec['profile']);profile=json.loads(original.read_text())
 changed={}
 for key,value in dict(closure=0.,pregrip_closure=0.,pregrip=0.,hold_curls=[0.,0.],
                       grasp_offsets_rad=[0.]*14,hold_offsets_rad=[0.]*14).items():
  changed[key]={'before':profile['play'].get(key),'after':value};profile['play'][key]=value
 target=a.output/(name+'-neutral-profile.json');target.write_text(json.dumps(profile,indent=2)+'\n')
 command=[sys.executable,spec['script'],'--source',a.source,'--amp-source',a.amp_source,
          '--output',str(a.output/name),spec['flag'],str(target),*spec['arguments']]
 env=dict(os.environ,PYTHONPATH=str(root/'src')+':'+str(root/'scripts'))
 with (a.output/(name+'.log')).open('w') as log:
  result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 report=a.output/name/'report.json'
 return {'route':name,'controller_root':str(root),'controller_sha256':sha256((root/spec['script']).read_bytes()).hexdigest(),
         'original_profile_sha256':sha256(original.read_bytes()).hexdigest(),'changes':changed,
         'command':command,'exit_code':result.returncode,
         'report':json.loads(report.read_text()) if report.exists() else None}

(a.output/'protocol.json').write_text(json.dumps({'purpose':__doc__,'rules':'No thresholds changed; no truth inputs or support added'},indent=2)+'\n')
with ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(run,routes.items()))
(a.output/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
if any(r['exit_code'] for r in results):raise SystemExit(1)
