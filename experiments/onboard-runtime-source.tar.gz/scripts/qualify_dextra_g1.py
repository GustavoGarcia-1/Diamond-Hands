"""Qualify paired hand catch and carry in a controlled free-base G1 drop fixture."""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
from hashlib import file_digest
import json
from pathlib import Path

import mujoco
import numpy as np

from g1_receiver.dextra import UPSTREAM_URDF, dextra_ready_joint_targets, verify_source_urdf
from g1_receiver.dextra_physical_eval import DextraContactAudit, DextraRetentionCriteria, TRACE_COLUMNS
from g1_receiver.hand_route_plant import HandRoutePlant
from g1_receiver.locomotion import CATCH_BALL_CENTER_OFFSET_M, CONTROL_DT
from g1_receiver.perception import ColorBallDetector
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT, RobotObservation, SkillGoal
from g1_receiver.train_receiver import _source_snapshot


@dataclass(frozen=True)
class Scenario:
    release_position_m: tuple[float, float, float] = (.47, 0., 1.30)
    release_velocity_mps: tuple[float, float, float] = (-.20, 0., -.15)
    closure: str = "scheduled"
    close_s: float = .12
    camera_height_m: float = 1.21
    carry_start_s: float | None = None
    carry_forward_mps: float = .20
    duration_s: float = 3.6


SCENARIOS = {
    "open_control": Scenario(closure="open"),
    "early_control": Scenario(close_s=.06),
    "late_control": Scenario(close_s=.20),
    "stationary": Scenario(),
    "stationary_forward_offset": Scenario(release_position_m=(.51, 0., 1.30)),
    "carry": Scenario(carry_start_s=1.20),
    "camera_stationary": Scenario(closure="camera"),
    "camera_carry": Scenario(closure="camera", carry_start_s=1.20),
    "camera_carry_earlier": Scenario(closure="camera", camera_height_m=1.215, carry_start_s=1.20),
}


class CatchReplay:
    """Record simultaneous close-up and whole-robot views of the same physics state."""

    def __init__(self, plant: HandRoutePlant, output: Path):
        import imageio.v2 as imageio

        self.data = plant.data
        plant.model.vis.global_.offwidth = 640
        plant.model.vis.global_.offheight = 540
        self.renderer = mujoco.Renderer(plant.model, height=540, width=640)
        self.writer = imageio.get_writer(output, fps=25, codec="libx264", macro_block_size=1)
        self.close_camera = mujoco.MjvCamera()
        self.close_camera.distance = .79
        self.close_camera.azimuth = 135.
        self.close_camera.elevation = -14.
        self.wide_camera = mujoco.MjvCamera()
        self.wide_camera.distance = 2.65
        self.wide_camera.azimuth = 130.
        self.wide_camera.elevation = -12.
        self.palms = tuple(self.data.body(f"dextra_{side}_palm") for side in ("left", "right"))
        self.pelvis = self.data.body("pelvis")

    def capture(self, *, slow_catch: bool) -> None:
        self.close_camera.lookat[:] = (self.palms[0].xpos + self.palms[1].xpos) / 2 + [.065, 0., .045]
        self.wide_camera.lookat[:] = [self.pelvis.xpos[0] + .11, self.pelvis.xpos[1], .80]
        self.renderer.update_scene(self.data, camera=self.close_camera)
        close = self.renderer.render().copy()
        self.renderer.update_scene(self.data, camera=self.wide_camera)
        combined = np.concatenate((close, self.renderer.render()), axis=1)
        self.writer.append_data(combined)
        if slow_catch:
            self.writer.append_data(combined)

    def close(self) -> None:
        try:
            self.writer.close()
        finally:
            self.renderer.close()


def evaluate(plant: HandRoutePlant, scenario: Scenario, target: np.ndarray,
             replay: CatchReplay | None = None) -> tuple[dict, np.ndarray]:
    plant.reset(release_position_m=scenario.release_position_m, release_velocity_mps=scenario.release_velocity_mps,
                joint_positions=target)
    audit = DextraContactAudit(plant.model)
    carry_audit = (
        DextraContactAudit(plant.model, criteria=DextraRetentionCriteria(
            window_s=scenario.duration_s - scenario.carry_start_s,
        )) if scenario.carry_start_s is not None else None
    )
    detector = ColorBallDetector(ball_center_offset_m=CATCH_BALL_CENTER_OFFSET_M)
    previous_height = None
    close_s = None
    camera_rows = []
    carry_start_xy = None
    carry_start_ball_xy = None
    initial_ball_center = plant.data.geom_xpos[audit.ball_geom].copy()
    initial_pelvis = plant.data.body("pelvis").xpos.copy()
    min_imu_upright = 1.0
    peak_finger_effort = 0.0
    unmeasured_body_effort = np.zeros(29)
    if replay is not None:
        replay.capture(slow_catch=True)
    for tick in range(round(scenario.duration_s / CONTROL_DT)):
        now = plant.timestamp_s
        if close_s is None:
            if scenario.closure == "scheduled" and now >= scenario.close_s - 1e-8:
                close_s = now
            if scenario.closure == "camera":
                detection = detector.detect(*plant.capture())
                height = None if detection is None else float(detection.position_m[2])
                camera_rows.append({"time_s": now, "height_m": height})
                if height is not None and previous_height is not None and height < previous_height:
                    if height <= scenario.camera_height_m:
                        close_s = now
                previous_height = height
        carrying = scenario.carry_start_s is not None and now >= scenario.carry_start_s - 1e-8
        if carrying and carry_start_xy is None:
            carry_start_xy = plant.data.body("pelvis").xpos[:2].copy()
            carry_start_ball_xy = plant.data.geom_xpos[audit.ball_geom, :2].copy()
        goal = SkillGoal(base_velocity=np.array([scenario.carry_forward_mps if carrying else 0., 0., 0.]))
        observation = RobotObservation(now, *plant.observe(), unmeasured_body_effort, None)
        min_imu_upright = min(min_imu_upright, 1. - 2. * float(observation.imu_quat_wxyz[1:3] @ observation.imu_quat_wxyz[1:3]))
        command = plant.wbc.act(observation, goal, upper_target=target)
        def record(data):
            nonlocal peak_finger_effort
            audit.record(data)
            if carrying:
                carry_audit.record(data)
            peak_finger_effort = max(peak_finger_effort, float(np.max(np.abs(data.actuator_force[plant.actuation.hand_actuators]))))
        plant.step(command, closure=float(close_s is not None), post_step=record)
        if replay is not None and tick % 2 == 1:
            replay.capture(slow_catch=plant.timestamp_s <= .48)
    result = audit.summary()
    trace = audit.trace()
    pelvis_final = plant.data.body("pelvis").xpos.copy()
    ball_final = plant.data.geom_xpos[audit.ball_geom].copy()
    result.update({
        "scenario": asdict(scenario), "closed_at_s": close_s, "camera_pretrigger_heights": camera_rows,
        "initial_ball_center_m": initial_ball_center.tolist(), "initial_pelvis_m": initial_pelvis.tolist(),
        "final_pelvis_m": pelvis_final.tolist(), "minimum_imu_upright_cosine": min_imu_upright,
        "peak_finger_actuator_effort_nm": peak_finger_effort, "warning_count": sum(w.number for w in plant.data.warning),
    })
    result["hands_only_catch_pass"] = bool(result["hands_only_catch"] and min_imu_upright >= .90 and not result["warning_count"])
    if carry_audit is not None:
        carry = carry_audit.summary()
        pelvis_travel = float(np.linalg.norm(pelvis_final[:2] - carry_start_xy))
        ball_travel = float(np.linalg.norm(ball_final[:2] - carry_start_ball_xy))
        carry.update({"pelvis_displacement_m": pelvis_travel, "ball_displacement_m": ball_travel})
        carry["hands_only_carry_pass"] = bool(result["hands_only_catch_pass"] and carry["hands_only_retention"]
                                              and min(pelvis_travel, ball_travel) >= .25)
        result["carry_interval"] = carry
    return result, trace


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("codesign_source", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--scenarios", nargs="+", choices=SCENARIOS,
                        default=[name for name, case in SCENARIOS.items() if case.closure != "camera"])
    parser.add_argument("--record", choices=SCENARIOS)
    args = parser.parse_args()
    if args.record is not None and args.record not in args.scenarios:
        parser.error("recorded scenario must be enabled in --scenarios")
    args.output.mkdir(parents=True, exist_ok=False)
    plant = HandRoutePlant(args.codesign_source, survey_camera=any(SCENARIOS[name].closure == "camera" for name in args.scenarios))
    target = dextra_ready_joint_targets(plant.nominal, plant.joint_names)
    sources = _source_snapshot(None, DEFAULT_RUNTIME_ROOT)
    script = Path(__file__).resolve()
    module_root = script.parent.parent / "src" / "g1_receiver"
    for path in (script, *(module_root / name for name in (
        "dextra.py", "dextra_physical_eval.py", "hand_route_plant.py",
    ))):
        with path.open("rb") as stream:
            sources[str(path.relative_to(script.parent.parent))] = file_digest(stream, "sha256").hexdigest()
    report = {
        "evidence_class": "controlled_free_base_simulation_development",
        "source_urdf_sha256": verify_source_urdf(args.codesign_source / UPSTREAM_URDF),
        "mujoco_version": mujoco.__version__,
        "control_hz": 1 / CONTROL_DT, "criteria": asdict(DextraRetentionCriteria()),
        "trace_columns": TRACE_COLUMNS, "body_target_rad": dict(zip(plant.joint_names, target.tolist(), strict=True)),
        "source_sha256": sources,
        "results": {},
    }
    try:
        for name in args.scenarios:
            movie_path = args.output / f"{name}.mp4"
            replay = CatchReplay(plant, movie_path) if name == args.record else None
            try:
                result, trace = evaluate(plant, SCENARIOS[name], target, replay)
            finally:
                if replay is not None:
                    replay.close()
            if replay is not None:
                with movie_path.open("rb") as stream:
                    result["video_sha256"] = file_digest(stream, "sha256").hexdigest()
            trace_path = args.output / f"{name}.npz"
            np.savez_compressed(trace_path, samples=trace, columns=TRACE_COLUMNS)
            with trace_path.open("rb") as stream:
                result["trace_sha256"] = file_digest(stream, "sha256").hexdigest()
            report["results"][name] = result
            print(name, result["closed_at_s"], result["hands_only_catch_pass"],
                  result.get("carry_interval", {}).get("hands_only_carry_pass"), flush=True)
    finally:
        plant.close()
    with (args.output / "report.json").open("x") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write("\n")


if __name__ == "__main__":
    main()
