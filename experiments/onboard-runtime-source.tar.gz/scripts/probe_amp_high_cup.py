"""No-ball AMP stability test with explicit upper-command observation centering.

The optional transform subtracts the *commanded* change from the ready-arm
posture from measured arm encoders and its rate from measured velocities. Leg
encoders, IMU and all physical dynamics are unchanged. This tests a frozen
policy adaptation, not training or a Kimodo full-body tracker.
"""
import argparse
from dataclasses import replace
import json
from pathlib import Path
import mujoco
import numpy as np
from evaluate_aero_receiver import make_plant
from g1_receiver.aero import aero_ready_joint_targets
from g1_receiver.football_routes import imu_yaw, heading_error
from g1_receiver.locomotion import CONTROL_DT
from g1_receiver.running_catch_eval import FootContactRecorder
from g1_receiver.running_policy import AmpRunningPolicy
from g1_receiver.routes import Route
from g1_receiver.runtime import RobotObservation, SkillGoal


def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--source',type=Path,required=True);p.add_argument('--amp-source',type=Path,required=True)
 p.add_argument('--profile',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
 p.add_argument('--centering',type=float,default=0.);p.add_argument('--raise-cup',action='store_true')
 a=p.parse_args()
 if not 0.<=a.centering<=1.:p.error('centering must be within[0,1]')
 if a.output.exists():raise FileExistsError(a.output)
 spec=json.loads(a.profile.read_text())
 plant=make_plant(a.source,Route('go',((0.,0.),(16.,0.)),2.))
 try:
  policy=AmpRunningPolicy(plant.joint_names,plant.joint_ranges,a.amp_source)
  ready=aero_ready_joint_targets(policy.nominal,plant.joint_names)
  arms=[plant.joint_names.index(f'{s}_{axis}_joint') for s in ('left','right') for axis in
        ('shoulder_roll','shoulder_yaw','shoulder_pitch','elbow','wrist_roll','wrist_pitch','wrist_yaw')]
  offsets=np.asarray(spec['out_staged_arm_offsets_rad']);assert offsets.shape==(14,)
  plant.reset(joint_positions=ready,release_position_m=(-10.,-10.,.085))
  plant.data.qpos[plant.base+3:plant.base+7]=(np.cos(-.35),0.,0.,np.sin(-.35))
  mujoco.mj_forward(plant.model,plant.data)
  policy.reset();feet=FootContactRecorder(plant.model)
  motion=[];poses=[];commands=[];last_shift=np.zeros(14)
  for tick in range(351):
   now=plant.timestamp_s;obs=RobotObservation(now,*plant.observe(),np.zeros(29),None)
   yaw=imu_yaw(obs.imu_quat_wxyz)
   u=float(np.clip((now-1.6)/1.,0.,1.)) if a.raise_cup else 0.
   shift=(u*u*(3.-2.*u))*offsets
   target=ready.copy();target[arms]+=shift
   q=obs.joint_position.copy();dq=obs.joint_velocity.copy()
   q[arms]-=a.centering*shift;dq[arms]-=a.centering*(shift-last_shift)/CONTROL_DT
   centered=replace(obs,joint_position=q,joint_velocity=dq)
   last_shift=shift.copy()
   drive=np.array([min(2.,1.8*max(0.,now-.4)),0.,np.clip(1.8*heading_error(0.,yaw),-.75,.75)])
   pelvis=plant.data.body('pelvis')
   motion.append((now,*pelvis.xpos,float(pelvis.xmat[8]),yaw))
   commands.append((now,*drive,u,*q,*dq))
   if tick%2==0:poses.append((now,plant.data.qpos.copy()))
   _,x,y,_=obs.imu_quat_wxyz
   if tick==350 or 1.-2.*(x*x+y*y)<.54:break
   command=policy.act(centered,SkillGoal(base_velocity=drive),upper_target=target)
   plant.step(command,closure=.2,post_step=feet.record)
  m=np.array(motion);a.output.mkdir(parents=True)
  np.savez_compressed(a.output/'trace.npz',motion=m,commands=commands,**feet.arrays())
  t,qpos=zip(*poses);np.savez_compressed(a.output/'view.npz',timestamps_s=t,qpos=qpos)
  report={'purpose':__doc__,'centering_fraction':a.centering,'raised_cup':a.raise_cup,
          'initial_yaw_rad':-.7,'duration_s':float(m[-1,0]),'minimum_upright_cosine':float(m[:,4].min()),
          'max_stem_error_m':float(abs(m[:,2]).max()),'final_xyz_m':m[-1,1:4].tolist(),
          'final_yaw_rad':float(m[-1,5]),'warning_count':sum(int(w.number) for w in plant.data.warning)}
  (a.output/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
 finally:plant.close()

if __name__=='__main__':main()
