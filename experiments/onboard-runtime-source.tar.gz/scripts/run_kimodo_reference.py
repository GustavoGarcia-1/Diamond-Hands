"""Bounded native-G1 Kimodo pilot: verify ordinary gated access before setup.

Never prints token values, authentication headers, response bodies or signed URLs.
An access failure is a recorded blocker, not an invitation to bypass model gates.
"""
import argparse
from datetime import datetime,timezone
from hashlib import sha256
import json,os,subprocess,sys,shutil
from pathlib import Path
import urllib.request,urllib.error,urllib.parse

KIMODO_COMMIT='e1c219c99b4b94ba48be1fb6a1cbc64ecee4c954'
KIMODO_MODEL='nvidia/Kimodo-G1-RP-v1'
KIMODO_REVISION='3020ad8c419c244e0429d360163730c63c4ed011'
ENCODERS=('meta-llama/Meta-Llama-3-8B-Instruct',
          'McGill-NLP/LLM2Vec-Meta-Llama-3-8B-Instruct-mntp',
          'McGill-NLP/LLM2Vec-Meta-Llama-3-8B-Instruct-mntp-supervised')

class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,request,fp,code,msg,headers,newurl):
        redirected=super().redirect_request(request,fp,code,msg,headers,newurl)
        if redirected is not None and urllib.parse.urlparse(request.full_url).netloc!=urllib.parse.urlparse(newurl).netloc:
            redirected.remove_header('Authorization')
        return redirected

def standard_token():
    try:
        from huggingface_hub import get_token
        token=get_token()
        if token:return token,'huggingface_hub standard provider'
    except ImportError:pass
    for key in ('HF_TOKEN','HUGGING_FACE_HUB_TOKEN'):
        token=os.environ.get(key)
        if token and token.strip():return token.strip(),'standard environment'
    home=Path(os.environ.get('HF_HOME',Path.home()/'.cache/huggingface'))
    path=Path(os.environ.get('HF_TOKEN_PATH',home/'token'))
    if path.is_file():
        token=path.read_text().strip()
        if token:return token,'standard token cache'
    return None,'none'

def request_status(url,token,*,json_body=False):
    headers={'User-Agent':'g1-receiver-kimodo-access-check'}
    if token:headers['Authorization']='Bearer '+token
    request=urllib.request.Request(url,headers=headers,method='GET' if json_body else 'HEAD')
    try:
        with urllib.request.build_opener(SafeRedirect()).open(request,timeout=30) as response:
            status={'http_status':response.status,'host':urllib.parse.urlparse(response.url).hostname}
            if json_body:return status,json.loads(response.read(2_000_000))
            return status
    except urllib.error.HTTPError as error:
        return {'http_status':error.code,'error_code':error.headers.get('X-Error-Code'),'host':urllib.parse.urlparse(url).hostname}
    except Exception as error:
        return {'http_status':None,'error_type':type(error).__name__,'host':urllib.parse.urlparse(url).hostname}

def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--output',type=Path,required=True)
    cli.add_argument('--track-components',action='store_true',help='Paired no-ball AMP trial: common reference velocity, ready vs native reference arms')
    cli.add_argument('--source',type=Path)
    cli.add_argument('--amp-source',type=Path)
    cli.add_argument('--reference',type=Path)
    cli.add_argument('--mapping',type=Path)
    cli.add_argument('--arm-fractions',default='0,1',help='Predeclared native arm blend fractions; default original paired0,1')
    cli.add_argument('--generate',action='store_true',help='Isolated pinned setup/download and one constrained native G1 generation')
    cli.add_argument('--worker',action='store_true',help=argparse.SUPPRESS)
    cli.add_argument('--work-dir',type=Path)
    cli.add_argument('--check-only',action='store_true',help='Check existing access/cache; never install/download model weights')
    args=cli.parse_args();args.output.mkdir(parents=True,exist_ok=False)
    if args.track_components:
        track_components(args);return
    if args.worker:
        generate_worker(args);return
    if args.generate:
        setup_and_generate(args);return
    token,provider=standard_token()
    home=Path(os.environ.get('HF_HOME',Path.home()/'.cache/huggingface'))
    cache=Path(os.environ.get('HF_HUB_CACHE',home/'hub'))
    cached={}
    for repo in (KIMODO_MODEL,*ENCODERS):
        folder=cache/('models--'+repo.replace('/','--'))
        snapshots=list((folder/'snapshots').glob('*')) if (folder/'snapshots').is_dir() else []
        cached[repo]={'snapshot_count':len(snapshots),'has_config':any((p/'config.json').is_file() or (p/'config.yaml').is_file() for p in snapshots),'has_any_weight_file':any(any(p.rglob(pattern)) for p in snapshots for pattern in ('*.safetensors','*.bin'))}
    receipt={'checked_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
             'kimodo_commit':KIMODO_COMMIT,'kimodo_model':KIMODO_MODEL,'kimodo_revision':KIMODO_REVISION,
             'token_present':token is not None,'token_provider':provider,'cache_summary':cached,
             'authentication':'existing standard Hugging Face authentication only','checks':[],'weights_downloaded':False,
             'receiver_environment_modified':False,'generation_attempted':False}
    # These are actual gated small files, not the public model metadata API.
    for repo,filename in [(ENCODERS[0],'model.safetensors.index.json'),(ENCODERS[0],'config.json'),
                          (ENCODERS[1],'config.json'),(ENCODERS[2],'adapter_config.json'),(KIMODO_MODEL,'config.yaml')]:
        status=request_status(f'https://huggingface.co/{repo}/resolve/main/{filename}',token)
        receipt['checks'].append({'repo':repo,'file':filename,'method':'HEAD','existing_token_used':token is not None,**status})
    llama=receipt['checks'][0]
    if llama['http_status']!=200:
        receipt['status']='blocked_gated_access'
        receipt['blocker']='Required Meta-Llama-3-8B-Instruct download access is not available through existing standard authentication.'
        receipt['next_step']='An authorized user must obtain the official model access grant and configure standard Hugging Face login on the worker; do not send a token in chat.'
    elif not token:
        receipt['status']='blocked_missing_authenticated_permission'
        receipt['blocker']='A successful unauthenticated request does not establish the requested account grant; no standard Hugging Face authentication was present.'
    else:
        receipt['status']='access_verified'
        receipt['model_revisions']={}
        for repo in (KIMODO_MODEL,*ENCODERS):
            data=request_status(f'https://huggingface.co/api/models/{repo}',token,json_body=True)
            if isinstance(data,tuple):receipt['model_revisions'][repo]=data[1].get('sha')
        if not args.check_only:
            receipt['status']='access_verified_setup_pending'
            receipt['next_step']='Permission preflight passed. Continue pinned isolated installation and constrained generation; no automatic unpinned model download is allowed.'
    (args.output/'access-check.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2),flush=True)

REVISIONS={KIMODO_MODEL:KIMODO_REVISION,
 ENCODERS[0]:'8afb486c1db24fe5011ec46dfbe5b5dccdb575c2',
 ENCODERS[1]:'31474e395ada192e8ed1586db6be79fb3b70c9c0',
 ENCODERS[2]:'baa8ebf04a1c2500e61288e7dad65e8ae42601a7'}

def setup_and_generate(args):
    if args.work_dir is None:raise ValueError('--work-dir required')
    work=args.work_dir.resolve();work.mkdir(parents=True,exist_ok=False)
    source=work/'kimodo';venv=work/'venv';out=args.output.resolve()
    clean={k:v for k,v in os.environ.items() if k not in ('HF_TOKEN','HUGGING_FACE_HUB_TOKEN')}
    def run(command,timeout):
        with (out/'setup.log').open('a') as log:
            subprocess.run(command,check=True,stdout=log,stderr=subprocess.STDOUT,timeout=timeout,env=clean)
    run(['git','clone','https://github.com/nv-tlabs/kimodo.git',str(source)],180)
    run(['git','-C',str(source),'checkout','--detach',KIMODO_COMMIT],60)
    run(['git','-C',str(source),'submodule','update','--init','--recursive'],180)
    run([sys.executable,'-m','venv','--system-site-packages',str(venv)],60)
    python=str(venv/'bin/python')
    # Overlay is private to this new venv; existing receiver packages remain untouched.
    clean['PATH']=str(venv/'bin')+os.pathsep+clean.get('PATH','')
    # Official setup switch: native G1 generation disables motion correction.
    clean['SKIP_MOTION_CORRECTION_IN_SETUP']='1'
    run([python,'-m','pip','install','cmake','setuptools','wheel'],180)
    run([python,'-m','pip','install','--no-build-isolation',str(source)],900)
    with (out/'pip-freeze.txt').open('w') as f:subprocess.run([python,'-m','pip','freeze'],check=True,stdout=f,env=clean)
    env=os.environ.copy();env['HF_HOME']=str(work/'hf-cache');env['HF_HUB_DISABLE_PROGRESS_BARS']='1';env['HF_HUB_DISABLE_TELEMETRY']='1';env['PYTHONUNBUFFERED']='1'
    with (out/'generation.log').open('w') as f:
        result=subprocess.run([python,str(Path(__file__).resolve()),'--worker','--output',str(out/'generated'),'--work-dir',str(work)],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1500)
    (out/'process-result.json').write_text(json.dumps({'returncode':result.returncode,'isolated_work_dir':str(work),'source_commit':KIMODO_COMMIT,'auth_transport':'SDK in-memory environment overlay; never persisted','receiver_environment_modified':False},indent=2)+'\n')
    if result.returncode:raise RuntimeError('isolated generation failed; inspect sanitized generation.log')

def generate_worker(args):
    from huggingface_hub import snapshot_download
    paths={};manifest={}
    for repo,revision in REVISIONS.items():
        paths[repo]=Path(snapshot_download(repo,revision=revision,allow_patterns=['*.json','*.safetensors','*.yaml','*.py','*.npy','LICENSE*','README*'],token=os.environ.get('HF_TOKEN')))
        # Pin repo-name resolution used by PEFT to the same immutable cached revision.
        refs=paths[repo].parent.parent/'refs';refs.mkdir(exist_ok=True);(refs/'main').write_text(revision)
        manifest[repo]={'revision':revision,'files':{str(p.relative_to(paths[repo])):{'bytes':p.stat().st_size,'sha256':sha256(p.read_bytes()).hexdigest()}for p in sorted(paths[repo].rglob('*')) if p.is_file()}}
    (args.output/'model-files.json').write_text(json.dumps(manifest,indent=2)+'\n')
    # Generation has no authentication and is offline. Only the official pinned download phase used HF_TOKEN.
    os.environ.pop('HF_TOKEN',None);os.environ.pop('HUGGING_FACE_HUB_TOKEN',None)
    os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1';os.environ['TEXT_ENCODER_URL']='local'
    checkpoints=args.work_dir/'checkpoints';checkpoints.mkdir();(checkpoints/'Kimodo-G1-RP-v1').symlink_to(paths[KIMODO_MODEL],target_is_directory=True)
    os.environ['CHECKPOINT_DIR']=str(checkpoints)
    import importlib,runpy,numpy as np,torch
    loader=importlib.import_module('kimodo.model.load_model')
    loader.TEXT_ENCODER_PRESETS['llm2vec']['kwargs']['base_model_name_or_path']=str(paths[ENCODERS[1]])
    loader.TEXT_ENCODER_PRESETS['llm2vec']['kwargs']['peft_model_name_or_path']=str(paths[ENCODERS[2]])
    # Model config pins30Hz. Root2D is [X,Z], Y-up, default heading0 faces+Z.
    fps=30;frames=150;indices=[0,30,60,90,120,149]
    constraints=[{'type':'root2d','frame_indices':indices,'smooth_root_2d':[[0.,2.*i/fps]for i in indices],'global_root_heading':[[1.,0.]for i in indices]}]
    constraint_path=args.output/'constraints.json';constraint_path.write_text(json.dumps(constraints,indent=2)+'\n')
    prompt='A humanoid robot runs straight forward athletically along a straight line at a steady pace'
    command=['kimodo_gen',prompt,'--model','kimodo-g1-rp','--duration','5.0','--num_samples','1','--seed','173','--constraints',str(constraint_path),'--output',str(args.output/'go-reference'),'--save_example_dir']
    (args.output/'generation-protocol.json').write_text(json.dumps({'command':command,'seed':173,'fps':fps,'frames':frames,'axes':'Kimodo Y-up, Z-forward; root2d X,Z; exported G1CSV uses Z-up,X-forward','prompt':prompt,'source_commit':KIMODO_COMMIT,'cuda_device':torch.cuda.get_device_name(0),'physics_claim':False,'reference_tracking_tested':False},indent=2)+'\n')
    sys.argv=command;runpy.run_module('kimodo.scripts.generate',run_name='__main__')
    files={str(p.relative_to(args.output)):{'bytes':p.stat().st_size,'sha256':sha256(p.read_bytes()).hexdigest()}for p in args.output.rglob('*')if p.is_file()}
    (args.output/'output-hashes.json').write_text(json.dumps(files,indent=2)+'\n')

def track_components(args):
    """Reference-fed commands, not a whole-body motion tracking policy."""
    import numpy as np
    from evaluate_aero_receiver import make_plant
    from g1_receiver.aero import aero_ready_joint_targets
    from g1_receiver.football_routes import imu_yaw,heading_error
    from g1_receiver.running_policy import AmpRunningPolicy,ARM_JOINTS
    from g1_receiver.running_catch_eval import FootContactRecorder
    from g1_receiver.runtime import RobotObservation,SkillGoal
    from g1_receiver.routes import Route
    from g1_receiver.locomotion import CONTROL_DT
    ref=np.loadtxt(args.reference,delimiter=',');mapping=json.loads(args.mapping.read_text());rows={r['name']:r for r in mapping['rows']}
    if ref.shape!=(150,36)or not mapping['names_bijective']or any(any(row[k]>1e-8 for k in ('axis_error','zero_ref_error_rad','parent_frame_quaternion_error','parent_frame_translation_error_m'))for row in rows.values()):raise ValueError('reference/body mapping not verified')
    times=np.arange(len(ref))/30.;vel=np.gradient(ref[:,:2],1/30.,axis=0)
    qw,qx,qy,qz=ref[:,3:7].T;yaws=np.unwrap(np.arctan2(2*(qw*qz+qx*qy),1-2*(qy*qy+qz*qz)))
    fractions=[float(x) for x in args.arm_fractions.split(',')]
    if not fractions or any(not 0.<=x<=1. for x in fractions)or len(fractions)>4:raise ValueError('at most4 arm fractions in[0,1]')
    summary=[]
    for fraction in fractions:
        variant='ready-arms' if fraction==0. else 'reference-arms' if fraction==1. else f'reference-arms-f{fraction:.2f}'
        out=args.output/variant;out.mkdir();plant=make_plant(args.source,Route('go',((0.,0.),(10.,0.))))
        try:
            policy=AmpRunningPolicy(plant.joint_names,plant.joint_ranges,args.amp_source);upper=aero_ready_joint_targets(policy.nominal,plant.joint_names);plant.reset(joint_positions=upper,release_position_m=(18.,11.,.085));policy.reset();indices=np.array([plant.joint_names.index(name)for name in ARM_JOINTS]);columns=np.array([rows[name]['csv_column']for name in ARM_JOINTS]);previous=upper.copy();motion=[];poses=[];commands=[];feet=FootContactRecorder(plant.model)
            for tick in range(301):
                now=plant.timestamp_s;phase=float(np.clip(now-.4,0.,times[-1]));obs=RobotObservation(now,*plant.observe(),np.zeros(29),None);yaw=imu_yaw(obs.imu_quat_wxyz)
                world=np.array([np.interp(phase,times,vel[:,i])for i in (0,1)]);world=np.clip(world,[-2.5,-.35],[2.5,.35])*min(1.,max(0.,(now-.4)/.8));c,s=np.cos(yaw),np.sin(yaw);body=np.array([[c,s],[-s,c]])@world;desired_yaw=float(np.interp(phase,times,yaws));drive=np.r_[body,np.clip(1.8*heading_error(desired_yaw,yaw),-.75,.75)]
                target=upper.copy();desired=np.array([np.interp(phase,times,ref[:,i])for i in columns]);blend=float(np.clip((now-.4)/1.,0.,1.));blend=blend*blend*(3.-2.*blend)
                if fraction>0.:target[indices]=(1.-blend*fraction)*upper[indices]+blend*fraction*desired;target[indices]=np.clip(target[indices],plant.joint_ranges[indices,0],plant.joint_ranges[indices,1]);target[indices]=np.clip(target[indices],previous[indices]-.04,previous[indices]+.04)
                previous=target.copy()
                # Exact state reads below are evaluation/logging only, never a controller input.
                pelvis=plant.data.body('pelvis');motion.append((now,*pelvis.xpos,pelvis.xmat[8],yaw));commands.append((now,*drive,blend,*target[indices]));poses.append((now,plant.data.qpos.copy()))
                w,x,y,z=obs.imu_quat_wxyz
                if tick==300 or 1.-2.*(x*x+y*y)<.54:break
                action=policy.act(obs,SkillGoal(base_velocity=drive),upper_target=target);plant.step(action,closure=0.,post_step=feet.record)
            m=np.array(motion);qt,q=zip(*poses);q=np.array(q);arm_actual=np.array([[plant.model.joint(name).qposadr[0]for name in ARM_JOINTS]])[0];ideal=np.array([[np.interp(np.clip(t-.4,0.,times[-1]),times,ref[:,col])for col in columns]for t in qt]);settled=m[:,0]>=1.4
            report={'variant':variant,'native_arm_fraction':fraction,'actual_end_s':float(m[-1,0]),'minimum_upright':float(m[:,4].min()),'final_xyz_m':m[-1,1:4].tolist(),'max_abs_lateral_m':float(abs(m[:,2]).max()),'arm_reference_rmse_rad_after_blend':float(np.sqrt(np.mean((q[settled][:,arm_actual]-ideal[settled])**2)))if settled.any()else None,'reference_sha256':sha256(args.reference.read_bytes()).hexdigest(),'controller_inputs':['IMU','joint encoders','fixed offline reference velocity/yaw','fixed offline arm reference for reference-arms only'],'reference_components_used':['exported planar derivative','exported root yaw']+(['14 raw body arm joints, smooth initial blend, native limits,2rad/s rate bound']if fraction>0. else []),'not_used':['reference root position feedback','reference leg joints','reference waist joints','ball pose','contact data'],'whole_body_reference_tracker':False,'physics_steps_via_actuators_only':True,'postreset_pose_overwrites':0,'catch_claim':False}
            ft=feet.arrays();dt=np.diff(m[:,0]);vxy=np.diff(m[:,1:3],axis=0)/dt[:,None];fwd=(vxy*np.c_[np.cos(m[:-1,5]),np.sin(m[:-1,5])]).sum(1);window=m[:-1,0]>=1.4
            air=~ft['robot_floor_contact'].astype(bool);clear=(ft['sole_clearance_m']>=.005).all(axis=1);edges=np.flatnonzero(np.diff(np.r_[False,air,False]));phases=[]
            for a,b in zip(edges[::2],edges[1::2]):
                if a==0 or b==len(air)or ft['foot_time_s'][a]<.4:continue
                before,after=ft['foot_floor_contact'][a-1],ft['foot_floor_contact'][b];ee=np.flatnonzero(np.diff(np.r_[False,clear[a:b],False]));duration=float((ee[1::2]-ee[::2]).max(initial=0)*.001)
                if before.sum()==1 and after.sum()==1 and not np.array_equal(before,after) and duration>=.025:phases.append({'start_s':float(ft['foot_time_s'][a]),'clearance_duration_s':duration})
            report.update(qualified_alternate_foot_flight_phases=phases,bodyforward_mean_after_blend_mps=float(fwd[window].mean())if window.any()else None,bodyforward_negative_duration_s=float(dt[window&(fwd<-.05)].sum()),final_yaw_rad=float(m[-1,5]),arm_peak_to_peak_rad_after_blend={name:float(np.ptp(q[settled,adr]))for name,adr in zip(ARM_JOINTS,arm_actual)} if settled.any() else {},joint_names_arm=list(ARM_JOINTS))
            np.savez_compressed(out/'trace.npz',motion=m,commands=np.array(commands),**ft);np.savez_compressed(out/'view.npz',timestamps_s=qt,qpos=q);(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');summary.append(report)
        finally:plant.close()
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
