"""Matched exact7s and8/9s continuation; anatomical truth is evaluation only."""
from pathlib import Path
import argparse,json,multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
import probe_lower_cup_native_confirm as runner
from run_native_cup_grip_screen import exact
REFERENCE='173bf57168f5f97d0471d7bfa0a05e067a00f1e27a385994f57f21998a30af15'

def trial(job):
 source,amp,profile,output,duration=job;args=runner.build_parser().parse_args(['--source',str(source),'--amp-source',str(amp),'--profile',str(profile),'--output',str(output),'--walk-speed','1','--handoff-depth','1.3','--initial-yaw','-.7','--duration',str(duration),'--record-anatomical','--reference-physics-sha256',REFERENCE]);r=runner.run(args);return dict(label=output.name,anatomical=r['anatomical_score'],self_geometry=r['interhand_geometry_audit'])
def main():
 p=argparse.ArgumentParser()
 for n in ['source','amp-source','profile','output','reference']:p.add_argument('--'+n,type=Path,required=True)
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
 jobs=[(a.source,a.amp_source,a.profile,a.output/name,duration)for name,duration in [('exact7',7.),('extended8',8.),('extended9',9.)]];rows=[]
 with ProcessPoolExecutor(max_workers=2,mp_context=mp.get_context('spawn'))as pool:
  for f in as_completed([pool.submit(trial,j)for j in jobs]):rows.append(f.result());(a.output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
 matches=exact(a.reference,a.output/'exact7')
 with np.load(a.reference/'trace.npz')as x,np.load(a.output/'exact7/trace.npz')as y:
  assert np.array_equal(x['native_hand'],y['native_hand'],equal_nan=True)
 matches['native_encoder_and_target_stream_exact']=True
 for label in ['extended8','extended9']:
  for file in ['trace.npz','view.npz']:
   with np.load(a.output/'exact7'/file)as x,np.load(a.output/label/file)as y:
    for k in x.files:assert np.array_equal(x[k],y[k][:len(x[k])],equal_nan=True),(label,file,k)
 (a.output/'exact-and-prefix.json').write_text(json.dumps(dict(original_vs_exact7=matches,all_extended_prefix_arrays_exact=True),indent=2)+'\n')
if __name__=='__main__':main()
