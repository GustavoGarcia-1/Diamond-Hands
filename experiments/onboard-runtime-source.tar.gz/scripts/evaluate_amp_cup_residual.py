"""Baseline sensor preflight or one bounded final-checkpoint AMP cup pilot."""
import argparse,json,subprocess,sys
from hashlib import sha256
from pathlib import Path
import numpy as np
from g1_receiver.amp_cup_locomotion_rl import AmpCupEnv,SCHEMA,REWARD_SCHEMA,CAMERAS

def run_case(args,output,model=None,yaw=-.7,raise_cup=True):
 env=AmpCupEnv(args.source,args.amp_source,args.profile,initial_yaw=yaw,evaluation_dir=output,raise_cup=raise_cup)
 try:
  obs,_=env.reset(seed=173);finite=True
  while True:
   action=np.zeros(15)if model is None else model.predict(obs,deterministic=True)[0]
   obs,reward,term,trunc,info=env.step(action);finite=finite and bool(np.isfinite(obs).all()and np.isfinite(reward))
   if term or trunc:break
  folder=output/'episode-001';sensor=json.loads((folder/'sensors.json').read_text());rewards=json.loads((folder/'rewards.json').read_text());z=np.load(folder/'trace.npz');m=z['motion'];t=z['foot_time_s'];ground=z['robot_floor_contact'].astype(bool);feet=z['foot_floor_contact'].astype(bool);clear=(z['sole_clearance_m']>=.005).all(1);edges=np.flatnonzero(np.diff(np.r_[False,~ground,False]));phases=[]
  for a,b in zip(edges[::2],edges[1::2]):
   if a==0 or b==len(t)or t[a]<2.6-1e-8:continue
   before,after=feet[a-1],feet[b];ee=np.flatnonzero(np.diff(np.r_[False,clear[a:b],False]));duration=float((ee[1::2]-ee[::2]).max(initial=0)*.001)
   if before.sum()==1 and after.sum()==1 and not np.array_equal(before,after)and duration>=.025:phases.append({'start_s':float(t[a]),'clearance_duration_s':duration})
  count=maxcount=0;prev=None
  for phase in phases:
   start=phase['start_s'];count=count+1 if prev is not None and start-prev<=.72 else 1;maxcount=max(count,maxcount);prev=start
  windows={}
  for start in (1.,2.6):
   rows=[s for s in sensor if s['time_s']>=start-1e-8]
   windows[str(start)]={'samples':len(rows),'pose_valid_fraction':float(np.mean([s['pose_valid']for s in rows]))if rows else 0.,'velocity_valid_fraction':float(np.mean([s['velocity_valid']for s in rows]))if rows else 0.}
  report=json.loads((folder/'physical-report.json').read_text());report.update(initial_yaw_rad=yaw,raised_cup=raise_cup,finite_observations_rewards=finite,sensor_coverage=windows,invalid_pose_motion_reward_zero=all(r['speed_reward']==0 and r['stem_reward']==0 for r in rewards if not(r['pose_valid']and r['velocity_valid'])),sensor_return=env.return_sum,qualified_flights_after_cup=phases,max_recurrent_flights=maxcount,eligible=bool(abs(m[-1,0]-7.)<1e-7 and m[:,4].min()>=.9 and maxcount>=2 and m[-1,1]>np.interp(2.6,m[:,0],m[:,1])),source=str(folder))
  (output/'summary.json').write_text(json.dumps(report,indent=2)+'\n');return report
 finally:env.close()

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--mode',choices=['check','train-evaluate'],required=True)
 for key in ('source','amp-source','profile','output'):p.add_argument('--'+key,type=Path,required=True)
 p.add_argument('--original-trace',type=Path);p.add_argument('--original-view',type=Path);p.add_argument('--baseline-check',type=Path);p.add_argument('--steps',type=int,default=16384);p.add_argument('--envs',type=int,default=8);p.add_argument('--wall-seconds',type=float,default=1700.);p.add_argument('--seed',type=int,default=173);p.add_argument('--device',default='cuda');a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
 sourcefile=Path(__import__('g1_receiver.amp_cup_locomotion_rl',fromlist=['x']).__file__);sourcehash=sha256(sourcefile.read_bytes()).hexdigest();profilehash=sha256(a.profile.read_bytes()).hexdigest()
 protocol={'sensor_schema':SCHEMA,'reward_schema':REWARD_SCHEMA,'env_source_sha256':sourcehash,'profile_sha256':profilehash,'camera_surveys':CAMERAS,'training_yaw':-.7,'heldout_initial_yaws':[-.75,-.65],'final_checkpoint_only':True,'no_test_checkpoint_selection':True,'no_catch_claim':True}
 (a.output/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
 if a.mode=='check':
  if a.original_trace is None or a.original_view is None:p.error('check requires immutable original trace/view')
  report=run_case(a,a.output/'zero');new=a.output/'zero/episode-001';equality={}
  for name,oldpath in [('trace.npz',a.original_trace),('view.npz',a.original_view)]:
   old=np.load(oldpath);fresh=np.load(new/name);row={}
   for key in fresh.files:
    x,y=fresh[key],old[key]
    if key=='motion':y=y[:,:5]
    row[key]=bool(np.array_equal(x,y,equal_nan=True))
   equality[name]=row
  passed=all(v for row in equality.values()for v in row.values())and report['finite_observations_rewards']and report['invalid_pose_motion_reward_zero']and report['sensor_coverage']['1.0']['velocity_valid_fraction']>=.7 and report['sensor_coverage']['2.6']['velocity_valid_fraction']>=.5
  result={**protocol,'status':'pass'if passed else 'fail','baseline_arrays_exact':equality,'report':report}
  (a.output/'check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));
  if not passed:raise SystemExit(2)
 else:
  if a.baseline_check is None:p.error('training requires prior successful baseline check')
  check=json.loads(a.baseline_check.read_text())
  if check['status']!='pass'or check['env_source_sha256']!=sourcehash or check['profile_sha256']!=profilehash:raise ValueError('baseline/sensor check is missing or stale')
  from g1_receiver.amp_cup_locomotion_rl import train
  training=a.output/'training';a.output=training;train(a)
  from stable_baselines3 import PPO
  model=PPO.load(training/'final.zip',device=a.device)
  if model.receiver_sensor_schema!=SCHEMA or model.receiver_reward_schema!=REWARD_SCHEMA:raise ValueError('checkpoint sensor/reward mismatch')
  rows=[]
  for yaw in (-.7,-.75,-.65):
   for name,policy in [('zero',None),('learned',model)]:
    row=run_case(a,training.parent/f'eval-yaw{yaw:+.2f}-{name}',policy,yaw);row['policy']=name;rows.append(row)
    (training.parent/'evaluation-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
  print(json.dumps(rows,indent=2))
if __name__=='__main__':main()
