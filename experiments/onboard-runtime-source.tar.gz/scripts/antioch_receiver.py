"""Stage immutable receiver source and manage bounded, detached Antioch jobs.

Run with the installed Antioch SDK interpreter. The remote actions attach only
to the explicit existing session. They do not allocate, release, or sync it.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
import uuid

ROOT = Path(__file__).resolve().parents[1]
REMOTE_RUNS = "/workspace/g1-receiver-runs"


def sha256(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def save(path, value):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def antioch_requirements():
    """Lock-derived pins, preserving the selected session image's CUDA Torch."""
    exported = subprocess.check_output(
        ["uv", "export", "--locked", "--no-dev", "--extra", "training",
         "--no-emit-project", "--no-hashes"], cwd=ROOT, text=True,
    )
    pins = []
    for line in exported.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        package, separator, _ = line.partition("==")
        if not separator:
            raise ValueError(f"expected lockfile pin: {package}")
        if package not in ("torch", "triton") and not package.startswith(("cuda-", "nvidia-")):
            pins.append(line)
    return ("\n".join(pins) + "\n").encode()


def snapshot(path, data_paths=()):
    sources = [ROOT / name for name in ("pyproject.toml", "uv.lock", "scripts/remote_worker.py", "scripts/remote_probe.py")]
    sources.extend(path for path in (ROOT / "src").rglob("*")
                   if "__pycache__" not in path.parts and path.is_file())
    archive_sources = {str(source.relative_to(ROOT)): source for source in sources}
    for source in data_paths:
        name = f"datasets/{source.name}"
        if source.suffix not in (".npz", ".json", ".pt", ".zip") or not source.is_file():
            raise ValueError("additional inputs must be explicit NPZ, JSON, PT, or ZIP files")
        if not re.fullmatch(r"[A-Za-z0-9_.-]+", source.name) or name in archive_sources:
            raise ValueError("additional input names must be unique safe basenames")
        archive_sources[name] = source
    overlay = antioch_requirements()
    manifest = {}
    with (
        path.open("xb") as output,
        gzip.GzipFile(filename="", mode="wb", fileobj=output, mtime=0) as compressed,
        tarfile.open(fileobj=compressed, mode="w") as archive,
    ):
        for name, source in sorted(archive_sources.items()):
            if source.is_symlink():
                raise ValueError(f"symlinks are excluded: {source}")
            with source.open("rb") as data:
                manifest[name] = hashlib.file_digest(data, "sha256").hexdigest()
                info = tarfile.TarInfo(name)
                info.size = data.tell()
                data.seek(0)
                archive.addfile(info, data)
        info = tarfile.TarInfo("antioch-runtime-requirements.txt")
        info.size = len(overlay)
        archive.addfile(info, io.BytesIO(overlay))
        manifest[info.name] = hashlib.sha256(overlay).hexdigest()
        payload = json.dumps(manifest, sort_keys=True).encode()
        info = tarfile.TarInfo("snapshot-sha256.json")
        info.size = len(payload)
        archive.addfile(info, io.BytesIO(payload))
    return {"path": str(path.resolve()), "sha256": sha256(path), "files": len(manifest)}


REMOTE_EXTRACT = r"""
import hashlib,json,pathlib,shutil,sys,tarfile
base,transfer=map(pathlib.Path,sys.argv[1:3])
archive=base/'source.tar.gz'
if archive.exists():
    raise FileExistsError(archive)
shutil.move(transfer,archive)
with archive.open('rb') as f:
    if hashlib.file_digest(f,'sha256').hexdigest()!=sys.argv[3]:
        raise ValueError('snapshot archive hash mismatch')
source=base/'source'
source.mkdir()
with tarfile.open(archive) as tar:
    members=tar.getmembers()
    names={member.name for member in members}
    if len(names)!=len(members) or any(not m.isfile() or pathlib.PurePosixPath(m.name).is_absolute()
                                      or '..' in pathlib.PurePosixPath(m.name).parts for m in members):
        raise ValueError('invalid snapshot members')
    tar.extractall(source,filter='data')
manifest=json.loads((source/'snapshot-sha256.json').read_text())
if set(manifest)!=names-{'snapshot-sha256.json'}:
    raise ValueError('snapshot manifest mismatch')
for name,expected in manifest.items():
    with (source/name).open('rb') as f:
        if hashlib.file_digest(f,'sha256').hexdigest()!=expected:
            raise ValueError(f'snapshot file hash mismatch: {name}')
print(json.dumps({'verified_files':len(manifest)}))
"""

def remote(args, receipt):
    from antioch.client import Client, targeting
    from antioch.client.service import copy_path
    from antioch.transport import exit_code_of

    client = Client()
    resolved = targeting.resolve_session(client, session=receipt["session"], any_project=True, fresh=True)
    base = receipt["remote_root"]
    with targeting.attach_agent(client, resolved.session, "sim") as agent:
        def run(command, timeout=30):
            result = agent.run(command, cwd="/tmp", timeout=timeout, environment={"PYTHONDONTWRITEBYTECODE": "1"})
            if exit_code_of(result) != 0:
                raise RuntimeError(f"remote {command[0]} failed, exit {exit_code_of(result)}")
            return result.stdout.decode().strip()

        def ensure_idle():
            gpu = run(["nvidia-smi", "--query-gpu=name,driver_version,memory.total", "--format=csv,noheader"])
            if len(gpu.splitlines()) != 1:
                raise RuntimeError("this run requires exactly one visible GPU")
            if run(["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"]):
                raise RuntimeError("GPU currently has a compute process")
            return gpu

        if args.action == "prepare":
            receipt["gpu"] = ensure_idle()
            archive = Path(receipt["snapshot"]["path"])
            if sha256(archive) != receipt["snapshot"]["sha256"]:
                raise ValueError("local archive hash mismatch")
            create = "import pathlib,sys; p=pathlib.Path(sys.argv[1]); p.parent.mkdir(exist_ok=True); p.mkdir(); (p/'artifacts').mkdir()"
            run(["python3", "-B", "-c", create, base])
            transfer = f"/workspace/project/.receiver-transfer-{uuid.uuid4().hex}.tar.gz"
            copy_path(agent, ROOT, local=archive, remote=transfer, download=False,
                      cwd="/tmp", warn=lambda _: None)
            receipt["prepared"] = json.loads(run([
                "python3", "-B", "-c", REMOTE_EXTRACT, base, transfer, receipt["snapshot"]["sha256"],
            ], timeout=90))
            save(args.receipt, receipt)
            print(json.dumps(receipt["prepared"]))
        elif args.action == "configure":
            if "prepared" not in receipt or "command_handle" in receipt or "watchdog_pid" in receipt:
                raise RuntimeError("a new prepared receipt is required")
            ensure_idle()
            python = base + "/.venv/bin/python"
            run(["python3", "-m", "venv", "--system-site-packages", base + "/.venv"], timeout=60)
            run(["uv", "pip", "install", "--no-deps", "--python", python, "-r",
                 base + "/source/antioch-runtime-requirements.txt"], timeout=240)
            receipt["runtime"] = json.loads(run([
                python, "-B", base + "/source/scripts/remote_probe.py", base + "/source/src",
            ], timeout=120))
            save(args.receipt, receipt)
            print(json.dumps(receipt["runtime"]))
        elif args.action == "launch":
            if "runtime" not in receipt:
                raise RuntimeError("a configured receipt is required")
            already_launched = "command_handle" in receipt or "watchdog_pid" in receipt
            if args.resume_dispatch != already_launched:
                raise RuntimeError("use --resume-dispatch only for an existing completed dispatch")
            ensure_idle()
            if args.resume_dispatch:
                if "--resume" not in args.training_args or args.module != receipt["launch"]["command"][3]:
                    raise ValueError("resume requires the same trainer module and its explicit --resume")
                archive_status = """
import json,pathlib,sys
base=pathlib.Path(sys.argv[1]); index=sys.argv[2]; status=base/'artifacts/status.json'
phase=json.loads(status.read_text())['phase']
if phase not in ('completed','failed','time_limit'):
    raise RuntimeError('the previous dispatch is still active')
config=base/'launch.json'
for src, dst in [(config,base/f'launch-{index}.json'),
                 (status,base/'artifacts'/f'status-{index}.json')]:
    if dst.exists():
        raise FileExistsError(dst)
    src.rename(dst)
"""
                index = str(len(receipt.get("previous_dispatches", [])) + 1)
                run(["python3", "-B", "-c", archive_status, base, index])
                receipt.setdefault("previous_dispatches", []).append(
                    {"watchdog_pid": receipt.get("watchdog_pid"),
                     "command_handle": receipt.get("command_handle"), "launch": receipt["launch"]}
                )
            python = str(Path(base) / ".venv" / "bin" / "python")
            run(["test", "-x", python])
            config = {
                "wall_seconds": args.wall_seconds,
                "command": [python, "-u", "-m", args.module, *args.training_args],
                "snapshot_sha256": receipt["snapshot"]["sha256"],
                "created_utc": datetime.now(timezone.utc).isoformat(),
            }
            create = "import pathlib,sys; pathlib.Path(sys.argv[1]).open('x').write(sys.argv[2])"
            run(["python3", "-B", "-c", create, base + "/launch.json", json.dumps(config)])
            # Launch the watchdog as the agent's own supervised command.
            # An orphan spawned by a short exec was reaped after disconnect.
            started = agent.exec(
                ["python3", "-B", base + "/source/scripts/remote_worker.py", base],
                cwd="/tmp", timeout_s=30, drop_unread=True,
            )
            receipt["command_handle"] = started.handle
            receipt["launch"] = config
            save(args.receipt, receipt)
            print(json.dumps({"command_handle": started.handle, "remote_root": base}))
        elif args.action == "status":
            inspect = """
import json,pathlib,sys
p=pathlib.Path(sys.argv[1]); state=json.loads((p/'status.json').read_text())
state['files']=[{'path':str(f.relative_to(p)),'bytes':f.stat().st_size}
                for f in sorted(p.rglob('*')) if f.is_file()]
print(json.dumps(state,indent=2))
"""
            print(run(["python3", "-B", "-c", inspect, base + "/artifacts"]))
        elif args.action == "retrieve":
            target = args.receipt.with_suffix(".artifacts.tar.gz")
            if target.exists():
                raise FileExistsError(target)
            transfer = f"/workspace/project/.receiver-artifacts-{uuid.uuid4().hex}.tar.gz"
            run(["tar", "-czf", transfer, "-C", base, "artifacts"], timeout=120)
            try:
                copy_path(agent, ROOT, local=target, remote=transfer, download=True,
                          cwd="/tmp", warn=lambda _: None)
            finally:
                run(["rm", transfer])
            print(json.dumps({"path": str(target.resolve()), "sha256": sha256(target)}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("snapshot", "prepare", "configure", "launch", "status", "retrieve"))
    parser.add_argument("--receipt", type=Path, required=True)
    parser.add_argument("--run-id")
    parser.add_argument("--session")
    parser.add_argument("--wall-seconds", type=int, default=7200)
    parser.add_argument("--module")
    parser.add_argument("--resume-dispatch", action="store_true")
    parser.add_argument("--data", type=Path, action="append", default=[])
    parser.add_argument("--reuse-snapshot", type=Path, help="Use the immutable archive from another receipt")
    args, training_args = parser.parse_known_args()
    args.training_args = training_args[1:] if training_args[:1] == ["--"] else training_args
    if args.action != "launch" and args.resume_dispatch:
        parser.error("--resume-dispatch is available only for launch")
    if args.action != "snapshot" and (args.data or args.reuse_snapshot):
        parser.error("--data and --reuse-snapshot are available only for snapshot")
    if args.data and args.reuse_snapshot:
        parser.error("--data cannot change a reused snapshot")
    if args.action != "launch" and training_args:
        parser.error("unrecognized arguments")
    if args.action == "snapshot":
        if args.receipt.exists():
            parser.error("receipt already exists")
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", args.run_id or ""):
            parser.error("a valid run ID is required")
        if not re.fullmatch(r"ses-[A-Za-z0-9]+", args.session or ""):
            parser.error("an explicit session ID is required")
        args.receipt.parent.mkdir(parents=True, exist_ok=True)
        source = (json.loads(args.reuse_snapshot.read_text())["snapshot"] if args.reuse_snapshot
                  else snapshot(args.receipt.with_suffix(".source.tar.gz"), args.data))
        if sha256(Path(source["path"])) != source["sha256"]:
            raise ValueError("reused source archive hash mismatch")
        receipt = {"session": args.session, "remote_root": f"{REMOTE_RUNS}/{args.run_id}",
                   "snapshot": source}
        save(args.receipt, receipt)
        print(json.dumps(receipt["snapshot"]))
        return
    if args.action == "launch":
        if not re.fullmatch(r"[A-Za-z_][\w.]*", args.module or "") or not 60 <= args.wall_seconds <= 7200:
            parser.error("launch requires a Python module and a 60–7200 second cap")
    receipt = json.loads(args.receipt.read_text())
    if not re.fullmatch(rf"{re.escape(REMOTE_RUNS)}/[A-Za-z0-9][A-Za-z0-9_-]{{0,63}}",
                        receipt["remote_root"]):
        parser.error("unexpected remote run directory")
    remote(args, receipt)


if __name__ == "__main__":
    main()
