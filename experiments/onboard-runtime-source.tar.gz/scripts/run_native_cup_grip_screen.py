"""Bounded matched native Aero grip experiment; no scoring feedback controls it."""
from pathlib import Path
from copy import deepcopy
from concurrent.futures import ProcessPoolExecutor,as_completed
import argparse,json,traceback,multiprocessing as mp
import numpy as np
import probe_lower_cup_native as runner
from probe_overnight_lower import summarize
from g1_receiver.lower_cup_grip import OPEN,LEGACY_CLOSE

# Full native endpoint values, thumb angle capped to the mechanical joint range.
LOW=np.array([.05852]*4+[0.,.026152,.081568]);HIGH=np.array([.110387]*4+[1.7453,.038389,.112138]);END=LOW.copy();END[4]=HIGH[4]
LEGACY=(LEGACY_CLOSE-OPEN)/(END-OPEN)

def run_case(job):
 root,donor,source,amp,label,config=job;profile=deepcopy(donor)
 if config is not None:profile['native_grip']=config
 path=root/(label+'-profile.json');path.write_text(json.dumps(profile,indent=2)+'\n');trial=root/label
 try:
  args=runner.build_parser().parse_args(['--source',str(source),'--amp-source',str(amp),'--profile',str(path),'--output',str(trial),'--walk-speed','1','--handoff-depth','1.3','--initial-yaw','-.7','--duration','7.0']);runner.run(args);score=summarize(trial,source);score.update(label=label,profile=str(path));return score
 except BaseException as exc:return dict(label=label,error=repr(exc),traceback=traceback.format_exc())

def exact(a,b):
 matches={}
 for name in ['trace.npz','view.npz']:
  with np.load(a/name)as x,np.load(b/name)as y:
   matches[name]={k:bool(k in y.files and x[k].shape==y[k].shape and np.array_equal(x[k],y[k],equal_nan=True))for k in x.files if k!='native_hand'}
 assert all(all(v.values())for v in matches.values()),matches
 return matches

def configs():
 pre=.2*LEGACY;thumb=LEGACY[4:];rows=[]
 def add(label,p,c,delays=0.,ramp=.20):rows.append((label,dict(mode='staged',preload=list(p),capture=list(c),digit_delay_s=delays,ramp_s=ramp)))
 add('legacy-full-hold',pre,LEGACY)
 add('deep85',pre,np.r_[[.85]*4,thumb])
 add('deep100',pre,np.r_[[1.]*4,thumb])
 p=np.r_[[0.]*4,LEGACY[4],*(.2*LEGACY[5:])]
 add('give4-thumb-ready',p,np.r_[[.85]*4,thumb],[.08]*4+[0.]*3)
 p=np.r_[[0.]*4,LEGACY[4],0.,0.]
 add('give4-thumb-open-flex',p,np.r_[[.85]*4,thumb],[.04]*4+[0.,.08,.08])
 p=np.r_[[.1*LEGACY[0]]*4,LEGACY[4],*(.2*LEGACY[5:])]
 add('ring-pinky-first',p,np.r_[LEGACY[:2],[1.,1.],thumb],[.08,.08,0.,0.,0.,.04,.04])
 p=np.r_[pre[:4],LEGACY[4],*(.2*LEGACY[5:])]
 add('deep-thumb85',p,np.r_[[.85]*4,LEGACY[4],.85,.85])
 add('give40-deep-thumb85',p,np.r_[[.85]*4,LEGACY[4],.85,.85],[.04]*4+[0.,0.,0.])
 return rows

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for n in ['source','amp-source','profile','output']:p.add_argument('--'+n,type=Path,required=True)
 p.add_argument('--reference',type=Path);p.add_argument('--workers',type=int,default=2);a=p.parse_args();assert 1<=a.workers<=2;a.output.mkdir(parents=True,exist_ok=False);donor=json.loads(a.profile.read_text());common=(a.output,donor,a.source,a.amp_source)
 protocol=dict(primary_target='>=.75s continuous clean bilateral native-digit control, <=.1m/s relative drift, whole-episode zero nonhand/floor/applied-ball-load support, upright>=.9, bilateral palm-up>=.6, face height<=.12m above shoulders',original_strict_tip_palm_metric_preserved=True,required_before_promotion='1kHz anatomical region and actual contact-surface audit; interhand crossing audit; fresh confirmation; full8s extension',hand_inputs='commanded release event, visual grasp gate, native actuator encoders logged only',official_actuator_rates_and_gains_unchanged=True)
 (a.output/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
 baseline=run_case((*common,'baseline',None));legacy=run_case((*common,'legacy-native',dict(mode='legacy')))
 assert 'error'not in baseline and 'error'not in legacy,(baseline,legacy)
 preflight=dict(new_native_legacy_vs_scalar=exact(a.output/'baseline',a.output/'legacy-native'))
 if a.reference is not None:preflight['baseline_vs_archived_reference']=exact(a.reference,a.output/'baseline')
 (a.output/'preflight.json').write_text(json.dumps(preflight,indent=2)+'\n')
 rows=[baseline,legacy]
 with ProcessPoolExecutor(max_workers=a.workers,mp_context=mp.get_context("spawn"))as pool:
  for f in as_completed([pool.submit(run_case,(*common,label,cfg))for label,cfg in configs()]):
   row=f.result();rows.append(row);(a.output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
if __name__=='__main__':main()
