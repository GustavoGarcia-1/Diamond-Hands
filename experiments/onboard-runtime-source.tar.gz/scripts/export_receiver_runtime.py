"""Export deterministic inference and a task scene for the HIM G1 simulator."""

from __future__ import annotations

import argparse
from hashlib import sha256
import json
from pathlib import Path
from shutil import copy2, copytree
import xml.etree.ElementTree as ET

import mujoco
import numpy as np
from stable_baselines3 import PPO
from torch import nn

from g1_receiver.locomotion import make_dynamic_scene
from g1_receiver.receiver_deploy import BODY_NAMES, NumpyReceiverActor, ReceiverController
from g1_receiver.routes import make_route
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
from g1_receiver.train_receiver import _source_snapshot


def export_actor(checkpoint: Path, output: Path):
    model = PPO.load(checkpoint, device="cpu")
    policy = model.policy
    layers = tuple(policy.mlp_extractor.policy_net)
    if (len(layers) != 4 or not isinstance(layers[0], nn.Linear)
            or not isinstance(layers[1], nn.Tanh) or not isinstance(layers[2], nn.Linear)
            or not isinstance(layers[3], nn.Tanh) or not isinstance(policy.action_net, nn.Linear)
            or policy.squash_output or type(policy.features_extractor).__name__ != "FlattenExtractor"):
        raise ValueError("unexpected actor architecture")
    arrays = {}
    for index, layer in enumerate((layers[0], layers[2], policy.action_net)):
        arrays[f"weight_{index}"] = layer.weight.detach().numpy()
        arrays[f"bias_{index}"] = layer.bias.detach().numpy()
    np.savez_compressed(output, schema="receiver-ppo-tanh-actor-v1", **arrays)
    return model


def write_scene(output: Path, controller: ReceiverController, trial: dict) -> Path:
    root = ET.fromstring(make_dynamic_scene(DEFAULT_RUNTIME_ROOT, survey_camera=True))
    root.find("compiler").set("meshdir", "meshes")
    world = root.find("worldbody")
    world.find("geom[@name='floor']").set("name", "safety_floor")
    floor_friction = np.fromstring(world.find("geom[@name='safety_floor']").get("friction"), sep=" ")
    world.find("geom[@name='safety_floor']").set(
        "friction", " ".join(map(str, floor_friction * trial["floor_friction_scale"])))
    by_name = {name: i for i, name in enumerate(BODY_NAMES)}
    for motor in root.find("actuator"):
        index = by_name[motor.attrib["joint"]]
        effort = motor.attrib.pop("ctrlrange")
        motor.tag = "position"
        motor.attrib.update(ctrlrange=" ".join(map(str, controller.wbc.ranges[index])),
                            forcelimited="true", forcerange=effort,
                            kp=str(controller.wbc.kp[index]), kv=str(controller.wbc.kd[index]))
    output.mkdir()
    copytree(DEFAULT_RUNTIME_ROOT / "assets/robot/meshes", output / "meshes")
    for path in (DEFAULT_RUNTIME_ROOT / "NOTICE.txt", DEFAULT_RUNTIME_ROOT / "ASSET-MANIFEST.json",
                 DEFAULT_RUNTIME_ROOT / "assets/upstream/CODE-LICENSE.txt",
                 DEFAULT_RUNTIME_ROOT / "assets/upstream/WEIGHTS-LICENSE.txt"):
        copy2(path, output / path.name)
    scene = output / "scene.xml"
    ET.ElementTree(root).write(scene, encoding="unicode")
    model = mujoco.MjModel.from_xml_path(str(scene))
    qpos = model.qpos0.copy()
    qvel = np.zeros(model.nv)
    for name, value in zip(BODY_NAMES, controller.wbc.nominal):
        qpos[model.joint(name).qposadr[0]] = value
    qpos[model.joint("floating_base_joint").qposadr[0] + 2] = .79
    ball = model.joint("football_free")
    qpos[ball.qposadr[0]:ball.qposadr[0] + 3] = trial["release_position_m"]
    qvel[ball.dofadr[0]:ball.dofadr[0] + 3] = trial["release_velocity_mps"]
    keyframe = root.find("keyframe")
    if keyframe is None:
        keyframe = ET.SubElement(root, "keyframe")
    ET.SubElement(keyframe, "key", name="stand", qpos=" ".join(map(str, qpos)),
                  qvel=" ".join(map(str, qvel)))
    ET.indent(root)
    ET.ElementTree(root).write(scene, encoding="unicode")
    return scene


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--trial-report", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    checkpoint = args.checkpoint.resolve()
    run = checkpoint.parent
    manifest = json.loads((run / "manifest.json").read_text())
    if manifest["source_sha256"] != _source_snapshot(None, DEFAULT_RUNTIME_ROOT):
        parser.error("archived source/asset provenance mismatch")
    trial = json.loads(args.trial_report.read_text())["trials"][0]
    args.output.mkdir(parents=True, exist_ok=False)
    weights = args.output / "actor.npz"
    model = export_actor(checkpoint, weights)
    actor = NumpyReceiverActor(weights)
    with np.load(run / "bc-dataset.npz", allow_pickle=False) as data:
        observations = data["observation"]
    expected, _ = model.predict(observations, deterministic=True)
    exported = np.stack([actor(obs) for obs in observations])
    np.testing.assert_allclose(exported, expected, atol=2e-6, rtol=0.)
    route = make_route(trial["route"], scale=trial["route_scale"], speed_mps=.30)
    controller = ReceiverController(actor, route)
    scene = write_scene(args.output / "environment", controller, trial)
    receipt = {
        "evidence_class": "inference_export_and_scene",
        "checkpoint_sha256": sha256(checkpoint.read_bytes()).hexdigest(),
        "actor_sha256": sha256(weights.read_bytes()).hexdigest(),
        "scene_sha256": sha256(scene.read_bytes()).hexdigest(),
        "actor_comparison_observations": len(observations),
        "max_abs_actor_error": float(np.max(np.abs(expected - exported))),
        "joint_order": BODY_NAMES,
        "waypoints_m": route.waypoints,
        "required_inputs": ["joint_state", "imu", "externally_surveyed_rgbd"],
        "trial": trial,
    }
    (args.output / "export.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({key: receipt[key] for key in ("actor_comparison_observations", "max_abs_actor_error")}))


if __name__ == "__main__":
    main()
