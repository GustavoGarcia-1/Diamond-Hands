"""Bounded faster walking-receive screen using the immutable confirmed Go source."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import json,os,subprocess,sys
from pathlib import Path
import numpy as np

p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',required=True);p.add_argument('--amp-source',required=True);p.add_argument('--output',type=Path,required=True)
a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
frozen=Path('/workspace/g1-receiver-runs/aero-go-cup-confirm-20261113-r1/source')
basepath=Path('reports/aero-rl-20261113/go-cup-pass-linux/artifacts/go/profile-07.json').resolve()
base=json.loads(basepath.read_text())
env=dict(os.environ,PYTHONPATH=str(frozen/'src')+':'+str(frozen/'scripts'))
protocol={'purpose':__doc__,'speeds_mps':[1.2,1.35,1.5],'flight_s':1.1,'target_lifts_above_screen_palm_m':[.06,.08,.10],
 'eligibility':'No-ball12s complete,upright>=.90, wholepathlateralerror<=.75m, reach9.144m; passesonlyafterqualifying',
 'acceptance':'Unchanged150ms/1mpsshortreceive,cleanlonghold,no support; gaitandwholepathreportedseparately',
 'controller_source':str(frozen),'controller_sha256':sha256((frozen/'scripts/probe_go_cup.py').read_bytes()).hexdigest(),
 'not_training':'Fixedprofilecalibrationfromno-ballpalms; runtimeRGBD/IMU/encoders unchanged'}
(a.output/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
def rollout(name,speed,profile,duration,no_pass=False):
 out=a.output/name
 cmd=[sys.executable,'scripts/probe_go_cup.py','--source',a.source,'--amp-source',a.amp_source,
      '--profile',str(profile),'--output',str(out),'--walk-speed',str(speed),
      '--handoff-depth','1.3','--initial-yaw','-.7','--duration',str(duration)]
 if no_pass:cmd+=['--no-pass']
 with (a.output/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=frozen,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 result={'name':name,'speed':speed,'command':cmd,'exit_code':r.returncode}
 if (out/'report.json').exists():result['report']=json.loads((out/'report.json').read_text())
 return result
with ThreadPoolExecutor(max_workers=3) as pool:
 screens=list(pool.map(lambda v:rollout('screen-'+str(v),v,basepath,12.,True),protocol['speeds_mps']))
(a.output/'screen-summary.json').write_text(json.dumps(screens,indent=2)+'\n')
cases=[]
for screen in screens:
 if screen['exit_code']:continue
 r=screen['report']
 if not(r['duration_s']>=11.99 and r['minimum_upright_cosine']>=.9 and r['max_stem_error_m']<=.75 and r['final_xyz_m'][0]>=9.144):continue
 with np.load(a.output/screen['name']/'trace.npz') as data:
  m=data['motion'];palms=data['palms'];arrival=float(m[np.argmin(abs(m[:,1]-9.144)),0])
  center=np.array([np.interp(arrival,palms[:,0],palms[:,i]) for i in (1,2,3)])
 for lift in protocol['target_lifts_above_screen_palm_m']:
  index=len(cases);spec=json.loads(json.dumps(base));play=spec['play']
  target=center+[.02,0.,lift];axis=target[:2]-np.asarray(play['quarterback_origin_m'][:2]);axis/=np.linalg.norm(axis)
  play.update(quarterback_target_m=target.tolist(),field_catch_window_m=target.tolist(),field_approach_axis_xy=axis.tolist(),
              release_s=arrival-1.1,flight_s=1.1,finish_s=arrival+3.)
  spec['formation']['arrival_s']=arrival
  profile=a.output/f'profile-{index:02d}.json';profile.write_text(json.dumps(spec,indent=2)+'\n')
  cases.append((index,screen['speed'],profile,arrival+3.,lift))
def run(case):
 i,speed,profile,duration,lift=case;r=rollout(f'case-{i:02d}',speed,profile,duration);r['target_lift_m']=lift;return r
with ThreadPoolExecutor(max_workers=3) as pool:
 results=[]
 for result in pool.map(run,cases):
  results.append(result);(a.output/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
if not cases:(a.output/'summary.json').write_text('[]\n')
if any(r['exit_code'] for r in screens+results):raise SystemExit(1)
