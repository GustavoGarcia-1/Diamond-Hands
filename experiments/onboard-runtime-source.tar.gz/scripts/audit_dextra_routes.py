"""Use the same route audit on the free-base G1 with two actuated Dextra hands."""

from __future__ import annotations

import argparse
from contextlib import nullcontext
from functools import partial
from hashlib import sha256
from inspect import getfile
import json
from pathlib import Path
from unittest.mock import patch

import numpy as np

import audit_receiver_all_routes as route_audit
from audit_receiver_walk_terminal_cap import MINIMUM_NONZERO_DRIVE_MPS, TERMINAL_ARRIVAL_CAP_M, TerminalCapFollower
from g1_receiver.hand_route_plant import HandRoutePlant
from g1_receiver.localization import MarkerLocalizer
from g1_receiver.locomotion import SURVEY_CAMERA_TARGET_M
from g1_receiver.routes import make_route
from g1_receiver.runtime import RobotObservation, SkillGoal


class RoutePlant(HandRoutePlant):
    """Expose the route audit's plant interface with live hand position targets."""

    def __init__(self, codesign_source, closure, camera_position=None):
        if camera_position is not None:
            origin = np.asarray(camera_position, dtype=float)
            if not np.isfinite(origin).all() or np.linalg.norm(np.subtract(SURVEY_CAMERA_TARGET_M, origin)[:2]) < .1:
                raise ValueError("survey camera needs a finite position separated from its look-at target")
        super().__init__(codesign_source, route_camera_position=camera_position)
        self.route_camera = "survey_rgbd" if camera_position is None else "route_rgbd"
        self.closure = closure
        self.localizer = MarkerLocalizer(allow_synthetic_fixture=True)
        self.max_finger_motion = 0.

    def reset(self, start_x, start_y, start_yaw):
        if (start_x, start_y, start_yaw) != (0., 0., 0.):
            raise ValueError("only the declared zero-origin route start is supported")
        super().reset(closure=self.closure)
        self.finger_q0 = self.data.qpos[self.actuation.hand_joint_qpos].copy()
        self.max_finger_motion = 0.

    def camera_pose(self):
        return self.localizer.estimate(*self.capture(self.route_camera))

    def advance(self, drive, *, ticks=1):
        for _ in range(ticks):
            proprioception = self.observe()
            obs = RobotObservation(self.timestamp_s, *proprioception, np.zeros(29), None)
            command = self.wbc.act(obs, SkillGoal(base_velocity=drive))
            self.step(command, closure=self.closure)
            finger_angles = self.data.qpos[self.actuation.hand_joint_qpos]
            self.max_finger_motion = max(self.max_finger_motion, float(np.max(np.abs(finger_angles - self.finger_q0))))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--codesign-source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--plan", type=Path, default=route_audit.ROOT / "reports" / route_audit.PLAN_NAME)
    parser.add_argument("--route", action="append", choices=("go", "slant", "out", "hitch", "post"))
    parser.add_argument("--mode", choices=("stock", "walk_deadband", "terminal_cap"), default="stock")
    parser.add_argument("--camera-position", type=float, nargs=3, metavar=("X", "Y", "Z"),
                        help="fixed survey camera position in field meters")
    parser.add_argument("--closure", type=float, default=.35, help="normalized finger target")
    args = parser.parse_args()
    if args.output.exists() or not 0 <= args.closure <= 1:
        parser.error("output must be new and closure must be between zero and one")
    plan = json.loads(args.plan.read_text())
    hand_plant_sha256 = sha256(Path(getfile(HandRoutePlant)).read_bytes()).hexdigest()
    terminal_cap = TERMINAL_ARRIVAL_CAP_M if args.mode == "terminal_cap" else None
    minimum_speed = (MINIMUM_NONZERO_DRIVE_MPS if terminal_cap is not None
                     else plan["minimum_nonzero_command_mps"][args.mode])
    follower_factory = (patch.object(route_audit, "RouteFollower", partial(
        TerminalCapFollower, terminal_cap_m=terminal_cap,
    )) if terminal_cap is not None else nullcontext())
    plant = RoutePlant(args.codesign_source, args.closure, args.camera_position)
    results = {}
    try:
        with follower_factory:
            for name in args.route or plan["routes"]:
                route = make_route(name, scale=plan["scale"], speed_mps=plan["command_speed_mps"])
                result = route_audit.run_route(plant, route, plan, minimum_speed)
                result["maximum_finger_motion_rad"] = plant.max_finger_motion
                results[name] = result
                print(name, result["passed"], result["waypoint_hit_times_s"],
                      round(result["endpoint_error_m"], 4), flush=True)
    finally:
        plant.close()
    report = {
        "evidence_class": "no_throw_rendered_vision_with_two_articulated_hands",
        "plan_sha256": sha256(args.plan.read_bytes()).hexdigest(),
        "route_audit_sha256": sha256(Path(__file__).with_name("audit_receiver_all_routes.py").read_bytes()).hexdigest(),
        "dextra_route_script_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
        "hand_plant_sha256": hand_plant_sha256,
        "configuration": plan,
        "body_actuators": len(plant.body_actuators),
        "hand_actuators": len(plant.actuation.hand_actuators),
        "closure": args.closure,
        "mode": args.mode,
        "survey_camera_position_m": plant.cameras[plant.route_camera][1].tolist(),
        "terminal_arrival_cap_m": terminal_cap,
        "minimum_nonzero_command_mps": minimum_speed,
        "passed": sum(row["passed"] for row in results.values()),
        "rollouts": len(results),
        "results": results,
    }
    with args.output.open("x") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write("\n")


if __name__ == "__main__":
    main()
