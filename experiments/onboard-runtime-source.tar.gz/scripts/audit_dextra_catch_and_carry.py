"""Test a controlled airborne drop, articulated grasp, and ordered route carry."""

from __future__ import annotations

import argparse
from dataclasses import replace
import json
from pathlib import Path

import mujoco
import numpy as np

from audit_receiver_all_routes import vision_drive
from audit_receiver_walk_terminal_cap import TerminalCapFollower
from g1_receiver.dextra import dextra_ready_joint_targets
from g1_receiver.dextra_physical_eval import DextraContactAudit, TRACE_COLUMNS
from g1_receiver.hand_route_plant import HandRoutePlant
from g1_receiver.localization import MarkerLocalizer
from g1_receiver.locomotion import CONTROL_DT
from g1_receiver.perception import ColorBallDetector
from g1_receiver.routes import make_route
from g1_receiver.runtime import RobotObservation, SkillGoal

ROUTES = ("go", "slant", "out", "hitch", "post")
BALL_START = (.47, 0., 1.30)
BALL_VELOCITY = (-.20, 0., -.15)
SCHEDULED_CLOSE_S = .12
WALK_START_S = 1.20
HORIZON_S = 12.
ROUTE_CAMERA_M = (2.5, -.95, .65)


def evaluate(plant, route, *, mode, recordings=None, walk_start_s=WALK_START_S,
             slew_mps2=None, horizon_s=HORIZON_S, squeeze_rad=0., finger_curl_rad=.60):
    upper_target = dextra_ready_joint_targets(plant.nominal, plant.joint_names)
    plant.reset(release_position_m=BALL_START, release_velocity_mps=BALL_VELOCITY,
                joint_positions=upper_target)
    follower = TerminalCapFollower(route, terminal_cap_m=.025)
    localizer = MarkerLocalizer(allow_synthetic_fixture=True)
    detector = ColorBallDetector(ball_center_offset_m=.075)
    audit = DextraContactAudit(plant.model)
    pelvis = plant.model.body("pelvis").id
    pose, previous_ball = None, None
    next_camera, closed_at = 0., None
    good_frames, camera_frames, next_waypoint = 0, 0, 1
    waypoint_times, positions, speeds, overview, rgb_frames, frame_times = [], [], [], [], [], []
    upright_min = 1.
    drive = np.zeros(3)
    horizon_steps = round(horizon_s / CONTROL_DT)
    for tick in range(horizon_steps + 1):
        now = plant.timestamp_s
        if now >= next_camera - 1e-9:
            next_camera += 1 / 25
            frame, survey = plant.capture()
            route_view = (plant.capture("route_rgbd") if now >= walk_start_s and "route_rgbd" in plant.cameras
                          else (frame, survey))
            measured = localizer.estimate(*route_view)
            camera_frames += 1
            if measured is not None:
                pose = measured
                good_frames += 1
            if mode == "vision" and closed_at is None:
                ball = detector.detect(frame, survey)
                if ball is not None:
                    x, y, z = ball.position_m
                    if (previous_ball is not None and .30 < x < .65 and abs(y) < .13
                            and 1.03 < z < 1.22 and z < previous_ball.position_m[2]):
                        closed_at = now
                    previous_ball = ball
            if recordings is not None:
                plant.renderer.update_scene(plant.data, camera="overview")
                overview.append(plant.renderer.render().copy())
                rgb_frames.append(route_view[0].rgb.copy())
                frame_times.append(frame.timestamp_s)
        if mode == "scheduled" and closed_at is None and now >= SCHEDULED_CLOSE_S - 1e-9:
            closed_at = now
        target_drive = (vision_drive(follower, pose, now, max_age_s=.10, minimum_speed_mps=.055)
                        if now >= walk_start_s else np.zeros(3))
        if slew_mps2 is None:
            drive = target_drive
        else:
            limit = slew_mps2 * CONTROL_DT
            drive += np.clip(target_drive - drive, -limit, limit)
        xyz = plant.data.xpos[pelvis].copy()
        positions.append(xyz[:2])
        speeds.append(float(np.linalg.norm(drive[:2])))
        upright_min = min(upright_min, float(plant.data.xmat[pelvis, 8]))
        if next_waypoint < len(route.waypoints):
            start, goal = np.array(route.waypoints[next_waypoint - 1:next_waypoint + 1])
            if np.linalg.norm(xyz[:2] - goal) <= min(.05, .1 * np.linalg.norm(goal - start)):
                waypoint_times.append(now)
                next_waypoint += 1
        if tick == horizon_steps or upright_min < .55:
            break
        obs = RobotObservation(now, *plant.observe(), np.zeros(29), None)
        arm_target = upper_target.copy()
        reinforcement = 0. if closed_at is None else np.clip((now - closed_at - .30) / .35, 0., 1.)
        for side, sign in (("left", 1), ("right", -1)):
            arm_target[plant.joint_names.index(f"{side}_shoulder_roll_joint")] -= sign * squeeze_rad * reinforcement
        command = plant.wbc.act(obs, SkillGoal(base_velocity=drive), upper_target=arm_target)
        fingers = (0. if closed_at is None else .60 + (finger_curl_rad - .60) * reinforcement)
        plant.step(command, hand_target_rad=fingers * plant.actuation.flexion, post_step=audit.record)
    positions = np.array(positions)
    window = round(.50 / CONTROL_DT)
    endpoint_error = float(np.linalg.norm(positions[-1] - route.waypoints[-1]))
    tolerance = min(.05, .1 * np.linalg.norm(np.subtract(*route.waypoints[-2:])))
    tail_speed = float(np.linalg.norm(np.diff(positions[-window - 1:], axis=0), axis=1).sum() / .50)
    body_speed = np.linalg.norm(np.diff(positions, axis=0), axis=1) / CONTROL_DT
    moving = body_speed[np.asarray(speeds[:-1]) >= .05]
    route_complete = (next_waypoint == len(route.waypoints) and endpoint_error <= tolerance
                      and upright_min >= .90 and tail_speed <= .075)
    contact = audit.summary()
    trace = audit.trace()
    ground = np.flatnonzero(trace[:, TRACE_COLUMNS.index("ball_floor_contact")])
    contact["first_floor_contact_s"] = float(trace[ground[0], 0]) if ground.size else None
    if recordings is not None:
        recordings.mkdir(parents=True, exist_ok=False)
        for name, frames in (("overview", overview), ("camera-rgb", rgb_frames)):
            np.savez_compressed(recordings / f"{name}.npz", rgb=frames, timestamps_s=frame_times)
        np.savez_compressed(recordings / "contacts.npz", samples=audit.trace(), columns=TRACE_COLUMNS)
    return {
        "route": route.name, "waypoints_m": route.waypoints, "length_m": route.length_m,
        "elapsed_s": plant.timestamp_s, "closure_time_s": closed_at,
        "camera_frames": camera_frames, "localized_frames": good_frames,
        "waypoint_hit_times_s": waypoint_times, "endpoint_error_m": endpoint_error,
        "endpoint_tolerance_m": tolerance, "min_upright_cosine": upright_min,
        "final_mean_speed_mps": tail_speed, "peak_commanded_speed_mps": max(speeds),
        "mean_measured_speed_while_commanded_mps": float(moving.mean()) if moving.size else None,
        "route_complete": bool(route_complete), "contact": contact,
        "hand_catch_and_route": bool(route_complete and contact["hands_only_catch"]),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--codesign-source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--route", action="append", choices=ROUTES)
    parser.add_argument("--mode", choices=("scheduled", "vision", "open"), default="vision")
    parser.add_argument("--recording", type=Path)
    parser.add_argument("--speed", type=float, default=.20)
    parser.add_argument("--walk-start", type=float, default=WALK_START_S)
    parser.add_argument("--route-camera", type=float, nargs=3, default=ROUTE_CAMERA_M)
    parser.add_argument("--slew", type=float, default=.55)
    parser.add_argument("--horizon", type=float, default=HORIZON_S)
    parser.add_argument("--squeeze", type=float, default=.04, help="inward shoulder roll after securing the grip")
    parser.add_argument("--curl", type=float, default=.60, help="finger joint target after securing the grip")
    parser.add_argument("--hitch-return", type=float, default=.18, help="Hitch reversal distance in meters")
    args = parser.parse_args()
    if args.output.exists() or not 0 < args.speed <= .35 or not .5 <= args.walk_start <= 3.:
        parser.error("provide a new output, a speed between zero and 0.35, and a walk start within 0.5–3 s")
    if args.recording and args.recording.exists():
        parser.error("recording directory must be new")
    if not 4 <= args.horizon <= 20 or (args.slew is not None and not 0 < args.slew <= 2):
        parser.error("horizon must be 4–20 seconds and slew must be positive and at most 2 m/s²")
    if not 0 <= args.squeeze <= .08 or not .60 <= args.curl <= .85:
        parser.error("squeeze must be 0–0.08 rad and final curl 0.60–0.85 rad")
    if not .10 <= args.hitch_return <= .25:
        parser.error("Hitch return must be between 0.10 and 0.25 meters")
    plant = HandRoutePlant(args.codesign_source, route_camera_position=args.route_camera)
    results = []
    names = args.route or ROUTES
    try:
        for name in names:
            route = make_route(name, scale=.24, speed_mps=args.speed)
            if name == "hitch":
                turn_x, turn_y = route.waypoints[-2]
                route = replace(route, waypoints=(*route.waypoints[:-1], (turn_x - args.hitch_return, turn_y)))
            recordings = args.recording / name if args.recording and len(names) > 1 else args.recording
            result = evaluate(plant, route, mode=args.mode, recordings=recordings,
                              walk_start_s=args.walk_start, slew_mps2=args.slew, horizon_s=args.horizon,
                              squeeze_rad=args.squeeze, finger_curl_rad=args.curl)
            results.append(result)
            print(name, result["route_complete"], result["contact"]["hands_only_catch"],
                  round(result["endpoint_error_m"], 4), result["closure_time_s"], flush=True)
    finally:
        plant.close()
    report = {
        "evidence_class": "preposed_controlled_drop_and_route_carry_simulation",
        "mode": args.mode, "release_position_m": BALL_START, "release_velocity_mps": BALL_VELOCITY,
        "walk_start_s": args.walk_start, "command_speed_mps": args.speed,
        "route_camera_m": args.route_camera, "body_slew_mps2": args.slew, "horizon_s": args.horizon,
        "squeeze_rad": args.squeeze, "final_finger_curl_rad": args.curl,
        "hitch_return_m": args.hitch_return,
        "results": results,
    }
    with args.output.open("x") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write("\n")


if __name__ == "__main__":
    main()
