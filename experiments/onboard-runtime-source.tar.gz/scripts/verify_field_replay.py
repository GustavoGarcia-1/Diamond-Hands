"""Verify pose-preserving replay and save a decoded video contact sheet."""
import argparse,json
from pathlib import Path
import numpy as np
import imageio.v2 as iio
from PIL import Image,ImageDraw

def main():
 p=argparse.ArgumentParser();p.add_argument('--directory',type=Path,required=True);p.add_argument('--source',type=Path,required=True);a=p.parse_args()
 with np.load(a.directory/'full-play.npz') as r,np.load(a.source) as s:
  assert np.array_equal(r['qpos'],s['qpos']) and np.array_equal(r['timestamps_s'],s['timestamps_s'])
  end=float(s['timestamps_s'][-1]);stamps=np.linspace(0,end,8)
 reader=iio.get_reader(a.directory/'full-play.mp4');meta=reader.get_meta_data();meta.pop('nframes',None)
 sheet=Image.new('RGB',(800,900),'#101010');d=ImageDraw.Draw(sheet)
 for i,t in enumerate(stamps):
  frame=Image.fromarray(reader.get_data(round(t*meta['fps'])));frame.thumbnail((400,225));x=i%2*400;y=i//2*225;sheet.paste(frame,(x,y));d.text((x+8,y+8),f'{t:.2f} s',fill='white')
 reader.close();sheet.save(a.directory/'contact-sheet.jpg')
 (a.directory/'video-verification.json').write_text(json.dumps({'video':meta,'source':str(a.source),'identical_archive_poses_and_timestamps':True,'presentation':'Original green field markings, plain backdrop, spectator passing machine when a throw is present','recorded_end_s':end},indent=2)+'\n')
 print(json.dumps(meta))
if __name__=='__main__':main()
