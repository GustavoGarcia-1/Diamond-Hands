#!/usr/bin/env bash
set -euo pipefail
# Antioch's CLI needs its configured project; receiver files live separately.
antioch_project="${ANTIOCH_PROJECT:-$HOME/projects/simulation}"
antioch_cli="${ANTIOCH_CLI:-$antioch_project/.venv/bin/antioch}"
cd "$antioch_project"
exec "$antioch_cli" service shell \
  --session ses-3A0R1JMJWD4E7ENS2SEQQZRYS0 --service sim \
  tmux attach-session -t g1-receiver
