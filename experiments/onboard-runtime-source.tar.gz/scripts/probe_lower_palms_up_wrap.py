"""Three bounded earlier fixed-QB lower-cup throws; calibration is declared offline."""
import argparse,json
from pathlib import Path
from copy import deepcopy
import probe_go_cup as runner

def main():
 p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--amp-source',type=Path,required=True);p.add_argument('--profile',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True);donor=json.loads(a.profile.read_text());rows=[]
 for i,delay in enumerate((.04,.10,.16)):
  flight=1.6
  profile=deepcopy(donor);profile['play']['flight_s']=flight;profile['play']['grasp_joint_lead_s']=-delay;profile['play']['release_s']=5.2-flight;path=a.output/f'profile-{i:02d}.json';path.write_text(json.dumps(profile,indent=2)+'\n');argv=['--source',str(a.source),'--amp-source',str(a.amp_source),'--profile',str(path),'--output',str(a.output/f'case-{i:02d}'),'--walk-speed','1','--handoff-depth','1.3','--initial-yaw','-.7','--duration','6.5'];report=runner.run(runner.build_parser().parse_args(argv));rows.append(dict(case=i,flight_s=flight,arm_delay_s=delay,report=report))
 (a.output/'screen.json').write_text(json.dumps(rows,indent=2)+'\n')
if __name__=='__main__':main()
