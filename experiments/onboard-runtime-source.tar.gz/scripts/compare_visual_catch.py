"""Compare RGB-D-timed arm commands with matched ball-vision-disabled trials."""
from __future__ import annotations

import argparse
from dataclasses import asdict
import json
from pathlib import Path

import numpy as np

from g1_receiver.footfalls import MIN_FORWARD_STEP_M, MIN_STANCE_S, MIN_SWING_S, forward_footfalls
from g1_receiver.locomotion import run
from g1_receiver.routes import Route, RouteFollower
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT

# Fixed release conditions. The active gate never reads these parameters.
STATIONARY = (
    ((.84, 0., .38), (-1.00, 0., 4.36)),
    ((.92, -.02, .38), (-1.08, .035, 4.42)),
    ((1.20, .02, .39), (-1.50, -.03, 4.48)),
)
WALKING = (
    ((.90, 0., .40), (-.8533333333333334, 0., 4.6120833333333335)),
    ((1.45, 0., .40), (-1.62, 0., 4.44)),
)


def evaluate(truth, commands):
    stamps = truth["timestamps_s"]
    ball = truth["ball_position_m"]
    body = truth["robot_base_position_m"]
    contacts = truth["ball_robot_contact"]
    floor = truth["ball_ground_contact"]
    trigger = float(commands["catch_trigger_time_s"])
    triggers = np.flatnonzero(commands["catch_triggered"])
    support = stamps >= stamps[-1] - .3
    events = truth["robot_contact_timestamps_s"]
    first_contact = float(events[0]) if len(events) else None
    unsupported = np.flatnonzero(~contacts)
    last_unsupported = int(unsupported[-1]) if len(unsupported) else -1
    sustained = stamps[-1] - stamps[last_unsupported + 1] if last_unsupported + 1 < len(stamps) else 0.
    contact_tick = np.flatnonzero(contacts)
    index = int(contact_tick[0]) if len(contact_tick) else None
    max_rate = float(np.max(
        np.abs(np.diff(commands["upper_target_rad"], axis=0)) / np.diff(stamps)[:, None]
    ))
    result = {
        "trigger_s": trigger if np.isfinite(trigger) else None,
        "trigger_lead_s": float(commands["catch_time_to_crossing_s"][triggers[0]]) if len(triggers) else None,
        "trigger_count": len(triggers),
        "first_contact_s": first_contact,
        "first_floor_contact_s": float(stamps[floor][0]) if floor.any() else None,
        "final_height_m": float(ball[-1, 2]),
        "final_speed_mps": float(np.linalg.norm(truth["ball_velocity_mps"][-1])),
        "support_fraction_final_300ms": float(np.mean(contacts[support])),
        "continuous_final_support_s": float(sustained),
        "precontact_forward_m": float(body[index, 0] - body[0, 0]) if index is not None else None,
        "postcontact_displacement_m": float(np.linalg.norm(body[-1, :2] - body[index, :2]))
        if index is not None else None,
        "min_upright_cosine": float(np.min(truth["robot_upright"])),
        "max_arm_target_rate_rad_s": max_rate,
        "retained": bool(
            contacts.any() and not floor.any() and np.mean(contacts[support]) >= .85
            and np.min(ball[support, 2]) > .7 and np.min(truth["robot_upright"]) >= .9
        ),
    }
    if "route_waypoints_m" in commands:
        route = Route(str(commands["route_name"].item()),
                      tuple(map(tuple, commands["route_waypoints_m"])), nominal_speed_mps=.35)
        waypoint_visits = []
        next_sample = 0
        endpoint_error = None
        threshold = None
        for start, waypoint in zip(route.waypoints, route.waypoints[1:]):
            endpoint_error = np.linalg.norm(body[:, :2] - waypoint, axis=1)
            threshold = min(RouteFollower(route).arrival_tolerance_m,
                            .1 * np.linalg.norm(np.subtract(start, waypoint)))
            observed = np.flatnonzero(endpoint_error[next_sample:] <= threshold)
            if next_sample < len(stamps) and len(observed):
                visit = next_sample + int(observed[0])
                first_visit = float(stamps[visit])
                next_sample = visit + 1
            else:
                first_visit = None
                next_sample = len(stamps)
            waypoint_visits.append({
                "target_m": waypoint, "tolerance_m": float(threshold), "first_visit_s": first_visit,
            })
        status = commands["status"]
        controller_arrived = np.flatnonzero(status == "arrived")
        actual_arrived = np.flatnonzero(endpoint_error <= threshold)
        speed_start = max(0, len(stamps) - 6)
        speed_xy = np.linalg.norm(body[-1, :2] - body[speed_start, :2]) / (stamps[-1] - stamps[speed_start])
        result.update(
            route=route.name,
            endpoint_target_m=route.waypoints[-1],
            ordered_waypoint_visits=waypoint_visits,
            all_waypoints_visited=all(visit["first_visit_s"] is not None for visit in waypoint_visits),
            endpoint_tolerance_m=float(threshold),
            final_xy_m=body[-1, :2].tolist(),
            final_endpoint_error_m=float(endpoint_error[-1]),
            first_truth_arrival_s=float(stamps[actual_arrived[0]]) if len(actual_arrived) else None,
            first_controller_arrival_s=float(stamps[controller_arrived[0]]) if len(controller_arrived) else None,
            final_xy_speed_mps=float(speed_xy),
            final_within_endpoint_tolerance=bool(endpoint_error[-1] <= threshold),
            supported_through_controller_arrival=bool(
                len(controller_arrived) and contacts[controller_arrived[0]:].all()
                and not floor[controller_arrived[0]:].any()
            ),
            time_after_controller_arrival_s=float(stamps[-1] - stamps[controller_arrived[0]])
            if len(controller_arrived) else None,
        )
    if "foot_timestamps_s" in truth:
        footfalls = forward_footfalls(
            truth["foot_timestamps_s"], truth["foot_position_m"], truth["foot_floor_contact"],
            truth["foot_body_names"],
        )
        post_contact = [event for event in footfalls
                        if first_contact is not None and event.lifted_s >= first_contact]
        continuous_start = float(stamps[-1] - sustained)
        post_catch = [event for event in post_contact
                      if result["retained"] and event.lifted_s >= continuous_start]
        result.update(
            forward_footfalls=[asdict(event) for event in footfalls],
            forward_steps_after_first_contact=len(post_contact),
            continuous_retention_started_s=continuous_start if result["retained"] else None,
            forward_steps_during_continuous_retention=len(post_catch),
            footfall_thresholds={
                "min_swing_s": MIN_SWING_S, "min_stance_s": MIN_STANCE_S,
                "min_forward_step_m": MIN_FORWARD_STEP_M,
            },
        )
    return result


def pair_agrees_before_trigger(active, inactive, trigger_s):
    """Check that the comparison diverges only after the visual action."""
    stamps = active["timestamps_s"]
    through_trigger = stamps <= trigger_s if trigger_s is not None else np.ones(len(stamps), bool)
    return bool(
        np.array_equal(stamps, inactive["timestamps_s"])
        and all(np.array_equal(active[key][through_trigger], inactive[key][through_trigger])
                for key in ("ball_position_m", "ball_velocity_mps", "robot_base_position_m",
                            "robot_base_quaternion_wxyz"))
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--moving", action="store_true")
    parser.add_argument("--route", choices=("go", "slant"), default="go")
    parser.add_argument("--seconds", type=float)
    parser.add_argument("--fixture", type=int, help="Run one 1-based fixture index")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    mode = "visual-moving-catch" if args.moving else "visual-catch"
    fixtures = WALKING if args.moving else STATIONARY
    seconds = args.seconds if args.seconds is not None else (3.2 if args.moving else 2.2)
    if not np.isfinite(seconds) or seconds < .02:
        parser.error("--seconds must be finite and at least 0.02")
    if args.fixture is not None and not 1 <= args.fixture <= len(fixtures):
        parser.error("--fixture must be a valid 1-based index")
    trials = []
    for index, (position, velocity) in enumerate(fixtures, 1):
        if args.fixture is not None and index != args.fixture:
            continue
        pair = {"release_position_m": position, "release_velocity_mps": velocity}
        for ball_vision in (True, False):
            label = "vision" if ball_vision else "disabled"
            name = f"{mode}-{index:02}-{label}"
            truth, frames, sensor, commands = run(
                DEFAULT_RUNTIME_ROOT, mode, seconds, overview=True, survey_camera=True,
                route_name=args.route, route_scale=.20, release_position_m=position,
                release_velocity_mps=velocity, ball_vision=ball_vision,
            )
            outputs = {
                "truth": truth, "controller": commands, "sensor": sensor,
                "overview": {"rgb": frames, "timestamps_s": truth["timestamps_s"]},
            }
            for kind, arrays in outputs.items():
                np.savez_compressed(args.output / f"{name}-{kind}.npz", **arrays)
            pair[label] = {"name": name, **evaluate(truth, commands)}
            if ball_vision:
                active_truth = truth
            print(json.dumps(pair[label]), flush=True)
        pair["truth_matches_through_trigger"] = pair_agrees_before_trigger(
            active_truth, truth, pair["vision"]["trigger_s"]
        )
        if not pair["truth_matches_through_trigger"]:
            raise RuntimeError("comparison trajectories differ before the vision-triggered action")
        trials.append(pair)
    report = {
        "evidence_class": "physical_simulation", "mode": mode, "seconds": seconds,
        "route": args.route if args.moving else None, "route_scale": .20 if args.moving else None,
        "arm_start": "nominal", "comparison": "same release with ball vision disabled",
        "trials": trials,
    }
    (args.output / f"{mode}-comparison.json").write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
