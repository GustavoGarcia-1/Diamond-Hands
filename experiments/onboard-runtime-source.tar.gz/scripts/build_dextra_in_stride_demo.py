"""Verify five recorded Dextra plays and export their replay assets."""

from __future__ import annotations

import argparse
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import imageio.v2 as imageio
import numpy as np
from PIL import Image

from score_dextra_in_stride import score_recorded_route


ROOT = Path(__file__).resolve().parents[1]
PLAYS = ("go", "slant", "out", "hitch", "post")
REPLAY_FILES = (
    "docs/dextra-in-stride-demo.md",
    "scripts/audit_dextra_moving_release.py",
    "scripts/evaluate_dextra_in_stride.py",
    "scripts/score_dextra_in_stride.py",
)


def json_bytes(value):
    return (json.dumps(value, indent=2, allow_nan=False) + "\n").encode()


def export_play(route, folder, destination):
    report_path = folder / "report.json"
    report = json.loads(report_path.read_text())
    case, = report["results"]
    if case["route"] != route or case["close_s"] is None:
        raise ValueError(f"{route} requires a recorded trial with a visual close")
    score = score_recorded_route(folder, case)
    if not score["in_stride_catch_and_route"]:
        raise ValueError(f"{route} did not pass: {score['failed_checks']}")
    trace_path = folder / score["trace"]
    with np.load(trace_path, allow_pickle=False) as trace:
        motion = trace["motion"]
        contact = trace["contact"]
    raw_path = folder / trace_path.stem / "overview.npz"
    with np.load(raw_path, allow_pickle=False) as raw:
        frames, times = raw["rgb"], raw["timestamps_s"]
    if (frames.shape != (len(times), 360, 640, 3) or frames.dtype != np.uint8
            or not np.allclose(np.diff(times), .04, atol=1e-7, rtol=0)
            or not np.allclose(times, motion[::2, 0], atol=1e-7, rtol=0)):
        raise ValueError(f"video frames do not match the simulation clock: {raw_path}")
    movie_path = destination / f"{route}.mp4"
    with imageio.get_writer(movie_path, fps=25, codec="libx264", quality=8,
                            macro_block_size=1, ffmpeg_params=["-movflags", "+faststart"]) as writer:
        for frame in frames:
            writer.append_data(frame)
    poster = min(len(times) - 1, np.searchsorted(times, case["close_s"] + .20))
    Image.fromarray(frames[poster]).save(destination / f"{route}.webp", quality=90)

    first_tip = score["first_tip_contact_s"]
    release_time = case["release"]["time_s"]
    tip_index = np.searchsorted(contact[:, 0], first_tip)
    evidence = {
        "evidence_class": report["evidence_class"],
        "source_report_sha256": sha256(report_path.read_bytes()).hexdigest(),
        "video_sha256": sha256(movie_path.read_bytes()).hexdigest(),
        "initial_free_flight_s": first_tip - release_time,
        "ball_horizontal_travel_to_first_tip_m": float(np.linalg.norm(contact[tip_index, 1:3] - contact[0, 1:3])),
        "trial": case,
        "score": score,
    }
    (destination / f"{route}.json").write_bytes(json_bytes(evidence))
    play = {
        "route": route, "label": route.title(),
        "delivery": "Underhand lob" if case["release"]["mode"] == "underhand_lob" else "Controlled drop",
        "release": release_time, "speed": score["pre_tip_speed_mps"],
        "travel": score["total_post_tip_route_displacement_m"], "error": score["endpoint_error_m"],
        "waypoints": case["waypoints_m"], "motion": motion[::2, :3].round(4).tolist(),
        "firstTouch": [float(np.interp(first_tip, motion[:, 0], motion[:, axis])) for axis in (1, 2)],
    }
    return play, evidence, trace_path, report_path


def build_archive(base, output, destination, verified, fast_go_audit=None):
    with ZipFile(base) as source:
        manifest = json.loads(source.read("MANIFEST.json"))
        runtime = {}
        for name, checksum in manifest.items():
            if (name.startswith(("src/", "dextra-source/")) or name in ("pyproject.toml", "uv.lock")
                    or name.startswith("scripts/audit_receiver_")):
                data = source.read(name)
                if sha256(data).hexdigest() != checksum:
                    raise ValueError(f"asset digest differs: {name}")
                runtime[name] = data
    runtime.update({path.relative_to(ROOT).as_posix(): path.read_bytes()
                    for path in (ROOT / "src").rglob("*.py")})
    runtime.update({name: (ROOT / name).read_bytes() for name in REPLAY_FILES})
    runtime["README.md"] = b"# G1 in-stride receiver\n\nSee [the demo and reproduction instructions](docs/dextra-in-stride-demo.md).\n"
    for play, _, trace_path, report_path in verified:
        name = play["route"]
        for suffix in (".mp4", ".webp", ".json"):
            runtime[f"videos/{name}{suffix}"] = (destination / f"{name}{suffix}").read_bytes()
        runtime[f"traces/{name}/{trace_path.name}"] = trace_path.read_bytes()
        runtime[f"traces/{name}/report.json"] = report_path.read_bytes()
    if fast_go_audit is not None:
        for path in fast_go_audit.iterdir():
            if path.is_file() and path.suffix in {".json", ".npz", ".mp4", ".py", ".md"}:
                runtime[f"reports/fast-go/{path.name}"] = path.read_bytes()
    checksums = {name: sha256(data).hexdigest() for name, data in sorted(runtime.items())}
    with ZipFile(output, "x", compression=ZIP_DEFLATED, compresslevel=6) as archive:
        for name, data in runtime.items():
            archive.writestr(name, data)
        archive.writestr("MANIFEST.json", json_bytes(checksums))
    with ZipFile(output) as archive:
        if archive.testzip() is not None or any(
                sha256(archive.read(name)).hexdigest() != digest for name, digest in checksums.items()):
            raise ValueError("demo archive verification failed")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trial", metavar="ROUTE=DIRECTORY", action="append", required=True)
    parser.add_argument("--destination", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--base-package", type=Path)
    parser.add_argument("--archive", type=Path)
    parser.add_argument("--fast-go-audit", type=Path)
    args = parser.parse_args()
    trials = dict(item.split("=", 1) for item in args.trial)
    if len(args.trial) != len(PLAYS) or set(trials) != set(PLAYS):
        parser.error("specify one recorded trial per route")
    if bool(args.base_package) != bool(args.archive):
        parser.error("provide a verified base asset package and archive path together")
    args.destination.mkdir(parents=True, exist_ok=True)
    verified = [export_play(route, Path(trials[route]), args.destination) for route in PLAYS]
    (args.destination / "index.json").write_bytes(json_bytes([play for play, *_ in verified]))
    report = {"evidence_class": "selected_in_stride_dextra_playbook",
              "passed": len(verified), "trials": {play["route"]: evidence for play, evidence, *_ in verified}}
    args.report.write_bytes(json_bytes(report))
    if args.archive:
        build_archive(args.base_package, args.archive, args.destination, verified, args.fast_go_audit)
    print(f"Verified and exported {len(verified)} recorded plays")


if __name__ == "__main__":
    main()
