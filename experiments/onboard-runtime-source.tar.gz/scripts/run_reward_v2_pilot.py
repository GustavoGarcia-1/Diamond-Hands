"""Bounded reward-correctness pilot followed by fixed paired physical evaluation."""
import argparse
import json
from pathlib import Path
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--source', required=True)
    parser.add_argument('--amp-source', required=True)
    args = parser.parse_args()
    args.output.mkdir(exist_ok=False, parents=True)
    reference = 'reports/aero-rl-20261113/go-overhead.json'
    common = ['--source', args.source, '--amp-source', args.amp_source]
    train = [sys.executable, '-m', 'g1_receiver.aero_residual_rl',
             '--reference', reference, *common, '--output', str(args.output/'training'),
             '--steps', '8192', '--n-envs', '4', '--device', 'cuda',
             '--wall-seconds', '1620', '--normalized-observations',
             '--corrected-potential-reward']
    evaluate = [sys.executable, 'scripts/evaluate_aero_rl_checkpoints.py',
                '--pair', 'reward-v2', reference, str(args.output/'training/final.zip'),
                *common, '--output', str(args.output/'evaluation'), '--device', 'cuda',
                '--heldout', '--wall-seconds', '600']
    protocol = {
        'purpose': 'Test corrected potential accounting; not a catch-improvement claim',
        'baseline': 'Zero residual with identical sensors, route, throw and reward version',
        'selection': 'Final checkpoint only; no checkpoint choice from physical scores',
        'evaluation': 'Nominal plus fixed target Y offsets -0.02 and +0.02 m',
        'acceptance': 'Report short receive, long hold, running and falls separately; '
                      'reward gain alone never establishes physical improvement',
        'training_formation': 'Archived Go warmup formation, not current two-yard slot',
        'commands': [train, evaluate],
    }
    (args.output/'protocol.json').write_text(json.dumps(protocol, indent=2)+'\n')
    for name, command, timeout in [('training', train, 1800), ('evaluation', evaluate, 720)]:
        with (args.output/f'{name}.log').open('w') as log:
            subprocess.run(command, stdout=log, stderr=subprocess.STDOUT,
                           timeout=timeout, check=True)


if __name__ == '__main__':
    main()
