"""Copy verified receiver checkpoints off an Antioch session while it is available."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile
from time import monotonic, sleep
import uuid

TERMINAL = {"completed", "failed", "time_limit"}
CHECKPOINT = re.compile(r"ppo-[0-9]{9,}\.zip")
RUN_FILES = (
    "manifest.json", "heldout-manifest.json", "heldout-sha256.json",
    "heldout-status.jsonl", "heldout-physical.jsonl", "heldout-sensor.jsonl",
    "training-episodes.jsonl", "run-summary.json", "bc-summary.json",
    "bc-dataset.npz", "bc.zip",
)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def complete_records(data: bytes):
    # The writer appends JSONL while training. An unfinished final row can wait.
    for row in data.splitlines(keepends=True):
        if row.endswith(b"\n") and row.strip():
            yield json.loads(row)


def best_evaluated(data: bytes, run: Path) -> str | None:
    candidates = []
    for record in complete_records(data):
        match = re.fullmatch(r"ppo_([0-9]+)", record["label"])
        suites = list(record["suites"].values())
        if not match or record["stop"] != "complete" or not suites:
            continue
        total = sum(s["expected"] for s in suites)
        if not total or any(s["completed"] != s["expected"] for s in suites):
            continue
        steps = int(match[1])
        name = f"ppo-{steps:09d}.zip"
        if (run / name).is_file():
            score = sum(s["physical_support_2s"] for s in suites) / total
            candidates.append((score, -steps, name))
    return max(candidates)[2] if candidates else None


def pack(base: Path, archive: Path, snapshot_sha256: str) -> dict:
    artifacts = base / "artifacts"
    run = artifacts / "run"
    files = {"status.json": (artifacts / "status.json").read_bytes()}
    status = json.loads(files["status.json"])
    if status["snapshot_sha256"] != snapshot_sha256:
        raise ValueError("run and source receipt hashes differ")

    latest_path = run / "latest.json"
    latest = None
    best = None
    if latest_path.is_file():
        latest_data = latest_path.read_bytes()
        latest = json.loads(latest_data)
        name = latest["checkpoint"]
        if not CHECKPOINT.fullmatch(name):
            raise ValueError("unexpected checkpoint name")
        checkpoint = (run / name).read_bytes()
        if digest(checkpoint) != latest["checkpoint_sha256"]:
            raise ValueError("latest checkpoint hash mismatch")
        files.update({"run/latest.json": latest_data, f"run/{name}": checkpoint})

    for name in RUN_FILES:
        path = run / name
        if path.is_file():
            files[f"run/{name}"] = path.read_bytes()
    best = best_evaluated(files.get("run/heldout-status.jsonl", b""), run)
    if best and f"run/{best}" not in files:
        files[f"run/{best}"] = (run / best).read_bytes()
    for name, path in (("launch.json", base / "launch.json"),
                       ("training.log", artifacts / "training.log")):
        if path.is_file():
            files[name] = path.read_bytes()
    if latest is None and status["phase"] not in TERMINAL:
        return {"phase": status["phase"], "archived": False}

    report = {
        "phase": status["phase"],
        "latest_steps": latest["timesteps"] if latest else None,
        "best_on_in_run_evaluation": best,
        "source_snapshot_sha256": snapshot_sha256,
        "files_sha256": {name: digest(data) for name, data in files.items()},
    }
    with tarfile.open(archive, "x:gz") as bundle:
        files["backup.json"] = json.dumps(report, indent=2).encode() + b"\n"
        for name, data in sorted(files.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            bundle.addfile(info, io.BytesIO(data))
    return {**report, "archived": True}


def verify(archive: Path, expected: dict) -> None:
    with tarfile.open(archive, "r:gz") as bundle:
        members = bundle.getmembers()
        names = {member.name for member in members}
        hashes = expected["files_sha256"]
        if (len(names) != len(members) or names != set(hashes) | {"backup.json"}
                or any(not member.isfile() for member in members)):
            raise ValueError("backup file manifest mismatch")
        report = json.load(bundle.extractfile("backup.json"))
        if report != {key: value for key, value in expected.items() if key != "archived"}:
            raise ValueError("backup metadata mismatch")
        for name, expected_hash in hashes.items():
            with bundle.extractfile(name) as stream:
                if hashlib.file_digest(stream, "sha256").hexdigest() != expected_hash:
                    raise ValueError(f"backup file hash mismatch: {name}")


def backup(receipt: dict, output: Path) -> dict:
    from antioch.client import Client, targeting
    from antioch.client.service import copy_path
    from antioch.transport import exit_code_of

    base = receipt["remote_root"]
    client = Client()
    resolved = targeting.resolve_session(client, session=receipt["session"], any_project=True, fresh=True)
    transfer = f"/workspace/project/.receiver-backup-{uuid.uuid4().hex}.tar.gz"
    source = Path(__file__).read_text()
    with targeting.attach_agent(client, resolved.session, "sim") as agent:
        try:
            response = agent.run(
                ["python3", "-B", "-c", source, "--pack", base, transfer, receipt["snapshot"]["sha256"]],
                cwd="/tmp", timeout=120,
            )
            if exit_code_of(response) != 0:
                raise RuntimeError("remote checkpoint backup could not be created")
            report = json.loads(response.stdout)
            if not report["archived"]:
                return report
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
            target = output / f"{stamp}-{report['phase']}-{report['latest_steps']}.tar.gz"
            partial = target.with_suffix(".partial")
            try:
                copy_path(agent, output, local=partial, remote=transfer, download=True,
                          cwd="/tmp", warn=lambda _: None)
                verify(partial, report)
                partial.replace(target)
            finally:
                partial.unlink(missing_ok=True)
            return {**report, "path": str(target)}
        finally:
            agent.run(["rm", "-f", transfer], cwd="/tmp", timeout=30)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--receipt", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--watch-seconds", type=int, default=0)
    parser.add_argument("--interval-seconds", type=int, default=300)
    parser.add_argument("--pack", nargs=3, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.pack:
        base, archive, source = args.pack
        print(json.dumps(pack(Path(base), Path(archive), source)))
        return
    if not args.receipt or not args.output or args.watch_seconds < 0 or args.interval_seconds < 10:
        parser.error("provide a receipt, output directory, and valid polling times")
    receipt = json.loads(args.receipt.read_text())
    if not re.fullmatch(r"/workspace/g1-receiver-runs/[A-Za-z0-9][A-Za-z0-9_-]{0,63}", receipt["remote_root"]):
        parser.error("unexpected remote run directory")
    args.output.mkdir(parents=True, exist_ok=True)
    deadline = monotonic() + args.watch_seconds
    while True:
        try:
            report = backup(receipt, args.output.resolve())
        except Exception as exc:
            if monotonic() >= deadline:
                raise
            print(json.dumps({"retrying": type(exc).__name__}), flush=True)
        else:
            print(json.dumps(report), flush=True)
            if report["phase"] in TERMINAL or monotonic() >= deadline:
                return
        sleep(max(0, min(args.interval_seconds, deadline - monotonic())))


if __name__ == "__main__":
    main()
