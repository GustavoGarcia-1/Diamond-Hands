"""Declared initial-stance calibration; fixed field and camera survey throughout."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--source',required=True);p.add_argument('--amp-source',required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
profile='reports/out-scrimmage/left-turn-20261113/overhead-pass-linux/artifacts/out/profile-07.json'
cases=[(yaw,depth) for yaw in (-.3,-.5,-.7) for depth in (1.3,2.1)]
(a.output/'protocol.json').write_text(json.dumps({
    'purpose':'Physical initial stance calibration, no in-play reset or retrospective route-frame rotation',
    'cases_yaw_rad_handoff_depth_m':cases,'walk_speed_mps':1.,
    'eligibility':'Complete14s, upright>=.90, reach9.144m, maxstemerror<=.75m',
    'baseline':'go-cup-screen-linux case01, initialyaw0 andhandoff2.1m'},indent=2)+'\n')
def run(pair):
    index,(yaw,depth)=pair
    command=[sys.executable,'scripts/probe_go_cup.py','--source',a.source,'--amp-source',a.amp_source,
             '--profile',profile,'--output',str(a.output/f'case-{index:02d}'),
             '--walk-speed','1','--handoff-depth',str(depth),'--initial-yaw',str(yaw),
             '--no-pass','--duration','14']
    with (a.output/f'case-{index:02d}.log').open('w') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=300)
    report=a.output/f'case-{index:02d}/report.json'
    return {'case':index,'initial_yaw_rad':yaw,'handoff_depth_m':depth,'exit_code':result.returncode,
            'command':command,'report':json.loads(report.read_text()) if report.exists() else None}
with ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(run,enumerate(cases)))
(a.output/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
if any(r['exit_code'] for r in results):raise SystemExit(1)
