"""Detached watchdog for one Antioch receiver training job."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import signal
import subprocess
import sys


def main():
    base = Path(sys.argv[1])
    config = json.loads((base / "launch.json").read_text())
    artifacts = base / "artifacts"
    state = {"phase": "starting", "started_utc": datetime.now(timezone.utc).isoformat(),
             "snapshot_sha256": config["snapshot_sha256"], "wall_seconds": config["wall_seconds"]}

    def save():
        temporary = artifacts / "status.tmp"
        temporary.write_text(json.dumps(state, indent=2) + "\n")
        temporary.replace(artifacts / "status.json")

    save()
    env = {**os.environ, "PYTHONPATH": str(base / "source/src"), "WANDB_MODE": "disabled",
           "PYTHONDONTWRITEBYTECODE": "1", "MUJOCO_GL": "egl",
           "PYOPENGL_PLATFORM": "egl", "OMP_NUM_THREADS": "1",
           "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"}
    try:
        with (artifacts / "training.log").open("ab", buffering=0) as log:
            child = subprocess.Popen(config["command"], cwd=base / "source", env=env,
                                     stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                     start_new_session=True, close_fds=True)
            state.update(phase="running", worker_pid=child.pid)
            save()
            try:
                code = child.wait(timeout=config["wall_seconds"])
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait()
                state.update(phase="time_limit", exit_code=124)
            else:
                state.update(phase="completed" if code == 0 else "failed", exit_code=code)
    except Exception as exc:
        state.update(phase="failed", exit_code=1, error_type=type(exc).__name__)
    finally:
        state["finished_utc"] = datetime.now(timezone.utc).isoformat()
        save()


if __name__ == "__main__":
    main()
