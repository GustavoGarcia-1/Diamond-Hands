"""Compare two internal arrival caps and two diagnostic horizons for the receiver."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from statistics import median

import numpy as np
from stable_baselines3 import PPO
import torch

from audit_receiver_checkpoints import ROOT, digest, read_json, route_result, verify_recovery
from audit_receiver_extended_routes import build_cases, release_key, require_digest
from compare_receiver_route_control import route_action
from g1_receiver.locomotion import CONTROL_DT
from g1_receiver.receiver_env import POLICY_HZ, ReceiverTrial
from g1_receiver.receiver_physical_eval import PhysicalAuditReceiverEnv
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT

PLAN_NAME = "receiver-endpoint-cap-plan.json"
PLAN_SHA256 = "ec2092fd53d29a19148241e316b0b19c5dab60701fc8eb75e5548e27f5427064"
SETTINGS = {
    "base_5p2": ("base", 5.2),
    "tight_5p2": ("tight", 5.2),
    "base_6": ("base", 6.0),
    "tight_6": ("tight", 6.0),
}


class ArrivalCapAuditEnv(PhysicalAuditReceiverEnv):
    """Override the control cap before each sensor-driven route update."""

    def __init__(self, cap_m: float):
        super().__init__(DEFAULT_RUNTIME_ROOT)
        self.cap_m = cap_m

    def _sensor_sample(self) -> None:
        if self.follower is not None:
            self.follower.arrival_tolerance_m = self.cap_m
        super()._sensor_sample()


def snapshot(env, sensor: dict, horizon_s: float, score: dict) -> dict:
    rows = env.sampled_truth()
    full = bool(
        np.isclose(rows[-1, 0], horizon_s, rtol=0, atol=1e-7)
        and np.isfinite(rows).all()
        and np.allclose(rows[:, 0], CONTROL_DT * np.arange(1, len(rows) + 1), rtol=0, atol=1e-7)
    )
    physical = env.physical_summary()
    route = route_result(env.route, rows, score, full)
    ordered = route["endpoint_reached"] and physical["min_upright_cosine"] >= score["minimum_upright_cosine"]
    retained = full and physical["retained_sim_support_2s"]
    return {
        **physical,
        "elapsed_s": float(rows[-1, 0]),
        "full_horizon": full,
        "ordered_waypoint_hit_s": route["ordered_waypoint_hit_s"],
        "endpoint_tolerance_m": route["endpoint_tolerance_m"],
        "internal_waypoints_acknowledged": env.follower.next_waypoint - 1,
        "ordered_route_complete": ordered,
        "physical_support_2s": retained,
        "route_and_retention": ordered and retained,
        "visual_retention": sensor["retained_visual_proxy"],
    }


def evaluate(model, trial, seed: int, cap_m: float, horizons: list[float], score: dict) -> dict:
    env = ArrivalCapAuditEnv(cap_m)
    try:
        observation, _ = env.reset(seed=seed, options={"trial": trial})
        milestones = {round(horizon * POLICY_HZ): horizon for horizon in horizons}
        outcomes = {}
        for step in range(1, max(milestones) + 1):
            action, _ = model.predict(observation, deterministic=True)
            action[:3] = route_action(env)
            observation, _, terminated, _, sensor = env.step(action)
            if step in milestones:
                horizon = milestones[step]
                outcomes[horizon] = snapshot(env, sensor, horizon, score)
            if terminated:
                break
        for horizon in horizons:
            if horizon not in outcomes:
                outcomes[horizon] = snapshot(env, sensor, horizon, score)
        return outcomes
    finally:
        env.close()


def counts(rows: list[dict]) -> dict:
    return {
        "cases": len(rows),
        "full_horizon": sum(row["full_horizon"] for row in rows),
        "ordered_route_complete": sum(row["ordered_route_complete"] for row in rows),
        "physical_support_2s": sum(row["physical_support_2s"] for row in rows),
        "route_and_retention": sum(row["route_and_retention"] for row in rows),
        "visual_retention": sum(row["visual_retention"] for row in rows),
        "median_endpoint_error_m": median(row["final_route_endpoint_error_m"] for row in rows),
    }


def summarize(rows: list[dict]) -> dict:
    return {
        "all": counts(rows),
        "by_route": {route: counts([row for row in rows if row["route"] == route]) for route in ("go", "slant")},
    }


def advances(candidate: dict, base: dict) -> bool:
    a, b = candidate["all"], base["all"]
    return (
        a["full_horizon"] == b["full_horizon"] == a["cases"] == b["cases"]
        and a["route_and_retention"] > b["route_and_retention"]
        and a["physical_support_2s"] >= b["physical_support_2s"]
        and all(
            candidate["by_route"][route]["route_and_retention"] >= base["by_route"][route]["route_and_retention"]
            for route in ("go", "slant")
        )
    )


def select(summary: dict) -> tuple[str, str] | None:
    if advances(summary["tight_5p2"], summary["base_5p2"]):
        return "tight_5p2", "base_5p2"
    if advances(summary["tight_6"], summary["base_6"]) and advances(summary["tight_6"], summary["base_5p2"]):
        return "tight_6", "base_6"
    if advances(summary["base_6"], summary["base_5p2"]):
        return "base_6", "base_5p2"
    return None


def check_historical_parity(current: list[dict], previous: list[dict]) -> dict:
    keys = (
        "ordered_route_complete", "retained_sim_support_2s", "route_and_retention",
        "visual_retention", "continuous_final_support_s", "final_route_endpoint_error_m",
    )
    differing = [
        row["case"] for row, original in zip(current, previous, strict=True)
        if any(not np.isclose(row[key], original[key], rtol=0, atol=1e-8) for key in keys)
    ]
    return {"all_compared_fields_match": not differing, "different_cases": differing}


def reserved_cases(plan: dict, reports: Path, original_trials: list[dict]) -> list[dict]:
    cases, _ = build_cases(plan, reports, original_trials)
    previous = reports / "receiver-extended-paired-cases.json"
    require_digest(previous, plan["prior_extended_cases_sha256"])
    older = read_json(previous)["fixtures"]
    old_releases = {release_key(fixture) for fixture in older}
    old_scales = {(fixture["route"], fixture["route_scale"]) for fixture in older}
    if any(
        release_key(fixture) in old_releases or (fixture["route"], fixture["route_scale"]) in old_scales
        for fixture in plan["fixtures"]
    ):
        raise ValueError("reserved test repeats a prior extended release or route geometry")
    return cases


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reports", type=Path, default=ROOT / "reports")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--development-report", type=Path, help="Run the reserved confirmation after a qualifying development result.")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists")

    plan_path = args.reports / PLAN_NAME
    require_digest(plan_path, PLAN_SHA256)
    plan = read_json(plan_path)
    require_digest(Path(__file__).with_name("compare_receiver_route_control.py"), plan["shared_comparison_script_sha256"])
    historical_path = args.reports / "receiver-route-control-extended.json"
    require_digest(historical_path, plan["prior_development_report_sha256"])
    historical = read_json(historical_path)
    run, config, provenance = verify_recovery(args.reports)
    if POLICY_HZ != plan["policy_hz"]:
        raise ValueError("unexpected policy cadence")
    checkpoint = run / provenance["checkpoints"]["ppo_12288"]["filename"]
    require_digest(checkpoint, plan["checkpoint_sha256"])
    reserved = reserved_cases(plan, args.reports, config["heldout"])

    script_sha = digest(Path(__file__))
    confirmation = None
    if args.development_report is None:
        cases = [
            {"case": f"development-{index}", "seed": plan["development_sensor_seed_base"] + index, "trial": ReceiverTrial(**trial)}
            for index, trial in enumerate(historical["trials"])
        ]
        settings = SETTINGS
    else:
        development = read_json(args.development_report)
        if development["plan_sha256"] != PLAN_SHA256 or development["audit_script_sha256"] != script_sha:
            raise ValueError("development result was generated with a different plan or evaluator")
        selection = select(development["summary"])
        if selection is None:
            parser.exit(2, "No development configuration passed the predeclared advancement gate.\n")
        cases = reserved
        settings = {name: SETTINGS[name] for name in selection}
        confirmation = {"candidate": selection[0], "reference": selection[1], "development_report_sha256": digest(args.development_report)}

    torch.set_num_threads(1)
    model = PPO.load(checkpoint, device="cpu")
    if model.num_timesteps != 12288:
        raise ValueError("unexpected checkpoint step count")
    rows = {setting: [] for setting in settings}
    for cap_name, cap_m in plan["caps_m"].items():
        horizons = sorted({horizon for cap, horizon in settings.values() if cap == cap_name})
        if not horizons:
            continue
        for case in cases:
            trial = case["trial"]
            outcomes = evaluate(model, trial, case["seed"], cap_m, horizons, plan["score"])
            for setting, (cap, horizon) in settings.items():
                if cap == cap_name:
                    result = outcomes[horizon]
                    rows[setting].append({
                        **result, "case": case["case"], "seed": case["seed"],
                        "route": trial.route, "profile": trial.suite,
                    })
                    print(
                        setting, case["case"], result["ordered_route_complete"],
                        result["physical_support_2s"], result["route_and_retention"], flush=True,
                    )

    summary = {setting: summarize(results) for setting, results in rows.items()}
    report = {
        "evidence_class": "paired_endpoint_cap_confirmation" if confirmation else "paired_endpoint_cap_development",
        "plan_sha256": PLAN_SHA256,
        "audit_script_sha256": script_sha,
        "checkpoint_sha256": plan["checkpoint_sha256"],
        "run_manifest_sha256": provenance["run_manifest_sha256"],
        "shared_comparison_script_sha256": plan["shared_comparison_script_sha256"],
        "mujoco_gl": os.environ.get("MUJOCO_GL"),
        "summary": summary,
        "rollouts": rows,
    }
    if confirmation:
        confirmation["passed_gate"] = advances(summary[confirmation["candidate"]], summary[confirmation["reference"]])
        report["confirmation"] = confirmation
    else:
        report["selected_for_confirmation"] = select(summary)
        report["historical_base_5p2_parity"] = check_historical_parity(rows["base_5p2"], historical["results"]["route_follower"])
    with args.output.open("x") as stream:
        json.dump(report, stream, separators=(",", ":"), allow_nan=False)
        stream.write("\n")
    print(f"Wrote {args.output}", flush=True)


if __name__ == "__main__":
    main()
