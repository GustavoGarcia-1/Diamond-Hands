"""Verify five hand-supported route trials and package their runnable source."""

from __future__ import annotations

import argparse
from hashlib import sha256
import json
from pathlib import Path
import xml.etree.ElementTree as ET
from zipfile import ZIP_DEFLATED, ZipFile

from package_demo import ROOT, VENDOR
from g1_receiver.dextra import UPSTREAM_URDF, import_dextra_urdf

RUNS = {
    "go-slant": ("go", "slant"),
    "out-hitch": ("out", "hitch"),
    "post": ("post",),
}
PLAYBOOK_FILES = (
    "pyproject.toml", "uv.lock", "docs/hand-equipped-playbook.md", "docs/dextra-integration.md",
    "scripts/audit_dextra_catch_and_carry.py", "scripts/audit_receiver_all_routes.py",
    "scripts/audit_receiver_walk_terminal_cap.py", "scripts/audit_receiver_checkpoints.py",
    "scripts/probe_g1_dextra.py", "scripts/export_dextra_model.py",
    "reports/dextra-g1-articulated-smoke.json",
)


def collect_reports():
    rows, configs, evidence = {}, [], {}
    for name, routes in RUNS.items():
        report_name = f"reports/dextra-route-reviewed-{name}.json"
        path = ROOT / report_name
        data = json.loads(path.read_text())
        configs.append({key: value for key, value in data.items() if key != "results"})
        evidence[report_name] = sha256(path.read_bytes()).hexdigest()
        if {result["route"] for result in data["results"]} != set(routes):
            raise ValueError(f"route set differs in {name}")
        for result in data["results"]:
            contact = result["contact"]
            if (not result["hand_catch_and_route"] or not contact["hands_only_catch"]
                    or not contact["physics_clock_ok"] or contact["ball_floor_contact"]):
                raise ValueError(f"{result['route']} failed the combined gate")
            rows[result["route"]] = result
    if len(rows) != 5 or any(config != configs[0] for config in configs):
        raise ValueError("requires five routes using one controller configuration")
    return {
        "evidence_class": "articulated_hand_controlled_catch_then_carry",
        "passed": len(rows), "trials": len(rows), "configuration": configs[0],
        "source_reports_sha256": evidence, "results": rows,
    }


def package(source: Path, output: Path, report_path: Path):
    urdf = source / UPSTREAM_URDF
    import_dextra_urdf(urdf)
    report = collect_reports()
    assets = {ROOT / name: name for name in PLAYBOOK_FILES}
    assets.update({path: path.relative_to(ROOT).as_posix() for path in (ROOT / "src").rglob("*.py")
                   if "__pycache__" not in path.parts})
    assets.update({ROOT / name: name for name in report["source_reports_sha256"]})
    assets.update({ROOT / VENDOR / name: (VENDOR / name).as_posix()
                   for name in ("ASSET-MANIFEST.json", "NOTICE.txt")})
    manifest = json.loads((ROOT / VENDOR / "ASSET-MANIFEST.json").read_text())
    for row in manifest["files"]:
        relative = VENDOR / row["path"]
        full = ROOT / relative
        if sha256(full.read_bytes()).hexdigest() != row["sha256"]:
            raise ValueError(f"asset provenance differs: {relative}")
        assets[full] = relative.as_posix()
    meshes = {element.attrib["filename"] for element in ET.parse(urdf).getroot().findall(".//mesh")}
    for relative in (Path("LICENSE"), UPSTREAM_URDF, *(UPSTREAM_URDF.parent / mesh for mesh in meshes)):
        path = source / relative
        if not path.resolve().is_relative_to(source.resolve()):
            raise ValueError("Dextra asset must resolve inside the pinned checkout")
        assets[path] = "dextra-source/" + relative.as_posix()
    for group, routes in RUNS.items():
        for route in routes:
            folder = ROOT / "reports/dextra-route-videos" / group
            folder = folder / route if len(routes) > 1 else folder
            assets[folder / "replay.mp4"] = f"videos/{route}.mp4"

    readme = b"# Articulated G1 football playbook\n\nSee [reproduction and assumptions](docs/hand-equipped-playbook.md).\n"
    result_bytes = (json.dumps(report, indent=2, allow_nan=False) + "\n").encode()
    checksums = {}
    with ZipFile(output, "x", compression=ZIP_DEFLATED, compresslevel=6) as archive:
        for path, name in sorted(assets.items(), key=lambda item: item[1]):
            if path.is_symlink() or not path.is_file():
                raise ValueError(f"missing or unsafe package file: {path}")
            data = path.read_bytes()
            checksums[name] = sha256(data).hexdigest()
            archive.writestr(name, data)
        for name, data in (("README.md", readme), ("reports/dextra-playbook.json", result_bytes)):
            checksums[name] = sha256(data).hexdigest()
            archive.writestr(name, data)
        archive.writestr("MANIFEST.json", json.dumps(checksums, indent=2) + "\n")
    with ZipFile(output) as archive:
        if archive.testzip() is not None or any(
            sha256(archive.read(name)).hexdigest() != digest for name, digest in checksums.items()
        ):
            raise ValueError("archive verification failed")
    with report_path.open("xb") as stream:
        stream.write(result_bytes)
    return {"archive": str(output), "bytes": output.stat().st_size, "sha256": sha256(output.read_bytes()).hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--codesign-source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists() or args.report.exists():
        parser.error("output and report must be new")
    print(json.dumps(package(args.codesign_source, args.output, args.report), indent=2))


if __name__ == "__main__":
    main()
