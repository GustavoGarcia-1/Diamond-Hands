"""Fixed two-yard formation: move arrival inside the existing hand aperture."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys

p = argparse.ArgumentParser()
p.add_argument('--output', type=Path, required=True)
p.add_argument('--source', required=True)
p.add_argument('--amp-source', required=True)
a = p.parse_args()
a.output.mkdir(parents=True, exist_ok=False)
cases = [(flight, dy, dz) for flight in (1.2, 1.4, 1.6)
         for dy in (-.12, -.06, 0.) for dz in (0., .04)]
(a.output / 'protocol.json').write_text(json.dumps({
    'formation': 'receiver two yards beside fixed midfield machine, same LOS',
    'held_fixed': ['locomotion', 'hand controller', 'camera surveys', 'catch window', 'launch-aligned football'],
    'selection': 'existing >=150ms clean bilateral and <=1m/s horizontal relative speed; running reported separately',
    'changes': 'flight time and physical throw target Y/Z only; no applied ball loads after release',
    'cases': cases}, indent=2) + '\n')

def run(item):
    index, (flight, dy, dz) = item
    profile = json.loads(Path(f'reports/aero-rl-20261113/slot-flight-{flight:.1f}.json').read_text())
    profile['play']['quarterback_target_m'][1] += dy
    profile['play']['quarterback_target_m'][2] += dz
    spec = a.output / f'profile-{index:02d}.json'
    spec.write_text(json.dumps(profile, indent=2) + '\n')
    out = a.output / f'case-{index:02d}'
    command = [sys.executable, 'scripts/probe_go_stem.py', '--reference', str(spec),
               '--source', a.source, '--amp-source', a.amp_source,
               '--output', str(out), '--duration', '7', '--record-poses']
    with (a.output / f'case-{index:02d}.log').open('w') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=300)
    score_path = out / 'stem-score.json'
    return dict(case=index, flight_s=flight, target_dy_m=dy, target_dz_m=dz,
                command=command, exit_code=result.returncode,
                score=json.loads(score_path.read_text()) if score_path.exists() else None)

results = []
with ThreadPoolExecutor(max_workers=3) as pool:
    for result in pool.map(run, enumerate(cases)):
        results.append(result)
        (a.output / 'summary.json').write_text(json.dumps(results, indent=2) + '\n')
if any(result['exit_code'] for result in results):
    raise SystemExit(1)
