"""Export and reload a portable MuJoCo scene with the two articulated hands."""

from __future__ import annotations

import argparse
from hashlib import sha256
import json
from pathlib import Path
from shutil import copy2
import xml.etree.ElementTree as ET
from zipfile import ZIP_DEFLATED, ZipFile

import mujoco
import numpy as np

from g1_receiver.dextra import UPSTREAM_REVISION, UPSTREAM_URDF_SHA256, DextraActuation, make_dextra_scene
from g1_receiver.hand_route_plant import HandRoutePlant
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT


def export(source: Path, output: Path):
    output.mkdir(parents=True, exist_ok=False)
    xml = ET.fromstring(make_dextra_scene(DEFAULT_RUNTIME_ROOT, source))
    compiler = xml.find("compiler")
    original_mesh_dir = Path(compiler.attrib.pop("meshdir"))
    for mesh in xml.findall("./asset/mesh"):
        location = Path(mesh.attrib["file"])
        folder = "dextra" if location.is_absolute() else "g1"
        input_file = location if location.is_absolute() else original_mesh_dir / location
        relative = Path("meshes") / folder / input_file.name
        destination = output / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            if destination.read_bytes() != input_file.read_bytes():
                raise ValueError(f"mesh filename collision: {relative}")
        else:
            copy2(input_file, destination)
        mesh.set("file", relative.as_posix())
    licenses = output / "licenses"
    licenses.mkdir()
    for file in ("CODE-LICENSE.txt", "WEIGHTS-LICENSE.txt"):
        copy2(DEFAULT_RUNTIME_ROOT / "assets/upstream" / file, licenses / ("NVIDIA-" + file))
    copy2(DEFAULT_RUNTIME_ROOT / "NOTICE.txt", licenses / "G1-NOTICE.txt")
    copy2(source / "LICENSE", licenses / "Dextra-LICENSE.txt")
    scene = output / "scene.xml"
    tree = ET.ElementTree(xml)
    tree.write(scene, encoding="unicode")
    model = mujoco.MjModel.from_xml_path(str(scene))
    actuation = DextraActuation.from_model(model)
    plant = HandRoutePlant(source)
    plant.reset()
    if plant.model.nq != model.nq or model.nu != 69:
        raise ValueError("export layout differs from the tested model")
    keyframes = xml.find("keyframe")
    if keyframes is None:
        keyframes = ET.SubElement(xml, "keyframe")
    ET.SubElement(keyframes, "key", name="stand", qpos=" ".join(map(str, plant.data.qpos)),
                  ctrl=" ".join(map(str, np.zeros(model.nu))))
    ET.indent(xml)
    tree.write(scene, encoding="unicode")
    model = mujoco.MjModel.from_xml_path(str(scene))
    if model.key("stand").id < 0:
        raise ValueError("exported scene lacks its stand keyframe")
    receipt = {
        "evidence_class": "portable_articulated_simulation_model",
        "dextra_revision": UPSTREAM_REVISION, "dextra_urdf_sha256": UPSTREAM_URDF_SHA256,
        "actuators": {"g1_body": len(actuation.body_actuators), "dextra_hands": len(actuation.hand_actuators)},
        "limitations": ["Estimated mounts and inertia", "Scene and actuators; a controller is required for balance"],
        "files_sha256": {file.relative_to(output).as_posix(): sha256(file.read_bytes()).hexdigest()
                         for file in sorted(output.rglob("*")) if file.is_file()},
    }
    (output / "manifest.json").write_text(json.dumps(receipt, indent=2) + "\n")
    bundle = output.with_suffix(".zip")
    with ZipFile(bundle, "x", compression=ZIP_DEFLATED, compresslevel=6) as archive:
        for file in sorted(output.rglob("*")):
            if file.is_file():
                archive.write(file, file.relative_to(output))
    with ZipFile(bundle) as archive:
        if archive.testzip() is not None:
            raise ValueError("bad ZIP member")
    return {"scene": str(scene), "archive": str(bundle), "files": len(receipt["files_sha256"]),
            "archive_sha256": sha256(bundle.read_bytes()).hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--codesign-source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(export(args.codesign_source, args.output), indent=2))


if __name__ == "__main__":
    main()
