"""Offline surveyed-camera audit of archived poses. Never actor/critic input or a rollout."""
from pathlib import Path
import argparse,json
import numpy as np
import mujoco
from evaluate_aero_receiver import fixed_camera
from evaluate_dextra_in_stride import RearMarkerLocalizer
from g1_receiver.hand_route_plant import HandRoutePlant
from g1_receiver.perception import ColorBallDetector

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=Path,required=True);p.add_argument('--view',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--far-x',type=float,default=10.);p.add_argument('--times',type=float,nargs='+',default=(6.4,7.2,8.4,9.48));a=p.parse_args();surveys={}
 def setup(scene):
  for tag,x in [('near',8.),('far',a.far_x)]:
   for kind,z,tz in [('ball',2.4,1.5),('pose',1.5,.8)]:
    name=tag+'_'+kind;surveys[name]=fixed_camera(scene,name,(x,1,z),(11 if tag=='near' else 12,-1.5 if tag=='near' else -2,tz))
 plant=HandRoutePlant(a.source,hand_model='aero',rear_markers=True,scene_setup=setup);plant.cameras.update(surveys);backdrop=plant.model.geom('backdrop').id;plant.model.geom_rgba[backdrop,3]=0.;plant.model.geom_group[backdrop]=5;v=np.load(a.view);detector=ColorBallDetector(max_depth_m=20.,ball_center_offset_m=.075);tracker=RearMarkerLocalizer(allow_synthetic_fixture=True,max_range_m=8.);rows=[]
 try:
  for wanted in a.times:
   i=int(np.argmin(abs(v['timestamps_s']-wanted)));now=float(v['timestamps_s'][i]);plant.data.qpos[:]=v['qpos'][i];plant.data.time=now;mujoco.mj_forward(plant.model,plant.data);q,dq,imu,gyro=plant.observe();w,x,y,z=imu;yaw=np.arctan2(2*(w*z+x*y),1-2*(y*y+z*z));c,s=np.cos(yaw),np.sin(yaw);Y=np.array([[c,s,0],[-s,c,0],[0,0,1]])
   estimates={}
   for name in surveys:
    frame,survey=plant.capture(name);ball=detector.detect(frame,survey);pose=tracker.estimate(frame,survey);estimates[name]=(ball,pose)
   for label in ('near','far'):
    ball=estimates[label+'_ball'][0];candidates=[(name,estimates[name][1])for name in (label+'_ball',label+'_pose')if estimates[name][1]is not None and estimates[name][1].z_std_m is not None];chosen=min(candidates,key=lambda v:float(np.trace(np.array(v[1].covariance)[:2,:2]))+v[1].z_std_m**2)if candidates else(None,None);pose=chosen[1];out=dict(time_s=now,view=label,ball_detected=ball is not None,pose_detected=pose is not None,selected_pose_camera=chosen[0])
    if ball is not None and pose is not None and pose.z_std_m is not None:
     cov=np.array(ball.covariance_m2);cov[:2,:2]+=np.array(pose.covariance)[:2,:2];cov[2,2]+=pose.z_std_m**2;cov=Y@cov@Y.T+np.eye(3)*.01**2;sigma=np.sqrt(np.diag(cov));out.update(sigma_body_m=sigma.tolist(),passes_unchanged60mm_gate=bool(sigma.max()<=.06),ball_position_m=ball.position_m.tolist(),pose_z_m=pose.z_m)
    rows.append(out)
 finally:plant.close()
 a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(dict(mode='offline archivedpose replay only, no control or training data',near_position_xy_m=[8,1],far_position_xy_m=[a.far_x,1],rows=rows),indent=2)+'\n');print(json.dumps(rows))
if __name__=='__main__':main()
