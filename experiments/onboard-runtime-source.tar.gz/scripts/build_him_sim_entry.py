"""Build the source ZIP and real MuJoCo replay MP4 for a reviewed Arena upload."""

from __future__ import annotations

import argparse
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import imageio.v2 as imageio
import numpy as np
from PIL import Image, ImageDraw

from package_demo import ROOT, VENDOR

REPORTS = (
    "receiver-hybrid-slant-replay/report.json", "receiver-hybrid-go-replay/report.json",
    "receiver-extended-paired-audit.json", "receiver-extended-paired-cases.json",
    "receiver-route-control-extended.json",
    "receiver-him-plant-localization-hold.json", "receiver-him-handoff.json",
    "receiver-him-safety-catch-diagnostic.json", "receiver-him-safety-catch-relative-start.json",
    "receiver-him-safety-catch-low-camera.json",
    "antioch-final-uniform173/run/manifest.json", "antioch-final-uniform173/run/ppo-000012288.zip",
)
REPLAYS = ("receiver-hybrid-slant-replay", "receiver-hybrid-go-replay")


def make_source(archive: Path) -> None:
    paths = {Path(name) for name in (
        "pyproject.toml", "uv.lock",
        "docs/him-open-build.md", "docs/SENSOR_CONTRACT.md", "docs/hardware-qualification.md",
        "docs/him-runner-integration.md",
        "scripts/compare_receiver_route_control.py",
    )}
    paths.update(Path("reports") / name for name in REPORTS)
    paths.update(path.relative_to(ROOT) for path in (ROOT / "src").rglob("*.py"))
    paths.update((VENDOR / "ASSET-MANIFEST.json", VENDOR / "NOTICE.txt"))
    vendor = json.loads((ROOT / VENDOR / "ASSET-MANIFEST.json").read_text())
    for item in vendor["files"]:
        path = VENDOR / item["path"]
        if sha256((ROOT / path).read_bytes()).hexdigest() != item["sha256"]:
            raise ValueError(f"runtime asset hash mismatch: {path}")
        paths.add(path)
    readme = (
        "# G1 Football Receiver\n\n"
        "Simulation entry for HIM Open Build. See [entry details and reproduction]"
        "(docs/him-open-build.md), [sensor inputs](docs/SENSOR_CONTRACT.md), and "
        "[runner evidence](docs/him-runner-integration.md).\n"
    ).encode()
    manifest = {"README.md": sha256(readme).hexdigest()}
    with ZipFile(archive, "x", compression=ZIP_DEFLATED) as output:
        output.writestr("g1-receiver/README.md", readme)
        for path in sorted(paths):
            full_path = ROOT / path
            if (full_path.is_symlink() or not full_path.resolve().is_relative_to(ROOT)
                    or "__pycache__" in path.parts):
                raise ValueError(f"unsafe package path: {path}")
            data = full_path.read_bytes()
            manifest[str(path)] = sha256(data).hexdigest()
            entry = ZipInfo("g1-receiver/" + str(path), date_time=(1980, 1, 1, 0, 0, 0))
            entry.compress_type = ZIP_DEFLATED
            output.writestr(entry, data)
        output.writestr("g1-receiver/MANIFEST.json", json.dumps(manifest, indent=2) + "\n")
    with ZipFile(archive) as output:
        if output.testzip() is not None:
            raise ValueError("ZIP integrity check failed")
        for path, expected in manifest.items():
            if sha256(output.read("g1-receiver/" + path)).hexdigest() != expected:
                raise ValueError(f"packaged file hash mismatch: {path}")


def card(lines) -> np.ndarray:
    canvas = Image.new("RGB", (1280, 440), "#121a23")
    draw = ImageDraw.Draw(canvas)
    draw.rectangle((65, 85, 73, 357), fill="#bbdf78")
    for index, line in enumerate(lines):
        draw.text((112, 122 + index * 68), line, fill="white", font_size=31 if index else 48)
    return np.asarray(canvas)


def make_video(output: Path) -> None:
    intro = card(("G1 Football Receiver", "Catch, cut, and finish a short route",
                  "MuJoCo simulation / RGB-D, encoders and IMU"))
    results = card(("14 of 18 paired tests",
                    "Vision route following + PPO arms: finish and retain",
                    "Six new throws crossed with three camera conditions"))
    with imageio.get_writer(output, fps=25, codec="libx264", macro_block_size=1) as writer:
        for _ in range(44):
            writer.append_data(intro)
        for replay in REPLAYS:
            with imageio.get_reader(ROOT / "reports" / replay / "replay.mp4") as source:
                if abs(source.get_meta_data()["fps"] - 25.) > .01:
                    raise ValueError("replay frame rate differs from 25 Hz")
                for frame in source:
                    if frame.shape != (440, 1280, 3):
                        raise ValueError("unexpected recorded frame dimensions")
                    writer.append_data(frame)
        for _ in range(57):
            writer.append_data(results)
    with imageio.get_reader(output) as verified:
        if verified.count_frames() <= 101:
            raise ValueError("no decoded simulation frames in submission video")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    archive = args.output / "g1-football-receiver.zip"
    video = args.output / "g1-football-receiver.mp4"
    make_source(archive)
    make_video(video)
    total = archive.stat().st_size + video.stat().st_size
    if total >= 100_000_000 or video.stat().st_size > 50_000_000:
        raise ValueError("entry exceeds the Arena upload limit")
    receipt = {
        "kind": "simulation",
        "robot": "Unitree G1",
        "simulator": "MuJoCo",
        "challenge": "Open Build",
        "files": {path.name: {"bytes": path.stat().st_size, "sha256": sha256(path.read_bytes()).hexdigest()}
                  for path in (archive, video)},
        "combined_bytes": total,
    }
    (args.output / "entry-files.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
