"""Recompute catch, running, and pass results from an archived Aero trace."""

import argparse
from hashlib import sha256
import json
from pathlib import Path

import numpy as np

from g1_receiver.dextra_physical_eval import TRACE_COLUMNS
from g1_receiver.in_stride_eval import MOTION_COLUMNS, score_in_stride_catch
from g1_receiver.routes import Route
from g1_receiver.running_catch_eval import RunningCatchCriteria, score_running_long_pass
from g1_receiver.throw_eval import score_throw_receive


def rescore(directory):
    report = json.loads((directory / "report.json").read_text())
    path = directory / "trace.npz"
    if sha256(path.read_bytes()).hexdigest() != report["trace_sha256"]:
        raise ValueError("contact and gait trace do not match the report digest")
    play = report["play"]
    route = Route(play["route"], tuple(map(tuple, report["waypoints_m"])), play["speed"])
    release_s = report["release"]["release_time_s"] if report["release"] else None
    with np.load(path, allow_pickle=False) as trace:
        if tuple(trace["contact_columns"]) != TRACE_COLUMNS or tuple(trace["motion_columns"]) != MOTION_COLUMNS:
            raise ValueError("unexpected trace columns")
        contact, motion = trace["contact"], trace["motion"]
        strict = score_in_stride_catch(
            contact, motion, route, release_time_s=release_s,
            finish_time_s=round(play["finish_s"] / .02) * .02,
            ball_weight_n=report["ball_weight_n"], verified_free_ball=True,
            physics_step_s=report["physics_step_s"], simulator_warning_count=report["warning_count"],
        )
        foot = {name: trace[name] for name in ("foot_time_s", "foot_floor_contact", "robot_floor_contact",
                                               "sole_clearance_m")}
        forward = np.subtract(route.waypoints[1], route.waypoints[0])
        forward = forward / np.linalg.norm(forward)
        recorded_criteria = report["running_score"]["criteria"]
        archived_before_stance_tolerance = "min_ground_fraction" not in recorded_criteria
        gate = RunningCatchCriteria(**({"min_ground_fraction": 1.} | recorded_criteria))
        running = score_running_long_pass(
            contact, motion, **foot, strict_catch_score=strict, release_time_s=release_s,
            gait_start_s=play["settle_s"],
            forward_xy=forward, pass_toward_receiver_xy=-forward if play.get("allow_downfield_lob") else None,
            criteria=gate,
        )
        if archived_before_stance_tolerance:
            del running["criteria"]["min_ground_fraction"]
        quarterback_pass = None
        if "quarterback_pass_score" in report:
            quarterback_pass = score_throw_receive(
                contact, motion, report["release"], strict["first_tip_contact_s"],
                physics_step_s=report["physics_step_s"])
    if strict != report["strict_score"] or running != report["running_score"]:
        raise ValueError("archived score differs from the recomputed result")
    if quarterback_pass != report.get("quarterback_pass_score"):
        raise ValueError("archived quarterback score differs from the recomputed result")
    result = {"strict_score": strict, "running_score": running}
    if quarterback_pass is not None:
        result["quarterback_pass_score"] = quarterback_pass
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    summary = rescore(args.directory)
    if args.output:
        with args.output.open("x") as stream:
            json.dump(summary, stream, indent=2, allow_nan=False)
            stream.write("\n")
    else:
        print(json.dumps(summary, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
