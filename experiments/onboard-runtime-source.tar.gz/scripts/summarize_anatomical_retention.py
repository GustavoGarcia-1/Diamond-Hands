"""Supplemental posthoc finger-link retention; predeclared tip/palm score unchanged.

DextraContactAudit's other_hand bucket consists of palm-descended digit bodies.
Wrist/mount/arm geoms are OTHER and remain forbidden support. This diagnostic
adds real proximal/middle/thumb links rather than silently relaxing force gates.
It never enters runtime control, training observation, critic, or reward.
"""
from pathlib import Path
import argparse,json
import numpy as np

def summarize(trial):
 a=np.load(trial/'trace.npz');c=a['contact'];m=a['motion'];dt=float(json.loads((trial/'report.json').read_text()).get('physics_step_s',.001));left=c[:,6:9].sum(1);right=c[:,9:12].sum(1);bilateral=(left>=.1)&(right>=.1);bad=(c[:,4]!=0)|(c[:,5]>1e-9)|(c[:,12:15].max(1)>1e-9);first=np.flatnonzero(bad);cutoff=int(first[0])if len(first)else len(c);clean=bilateral.copy();clean[cutoff:]=False;ee=np.flatnonzero(np.diff(np.r_[False,clean,False]));bands=[dict(start_s=float(c[b,0]),end_s=float(c[e-1,0]+dt),duration_s=float(c[e-1,0]-c[b,0]+dt))for b,e in zip(ee[::2],ee[1::2])];longest=max((r['duration_s']for r in bands),default=0.);end=c[:,0]>=c[-1,0]-2.;mask=bilateral[end];gaps=np.flatnonzero(np.diff(np.r_[False,~mask,False]));gap=max((float((e-b)*dt)for b,e in zip(gaps[::2],gaps[1::2])),default=0.);vertical=c[end,15:21].sum(1);weight=.42*9.81;fraction=float(mask.mean());meanweight=float(vertical.mean()/weight);finalgate=bool(fraction>=.85 and gap<=.1 and meanweight>=.8 and bilateral[-1]and not bad.any());pelvis=np.column_stack([np.interp(c[:,0],m[:,0],m[:,i])for i in (1,2,3)]);relative=c[:,1:4]-pelvis;velocity=np.gradient(relative,c[:,0],axis=0)
 return dict(schema='supplemental-native-digit-link-retention-v1',region_scope='tips+palms+allpalm-descendeddigitlinks; excludeswrist/mount/arms/body/floor',old_tip_palm_criterion_unchanged=True,min_normal_per_hand_n=.1,first_nonhand_support_s=None if cutoff==len(c)else float(c[cutoff,0]),whole_episode_no_nonhand_support=bool(not bad.any()),longest_bilateral_all_finger_links_before_nonhand_support_s=longest,bands=bands,held750ms_clean_episode=bool(longest>=.75 and not bad.any()),final2s=dict(bilateral_fraction=fraction,max_gap_s=gap,mean_vertical_hand_load_ballweight=meanweight,bilateral_at_finish=bool(bilateral[-1]),passes=finalgate),last2s_relative_ball_to_pelvis_range_m=np.ptp(relative[end],axis=0).tolist(),last2s_mean_relative_ball_to_pelvis_speed_mps=float(np.linalg.norm(velocity[end],axis=1).mean()),last2s_mean_relative_ball_to_pelvis_horizontal_speed_mps=float(np.linalg.norm(velocity[end,:2],axis=1).mean()),last2s_mean_normal_by_region_n=c[end,6:12].mean(0).tolist(),minimum_upright_cosine=float(m[:,4].min()))
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--trial',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();r=summarize(a.trial);a.output.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
if __name__=='__main__':main()
