"""Repeat selected Go exactly and extend one second; no parameter selection."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--source',required=True);p.add_argument('--amp-source',required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
profile='reports/aero-rl-20261113/go-cup-pass-linux/artifacts/go/profile-07.json'
def run(pair):
    name,duration=pair
    command=[sys.executable,'scripts/probe_go_cup.py','--source',a.source,'--amp-source',a.amp_source,
             '--profile',profile,'--output',str(a.output/name),'--walk-speed','1',
             '--handoff-depth','1.3','--initial-yaw','-.7','--duration',str(duration)]
    with (a.output/(name+'.log')).open('w') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=300)
    return {'name':name,'duration':duration,'exit_code':result.returncode,'command':command}
with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,[('exact',11.88),('extended',12.88)]))
(a.output/'receipt.json').write_text(json.dumps({'purpose':'Exact repeat plus duration extension',
  'evaluation_correction':'Pass approach axis changed to -X per scorer convention; physics unchanged',
  'trials':results},indent=2)+'\n')
if any(r['exit_code'] for r in results):raise SystemExit(1)
