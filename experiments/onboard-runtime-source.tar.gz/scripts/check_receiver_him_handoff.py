"""Exercise the official safety runner in-process with the exported receiver."""

from __future__ import annotations

import argparse
from dataclasses import replace
from hashlib import sha256
import json
from pathlib import Path
import sys

import mujoco
import numpy as np

from g1_receiver.locomotion import SURVEY_CAMERA_FOV_Y_DEG, SURVEY_CAMERA_POSITION_M, SURVEY_CAMERA_TARGET_M
from g1_receiver.perception import CameraIntrinsics, RGBDFrame, RigidPose
from g1_receiver.receiver_deploy import NumpyReceiverActor, ReceiverController
from g1_receiver.routes import make_route
from g1_receiver.sim import HEIGHT, WIDTH


class RenderedCatch:
    """Reset the free football once at task start, then observe rendered RGB-D."""

    def __init__(self, plant, trial, route, camera_position):
        self.plant = plant
        self.trial = trial
        self.route = route
        self.ball = plant.model.joint("football_free")
        self.ball_geom = plant.model.geom("football_surface").id
        self.ball_body = plant.model.body("football").id
        self.renderer = mujoco.Renderer(plant.model, height=HEIGHT, width=WIDTH)
        focal = HEIGHT / (2 * np.tan(np.deg2rad(SURVEY_CAMERA_FOV_Y_DEG / 2)))
        self.intrinsics = CameraIntrinsics(focal, focal, (WIDTH - 1) / 2, (HEIGHT - 1) / 2)
        self.origin = np.asarray(camera_position, dtype=float)
        forward = np.asarray(SURVEY_CAMERA_TARGET_M) - self.origin
        forward /= np.linalg.norm(forward)
        right = np.cross(forward, (0., 0., 1.))
        right /= np.linalg.norm(right)
        down = np.cross(forward, right)
        self.rotation = np.column_stack((right, down, forward))
        camera = plant.model.camera("survey_rgbd")
        camera.pos[:] = self.origin
        mujoco.mju_mat2Quat(camera.quat, np.column_stack((right, -down, -forward)).ravel())
        mujoco.mj_forward(plant.model, plant.data)
        self.start = None
        self.result = None
        self.rows = []
        self.next_waypoint = 1
        self.camera_frames = 0
        self.localized_frames = 0
        self.ball_frames = 0
        self.peak_requested_speed_mps = 0.
        self.start_xy = None
        self.first_host_kp = None

    def reset_ball(self, position, velocity):
        position_index = self.ball.qposadr[0]
        velocity_index = self.ball.dofadr[0]
        self.plant.data.qpos[position_index:position_index + 7] = (*position, 1., 0., 0., 0.)
        self.plant.data.qvel[velocity_index:velocity_index + 6] = (*velocity, 0., 0., 0.)
        mujoco.mj_forward(self.plant.model, self.plant.data)

    def camera_frame(self, stamp):
        self.renderer.update_scene(self.plant.data, camera="survey_rgbd")
        rgb = self.renderer.render()
        self.renderer.enable_depth_rendering()
        try:
            depth = self.renderer.render()
        finally:
            self.renderer.disable_depth_rendering()
        frame = RGBDFrame(stamp, "camera_optical", rgb, depth, self.intrinsics)
        pose = RigidPose(stamp, "camera_optical", "field", self.rotation, self.origin, "synthetic_fixture")
        return frame, pose

    def capture(self, stamp, controller):
        controller.ingest_rgbd(*self.camera_frame(stamp), now_s=stamp)
        self.camera_frames += 1
        self.localized_frames += controller.observable.receiver is not None
        self.ball_frames += controller.observable.ball is not None

    def audit(self):
        plant = self.plant
        contacts = {
            c.geom2 if c.geom1 == self.ball_geom else c.geom1 for c in plant.data.contact
            if self.ball_geom in (c.geom1, c.geom2)
        }
        self.rows.append((bool(contacts & plant.robot_geoms), plant.floor in contacts))
        position = plant.data.xpos[plant.base, :2]
        if self.next_waypoint < len(self.route.waypoints):
            start, goal = np.array(self.route.waypoints[self.next_waypoint - 1:self.next_waypoint + 1])
            if np.linalg.norm(position - goal) <= min(.05, .1 * np.linalg.norm(goal - start)):
                self.next_waypoint += 1
        if len(self.rows) < 260:
            return
        errors = [i for i, (support, _) in enumerate(self.rows) if not support]
        duration = (len(self.rows) - (errors[-1] + 1 if errors else 0)) * plant.dt
        hit_floor = any(floor for _, floor in self.rows)
        endpoint = float(np.linalg.norm(position - self.route.waypoints[-1]))
        tolerance = min(.05, .1 * np.linalg.norm(np.subtract(*self.route.waypoints[-2:])))
        retained = duration >= 2. and not hit_floor and plant.data.xpos[self.ball_body, 2] > .70
        complete = self.next_waypoint == len(self.route.waypoints) and endpoint <= tolerance
        self.result = {
            "task_start_s": self.start, "duration_s": 5.2, "final_sampled_support_s": duration,
            "any_sampled_floor_contact": hit_floor, "endpoint_error_m": endpoint,
            "ordered_waypoints": self.next_waypoint - 1, "retained": bool(retained),
            "route_complete": bool(complete), "combined": bool(retained and complete),
            "camera_frames": self.camera_frames, "localized_frames": self.localized_frames,
            "ball_frames": self.ball_frames, "peak_requested_speed_mps": self.peak_requested_speed_mps,
            "start_xy_m": self.start_xy, "first_host_kp": self.first_host_kp,
        }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--kit", type=Path, required=True)
    parser.add_argument("--export", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--rendered-catch", action="store_true", help="start a synthetic camera task after handoff")
    parser.add_argument("--relative-start", action="store_true",
                        help="survey the task origin from the camera after handoff")
    parser.add_argument("--camera-position", type=float, nargs=3, default=SURVEY_CAMERA_POSITION_M,
                        metavar=("X", "Y", "Z"))
    args = parser.parse_args()
    if args.relative_start and not args.rendered_catch:
        parser.error("--relative-start requires --rendered-catch")
    if (not np.isfinite(args.camera_position).all()
            or np.linalg.norm(np.subtract(args.camera_position[:2], SURVEY_CAMERA_TARGET_M[:2])) < .1):
        parser.error("camera position must be finite and separate from its look-at target")
    kit = args.kit.resolve()
    manifest = json.loads((kit / "KIT_FILES.json").read_text())
    if any(sha256((kit / name).read_bytes()).hexdigest() != checksum for name, checksum in manifest.items()):
        raise ValueError("public builder kit files differ from their manifest")
    sys.path[:0] = [str(kit / "containers/sim"), str(kit / "robot_safety"),
                    str(kit / "packages/policy_safety/src")]
    from runner import Runner
    from robot_safety.thrash import ThrashConfig

    export = json.loads((args.export / "export.json").read_text())
    scene, actor_path = args.export / "environment/scene.xml", args.export / "actor.npz"
    for path, key in ((scene, "scene_sha256"), (actor_path, "actor_sha256")):
        if sha256(path.read_bytes()).hexdigest() != export[key]:
            raise ValueError(f"export hash mismatch: {path.name}")
    trial = export["trial"]
    runner = Runner(scene=scene, safety_checks=True, thrash_config=ThrashConfig(mode="enforce"))
    route = make_route(trial["route"], scale=trial["route_scale"], speed_mps=.30)
    controller = ReceiverController(
        NumpyReceiverActor(actor_path), route, allow_synthetic_fixture=args.rendered_catch)
    if runner.plant.joint_names != controller.wbc.names:
        raise ValueError("controller and runner joint order differ")
    session = runner.arm()
    zero = [0.] * 29
    catch = RenderedCatch(runner.plant, trial, route, args.camera_position) if args.rendered_catch else None
    try:
        if catch:
            catch.reset_ball((5., 3., .15), (0., 0., 0.))
        for index in range(3000):
            stamp = index * runner.plant.dt
            feedback = runner.feedback(stamp)
            if catch and feedback["control_ready"] and catch.start is None and index % 2 == 0:
                if stamp - feedback["policy_handoff_at_secs"] >= 1.2:
                    measured = controller.localizer.estimate(*catch.camera_frame(stamp)) if args.relative_start else None
                    if measured is not None or not args.relative_start:
                        offset = measured.xy_m if measured is not None else np.zeros(2)
                        catch.route = replace(route, waypoints=tuple(
                            tuple(np.asarray(point) + offset) for point in route.waypoints))
                        controller.route = catch.route
                        catch.start = stamp
                        catch.start_xy = runner.plant.data.xpos[runner.plant.base, :2].tolist()
                        controller.reset()
                        catch.reset_ball(np.asarray(trial["release_position_m"]) + np.r_[offset, 0.],
                                         trial["release_velocity_mps"])
            if catch and catch.start is not None and catch.result is None and index % 2 == 0:
                catch.capture(stamp, controller)
            command = controller.tick(stamp, (feedback["q"], feedback["dq"], feedback["quat"], feedback["gyro"]))
            if catch is None and (controller.drive.any() or not np.allclose(controller.upper, controller.wbc.nominal)):
                raise ValueError("missing camera allowed task motion")
            packet = {
                "session_id": session, "sequence": index, "observation_id": feedback["observation_id"],
                "q": feedback["q"] if index == 0 else command.target_position.tolist(),
                "dq": zero, "kp": command.kp.tolist(), "kd": command.kd.tolist(), "tau": zero,
            }
            if runner.command(packet, stamp) is not None:
                break
            runner.step(stamp)
            if catch and catch.start is not None and catch.result is None:
                catch.peak_requested_speed_mps = max(catch.peak_requested_speed_mps,
                                                     float(np.linalg.norm(controller.drive[:2])))
                if catch.first_host_kp is None and runner.active is not None:
                    catch.first_host_kp = runner.active["kp"].tolist()
                catch.audit()
            if runner.reason is not None:
                break
    finally:
        if catch:
            catch.renderer.close()
    report = runner.report()
    report.update(
        evidence_class="host_direct_him_safety_runner",
        kit_revision=json.loads((kit / "arena/release.json").read_text())["revision"],
        catch=catch.result if catch else None,
        task_origin="measured_camera_xy" if args.relative_start else "configured_field_xy",
        camera_position_m=args.camera_position if catch else None,
        limitations=["In-process runner, no ROS or container transport",
                     "Synthetic RGB-D with free-ball initialization at task start" if catch else "No camera, no catch attempt",
                     "Simulated monotonic clock, no wall-time deadline validation"],
    )
    with args.output.open("x") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({key: report[key] for key in (
        "status", "reason", "detail", "seconds", "commands", "policy_handoff_at_secs", "control_ready", "catch",
    )}, indent=2))


if __name__ == "__main__":
    main()
