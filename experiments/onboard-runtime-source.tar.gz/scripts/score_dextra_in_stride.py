"""Score a saved Dextra moving-release archive without rerunning its controller."""

from __future__ import annotations

import argparse
from hashlib import file_digest
from inspect import getfile
import json
from pathlib import Path

import numpy as np

from g1_receiver.in_stride_eval import MOTION_COLUMNS, TRACE_COLUMNS, score_in_stride_catch
from g1_receiver.routes import Route, make_route


def digest(path: Path) -> str:
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def score_recorded_route(folder: Path, case: dict) -> dict:
    name = case["trace_file"]
    if Path(name).name != name:
        raise ValueError("trace must be stored directly in the archive directory")
    trace_path = folder / name
    trace_hash = digest(trace_path)
    if trace_hash != case["trace_sha256"]:
        raise ValueError(f"trace digest differs from report: {trace_path}")
    route = Route(case["route"], tuple(map(tuple, case["waypoints_m"])), case["speed_mps"])
    release = case["release"]
    with np.load(trace_path, allow_pickle=False) as trace:
        if tuple(trace["contact_columns"]) != TRACE_COLUMNS or tuple(trace["motion_columns"]) != MOTION_COLUMNS:
            raise ValueError(f"unexpected contact or motion columns: {trace_path}")
        result = score_in_stride_catch(
            trace["contact"], trace["motion"], route,
            release_time_s=release["time_s"] if release is not None else None,
            finish_time_s=case["horizon_s"], ball_weight_n=case["ball_weight_n"] or .42 * 9.81,
            verified_free_ball=release is not None and case["hands_only_contact"] is not None,
            simulator_warning_count=case["warning_count"],
        )
    return {"trace": name, "trace_sha256": trace_hash, "route": case["route"],
            "route_waypoints_m": route.waypoints, "requested_release_s": case["release_s"],
            "visual_close_s": case["close_s"], **result}


def score_legacy_archive(folder: Path, archive: dict, scale: float, ball_weight_n: float) -> list[dict]:
    route = make_route(archive["route"], scale=scale, speed_mps=archive["target_speed_mps"])
    results = []
    for index, case in enumerate(archive["results"]):
        trace_path = folder / f"case-{index:02d}.npz"
        trace_hash = digest(trace_path)
        if trace_hash != case["trace_sha256"]:
            raise ValueError(f"trace digest differs from report: {trace_path}")
        with np.load(trace_path, allow_pickle=False) as trace:
            if tuple(trace["contact_columns"]) != TRACE_COLUMNS or tuple(trace["motion_columns"]) != MOTION_COLUMNS:
                raise ValueError(f"unexpected contact or motion columns: {trace_path}")
            release = case["release"]
            result = score_in_stride_catch(
                trace["contact"], trace["motion"], route,
                release_time_s=release["time_s"] if release is not None else None,
                finish_time_s=archive["horizon_s"], ball_weight_n=ball_weight_n,
                verified_free_ball=release is not None,
                simulator_warning_count=case["warning_count"],
            )
        results.append({
            "trace": trace_path.name, "trace_sha256": trace_hash,
            "requested_release_s": case["requested_release_s"],
            "intermediate_hands_only_catch": bool((case["checkpoint_contact"] or {}).get("hands_only_catch")),
            **result,
        })
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--route-scale", type=float, default=.24)
    parser.add_argument("--ball-weight-n", type=float, default=.42 * 9.81)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists")
    report_path = args.archive / "report.json"
    archive = json.loads(report_path.read_text())
    if archive["evidence_class"] == "controlled_free_ball_catch_during_route_simulation":
        results = [score_recorded_route(args.archive, case) for case in archive["results"]]
        route_metadata = {}
    elif archive["evidence_class"] == "controlled_moving_release_development_simulation":
        results = score_legacy_archive(args.archive, archive, args.route_scale, args.ball_weight_n)
        route = make_route(archive["route"], scale=args.route_scale, speed_mps=archive["target_speed_mps"])
        route_metadata = {"route_waypoints_m": route.waypoints, "ball_weight_n": args.ball_weight_n}
    else:
        parser.error("archive must originate from a free-joint Dextra moving-release audit")
    output = {
        "evidence_class": "offline_in_stride_dextra_evaluation",
        "source_report_sha256": digest(report_path),
        "scorer_sha256": digest(Path(getfile(score_in_stride_catch))),
        **route_metadata,
        "passed": sum(case["in_stride_catch_and_route"] for case in results),
        "results": results,
    }
    with args.output.open("x") as stream:
        json.dump(output, stream, indent=2, allow_nan=False)
        stream.write("\n")


if __name__ == "__main__":
    main()
