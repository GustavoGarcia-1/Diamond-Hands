"""Narrow depth/full-curl refinement around preserved472ms lower catch."""
from pathlib import Path
from copy import deepcopy
import argparse,json
from concurrent.futures import ProcessPoolExecutor,as_completed
import probe_overnight_lower as base

def execute(job):
 root,profile,source,amp,index,z,hold=job;profile=deepcopy(profile);profile['_experiment_duration_s']=9.5;profile['play']['hold_curls']=None if hold is None else[hold,hold];row=base.execute((root,profile,source,amp,index,(z,0.,.04)));row['hold_curl_mode']='no_relax_full_1'if hold is None else str(hold);(root/f'score-{index:02d}.json').write_text(json.dumps(row,indent=2)+'\n');return row

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for n in ['source','amp-source','profile','output']:p.add_argument('--'+n,type=Path,required=True)
 p.add_argument('--workers',type=int,default=2);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);profile=json.loads(a.profile.read_text());parameters=[(z,h)for z in(-.01,-.015,-.02,-.025,-.03)for h in(.8,.95,None)];jobs=[(a.output,profile,a.source,a.amp_source,i,z,h)for i,(z,h)in enumerate(parameters)];rows=[]
 with ProcessPoolExecutor(max_workers=a.workers)as pool:
  for f in as_completed([pool.submit(execute,j)for j in jobs]):
   row=f.result();rows.append(row);(a.output/'summary.json').write_text(json.dumps(sorted(rows,key=lambda x:x['case']),indent=2)+'\n');print(json.dumps(row),flush=True)
if __name__=='__main__':main()
