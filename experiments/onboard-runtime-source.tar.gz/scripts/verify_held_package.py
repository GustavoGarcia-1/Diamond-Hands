"""Extract the exact ZIP and rerun its public command against archived arrays."""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from zipfile import ZipFile
import numpy as np

p=argparse.ArgumentParser()
p.add_argument('--zip',type=Path,required=True)
p.add_argument('--amp-source',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
checkout=Path(tempfile.mkdtemp(prefix='receiver-package-check-'))
try:
    with ZipFile(a.zip) as archive:
        for name in archive.namelist():
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
        manifest=json.loads(archive.read('MANIFEST.json'))
        assert all(sha256(archive.read(name)).hexdigest()==value for name,value in manifest.items())
        archive.extractall(checkout)
    (checkout/'.venv').symlink_to(sys.prefix,target_is_directory=True)
    out=(a.output/'trial').resolve()
    command=['sh','run-out.sh',str(a.amp_source.resolve()),str(out)]
    with (a.output/'run.log').open('w') as log:
        subprocess.run(command,cwd=checkout,stdout=log,stderr=subprocess.STDOUT,
                       env={**os.environ,'MUJOCO_GL':'egl'},timeout=240,check=True)
    original=checkout/'reports/out-scrimmage/left-turn-20261113/overhead-pass-linux/artifacts/out/case-07'
    equal={}
    for name in ('trace.npz','view.npz'):
        with np.load(original/name) as expected,np.load(out/name) as actual:
            assert set(expected.files)==set(actual.files)
            equal[name]={key:bool(np.array_equal(expected[key],actual[key],equal_nan=True)) for key in expected.files}
    same_report=json.loads((original/'report.json').read_text())==json.loads((out/'report.json').read_text())
    receipt={'zip_sha256':sha256(a.zip.read_bytes()).hexdigest(),
             'command':command,'dependency_environment':sys.prefix,
             'dependency_installation':'Reused validated Linux dependency environment; source and Aero assets extracted from ZIP',
             'all_member_hashes_valid':True,'array_matches':equal,'complete_report_matches':same_report}
    (a.output/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt),flush=True)
    assert same_report and all(all(values.values()) for values in equal.values())
finally:
    shutil.rmtree(checkout)
