"""Posthoc replay geometry attribution for actual archived hand force traces."""
from pathlib import Path
from collections import Counter
import argparse,json
import numpy as np
import mujoco
from g1_receiver.aero import make_aero_scene,PALM_BODIES,FINGERTIP_GEOMS
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
from g1_receiver.dextra_physical_eval import DextraContactAudit,GROUPS

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=Path,required=True);p.add_argument('--evaluation',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();m=mujoco.MjModel.from_xml_string(make_aero_scene(DEFAULT_RUNTIME_ROOT,a.source));d=mujoco.MjData(m);audit=DextraContactAudit(m,palms=PALM_BODIES,fingertip_geoms=FINGERTIP_GEOMS);rows=[]
 for case in ['nominal','aim-minus-2cm','aim-plus-2cm']:
  trial=a.evaluation/case/'learned/episode-0001/trial';view=np.load(trial/'view.npz');c=np.load(trial/'trace.npz')['contact'];last=c[c[:,0]>=c[-1,0]-2];groups=Counter();surfaces=Counter();heights={'left':[],'right':[]};frames=0
  for t,q in zip(view['timestamps_s'],view['qpos']):
   if t<c[-1,0]-2:continue
   frames+=1;d.qpos[:]=q;mujoco.mj_forward(m,d)
   for contact in d.contact:
    pair=(int(contact.geom1),int(contact.geom2))
    if audit.ball_geom not in pair:continue
    other=pair[1]if pair[0]==audit.ball_geom else pair[0];group=GROUPS[int(audit.geom_group[other])];body=m.body(int(m.geom_bodyid[other])).name;geom=m.geom(other).name or f'unnamed_geom_{other}';groups[group]+=1;surfaces[(group,body,geom)]+=1
   for side,sign in [('left',1),('right',-1)]:
    b=d.body('aero_'+side+'_palm');R=b.xmat.reshape(3,3);face=b.xpos+R@[-.0025,.017*sign,.07225];normal=R@[0,sign,0];heights[side].append(float((d.body('football').xpos-face)@normal))
  rows.append(dict(case=case,replay_samples=frames,actual_trace_last2s_mean_normal_n=last[:,6:12].mean(0).tolist(),actual_trace_last2s_mean_vertical_n=last[:,15:21].mean(0).tolist(),geometric_contact_counts=dict(groups),contact_surfaces=[dict(region=k[0],body=k[1],geom=k[2],samples=v)for k,v in surfaces.most_common()],ball_center_palmar_halfspace_distance_m={s:dict(min=float(min(v)),max=float(max(v)),mean=float(np.mean(v)))for s,v in heights.items()}))
 a.output.write_text(json.dumps(dict(mode='Archivedqpos replay surface identification only; forces are recorded actualtrace, never recomputed fixtureforces',normal_columns=['left_tip','left_palm','left_other_hand','right_tip','right_palm','right_other_hand'],rows=rows),indent=2)+'\n');print(json.dumps(rows))
if __name__=='__main__':main()
