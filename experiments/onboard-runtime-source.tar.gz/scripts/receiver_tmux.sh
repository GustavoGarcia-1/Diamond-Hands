#!/usr/bin/env bash
# Create (or reattach to) a project-local persistent terminal workspace.
set -euo pipefail
root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
session="${RECEIVER_TMUX_SESSION:-g1-receiver}"
command -v tmux >/dev/null || { echo 'Install tmux on this host first.' >&2; exit 1; }
if ! tmux has-session -t "=$session" 2>/dev/null; then
  tmux new-session -d -s "$session" -n lead -c "$root"
  tmux set-option -t "$session" history-limit 50000
  tmux set-option -t "$session" mouse on
  tmux set-option -t "$session" status-right '#H | %Y-%m-%d %H:%M'
  tmux new-window -t "$session" -n simulations -c "$root"
  tmux new-window -t "$session" -n validation -c "$root"
  tmux select-window -t "$session:lead"
fi
if [[ "${1:-}" == '--detach' ]]; then
  tmux list-windows -t "=$session"
elif [[ -n "${TMUX:-}" ]]; then
  tmux switch-client -t "=$session"
else
  exec tmux attach-session -t "=$session"
fi
