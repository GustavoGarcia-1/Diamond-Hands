"""Redraw archived Aero poses at the school stadium without running the controller."""

import argparse
import json
from pathlib import Path

import mujoco
import numpy as np

from g1_receiver.hand_route_plant import HandRoutePlant
from g1_receiver.stadium import StadiumRenderer
from g1_receiver.stadium_quarterback import PassCamera


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True, help="Pinned Aero model source")
    parser.add_argument("--input", type=Path, required=True, help="view.npz with qpos and timestamps_s")
    parser.add_argument("--output", type=Path, required=True, help="Replay NPZ, or PNG with --time")
    parser.add_argument("--heading-deg", type=float, default=0., help="Direction the field runs in")
    parser.add_argument("--scrimmage-xy", type=float, nargs=2, default=(0., 0.))
    parser.add_argument("--receiver-split-m", type=float,
                        help="Receiver's lateral split from field centerline; preserves recorded physics")
    parser.add_argument("--azimuth-deg", type=float, default=109., help="Relative to field heading")
    parser.add_argument("--elevation-deg", type=float, default=-10.)
    parser.add_argument("--distance-m", type=float, default=3.2)
    parser.add_argument("--width", type=int, default=800)
    parser.add_argument("--height", type=int, default=448)
    parser.add_argument("--fixed-lookat", type=float, nargs=3,
                        help="Fixed stadium camera target XYZ for one uninterrupted full-field view")
    parser.add_argument("--time", type=float, help="Save a PNG for the closest recorded time")
    parser.add_argument("--quarterback", action="store_true",
                        help="Show the fixed passer at the measured launch origin")
    parser.add_argument("--studio", action="store_true",
                        help="Green field, plain grey-blue backdrop and stationary passing machine")
    parser.add_argument("--report", type=Path, help="Rollout report for launch and catch timing")
    parser.add_argument("--release-time", type=float)
    parser.add_argument("--catch-time", type=float, help="Override the recorded end of the flight shot")
    parser.add_argument("--quarterback-origin", type=float, nargs=3)
    args = parser.parse_args()
    if args.output.exists():
        parser.error(f"output already exists: {args.output}")
    if args.width < 64 or args.height < 64:
        parser.error("render dimensions must be at least 64 pixels")
    if args.output.suffix.lower() != (".png" if args.time is not None else ".npz"):
        parser.error("use .png with --time or .npz for the replay")
    camera_parameters = (args.heading_deg, *args.scrimmage_xy, args.azimuth_deg,
                         args.elevation_deg, args.distance_m, *(args.fixed_lookat or ()))
    if (not np.isfinite(camera_parameters).all() or args.distance_m <= 0.
            or (args.time is not None and not np.isfinite(args.time))):
        parser.error("camera parameters must be finite and distance must be positive")
    args.output.parent.mkdir(parents=True, exist_ok=True)

    with np.load(args.input, allow_pickle=False) as replay:
        if not {"qpos", "timestamps_s"} <= set(replay.files):
            parser.error("the input replay needs qpos and timestamps_s")
        states, times = replay["qpos"], replay["timestamps_s"]
    plant = HandRoutePlant(args.source, hand_model="aero", survey_camera=False)
    if (times.ndim != 1 or len(times) == 0 or states.shape != (len(times), plant.model.nq)
            or not np.isfinite(states).all() or not np.isfinite(times).all()
            or np.any(np.diff(times) <= 0)):
        parser.error("expected finite, sample-aligned Aero qpos and strictly increasing timestamps")

    heading = np.radians(args.heading_deg)
    lookahead = .38 * np.array([np.cos(heading), np.sin(heading)])
    pass_camera = None
    origin = None
    release_time = None
    quarterback_heading = None
    if args.quarterback:
        report_path = args.report or args.input.with_name("report.json")
        report = json.loads(report_path.read_text()) if report_path.exists() else {}
        release = report.get("release") or {}
        release_time = args.release_time if args.release_time is not None else release.get("release_time_s")
        flight_end = args.catch_time if args.catch_time is not None else (
            (report.get("strict_score") or report.get("catch_score") or {}).get("first_tip_contact_s")
        )
        if flight_end is None and release_time is not None and release.get("flight_time_s") is not None:
            flight_end = min(times[-1], release_time + release["flight_time_s"])
        origin = args.quarterback_origin or release.get("release_xyz_m")
        if (release_time is None or flight_end is None
                or not np.isfinite((release_time, flight_end)).all()
                or not times[0] <= release_time < flight_end <= times[-1]):
            parser.error("quarterback replay requires release and flight timing within the archive")
        if origin is None:
            index = np.searchsorted(times, release_time, side="left") - 1
            origin = states[max(0, index), plant.ball_qpos:plant.ball_qpos + 3]
        if np.shape(origin) != (3,) or not np.isfinite(origin).all():
            parser.error("quarterback origin requires finite XYZ coordinates")
        origin = np.asarray(origin)
        if args.receiver_split_m is not None:
            normal = np.array([-np.sin(heading), np.cos(heading)])
            forward = np.array([np.cos(heading), np.sin(heading)])
            relative_origin = origin[:2] - np.asarray(args.scrimmage_xy)
            if not np.allclose((relative_origin @ forward, relative_origin @ normal),
                               (0., -args.receiver_split_m), atol=.01, rtol=0.):
                parser.error("declared split must put the actual passer on field centerline at scrimmage")
        held = states[times < release_time - 1e-8, plant.ball_qpos:plant.ball_qpos + 3]
        if len(held) and not np.allclose(held, origin, rtol=0., atol=1e-6):
            drift = np.max(np.linalg.norm(held - origin, axis=1))
            parser.error(f"quarterback replay requires a fixed pre-release ball (archive drift: {drift:.6f} m)")
        launch_velocity = release.get("release_velocity_mps")
        if launch_velocity is not None and np.linalg.norm(launch_velocity[:2]) > 0:
            quarterback_heading = float(np.arctan2(launch_velocity[1], launch_velocity[0]))
        pass_camera = PassCamera(release_time, flight_end, times[0], origin, args.heading_deg)
    viewer = StadiumRenderer(plant, width=args.width, height=args.height,
                             field_heading_rad=heading, scrimmage_xy_m=args.scrimmage_xy,
                             quarterback_origin=origin, release_time=release_time,
                             quarterback_heading_rad=quarterback_heading, studio=args.studio,
                             receiver_split_m=args.receiver_split_m)
    camera = mujoco.MjvCamera()

    def frame(index):
        plant.data.time = times[index]
        plant.data.qpos[:] = states[index]
        receiver = states[index, plant.base:plant.base + 2]
        camera.azimuth = args.azimuth_deg + args.heading_deg
        camera.elevation = args.elevation_deg
        camera.distance = args.distance_m
        camera.lookat[:] = (*(receiver + lookahead), .76)
        if args.fixed_lookat is not None:
            camera.lookat[:] = args.fixed_lookat
        elif pass_camera is not None:
            ball = states[index, plant.ball_qpos:plant.ball_qpos + 3]
            pass_camera.frame(camera, times[index], receiver, ball)
        viewer.update_scene(plant.data, camera=camera)
        return viewer.render()

    try:
        if args.time is None:
            frames = [frame(index) for index in range(len(times))]
            np.savez_compressed(args.output, rgb=frames, timestamps_s=times, qpos=states)
        else:
            from PIL import Image

            index = int(np.argmin(np.abs(times - args.time)))
            Image.fromarray(frame(index)).save(args.output)
    finally:
        viewer.close()
        plant.close()


if __name__ == "__main__":
    main()
