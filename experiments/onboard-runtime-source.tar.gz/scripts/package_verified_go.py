"""Build and verify the isolated baseline-Go project ZIP (video uploaded separately)."""
import argparse
import ast
from hashlib import sha256
import json
import shutil
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
RUN = '''#!/bin/sh
set -eu
cd "$(dirname "$0")"
export PYTHONPATH=src:scripts
HAND_SOURCE=${1:-aero-source}
AMP_SOURCE=${2:-/tmp/g1-pretrained-run-legged}
.venv/bin/python scripts/rescore_aero_receiver.py reports/quarterback-pass/offset-fixed-controlled
.venv/bin/python reports/quarterback-pass/camera_throw.py --candidate reports/quarterback-pass/offset-controlled-profile.json --output reports/quarterback-pass/reproduce --lead .138 --expected-close 4.42 --field-window --record --finish 5.42 --source "$HAND_SOURCE" --amp-source "$AMP_SOURCE"
.venv/bin/python scripts/rescore_aero_receiver.py reports/quarterback-pass/reproduce
'''
CAPTION = '''Simulated Unitree G1 football receiver with Aero hands. A fixed-origin pass travels 9.54 m in 0.979 s; the receiver reaches 9.148 m downfield and controls the ball with both hands for 254 ms at 0.668 m/s relative horizontal speed. Recurrent foot flights bracket contact. The play drifts 3.25 m laterally and ends in a drop and fall; full route completion/retention fails. Pinned pretrained AMP locomotion plus RGB-D-triggered calibrated scripted grip; no demonstrated locally learned catch improvement. The green football field, plain grey-blue backdrop and stationary passing machine are spectator visuals; the physical release is unchanged. A matched neutral-grip ablation achieves 0 ms bilateral control versus 254 ms for the calibrated action bundle. Camera, Aero integration, Linux ARM64 image and HIM hardware checks remain unverified.\n'''

def package(output, hand_source, video_dir, supplement=False, caption_file=None, extra_evidence_dirs=()):
    caption = CAPTION if caption_file is None else caption_file.read_text()
    if supplement and caption_file is None:
        raise ValueError("combined supplement requires an explicitly reviewed --caption-file")
    video_dir = video_dir.resolve()
    for required in ("full-play.mp4", "video-verification.json", "contact-sheet.jpg"):
        if not (video_dir / required).is_file():
            raise FileNotFoundError(video_dir / required)
    from g1_receiver.aero import MODEL_DIR, _load_source
    _load_source(hand_source)
    source = hand_source if hand_source.name == MODEL_DIR else hand_source / MODEL_DIR
    files = {}
    def add(path, name=None):
        if path.is_symlink():
            raise ValueError(f'symlink forbidden: {path}')
        files[name or path.relative_to(ROOT).as_posix()] = path.read_bytes()
    for folder in ['src/g1_receiver', 'tests']:
        for path in sorted((ROOT / folder).rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
                add(path)
    # Resolve transitive local script imports rather than bundling unrelated experiments.
    pending = ['package_verified_go', 'rescore_aero_receiver', 'render_aero_stadium', 'encode_receiver_replay',
               'probe_aero_out', 'probe_qb_arm_trim', 'probe_go_neutral_grip', 'verify_field_replay', 'fetch_aero_hand']
    pending += ['evaluate_aero_receiver']
    seen = set()
    while pending:
        name = pending.pop()
        if name in seen:
            continue
        seen.add(name)
        path = ROOT / 'scripts' / (name + '.py')
        add(path)
        for node in ast.walk(ast.parse(path.read_text())):
            names = ([node.module.split('.')[0]] if isinstance(node, ast.ImportFrom) and node.module
                     else [alias.name.split('.')[0] for alias in node.names] if isinstance(node, ast.Import) else [])
            pending.extend(n for n in names if (ROOT / 'scripts' / (n + '.py')).is_file())
    for name in ['pyproject.toml', 'uv.lock', 'SENSOR_CONTRACT.md', 'docs/submission-go.md',
                 'docs/aero-integration.md', 'docs/running-policy.md', 'docs/hardware-qualification.md',
                 'reports/quarterback-pass/camera_throw.py', 'reports/quarterback-pass/offset-controlled-profile.json',
                 'reports/out-scrimmage/refine-best/profile.json']:
        add(ROOT / name)
    for folder in ['reports/quarterback-pass/offset-fixed-controlled',
                   'reports/quarterback-pass/offset-arm-trim-align-y-recorded',
                   'reports/out-scrimmage/refine-best/trial', 'reports/independent-validation-20261113',
                   'reports/quarterback-pass/neutral-grip-20261113']:
        for path in sorted((ROOT / folder).iterdir()):
            if path.is_file() and path.name not in ['stadium-view.npz', 'stadium-replay.mp4', 'COMPARISON.md']:
                add(path)
    if supplement:
        for name in ['docs/submission-status-20261113.md', 'docs/football-route-contract.md',
                     'reports/aero-amp-slant/two-step-20261113/README.md',
                     'reports/aero-amp-slant/two-step-20261113/CRITERIA.md',
                     'reports/aero-amp-slant/two-step-20261113/REPRODUCE.sh',
                     'reports/aero-amp-slant/two-step-20261113/formation-and-path.json',
                     'reports/out-scrimmage/frame-speed-20261113/score-inside.py',
                     'reports/out-scrimmage/frame-speed-20261113/reproduce-best.sh',
                     'reports/out-scrimmage/frame-speed-20261113/reproduce-inside-held.sh',
                     'reports/out-scrimmage/frame-speed-20261113/reproduce-final-braked.sh',
                     'reports/out-scrimmage/frame-speed-20261113/README.md',
                     'reports/out-scrimmage/frame-speed-20261113/finish-extra-stop-windows.json',
                     'reports/out-scrimmage/frame-speed-20261113/finish-extra-audit.json',
                     'reports/out-scrimmage/frame-speed-20261113/finish-grip-audit.json',
                     'reports/out-scrimmage/frame-speed-20261113/lookback-target-linux/artifacts/out/profile-08.json']:
            add(ROOT / name)
        extra_evidence_dirs = (*extra_evidence_dirs,
            ROOT/'reports/formation-audit-20261113',
            ROOT/'reports/independent-validation-out-held-20261113',
            ROOT/'reports/independent-validation-out-brake-20261113',
            ROOT/'reports/out-scrimmage/frame-speed-20261113/finish-extra-camera-linux/artifacts/out',
            ROOT/'reports/aero-amp-slant/two-step-20261113/antioch-grip/artifacts/slant/case-02',
            ROOT/'reports/go-stem-20261113/independent-screen-review',
            ROOT/'reports/out-scrimmage/frame-speed-20261113/lookback-target-linux/artifacts/out/case-08',
            ROOT/'reports/out-scrimmage/frame-speed-20261113/lookback-extend-linux/artifacts/out/case-00',
            ROOT/'reports/aero-amp-slant/two-step-20261113/antioch-exit/artifacts/slant/case-00',
            ROOT/'reports/aero-amp-slant/two-step-20261113/antioch-exit/artifacts/slant/case-03')
    for folder in extra_evidence_dirs:
        for path in sorted(folder.rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts and path.suffix not in ('.pyc', '.mp4'):
                add(path)
    for path in sorted(source.rglob('*')):
        if path.is_file():
            add(path, f'aero-source/{MODEL_DIR}/{path.relative_to(source).as_posix()}')
    for name in ('video-verification.json', 'contact-sheet.jpg'):
        add(video_dir / name, f'reports/submission-video/{name}')
    files['README.md'] = b'# G1 verified Go simulation\n\nRead docs/submission-go.md and SENSOR_CONTRACT.md. Run sh run.sh after dependency setup and external AMP fetch. Upload full-play.mp4 separately.\n'
    if supplement:
        files['README.md'] = b'# G1 football receiver evidence supplement\n\nStart with docs/submission-status-20261113.md, docs/football-route-contract.md and SENSOR_CONTRACT.md. The primary video is separate; reviewed caption.txt states the observed outcome. Corrected Out evidence, original Go fallback, Slant locomotion and independent audits are included. run.sh reproduces the baseline Go only; the selected Out uses sh reports/out-scrimmage/frame-speed-20261113/reproduce-final-braked.sh. External AMP fetch/dependencies: docs/submission-go.md.\n'
    files['run.sh'] = RUN.encode()
    files['caption.txt'] = caption.encode()
    manifest = {name: sha256(data).hexdigest() for name, data in sorted(files.items())}
    output.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(output, 'x', ZIP_DEFLATED, compresslevel=6) as archive:
        for name, data in sorted(files.items()):
            archive.writestr(name, data)
        archive.writestr('MANIFEST.json', json.dumps(manifest, indent=2) + '\n')
    with ZipFile(output) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist()) == len(manifest) + 1
        assert all(sha256(archive.read(name)).hexdigest() == digest for name, digest in manifest.items())
        assert not any(n.endswith('g1_run.onnx') or n.startswith('/') or '..' in Path(n).parts for n in archive.namelist())
    receipt = {'zip': str(output), 'sha256': sha256(output.read_bytes()).hexdigest(),
               'bytes': output.stat().st_size, 'members': len(manifest)+1,
               'uncompressed_bytes': sum(map(len, files.values())), 'crc_and_member_hashes_verified': True,
               'video': 'Separate upload: full-play.mp4',
               'video_source_directory': str(video_dir),
               'baseline_trace_sha256': manifest['reports/quarterback-pass/offset-fixed-controlled/trace.npz']}
    video_source = video_dir / 'full-play.mp4'
    shutil.copyfile(video_source, output.with_name('full-play.mp4'))
    receipt['video_sha256'] = sha256(video_source.read_bytes()).hexdigest()
    receipt['video_bytes'] = video_source.stat().st_size
    output.with_name('caption.txt').write_text(caption)
    output.with_name('package-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps(receipt, indent=2))

if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--output', type=Path, default=ROOT/'artifacts/him-open-build-clean-field-20261113/project.zip')
    cli.add_argument('--hand-source', type=Path, default=Path('/tmp/g1-aero-source'))
    cli.add_argument('--video-dir', type=Path, default=ROOT/'reports/submission-clean-field-20261113')
    cli.add_argument('--supplement', action='store_true', help='Add current route audit and corrected Out/Slant development evidence')
    cli.add_argument('--caption-file', type=Path)
    cli.add_argument('--extra-evidence-dir', type=Path, action='append', default=[])
    args = cli.parse_args()
    package(args.output, args.hand_source, args.video_dir, args.supplement, args.caption_file, args.extra_evidence_dir)
