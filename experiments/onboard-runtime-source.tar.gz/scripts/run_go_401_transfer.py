"""Matched two-yard Go grip-geometry transfer; calibrated baseline, not RL."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys
import numpy as np

p=argparse.ArgumentParser()
p.add_argument('--output',type=Path,required=True)
p.add_argument('--source',required=True)
p.add_argument('--amp-source',required=True)
a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
base=json.loads(Path('reports/aero-rl-20261113/slot-pocket-linux/artifacts/go/profile-11.json').read_text())
transfer=json.loads(Path('reports/amp-aero-physics-screen/rgbd-401-settled/report.json').read_text())['play']
cases=[(fraction,height,lead) for fraction in (0.,.5,1.) for height in (-.06,0.,.06) for lead in (.03180683279743857,-.12)]
(a.output/'protocol.json').write_text(json.dumps({'purpose':'Calibrated geometry transfer only; no new learned controller',
    'formation':'fixed machine on LOS, receiver two yards beside it',
    'selection':'unchanged >=150ms bilateral and <=1m/s relative; gait and later drop separate',
    'cases':cases},indent=2)+'\n')
def run(item):
    i,(fraction,height,lead)=item
    spec=json.loads(json.dumps(base));play=spec['play']
    for key in ('grasp_offsets_rad','hold_offsets_rad','hold_curls'):
        play[key]=((1-fraction)*np.asarray(play[key])+fraction*np.asarray(transfer[key])).tolist()
    play['closure']=(1-fraction)*play['closure']+fraction*transfer['closure']
    play['quarterback_target_m'][2]+=height
    play['grasp_joint_lead_s']=lead
    profile=a.output/f'profile-{i:02d}.json';profile.write_text(json.dumps(spec,indent=2)+'\n')
    out=a.output/f'case-{i:02d}'
    command=[sys.executable,'scripts/probe_go_stem.py','--reference',str(profile),
             '--source',a.source,'--amp-source',a.amp_source,'--output',str(out),'--duration','7','--record-poses']
    with (a.output/f'case-{i:02d}.log').open('w') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=240)
    score=out/'stem-score.json'
    return dict(case=i,transfer_fraction=fraction,aim_height_delta_m=height,joint_lead_s=lead,
                exit_code=result.returncode,command=command,score=json.loads(score.read_text()) if score.exists() else None)
results=[]
with ThreadPoolExecutor(max_workers=3) as pool:
    for result in pool.map(run,enumerate(cases)):
        results.append(result);(a.output/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
if any(r['exit_code'] for r in results):raise SystemExit(1)
