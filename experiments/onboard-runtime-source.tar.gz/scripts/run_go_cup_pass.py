"""Full fixed-machine throws after predeclared straight-path checks passed."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys
import numpy as np

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--source',required=True);p.add_argument('--amp-source',required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
base=json.loads(Path('reports/out-scrimmage/left-turn-20261113/overhead-pass-linux/artifacts/out/profile-07.json').read_text())
screens=Path('reports/aero-rl-20261113/go-cup-alignment-linux/artifacts/screen')
calibrations={}
for index,yaw,depth in ((3,-.5,2.1),(4,-.7,1.3)):
    folder=screens/f'case-{index:02d}'
    report=json.loads((folder/'report.json').read_text())
    assert report['duration_s']>=13.99 and report['minimum_upright_cosine']>=.9
    assert report['max_stem_error_m']<=.75 and report['final_xyz_m'][0]>=9.144
    with np.load(folder/'trace.npz') as data:
        motion=data['motion'];palms=data['palms']
        arrival=float(motion[np.argmin(abs(motion[:,1]-9.144)),0])
        palm=np.array([np.interp(arrival,palms[:,0],palms[:,i]) for i in (1,2,3)])
    calibrations[index]={'initial_yaw':yaw,'handoff_depth':depth,'arrival_s':arrival,'palm_m':palm.tolist()}
cases=[(index,flight,lift) for index in calibrations for flight in (1.1,1.4,1.6) for lift in (.03,.08)]
(a.output/'protocol.json').write_text(json.dumps({
    'purpose':'Calibrated full physics Go throw, scripted camera grip; no learned-catch claim',
    'calibrations':calibrations,'cases':cases,
    'formation':'receiver0,0;fixedmachine0,-1.8288,1.4;fielddownfield+X',
    'acceptance':'Existing150ms/1mps shortcheck; longhold and support cutoff; '
                 'Go contact depth9.144+/-.30m, fullstemerror<=.75m; gait reported separately',
    'calibration_boundary':'Screen simulator palms used only to select fixed throw parameters offline; runtime camera/IMU/encoders only'},indent=2)+'\n')
def run(pair):
    index,(screen,flight,lift)=pair
    calibration=calibrations[screen]
    spec=json.loads(json.dumps(base));play=spec['play']
    origin=np.array([0.,-1.8288,1.4])
    target=np.array(calibration['palm_m'])+np.array([.02,0.,lift])
    axis=target[:2]-origin[:2];axis/=np.linalg.norm(axis)
    play.update(quarterback_origin_m=origin.tolist(),quarterback_target_m=target.tolist(),
                field_catch_window_m=target.tolist(),field_approach_axis_xy=axis.tolist(),
                quarterback_horizontal_distance_only=True,flight_s=flight,
                release_s=calibration['arrival_s']-flight,finish_s=calibration['arrival_s']+3.)
    spec.update(pass_camera=[[6.,-4.,3.8],[9.,0.,1.5]],
                formation={'receiver_origin_xy_m':[0.,0.],'quarterback_lateral_m':-1.8288,
                           'arrival_s':calibration['arrival_s']},
                route_frame={'heading_rad':0.,'scrimmage_origin_xy_m':[0.,0.]})
    profile=a.output/f'profile-{index:02d}.json';profile.write_text(json.dumps(spec,indent=2)+'\n')
    out=a.output/f'case-{index:02d}'
    command=[sys.executable,'scripts/probe_go_cup.py','--source',a.source,'--amp-source',a.amp_source,
             '--profile',str(profile),'--output',str(out),'--walk-speed','1',
             '--handoff-depth',str(calibration['handoff_depth']),'--initial-yaw',str(calibration['initial_yaw']),
             '--duration',str(play['finish_s'])]
    with (a.output/f'case-{index:02d}.log').open('w') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=300)
    report=out/'report.json'
    return {'case':index,'screen_case':screen,'flight_s':flight,'target_lift_m':lift,
            'exit_code':result.returncode,'command':command,
            'report':json.loads(report.read_text()) if report.exists() else None}
with ThreadPoolExecutor(max_workers=3) as pool:
    results=[]
    for result in pool.map(run,enumerate(cases)):
        results.append(result);(a.output/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
if any(r['exit_code'] for r in results):raise SystemExit(1)
