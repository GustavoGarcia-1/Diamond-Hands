"""Compare the extracted sensor controller with the frozen simulator on identical inputs."""

from __future__ import annotations

import argparse
from pathlib import Path
import json

import numpy as np

from compare_receiver_route_control import route_action
from g1_receiver.receiver_deploy import NumpyReceiverActor, ReceiverController
from g1_receiver.receiver_env import ReceiverTrial
from g1_receiver.receiver_physical_eval import PhysicalAuditReceiverEnv
from g1_receiver.routes import make_route
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT


class CompareOnSensorTrace(PhysicalAuditReceiverEnv):
    def __init__(self, controller):
        super().__init__(DEFAULT_RUNTIME_ROOT)
        self.controller = controller
        self.last_frame = -np.inf
        self.errors = []
        self.fresh = []

    def _advance(self):
        if self._last_camera is not None:
            frame, survey, _ = self._last_camera
            if frame.timestamp_s > self.last_frame:
                self.controller.ingest_rgbd(frame, survey, now_s=self.plant.timestamp_s)
                self.last_frame = frame.timestamp_s
        candidate = self.controller.tick(self.plant.timestamp_s, self.plant.proprioception())
        super()._advance()
        self.errors.append(float(np.max(np.abs(candidate.target_position - self.plant.last_joint_targets))))
        self.fresh.append(self.state.receiver is not None)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--export", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    source = json.loads((args.export / "export.json").read_text())
    trial = ReceiverTrial(**{**source["trial"], "dropout_probability": 0., "camera_delay_ticks": 0})
    route = make_route(trial.route, scale=trial.route_scale, speed_mps=.30)
    actor = NumpyReceiverActor(args.export / "actor.npz")
    controller = ReceiverController(actor, route, allow_synthetic_fixture=True)
    env = CompareOnSensorTrace(controller)
    try:
        observation, _ = env.reset(seed=85178, options={"trial": trial})
        for _ in range(130):
            action = actor(observation)
            action[:3] = route_action(env)
            observation, _, terminated, _, _ = env.step(action)
            if terminated:
                break
        fresh_errors = np.array(env.errors)[env.fresh]
        first_missing = next((i for i, valid in enumerate(env.fresh) if not valid), len(env.errors))
        result = {
            "evidence_class": "same_trace_sensor_controller_comparison",
            "trial": source["trial"],
            "dropout_probability_override": 0.,
            "paired_commands": len(env.errors),
            "fresh_commands": len(fresh_errors),
            "commands_before_first_localization_loss": first_missing,
            "max_target_error_before_loss_rad": max(env.errors[:first_missing], default=None),
            "first_target_difference_above_1e_5_tick": next(
                (i for i, error in enumerate(env.errors) if error > 1e-5), None),
            "max_fresh_target_error_rad": float(fresh_errors.max()),
            "max_target_error_rad": max(env.errors),
            "physical_evaluation_only": env.physical_summary(),
        }
    finally:
        env.close()
    with args.output.open("x") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
