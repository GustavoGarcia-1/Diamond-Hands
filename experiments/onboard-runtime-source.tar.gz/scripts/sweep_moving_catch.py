"""Screen eight predefined near-field lobs; archive success and failure physics."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from g1_receiver.locomotion import run
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT

# Ballistic fixture design targets (release x/z, arrival t/x/y); fixed before sweep.
FIXTURES = (
    (.73, .30, .53, .19, 0.0),
    (.73, .30, .53, .24, -.02),
    (.78, .32, .60, .18, -.02),
    (.78, .32, .60, .24, 0.0),
    (.84, .38, .67, .18, 0.0),
    (.84, .38, .67, .24, .02),
    (.90, .40, .75, .20, -.02),
    (.90, .40, .75, .26, 0.0),
)
SECONDS = 3.2


def release(fixture):
    x, z, flight, target_x, target_y = fixture
    return (x, 0., z), ((target_x - x) / flight, target_y / flight,
                       (1.10 - z) / flight + 9.81 / 2 * flight)


def evaluate(truth):
    stamps = truth["timestamps_s"]
    contact = truth["ball_robot_contact"]
    floor = truth["ball_ground_contact"]
    body_xy = truth["robot_base_position_m"][:, :2]
    ball = truth["ball_position_m"]
    speed = np.linalg.norm(truth["ball_velocity_mps"], axis=1)
    indices = np.flatnonzero(contact)
    first = int(indices[0]) if indices.size else None
    pre_move = float(np.linalg.norm(body_xy[first] - body_xy[0])) if first is not None else 0.
    after_move = float(np.linalg.norm(body_xy[-1] - body_xy[first])) if first is not None else 0.
    final = stamps >= stamps[-1] - .3
    support = float(np.mean(contact[final]))
    metrics = {
        "first_robot_contact_s": float(stamps[first]) if first is not None else None,
        "first_floor_contact_s": float(stamps[floor][0]) if floor.any() else None,
        "min_upright_cosine": float(np.min(truth["robot_upright"])),
        "precontact_displacement_m": pre_move,
        "precontact_forward_progress_m": float(body_xy[first, 0] - body_xy[0, 0]) if first is not None else 0.,
        "postcontact_displacement_m": after_move,
        "final_ball_height_m": float(ball[-1, 2]),
        "final_ball_speed_mps": float(speed[-1]),
        "final_window_support_fraction": support,
    }
    metrics["retained_while_moving"] = bool(
        first is not None and not floor.any() and support >= .85 and np.min(ball[final, 2]) > .7
        and metrics["precontact_forward_progress_m"] >= .025 and after_move >= .20
        and metrics["min_upright_cosine"] >= .90
    )
    return metrics


def trial(pool_root, output, index, fixture):
    position, velocity = release(fixture)
    truth, _, _, commands = run(
        pool_root, "moving-catch", SECONDS, route_name="go", route_scale=.20, camera_hz=25.,
        release_position_m=position, release_velocity_mps=velocity,
    )
    name = f"moving-grid-{index:02}"
    np.savez_compressed(output / f"{name}-truth.npz", **truth)
    np.savez_compressed(output / f"{name}-controller.npz", **commands)
    return {"name": name, "release_position_m": position, "release_velocity_mps": velocity,
            **evaluate(truth)}


def write_report(output, results):
    best = max(results, key=lambda row: (
        row["retained_while_moving"], row["final_window_support_fraction"],
        -row["final_ball_speed_mps"],
    ))
    report = {
        "evidence_class": "physical_simulation", "seconds": SECONDS,
        "route": "go", "route_scale": .20, "nominal_camera_hz": 25., "best": best,
        "retained_count": sum(row["retained_while_moving"] for row in results),
        "trials": results,
    }
    (output / "moving-catch-grid.json").write_text(json.dumps(report, indent=2) + "\n")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pool-root", default=DEFAULT_RUNTIME_ROOT, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    results = []
    for index, fixture in enumerate(FIXTURES, 1):
        result = trial(args.pool_root, args.output, index, fixture)
        results.append(result)
        print(f"{result['name']}: retained={result['retained_while_moving']}", flush=True)
    report = write_report(args.output, results)
    print(json.dumps({"trial_count": len(results), "best": report["best"]}, indent=2))



if __name__ == "__main__":
    main()
