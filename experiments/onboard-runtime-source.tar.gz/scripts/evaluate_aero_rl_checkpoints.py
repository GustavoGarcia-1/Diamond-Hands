"""Independent final-checkpoint paired physics evaluation; no training/selection."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import time
import numpy as np
from g1_receiver.aero_residual_rl import (AeroResidualEnv, SCHEMA, NORMALIZED_SCHEMA,
                                        REWARD_SCHEMA, CORRECTED_REWARD_SCHEMA)
from g1_receiver.in_stride_eval import NORMAL_COLUMNS
from g1_receiver.throw_eval import score_throw_receive

def digest(path):return sha256(Path(path).read_bytes()).hexdigest()

def physical(directory):
    report=json.loads((directory/'report.json').read_text())
    with np.load(directory/'trace.npz') as trace:
        contact=trace['contact'];motion=trace['motion']
    normals=contact[:,NORMAL_COLUMNS];times=contact[:,0]
    bad=(normals[:,6:].sum(1)>1e-9)|contact[:,4].astype(bool)|contact[:,5].astype(bool)
    strict=report['strict_score'];tip=strict['first_tip_contact_s']
    short=score_throw_receive(contact,motion,report['release'],tip,physics_step_s=report['physics_step_s'])
    both=(normals[:,:2].sum(1)>=.1)&(normals[:,3:5].sum(1)>=.1)
    if tip is None:both[:]=False
    else:both &= times>=tip-1e-8
    if bad.any():both[np.flatnonzero(bad)[0]:]=False
    edges=np.flatnonzero(np.diff(np.r_[False,both,False]));runs=list(zip(edges[::2],edges[1::2]));a,b=max(runs,key=lambda x:x[1]-x[0],default=(0,0));relative=None
    if b-a>1:
        pelvis=np.stack([np.interp(times[[a,b-1]],motion[:,0],motion[:,i]) for i in (1,2)],axis=1)
        relative=float(np.linalg.norm(np.diff(contact[[a,b-1],1:3]-pelvis,axis=0))/(times[b-1]-times[a]))
    floor=np.flatnonzero(contact[:,4]);end=motion[-1,0]
    speed=np.linalg.norm(np.diff(motion[:,1:3],axis=0)/np.diff(motion[:,0])[:,None],axis=1)
    pose=np.load(directory/'view.npz');q=pose['qpos'];pt=pose['timestamps_s'];w,x,y,z=q[:,3:7].T
    yaw=np.unwrap(np.arctan2(2*(w*z+x*y),1-2*(y*y+z*z)))
    myaw=np.interp(motion[:-1,0],pt,yaw)
    velocity=np.diff(motion[:,1:3],axis=0)/np.diff(motion[:,0])[:,None]
    forward=(velocity*np.c_[np.cos(myaw),np.sin(myaw)]).sum(1)
    window=(motion[:-1,0]>=tip if tip is not None else np.zeros(len(forward),dtype=bool))
    elapsed=np.diff(motion[:,0])
    result={'short_receive':short,'running_at_catch':report['running_score']['running_at_catch'],
            'qualified_flight_phases':report['running_score']['qualified_flight_phases'],
            'strict_route_and_catch':strict['in_stride_catch_and_route'],'strict_failed_checks':strict['failed_checks'],
            'long_clean_bilateral_s':float((b-a)*report['physics_step_s']),
            'long_hold_start_s':None if b==a else float(times[a]),'long_hold_end_s':None if b==a else float(times[b-1]),
            'long_hold_horizontal_relative_mps':relative,'last_clean_bilateral_s':None if not both.any() else float(times[np.flatnonzero(both)[-1]]),
            'first_external_support_s':None if not bad.any() else float(times[np.flatnonzero(bad)[0]]),
            'first_floor_s':None if not len(floor) else float(times[floor[0]]),
            'bilateral_at_end':bool(both[-1]),'end_s':float(end),'final_upright_cosine':float(motion[-1,4]),
            'minimum_upright_cosine':float(motion[:,4].min()),'upright_through_requested_finish':bool(end>=report['play']['finish_s']-.04 and motion[:,4].min()>=.9),
            'final_half_second_mean_speed_mps':float(speed[motion[1:,0]>=end-.5].mean()),
            'post_contact_mean_body_forward_mps':None if not window.any() else float(forward[window].mean()),
            'post_contact_negative_body_forward_s':float(elapsed[window&(forward<-.05)].sum()),
            'max_abs_world_y_stem_error_m':float(abs(motion[:,2]).max()),
            'peak_applied_ball_load':float(contact[:,5].max()),'trace_sha256':digest(directory/'trace.npz'),
            'report_sha256':digest(directory/'report.json'),'pose_sha256':digest(directory/'view.npz')}
    return result

def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--pair',nargs=3,action='append',metavar=('NAME','REFERENCE','CHECKPOINT'),required=True)
    cli.add_argument('--source',type=Path,required=True);cli.add_argument('--amp-source',type=Path,required=True)
    cli.add_argument('--output',type=Path,required=True);cli.add_argument('--device',default='cuda')
    cli.add_argument('--seed',type=int,default=173);cli.add_argument('--heldout',action='store_true')
    cli.add_argument('--heldout-only',action='store_true',help='Fixed two target offsets; nominal pair already archived')
    cli.add_argument('--wall-seconds',type=float,default=1200.)
    args=cli.parse_args();args.output.mkdir(parents=True,exist_ok=False);start=time.monotonic()
    from stable_baselines3 import PPO
    manifest={'purpose':'final-checkpoint independent paired physical evaluation, never feeds training or SGS',
              'schema':None,'observation_schemas':[],'reward_schemas':[],'seed':args.seed,'device':args.device,'heldout':args.heldout or args.heldout_only,'pairs':[],
              'source_sha256':digest(__file__),'environment_sha256':digest(Path(__file__).resolve().parents[1]/'src/g1_receiver/aero_residual_rl.py')}
    results=[]
    for name,refname,checkpointname in args.pair:
        reference=Path(refname);checkpoint=Path(checkpointname)
        if not checkpoint.is_file():raise FileNotFoundError(checkpoint)
        original=json.loads(reference.read_text())
        model=PPO.load(checkpoint,device=args.device)
        model_schema=getattr(model,'receiver_sensor_schema',SCHEMA)
        if model_schema not in (SCHEMA,NORMALIZED_SCHEMA):
            raise ValueError('unknown checkpoint observation schema')
        model_reward_schema=getattr(model,'receiver_reward_schema',REWARD_SCHEMA)
        if model_reward_schema not in (REWARD_SCHEMA,CORRECTED_REWARD_SCHEMA):
            raise ValueError('unknown checkpoint reward schema')
        manifest['pairs'].append({'name':name,'reference':str(reference),'reference_sha256':digest(reference),
                                  'checkpoint':str(checkpoint),'checkpoint_sha256':digest(checkpoint),
                                  'observation_schema':model_schema,'reward_schema':model_reward_schema})
        manifest['observation_schemas']=sorted(set(manifest['observation_schemas']+[model_schema]))
        manifest['reward_schemas']=sorted(set(manifest['reward_schemas']+[model_reward_schema]))
        manifest['schema']=model_schema if len(manifest['observation_schemas'])==1 else 'mixed-see-pairs'
        (args.output/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
        # Nominal always runs first; held-outs never used to select this final checkpoint.
        offsets=(-.02,.02) if args.heldout_only else ((0.,-.02,.02) if args.heldout else (0.,))
        for offset in offsets:
            variation='nominal' if offset==0 else ('target-y-minus-02' if offset<0 else 'target-y-plus-02')
            spec=json.loads(json.dumps(original));target=spec['play']['quarterback_target_m'];target[1]+=offset
            # Catch window and every controller/camera setting stay exactly unchanged.
            profile=args.output/f'{name}-{variation}-reference.json';profile.write_text(json.dumps(spec,indent=2)+'\n')
            for policy_name in ('zero','learned'):
                if time.monotonic()-start>args.wall_seconds:raise TimeoutError('bounded evaluation wall exceeded')
                output=args.output/name/variation/policy_name
                env=AeroResidualEnv(profile,args.source,args.amp_source,evaluation_dir=output,
                                    normalized_observations=model_schema==NORMALIZED_SCHEMA,
                                    corrected_potential_reward=model_reward_schema==CORRECTED_REWARD_SCHEMA)
                row={'pair':name,'variation':variation,'policy':policy_name,'target_y_delta_m':offset,
                     'profile_sha256':digest(profile),'checkpoint_sha256':digest(checkpoint),'seed':args.seed,
                     'observation_schema':model_schema,'reward_schema':model_reward_schema}
                try:
                    obs,_=env.reset(seed=args.seed);total=0.;steps=0
                    while True:
                        action=np.zeros(16,dtype=np.float32) if policy_name=='zero' else model.predict(obs,deterministic=True)[0]
                        obs,reward,done,_,info=env.step(action);total+=reward;steps+=1
                        if done:break
                    directory=output/f'episode-{env.episode:04d}'
                    row.update(status='completed',sensor_return=total,policy_steps=steps,sensor_info=info,
                               evidence=str(directory),physical=physical(directory))
                except BaseException as error:
                    row.update(status='failed',error=repr(error));raise
                finally:
                    env.close();results.append(row)
                    (args.output/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
                    with (args.output/'progress.jsonl').open('a') as f:f.write(json.dumps(row)+'\n');f.flush()
                    print(json.dumps(row),flush=True)
    manifest['elapsed_s']=time.monotonic()-start;manifest['completed_trials']=len(results)
    (args.output/'receipt.json').write_text(json.dumps(manifest,indent=2)+'\n')

if __name__=='__main__':main()
