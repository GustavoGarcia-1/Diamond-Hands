"""Reproduce the selected Aero running lead-pass contact and optics comparison."""

import argparse
from pathlib import Path
from evaluate_aero_receiver import Play, fixed_camera, make_route, run_play
from g1_receiver.hand_route_plant import HandRoutePlant
from g1_receiver.pass_control import PassGrip
from g1_receiver.running_policy import AmpRunningPolicy

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--amp-source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--optics", action="store_true")
    parser.add_argument("--record", action="store_true")
    parser.add_argument("--spectator-clear", action="store_true",
                        help="hide the noncolliding stage backdrop in recorded spectator images")
    parser.add_argument("--clear-optics", action="store_true",
                        help="remove the visual backdrop from sensor and spectator views")
    parser.add_argument("--earlier-grip", action="store_true", help="test earlier closure and asymmetric wrist targets")
    args = parser.parse_args()
    plane, lead = (.72, .24) if args.earlier_grip else (.60, .16)
    lateral = .23 if args.earlier_grip else (.20 if args.optics else .13)
    grip = PassGrip(plane_m=plane, lead_s=lead, height_m=.34, lateral_limit_m=lateral,
                    predict_beyond_last_frame=args.optics)
    play = Play(speed=2., scale=3.4, finish_s=5.2, release_s=3.60, flight_s=.34,
                launch_xyz=(7.586, 3.00, .658), launch_velocity=(1.6, 0., 2.735),
                runup="imu", pregrip=0., closure=.84, acceleration=1.8, upper_fraction=1.,
                yaw_gain=1.8, lateral_gain=0., allow_downfield_lob=True, arm_lead=True,
                receive_yaw_bias=-.10 if args.earlier_grip else 0.,
                receive_wrist_pitch_left=-.10 if args.earlier_grip else 0.,
                receive_wrist_roll=-.08 if args.earlier_grip else 0., grip=grip)
    route = make_route(play.route, scale=play.scale, speed_mps=play.speed)
    poses = {}

    def cameras(scene):
        poses["track"] = fixed_camera(scene, "track", (4.3, 1.5, 1.43), (7.2, 3.1, .81))
        poses["finish"] = fixed_camera(scene, "finish", (6.2, 1.8, 1.44), (9.3, 3.3, .81))
        pass_position, pass_target = ((10.5, 3.65, 1.30), (7.85, 3.0, .91)) if args.optics else (
            (9.2, 5.0, 1.7), (7.8, 3.0, .95))
        poses["pass"] = fixed_camera(scene, "pass", pass_position, pass_target)

    plant = HandRoutePlant(args.source, hand_model="aero", rear_markers=True, scene_setup=cameras)
    plant.cameras.update(poses)
    try:
        if args.spectator_clear or args.clear_optics:
            backdrop = plant.model.geom("backdrop").id
            if plant.model.geom_contype[backdrop] or plant.model.geom_conaffinity[backdrop]:
                raise ValueError("the backdrop must not collide")
        if args.clear_optics:
            plant.model.geom_rgba[backdrop, 3] = 0.
            plant.model.geom_group[backdrop] = 5
        elif args.spectator_clear:
            plant.model.geom_group[backdrop] = 5
            sensor_capture = plant.capture

            def capture(camera="survey_rgbd"):
                original_group = plant.model.geom_group[backdrop]
                try:
                    plant.model.geom_group[backdrop] = 0
                    return sensor_capture(camera)
                finally:
                    plant.model.geom_group[backdrop] = original_group

            plant.capture = capture
        policy = AmpRunningPolicy(plant.joint_names, plant.joint_ranges, args.amp_source)
        result = run_play(plant, policy, play, route, output=args.output, record=args.record)
        print(len(result["observed_ball"]), result["visual_closure_s"], result["strict_score"]["first_tip_contact_s"],
              result["running_score"], flush=True)
    finally:
        plant.close()


if __name__ == "__main__":
    main()
