"""Check the pinned receiver runtime with actual CUDA and EGL RGB-D."""
from importlib.metadata import version
import json
import os
import sys

os.environ["MUJOCO_GL"] = "egl"
os.environ["PYOPENGL_PLATFORM"] = "egl"
sys.path.insert(0, sys.argv[1])

import gymnasium
import mujoco
import numpy as np
from stable_baselines3 import PPO
import torch

from g1_receiver._vendor.g1_runtime.pool.wbc import WholeBodyController
from g1_receiver.localization import MarkerLocalizer
from g1_receiver.locomotion import (
    SURVEY_CAMERA_FOV_Y_DEG,
    SURVEY_CAMERA_POSITION_M,
    make_dynamic_scene,
    survey_camera_rotation,
)
from g1_receiver.perception import CameraIntrinsics, ColorBallDetector, RGBDFrame, RigidPose
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT
from g1_receiver.sim import HEIGHT, WIDTH

assert torch.cuda.device_count() == 1
assert torch.ones(4, device="cuda").sum().item() == 4
assert gymnasium.__version__ == "1.4.0"
probe_env = gymnasium.make("Pendulum-v1")
try:
    ppo = PPO("MlpPolicy", probe_env, device="cuda", n_steps=8, batch_size=8)
    assert next(ppo.policy.parameters()).device.type == "cuda"
finally:
    probe_env.close()
model = mujoco.MjModel.from_xml_string(make_dynamic_scene(DEFAULT_RUNTIME_ROOT, survey_camera=True))
data = mujoco.MjData(model)
joints = model.actuator_trnid[:, 0]
names = [model.joint(int(joint)).name for joint in joints]
wbc = WholeBodyController(names, model.jnt_range[joints], asset_root=DEFAULT_RUNTIME_ROOT)
data.qpos[model.jnt_qposadr[joints]] = wbc.nominal
data.qpos[2] = .79
ball_q = model.joint("football_free").qposadr[0]
data.qpos[ball_q:ball_q + 3] = (1.45, 0., .4)
mujoco.mj_forward(model, data)
with mujoco.Renderer(model, HEIGHT, WIDTH) as renderer:
    renderer.update_scene(data, camera="survey_rgbd")
    rgb = renderer.render()
    renderer.enable_depth_rendering()
    depth = renderer.render()
focal = HEIGHT / (2 * np.tan(np.deg2rad(SURVEY_CAMERA_FOV_Y_DEG / 2)))
intrinsics = CameraIntrinsics(focal, focal, (WIDTH - 1) / 2, (HEIGHT - 1) / 2)
survey = RigidPose(0., "camera_optical", "field", survey_camera_rotation(),
                   np.asarray(SURVEY_CAMERA_POSITION_M), "synthetic_fixture")
frame = RGBDFrame(0., "camera_optical", rgb, depth, intrinsics)
assert MarkerLocalizer(allow_synthetic_fixture=True).estimate(frame, survey) is not None
assert ColorBallDetector(ball_center_offset_m=.075).detect(frame, survey) is not None
print(json.dumps({
    "torch": torch.__version__, "torch_cuda": torch.version.cuda,
    "gpu": torch.cuda.get_device_name(), "mujoco": mujoco.__version__,
    "stable_baselines3": version("stable-baselines3"), "gymnasium": gymnasium.__version__,
    "ppo_cuda_parameters": True, "egl_rgbd": True, "rgbd_ball_detection": True, "rgbd_pelvis_detection": True,
}))
