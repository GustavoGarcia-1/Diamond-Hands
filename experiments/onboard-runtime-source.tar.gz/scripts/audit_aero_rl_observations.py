"""Archive sensor-only PPO inputs on a matched zero-residual rollout."""
import argparse
import json
from pathlib import Path
import numpy as np
from g1_receiver.aero_residual_rl import AeroResidualEnv, SCHEMA

p = argparse.ArgumentParser()
p.add_argument('--reference', type=Path, required=True)
p.add_argument('--source', type=Path, required=True)
p.add_argument('--amp-source', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
a.output.mkdir(parents=True, exist_ok=False)
env = AeroResidualEnv(a.reference, a.source, a.amp_source, evaluation_dir=a.output/'physical')
rows = []
try:
    obs, info = env.reset(seed=173)
    rows.append({'time_s': info['time_s'], 'observation': obs.tolist(), 'reward': 0.})
    while True:
        obs, reward, done, _, info = env.step(np.zeros(16, dtype=np.float32))
        rows.append({'time_s': info.get('time_s'), 'observation': obs.tolist(), 'reward': reward})
        if done:
            break
    (a.output/'sensor-steps.json').write_text(json.dumps({'schema': SCHEMA, 'steps': rows, 'final': info}, indent=2)+'\n')
    valid = [r for r in rows if r['observation'][74] and r['time_s'] is not None]
    near = [r for r in valid if np.linalg.norm(r['observation'][64:67]) < .25]
    summary = {'schema': SCHEMA, 'steps': len(rows), 'valid_steps': len(valid),
               'near_cup_steps': [{'time_s': r['time_s'], 'error_m': r['observation'][64:67],
                                  'relative_velocity_mps': r['observation'][67:70],
                                  'sigma_m': r['observation'][70:73], 'velocity_valid': r['observation'][75],
                                  'dwell_s': r['observation'][76], 'reward': r['reward']} for r in near],
               'final': info}
    (a.output/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary), flush=True)
finally:
    env.close()
