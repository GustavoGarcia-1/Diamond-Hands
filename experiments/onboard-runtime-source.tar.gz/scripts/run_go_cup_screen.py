"""Three no-pass Go cup transfer trials; no catch claim or automatic promotion."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--source',required=True)
p.add_argument('--amp-source',required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args()
a.output.mkdir(parents=True,exist_ok=False)
profile='reports/out-scrimmage/left-turn-20261113/overhead-pass-linux/artifacts/out/profile-07.json'
protocol={'stage':'No-ball straight Go path before any throw tuning',
          'eligibility':'Complete14s, upright>=.90, reach9.144m, maxstemerror<=.75m; '
                        'catch near9.144m +/- .30m; running at receive measured separately',
          'speeds_mps':[.65,1.,1.3], 'handoff_depth_m':2.1,
          'controller':'Camera/IMU transition to WBC, then staged overhead cup; not learned catching'}
(a.output/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
def run(pair):
    index,speed=pair
    command=[sys.executable,'scripts/probe_go_cup.py','--source',a.source,'--amp-source',a.amp_source,
             '--profile',profile,'--output',str(a.output/f'case-{index:02d}'),
             '--walk-speed',str(speed),'--no-pass','--duration','14']
    with (a.output/f'case-{index:02d}.log').open('w') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=300)
    report=a.output/f'case-{index:02d}/report.json'
    return {'case':index,'speed':speed,'exit_code':result.returncode,'command':command,
            'report':json.loads(report.read_text()) if report.exists() else None}
with ThreadPoolExecutor(max_workers=3) as pool:
    results=list(pool.map(run,enumerate(protocol['speeds_mps'])))
(a.output/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
if any(r['exit_code'] for r in results):raise SystemExit(1)
