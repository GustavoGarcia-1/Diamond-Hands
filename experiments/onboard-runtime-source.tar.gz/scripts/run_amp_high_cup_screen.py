"""Five predeclared no-ball controller-adaptation checks, no catch selection."""
import argparse,json,subprocess,sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',required=True);p.add_argument('--amp-source',required=True);p.add_argument('--output',type=Path,required=True)
a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
cases=[(False,0.),(True,0.),(True,.5),(True,.75),(True,1.)]
(a.output/'protocol.json').write_text(json.dumps({'cases_raised_cup_centering':cases,
 'eligibility':'Complete7s, upright>=.90, recurrent qualified airborne phases aftercupstage, actualforwardtravel; no-pass only',
 'fixed':'initialphysicalstanceyaw-.7, identicalAMPweights/gains/heading/speed2mps; no physics/state overridesafterreset',
 'transform':'Measuredarmq/dq minus fraction of commanded offset/rate relativeto originalreadyarms; no simulatortruth',
 'not_learned':'No weights trained or changed; neither actor nor reward usescontact'},indent=2)+'\n')
def run(pair):
 i,(raised,fraction)=pair;out=a.output/f'case-{i:02d}'
 cmd=[sys.executable,'scripts/probe_amp_high_cup.py','--source',a.source,'--amp-source',a.amp_source,
      '--profile','reports/out-scrimmage/left-turn-20261113/overhead-pass-linux/artifacts/out/profile-07.json',
      '--output',str(out),'--centering',str(fraction)]
 if raised:cmd+=['--raise-cup']
 with (a.output/f'case-{i:02d}.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 path=out/'report.json'
 return {'case':i,'exit_code':r.returncode,'command':cmd,'report':json.loads(path.read_text()) if path.exists() else None}
with ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(run,enumerate(cases)))
(a.output/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
if any(r['exit_code'] for r in results):raise SystemExit(1)
