"""Verify the opt-in articulated G1 hands on a free-base MuJoCo model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import mujoco
import numpy as np

from g1_receiver._vendor.g1_runtime.pool.wbc import WholeBodyController
from g1_receiver.dextra import (
    DEFAULT_MOUNTS,
    DextraActuation,
    EFFORT_LIMIT_NM,
    FLEXION_TARGET_RAD,
    SIDES,
    UPSTREAM_MESH_SET_SHA256,
    UPSTREAM_REVISION,
    UPSTREAM_URDF_SHA256,
    attach_dextra_hands,
    dextra_ready_joint_targets,
)
from g1_receiver.locomotion import CONTROL_DT, SUBSTEPS, cradle_joint_targets
from g1_receiver.runtime import DEFAULT_RUNTIME_ROOT, RobotObservation, SkillGoal
from g1_receiver.training import _plant_xml


def _sensor_addresses(model: mujoco.MjModel, prefix: str, count: int) -> np.ndarray:
    return np.array([model.sensor(f"{prefix}_{index}").adr[0] for index in range(count)])


def run_probe(xml: str, baseline_xml: str, asset_root: Path) -> dict:
    baseline = mujoco.MjModel.from_xml_string(baseline_xml)
    model = mujoco.MjModel.from_xml_string(xml)
    data = mujoco.MjData(model)
    actuation = DextraActuation.from_model(model)
    body = actuation.body_actuators
    joints = model.actuator_trnid[body, 0]
    names = [model.joint(int(joint)).name for joint in joints]
    assert names == [baseline.actuator(index).name for index in range(baseline.nu)]
    body_qpos = model.jnt_qposadr[joints]
    wbc = WholeBodyController(names, model.jnt_range[joints], asset_root=asset_root)
    ready = dextra_ready_joint_targets(wbc.nominal, names)
    data.qpos[model.joint("floating_base_joint").qposadr[0] + 2] = 0.79
    hand_names = [model.geom(index).name for index in range(model.ngeom)]
    hand_side = np.array([
        0 if name.startswith("dextra_left_") else 1 if name.startswith("dextra_right_") else -1
        for name in hand_names
    ])
    hand_geom = hand_side >= 0
    ball = model.geom("football_surface").id
    ball_qpos = int(model.joint("football_free").qposadr[0])
    palm = [model.body(f"dextra_{side}_palm").id for side in SIDES]
    flexion_angles = np.linspace(0.0, FLEXION_TARGET_RAD, 13)

    def hand_contacts() -> int:
        return int(sum(
            hand_geom[contact.geom1] or hand_geom[contact.geom2]
            for contact in data.contact
        ))

    unwanted_contacts = {}
    for label, posture in (("nominal", wbc.nominal), ("dextra_ready", ready)):
        data.qpos[body_qpos] = posture
        counts = []
        for angle in flexion_angles:
            data.qpos[actuation.hand_joint_qpos] = angle * actuation.flexion
            mujoco.mj_forward(model, data)
            counts.append(hand_contacts())
        unwanted_contacts[label] = counts
    data.qpos[body_qpos] = cradle_joint_targets(wbc.nominal, names)
    data.qpos[actuation.hand_joint_qpos] = 0.0
    mujoco.mj_forward(model, data)
    legacy_cradle_hand_contacts = hand_contacts()

    # A collision-only check with the free ball placed between the ready palms.
    # No ball pose is used to determine motor commands.
    data.qpos[body_qpos] = ready
    data.qpos[ball_qpos:ball_qpos + 3] = (0.51, 0.0, 1.11)
    ball_contacts = {}
    for label, angle in (("open", 0.0), ("closing", 0.20)):
        data.qpos[actuation.hand_joint_qpos] = angle * actuation.flexion
        mujoco.mj_forward(model, data)
        links = {
            model.body(int(model.geom_bodyid[geom])).name
            for contact in data.contact if ball in contact.geom
            for geom in contact.geom if hand_geom[geom]
        }
        ball_contacts[label] = sorted(links)
    placement_mirror_error = float(np.linalg.norm(data.xpos[palm[0]] - data.xpos[palm[1]] * [1, -1, 1]))
    assert not ball_contacts["open"] and all(
        any(name.startswith(f"dextra_{side}_") for name in ball_contacts["closing"]) for side in SIDES
    )

    # Advance the floating robot with the unchanged 29-joint WBC and the new
    # 40 hand drives. The distant football cannot support the robot or hands.
    mujoco.mj_resetData(model, data)
    data.qpos[2] = 0.79
    data.qpos[body_qpos] = ready
    data.qpos[ball_qpos:ball_qpos + 3] = (8.0, 4.0, 0.085)
    mujoco.mj_forward(model, data)
    q_addr = _sensor_addresses(model, "pilot_encoder_q", 29)
    dq_addr = _sensor_addresses(model, "pilot_encoder_dq", 29)
    effort_addr = _sensor_addresses(model, "pilot_effort", 29)
    hand_q_addr = _sensor_addresses(model, "dextra_encoder_q", 40)
    orientation_addr = int(model.sensor("receiver_orientation").adr[0])
    gyro_addr = int(model.sensor("receiver_gyro").adr[0])
    base = model.body("pelvis").id
    control_limits = model.actuator_ctrlrange[body]
    hold_target = np.where(actuation.flexion, FLEXION_TARGET_RAD, 0.05)
    min_upright = 1.0
    min_pelvis_height = float(data.xpos[base, 2])
    peak_hand_effort = 0.0
    dynamic_hand_contacts = 0
    for tick in range(round(1.0 / CONTROL_DT)):
        sensors = data.sensordata
        observation = RobotObservation(
            float(data.time), sensors[q_addr], sensors[dq_addr],
            sensors[orientation_addr:orientation_addr + 4], sensors[gyro_addr:gyro_addr + 3],
            sensors[effort_addr], None,
        )
        command = wbc.act(observation, SkillGoal(), upper_target=ready)
        for _ in range(SUBSTEPS):
            torque = command.kp * (command.target_position - sensors[q_addr]) - command.kd * sensors[dq_addr]
            data.ctrl[body] = np.clip(torque, control_limits[:, 0], control_limits[:, 1])
            if tick >= 10:
                actuation.set_targets(data, hold_target, dt_s=float(model.opt.timestep))
            mujoco.mj_step(model, data)
            peak_hand_effort = max(peak_hand_effort, float(np.max(np.abs(data.actuator_force[actuation.hand_actuators]))))
            dynamic_hand_contacts += hand_contacts()
            min_upright = min(min_upright, float(data.xmat[base, 8]))
            min_pelvis_height = min(min_pelvis_height, float(data.xpos[base, 2]))
    mujoco.mj_forward(model, data)
    finger_q = data.sensordata[hand_q_addr]
    encoder_error = float(np.max(np.abs(finger_q - data.qpos[actuation.hand_joint_qpos])))
    if (
        any(any(counts) for counts in unwanted_contacts.values())
        or dynamic_hand_contacts or placement_mirror_error > 2e-4
        or min_upright < 0.90 or min_pelvis_height < 0.62
        or peak_hand_effort > EFFORT_LIMIT_NM + 1e-8
        or np.min(finger_q[actuation.flexion]) < 0.50
        or np.min(finger_q[~actuation.flexion]) < 0.03
        or encoder_error > 1e-8 or any(warning.number for warning in data.warning)
    ):
        raise RuntimeError("free-base Dextra smoke checks failed")
    return {
        "evidence": "free-base G1 articulated Dextra model load, collision and actuator smoke",
        "mujoco_version": mujoco.__version__,
        "upstream_revision": UPSTREAM_REVISION,
        "upstream_urdf_sha256": UPSTREAM_URDF_SHA256,
        "upstream_mesh_set_sha256": UPSTREAM_MESH_SET_SHA256,
        "body_actuator_count": len(body),
        "hand_actuator_count": len(actuation.hand_actuators),
        "hand_collision_geoms_by_side": [int(np.sum((hand_side == i) & (model.geom_contype != 0))) for i in range(2)],
        "hand_sensors": 120,
        "hand_mass_kg_by_side": model.body_subtreemass[palm].tolist(),
        "hand_plus_adapter_mass_kg_by_side": [
            float(model.body_subtreemass[model.body(f"dextra_{side}_adapter").id]) for side in SIDES
        ],
        "bare_wrist_mass_kg_by_side": [float(model.body_mass[model.body(f"{side}_wrist_yaw_link").id]) for side in SIDES],
        "robot_mass_delta_from_baseline_kg": float(model.body_subtreemass[base] - baseline.body_subtreemass[baseline.body("pelvis").id]),
        "provisional_mounts": [
            {"side": side, "xyz_m": mount.position_m, "quat_wxyz": mount.quaternion_wxyz}
            for side, mount in zip(SIDES, DEFAULT_MOUNTS, strict=True)
        ],
        "kinematic_flexion_sweep_rad": flexion_angles.tolist(),
        "hand_contacts_in_kinematic_sweep": unwanted_contacts,
        "legacy_bare_cradle_hand_contacts_open": legacy_cradle_hand_contacts,
        "hand_ball_contacts_at_test_placement": ball_contacts,
        "dynamic_duration_s": float(data.time),
        "dynamic_hand_collision_samples": dynamic_hand_contacts,
        "minimum_pelvis_height_m": min_pelvis_height,
        "minimum_upright_cosine": min_upright,
        "peak_hand_actuator_effort_nm": peak_hand_effort,
        "minimum_final_flexion_rad": float(np.min(finger_q[actuation.flexion])),
        "minimum_final_abduction_rad": float(np.min(finger_q[~actuation.flexion])),
        "max_hand_encoder_error_rad": encoder_error,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("codesign_source", type=Path)
    parser.add_argument("--asset-root", type=Path, default=DEFAULT_RUNTIME_ROOT)
    parser.add_argument("--xml", type=Path, help="optional output MJCF with absolute mesh paths")
    args = parser.parse_args()
    baseline_xml = _plant_xml(args.asset_root)
    xml = attach_dextra_hands(baseline_xml, args.codesign_source)
    result = run_probe(xml, baseline_xml, args.asset_root)
    if args.xml is not None:
        args.xml.write_text(xml)
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
