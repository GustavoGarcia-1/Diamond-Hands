"""Build deterministic, isolated three-route simulation evidence and submission ZIP."""
from __future__ import annotations
import argparse,hashlib,json,shutil,subprocess,tarfile
from pathlib import Path,PurePosixPath
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
import imageio_ffmpeg

ROOT=Path(__file__).resolve().parents[1]
OUT=Path('artifacts/him-open-build-three-held-20261113')
BASE=Path('artifacts/him-open-build-held-out-20261113/project.zip')
GO=Path('reports/aero-rl-20261113')
SLANT=Path('reports/aero-amp-slant/retained-20261113')
OUT_EVIDENCE=Path('reports/out-scrimmage/left-turn-20261113')
CONTROLS=Path('reports/held-grip-counterfactuals-20261113')
VIDEO_ROOT=Path('reports/receiver-slot-20261113')
ROUTES={
 'go':dict(controller='controllers/go',entry='probe_go_cup.py',profile=f'{GO}/go-cup-pass-linux/artifacts/go/profile-07.json',expected=f'{GO}/go-cup-confirm-linux/artifacts/confirm/extended',video='go-held',duration_s=12.88),
 'out':dict(controller='.',entry='probe_aero_out.py',profile=f'{OUT_EVIDENCE}/overhead-pass-linux/artifacts/out/profile-07.json',expected=f'{OUT_EVIDENCE}/overhead-pass-linux/artifacts/out/case-07',video='out-tight',duration_s=8.),
 'slant':dict(controller='controllers/slant',entry='probe_aero_amp_slant.py',profile=f'{SLANT}/overhead-pass-profile-07.json',expected=f'{SLANT}/antioch-confirm/artifacts/slant/case-03',video='slant-held-95',duration_s=9.5),
}
CAPTION='''Simulated Unitree G1 with Aero hands catches three physical passes from a stationary midfield machine, starting two yards beside it. All three receives use grounded walking. Continuous clean two-hand holds: Go 3.820 s, Out 2.926 s, Slant 2.795 s. Go receives at 9.146 m depth with 0.176 m maximum lateral drift. Out turns left 81.53° and moves forward. Slant changes inward 42.49° early versus 14.65° zero steering, then curves roughly 59–61° from its original stem. No floor/body ball support or applied ball load occurs in the selected plays. No ordered stop, newly learned catch advantage, or hardware qualification is established. Pretrained locomotion and calibrated RGB-D grip. Complete plays shown; cuts occur only between plays.\n'''
README='''# G1 receiver — three held simulation catches

The primary full-play.mp4 concatenates the complete Go→Out→Slant plays, with cuts
only between plays. It lasts 30.48 s (762 untouched decoded frames at 25 fps).
Individual full MP4s are also provided. caption.txt states the measured claims.
These are forward-moving walking receives, not qualified running-gait catches.
The receivers do not complete an ordered stop. New residual-policy training has
not demonstrated a catch improvement and is not used in these selected plays.

## Reproduce the physics

Use Python 3.12 and uv at this project root:

    uv sync --locked --python 3.12 --extra training --extra test --extra video

The official Aero assets are included under aero-source. Fetch the pinned external
AMP checkout/checkpoint/YAML as documented in docs/running-policy.md. On headless
Linux set MUJOCO_GL=egl and PYOPENGL_PLATFORM=egl. Run fresh output directories:

    sh run-go.sh /absolute/path/to/pinned-amp reports/reproduced-go
    sh run-out.sh /absolute/path/to/pinned-amp reports/reproduced-out
    sh run-slant.sh /absolute/path/to/pinned-amp reports/reproduced-slant

Each wrapper accepts an optional third argument for another profile. Go and Slant
use their own isolated frozen src/scripts under controllers/go and controllers/slant.
Out uses the original verified root controller. All three use the root .venv and
included Aero assets and pretrained locomotion assets. No environment, credentials,
new residual-training checkpoints, or Kimodo model is bundled. Frozen source manifests and archive provenance are included.
Cross-platform trajectories can differ; the selected evidence is Linux simulation.

    .venv/bin/python scripts/verify_held_routes_package.py --zip project.zip \\
      --amp-source /absolute/path/to/pinned-amp --output FRESH_VERIFICATION_OUTPUT

The verifier extracts a fresh ZIP, checks every member hash, proves module-source
isolation, runs up to three route subprocesses, and requires exact trace/pose arrays
and exact reports. It temporarily links only the validated dependency environment;
no environment is embedded in the ZIP. Any allowed report-path normalization must
be explicitly logged; the default commands use canonical paths and require none.

## Evidence and limitations

ROUTES.json identifies each selected profile and reference evidence directory.
Original and confirmation traces, profiles, independent audits, and the earlier
running-Go fallback are retained. The fallback has a different formation, large
lateral drift, and a later drop/fall; it is not a selected video.

Selected Go: ten-yard depth 9.146 m, maximum lateral drift 0.176 m; holds 3.820 s through
12.88 s. Selected Out: actual left body turn 81.53°, no postbreak backpedaling; holds
2.926 s through 8 s; its stem still drifts 0.611 m and overshoots 0.453 m. Selected Slant:
two sustained footfall onsets before the cut, early inward change 42.49° versus 14.65° zero steering, with
later curvature roughly 59–61°; holds 2.795 s through 9.5 s. No recurrent airborne phases
qualify at any of these receives. All continue moving rather than stopping.

The no-grasp controls preserve fixed throws, route/camera/stance/open-cup motion
and duration, while disabling finger closure and triggered jaw/hold offsets:

    sh run-go.sh AMP FRESH_GO_CONTROL profiles/controls/go-neutral.json
    sh run-out.sh AMP FRESH_OUT_CONTROL profiles/controls/out-neutral.json
    sh run-slant.sh AMP FRESH_SLANT_CONTROL profiles/controls/slant-neutral.json

All three controls have zero bilateral control and no held ball at their ends.
They test the calibrated grasp's causal contribution, not a learned improvement
and not the HIM builder's hardware safety/counterfactual checks.

Read the current root SENSOR_CONTRACT.md and docs/hardware-qualification.md.
No connected hardware, Linux ARM64 controller image, builder safety/counterfactual
checks, or physical Aero/RGB-D integration has been verified. The public kit fetch
returned 403 and Docker was unavailable; reports/him-builder-20261113 records this.
The ZIP+primary MP4 must stay below 100 MB combined and the MP4 below 50 MB, per the
HIM guide: https://arena.himrobotics.com/docs/g1-policy-checks .
'''

def sha(data:bytes)->str:return hashlib.sha256(data).hexdigest()
def safe(name:str)->str:
 name=name.removeprefix('./');p=PurePosixPath(name)
 if not name or p.is_absolute() or '..' in p.parts or '\\' in name:raise ValueError(f'unsafe archive path {name!r}')
 return p.as_posix()
def read_json(path:Path):return json.loads(path.read_text())
def add_tree(files:dict[str,bytes],relative:Path,prefix:str|None=None):
 source=ROOT/relative
 if not source.exists():raise FileNotFoundError(source)
 for path in sorted(source.rglob('*')):
  if path.is_symlink():raise ValueError(f'symlink excluded: {path}')
  if path.is_file() and '__pycache__' not in path.parts:
   if path.suffix in ('.pyc','.pyo','.pt','.pth','.ckpt','.safetensors'):continue
   name=(relative/path.relative_to(source)).as_posix() if prefix is None else f'{prefix}/{path.relative_to(source).as_posix()}'
   files[safe(name)]=path.read_bytes()
def frozen(files,prefix,archive_path,receipt_path,key):
 receipt=read_json(ROOT/receipt_path);archive_bytes=(ROOT/archive_path).read_bytes();assert sha(archive_bytes)==receipt['archive_sha256'];expected=receipt[key];seen={}
 with tarfile.open(ROOT/archive_path) as archive:
  for member in archive:
   if member.isdir():continue
   if not member.isfile():raise ValueError(f'nonregular frozen-source member: {member.name}')
   name=safe(member.name)
   if any(x in name for x in ('__pycache__','.venv/','node_modules/')) or name.endswith(('.pyc','.pyo','.pt','.pth','.ckpt','.safetensors')):raise ValueError(f'forbidden frozen payload {name}')
   data=archive.extractfile(member).read();digest=sha(data)
   if name in expected:assert digest==expected[name],name
   else:assert name=='FROZEN_SOURCE_SHA256.json',name
   files[f'{prefix}/{name}']=data;seen[name]=digest
 assert set(expected)<=set(seen)
 files[f'{prefix}/SOURCE-ARCHIVE.json']=json.dumps({'archive':archive_path.as_posix(),'archive_sha256':receipt['archive_sha256'],'source_receipt':receipt_path.as_posix(),'files_sha256':seen},sort_keys=True,indent=2).encode()+b'\n'
 return {'archive_sha256':receipt['archive_sha256'],'files':len(seen),'controller_root':prefix}

WRAPPER='''#!/bin/sh
set -eu
held_caller=$PWD
held_amp=${1:?provide pinned AMP checkout}
held_output=${2:?provide fresh output directory}
case "$held_amp" in /*) ;; *) held_amp="$held_caller/$held_amp";; esac
case "$held_output" in /*) ;; *) held_output="$held_caller/$held_output";; esac
if [ "$#" -ge 3 ]; then
 held_profile=$3
 case "$held_profile" in /*) ;; *) held_profile="$held_caller/$held_profile";; esac
else
 held_profile='@PROFILE@'
fi
held_root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$held_root"
held_controller="$held_root/@CONTROLLER@"
export PYTHONPATH="$held_controller/src:$held_controller/scripts"
export PYTHONNOUSERSITE=1
exec "$held_root/.venv/bin/python" "$held_controller/scripts/@ENTRY@" @ARGS@
'''
ARGS={
 'go':'''--source "$held_root/aero-source" --amp-source "$held_amp" --profile "$held_profile" --output "$held_output" --initial-yaw -.7 --handoff-depth 1.3 --walk-speed 1. --duration 12.880000000000518''',
 'out':'''--source "$held_root/aero-source" --amp-source "$held_amp" --output "$held_output" --duration 8 --approach-handoff-depth-m 2.1 --cut-speed 1.4 --blend-s .5 --turn-s .4 --hold-straight-s 0 --depth-feedback-gain 4 --camera-start-s .8 --stopping-lookahead-s .55 --reverse-speed 0 --approach-speed .48 --horizontal-pass-distance --pass-profile "$held_profile" --record-poses''',
 'slant':'''--source "$held_root/aero-source" --amp-source "$held_amp" --output "$held_output" --two-step --turn-ramp .2 --cut-walk-s 1.35 --cut-walk-vx .65 --cut-arm-override-fraction 0 --cut-arm-recovery-s .45 --disable-braking --horizon 9.5 --endpoint 14.1 3.8 --record-poses --heading -.85 --cut-walk-vy -1.5 --post-cut-heading -.3 --pass-profile "$held_profile" --launch-shift 0 0 0''',
}
def wrapper(route):
 d=ROUTES[route];return WRAPPER.replace('@PROFILE@',d['profile']).replace('@CONTROLLER@',d['controller']).replace('@ENTRY@',d['entry']).replace('@ARGS@',ARGS[route]).encode()
def framehash(path,ffmpeg):
 command=[ffmpeg,'-v','error','-i',str(path),'-map','0:v:0','-an','-pix_fmt','rgb24','-fps_mode','passthrough','-f','framehash','-hash','sha256','-'];r=subprocess.run(command,capture_output=True,text=True,check=True,timeout=120);rows=[];timebase=None
 for line in r.stdout.splitlines():
  if line.startswith('#tb 0:'):timebase=line.split(':',1)[1].strip()
  if line and not line.startswith('#'):
   fields=[x.strip() for x in line.split(',')];rows.append(dict(dts=int(fields[1]),pts=int(fields[2]),duration=int(fields[3]),size=int(fields[4]),sha256=fields[5]))
 assert timebase=='1/25' and all(x['pts']==i and x['duration']==1 for i,x in enumerate(rows)),(path,timebase)
 return rows

def video_bundle(output):
 ffmpeg=imageio_ffmpeg.get_ffmpeg_exe();order=('go','out','slant');segments=[];frames=[];start=0.
 for route in order:
  source=ROOT/VIDEO_ROOT/ROUTES[route]['video']/'full-play.mp4';destination=output/f'{route}-held.mp4';shutil.copyfile(source,destination);reader=imageio_ffmpeg.read_frames(str(destination));meta=next(reader);reader.close();assert tuple(meta['size'])==(1280,720) and meta['fps']==25.;rows=framehash(destination,ffmpeg);duration=len(rows)/25.;assert abs(duration-meta['duration'])<1e-6
  segments.append(dict(route=route,source=str(source.relative_to(ROOT)),file=destination.name,sha256=sha(destination.read_bytes()),frame_count=len(rows),start_s=start,end_s=start+duration,duration_s=duration,first_pts_s=0.,last_pts_s=(len(rows)-1)/25.));frames.extend(x['sha256']for x in rows);start+=duration
 playlist=output/'concat-inputs.txt';playlist.write_text(''.join("file '"+str((output/x['file']).resolve()).replace("'","'\\''")+"'\n"for x in segments));target=output/'full-play.mp4';command=[ffmpeg,'-y','-v','error','-nostdin','-f','concat','-safe','0','-i',str(playlist),'-map','0:v:0','-c','copy','-an','-fflags','+bitexact','-movflags','+faststart',str(target)];subprocess.run(command,check=True,timeout=120);actual=framehash(target,ffmpeg);assert [x['sha256']for x in actual]==frames,'concatenation changed or omitted decoded frames';assert len(frames)==762 and abs(start-30.48)<1e-8
 result=dict(order=list(order),method='H264 stream copy; full plays; cuts only at segment boundaries',width=1280,height=720,fps=25,frame_count=len(frames),duration_s=start,segments=segments,decoded_frame_order_and_pixels_identical=True,decoded_frame_hashes_sha256=sha(('\n'.join(frames)+'\n').encode()),full_video_sha256=sha(target.read_bytes()));(output/'concat-manifest.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');return result

def zip_bytes(path,files):
 with ZipFile(path,'w',ZIP_DEFLATED,compresslevel=6) as archive:
  for name,data in sorted(files.items()):
   info=ZipInfo(safe(name),(2026,11,13,0,0,0));info.compress_type=ZIP_DEFLATED;info.create_system=3;info.external_attr=(0o100755 if name.startswith('run-') and name.endswith('.sh') else 0o100644)<<16;archive.writestr(info,data,compress_type=ZIP_DEFLATED,compresslevel=6)

def build(output:Path):
 output=output.resolve();output.mkdir(parents=True,exist_ok=True);base_bytes=(ROOT/BASE).read_bytes();base_sha=sha(base_bytes);files={}
 with ZipFile(ROOT/BASE) as archive:
  previous=json.loads(archive.read('MANIFEST.json'));assert archive.testzip() is None
  for name,digest in previous.items():
   data=archive.read(name);assert sha(data)==digest;files[safe(name)]=data
 source_info={'out':dict(controller_root='.',frozen_source_sha256='78380ff434e07d20773ed5efb4b97984a96cf81312af0f71272100c52ee705f4',base_out_zip_sha256=base_sha)}
 source_info['go']=frozen(files,'controllers/go',GO/'frozen-go-cup-source.tar.gz',GO/'frozen-go-cup-source.manifest.json','files_sha256');source_info['slant']=frozen(files,'controllers/slant',SLANT/'selected-frozen-source.tar.gz',SLANT/'selected-frozen-source-receipt.json','source_files_sha256')
 for rel in (GO/'go-cup-pass-linux/artifacts/go/case-07',GO/'go-cup-confirm-linux/artifacts/confirm',Path('reports/independent-validation-go-cup-20261113'),SLANT/'antioch-confirm/artifacts/slant',SLANT/'antioch-overhead-pass/artifacts/slant/case-04',SLANT/'antioch-overhead-pass/artifacts/slant/case-07',Path('reports/aero-amp-slant/two-step-20261113/antioch-exit/artifacts/slant/case-03'),Path('reports/independent-validation-slant-overhead-20261113'),CONTROLS/'linux/artifacts/controls'):
  add_tree(files,rel)
 # Also make the existing workspace-relative Slant audit runnable from its frozen controller root.
 for rel in (SLANT/'antioch-confirm/artifacts/slant',SLANT/'antioch-overhead-pass/artifacts/slant/case-04',SLANT/'antioch-overhead-pass/artifacts/slant/case-07',Path('reports/aero-amp-slant/two-step-20261113/antioch-exit/artifacts/slant/case-03'),Path('reports/independent-validation-slant-overhead-20261113')):
  add_tree(files,rel,'controllers/slant/'+rel.as_posix())
 for route,d in ROUTES.items():
  rel=Path(d['profile']);files[rel.as_posix()]=(ROOT/rel).read_bytes();files[f'profiles/{route}-held.json']=files[rel.as_posix()];files[f'run-{route}.sh']=wrapper(route)
  control=CONTROLS/f'linux/artifacts/controls/{route}-neutral-profile.json';files[f'profiles/controls/{route}-neutral.json']=(ROOT/control).read_bytes()
 for rel in (SLANT/'overhead-pass-profile-04.json',SLANT/'overhead-arms-02.json',SLANT/'selected-frozen-source-receipt.json',SLANT/'REPRODUCE_SELECTED.sh',SLANT/'SELECTED.json',GO/'frozen-go-cup-source.manifest.json',GO/'go-cup-confirm-receipt.json',CONTROLS/'receipt.json',Path('SENSOR_CONTRACT.md'),Path('docs/SENSOR_CONTRACT.md'),Path('docs/hardware-qualification.md'),Path('reports/him-builder-20261113/runtime-preflight.json'),Path('scripts/package_held_routes.py'),Path('scripts/verify_held_routes_package.py'),Path('scripts/run_held_grip_counterfactuals.py')):
  files[rel.as_posix()]=(ROOT/rel).read_bytes()
 videos=video_bundle(output)
 for route,d in ROUTES.items():
  files[f'videos/{route}-held.mp4']=(output/f'{route}-held.mp4').read_bytes()
  for filename in ('video-verification.json','contact-sheet.jpg'):
   rel=VIDEO_ROOT/d['video']/filename;files[rel.as_posix()]=(ROOT/rel).read_bytes()
 files['videos/full-play.mp4']=(output/'full-play.mp4').read_bytes();files['concat-manifest.json']=(output/'concat-manifest.json').read_bytes();files['README.md']=README.encode();files['caption.txt']=CAPTION.encode();files['ROUTES.json']=json.dumps(ROUTES,sort_keys=True,indent=2).encode()+b'\n';files['CONTROLLERS.json']=json.dumps(source_info,sort_keys=True,indent=2).encode()+b'\n';manifest={name:sha(data)for name,data in sorted(files.items())};files['MANIFEST.json']=json.dumps(manifest,sort_keys=True,indent=2).encode()+b'\n';temporary=output/'.project-building.zip';zip_bytes(temporary,files);target=output/'project.zip';temporary.replace(target)
 with ZipFile(target) as archive:
  assert len(archive.namelist())==len(set(archive.namelist()))==len(files);assert archive.testzip() is None
  assert all(sha(archive.read(name))==digest for name,digest in manifest.items())
 check=output/'.determinism-check.zip';zip_bytes(check,files);assert sha(check.read_bytes())==sha(target.read_bytes());check.unlink();assert sha((ROOT/BASE).read_bytes())==base_sha,'original Out submission changed';video_size=(output/'full-play.mp4').stat().st_size;combined=target.stat().st_size+video_size;assert video_size<=50_000_000 and combined<=100_000_000,(target.stat().st_size,video_size)
 (output/'caption.txt').write_text(CAPTION);receipt=dict(project_sha256=sha(target.read_bytes()),project_bytes=target.stat().st_size,video_sha256=videos['full_video_sha256'],video_bytes=video_size,combined_bytes=combined,combined_limit_bytes=100_000_000,video_limit_bytes=50_000_000,crc_and_all_member_hashes_verified=True,zip_rebuild_byte_identical=True,member_count=len(files),controller_sources=source_info,source_out_submission_unchanged=True,video_frame_count=videos['frame_count'],video_duration_s=videos['duration_s'],video_stream_copy_and_decoded_frames_verified=True,hardware_qualified=False,arena_submitted=False,zip_runtime_reproduction_pending=True);(output/'package-receipt.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n');print(json.dumps(receipt,indent=2));return receipt
if __name__=='__main__':
 cli=argparse.ArgumentParser(description=__doc__);cli.add_argument('--output',type=Path,default=ROOT/OUT);args=cli.parse_args();build(args.output)
