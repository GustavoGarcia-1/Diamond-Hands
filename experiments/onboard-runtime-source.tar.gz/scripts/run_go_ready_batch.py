"""Bounded nine-case full-ready early-camera screen; one isolated process per rollout."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--source',required=True);p.add_argument('--amp-source',required=True);a=p.parse_args()
 a.output.mkdir(parents=True,exist_ok=False)
 cases=[(v,g,f) for v in (2.,2.4,2.5) for g in (.3,.7,1.2) for f in (1.,)]
 def run(item):
  i,(v,g,f)=item;out=a.output/f'case-{i:02d}'
  cmd=[sys.executable,'scripts/probe_go_stem.py','--output',str(out),'--source',a.source,'--amp-source',a.amp_source,'--speed',str(v),'--stem-gain',str(g),'--upper-fraction',str(f),'--no-pass','--early-survey']
  with (a.output/f'case-{i:02d}.log').open('w') as log:
   result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=240)
  score=json.loads((out/'stem-score.json').read_text()) if result.returncode==0 else None
  return dict(case=i,command=cmd,exit_code=result.returncode,score=score)
 with ThreadPoolExecutor(max_workers=3) as pool: results=list(pool.map(run,enumerate(cases)))
 (a.output/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
 if any(r['exit_code'] for r in results):raise SystemExit(1)
if __name__=='__main__':main()
