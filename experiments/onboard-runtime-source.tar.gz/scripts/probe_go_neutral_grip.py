"""Matched counterfactual: archived Go with camera-induced grasp/hold actions disabled."""
import argparse
from dataclasses import fields
import json
from pathlib import Path
import numpy as np
import evaluate_aero_receiver as runner
from g1_receiver.pass_control import PassGrip
from g1_receiver.routes import Route
from g1_receiver.running_policy import AmpRunningPolicy

def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--reference',type=Path,default=Path('reports/quarterback-pass/offset-fixed-controlled/report.json'))
    cli.add_argument('--output',type=Path,default=Path('reports/quarterback-pass/neutral-grip-20261113'))
    cli.add_argument('--source',type=Path,default=Path('/tmp/g1-aero-source'))
    cli.add_argument('--amp-source',type=Path,default=Path('/tmp/g1-pretrained-run-legged'))
    args=cli.parse_args()
    if args.output.exists():raise FileExistsError(args.output)
    ref=json.loads(args.reference.read_text())
    settings={k:v for k,v in ref['play'].items() if k in {f.name for f in fields(runner.Play)}}
    changes=dict(closure=0.,pregrip=0.,squeeze=0.,grasp_offsets_rad=None,hold_offsets_rad=None,hold_curls=None)
    settings.update(changes)
    settings['grip']=PassGrip(**settings['grip'])
    play=runner.Play(**settings)
    route=Route(play.route,tuple(map(tuple,ref['waypoints_m'])),play.speed)
    cameras={}
    for name,arg in [('pass','pass_camera'),('track','tracking_camera'),('finish','finish_camera')]:
        sensor=ref['camera_surveys'][name];position=np.asarray(sensor['position_m'])
        cameras[arg]=(position,position+np.asarray(sensor['rotation'])[:,2])
    plant=runner.make_plant(args.source,route,**cameras)
    try:
        policy=AmpRunningPolicy(plant.joint_names,plant.joint_ranges,args.amp_source)
        report=runner.run_play(plant,policy,play,route,output=args.output,record=False)
    finally:plant.close()
    summary={'intervention':changes,'reference':str(args.reference),'reference_receive':ref['quarterback_pass_score'],
             'neutral_receive':report['quarterback_pass_score'],'neutral_running':report['running_score'],
             'visual_reach_s':report['visual_reach_s'],'visual_closure_s':report['visual_closure_s']}
    a=np.load(args.reference.parent/'trace.npz');b=np.load(args.output/'trace.npz')
    gate=ref['visual_closure_s'];n=min(len(a['motion']),len(b['motion']))
    before=(a['motion'][:n,0]<gate-1e-8)
    summary['motion_before_baseline_closure_exact']=bool(np.array_equal(a['motion'][:n][before],b['motion'][:n][before]))
    summary['max_motion_before_baseline_closure_abs_diff']=float(np.max(np.abs(a['motion'][:n][before]-b['motion'][:n][before])))
    summary['release_exact']=json.loads(json.dumps(report['release']))==ref['release']
    (args.output/'comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2),flush=True)
if __name__=='__main__':main()
