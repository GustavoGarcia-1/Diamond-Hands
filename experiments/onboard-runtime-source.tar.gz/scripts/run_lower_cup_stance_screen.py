"""Predeclared matched reset-stance screen; no active robot repositioning."""
import argparse,json,subprocess,sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for name in ('source','amp-source','profile'):p.add_argument('--'+name,required=True)
 p.add_argument('--output',type=Path,required=True)
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
 cases=[-.7,-.5,-.3,0.]
 (a.output/'protocol.json').write_text(json.dumps(dict(initial_stance_yaws_rad=cases,
     fixed='Lower wide palms-up ready profile; centering1.0; same frozen AMP/gains/physics; seven seconds',
     selection='Complete7s, upright>=.9, max surveyed stemerror<=.5m, >=2 recurrent qualified flights afterstaging; no-ball only'),indent=2)+'\n')
 def run(item):
  i,yaw=item;d=a.output/f'case-{i:02d}'
  cmd=[sys.executable,'scripts/probe_amp_lower_run.py','--source',a.source,'--amp-source',a.amp_source,'--profile',a.profile,'--output',str(d),'--centering','1','--raise-cup','--initial-yaw',str(yaw)]
  with (a.output/f'case-{i:02d}.log').open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=120)
  return dict(case=i,initial_yaw=yaw,command=cmd,exit_code=r.returncode,report=json.loads((d/'report.json').read_text())if(d/'report.json').exists()else None)
 with ThreadPoolExecutor(max_workers=2)as pool:rows=list(pool.map(run,enumerate(cases)))
 (a.output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
 if any(r['exit_code']for r in rows):raise SystemExit(1)

if __name__=='__main__':main()
