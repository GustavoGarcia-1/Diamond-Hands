"""Evaluation-only interhand geometry capture. Never imported by a policy."""
import numpy as np
import mujoco

class NativeInterhandGeometryAudit:
    def __init__(self,model):
        self.model=model;sides={}
        for side in ('left','right'):
            bodies=[i for i in range(model.nbody)if (model.body(i).name or'').startswith('aero_'+side+'_')]
            sides[side]=np.array([i for i in range(model.ngeom)if model.geom_bodyid[i]in bodies and(model.geom_contype[i]or model.geom_conaffinity[i])])
        left,right=np.meshgrid(sides['left'],sides['right'],indexing='ij');self.left=left.ravel();self.right=right.ravel();self.radii=model.geom_rbound[self.left]+model.geom_rbound[self.right];self.rows=[]
    def record(self,data):
        lower=np.linalg.norm(data.geom_xpos[self.left]-data.geom_xpos[self.right],axis=1)-self.radii
        closest=(.02,-1,-1)
        for i in np.flatnonzero(lower<.02):
            a,b=int(self.left[i]),int(self.right[i]);distance=float(mujoco.mj_geomDistance(self.model,data,a,b,.03,None))
            if distance<closest[0]:closest=(distance,a,b)
        self.rows.append((float(data.time),*closest))
    def arrays(self):
        return {'interhand_geometry':np.asarray(self.rows,dtype=float),'interhand_geometry_columns':np.asarray(['timestamp_s','minimum_distance_m','left_geom_id','right_geom_id'])}
    def summary(self):
        rows=np.asarray(self.rows);i=int(np.argmin(rows[:,1]));row=rows[i];return dict(evaluation_only=True,sampling_hz=1./self.model.opt.timestep,minimum_interhand_geometry_m=float(row[1]),minimum_time_s=float(row[0]),left_geom=None if row[2]<0 else self.model.geom(int(row[2])).name,right_geom=None if row[3]<0 else self.model.geom(int(row[3])).name,exceeds_predeclared_5mm_penetration=bool(row[1]<-.005),negative_samples=int((rows[:,1]<0).sum()),geometry_probe_is_read_only=True)
